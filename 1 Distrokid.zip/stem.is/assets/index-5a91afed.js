(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
    new MutationObserver(i => {
        for (const o of i)
            if (o.type === "childList")
                for (const s of o.addedNodes) s.tagName === "LINK" && s.rel === "modulepreload" && r(s)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function n(i) {
        const o = {};
        return i.integrity && (o.integrity = i.integrity), i.referrerPolicy && (o.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? o.credentials = "include" : i.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin", o
    }

    function r(i) {
        if (i.ep) return;
        i.ep = !0;
        const o = n(i);
        fetch(i.href, o)
    }
})();

function N1(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var A1 = {
        exports: {}
    },
    Cu = {},
    R1 = {
        exports: {}
    },
    he = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var pl = Symbol.for("react.element"),
    gw = Symbol.for("react.portal"),
    yw = Symbol.for("react.fragment"),
    _w = Symbol.for("react.strict_mode"),
    Sw = Symbol.for("react.profiler"),
    ww = Symbol.for("react.provider"),
    xw = Symbol.for("react.context"),
    Ew = Symbol.for("react.forward_ref"),
    Cw = Symbol.for("react.suspense"),
    Tw = Symbol.for("react.memo"),
    Pw = Symbol.for("react.lazy"),
    A0 = Symbol.iterator;

function kw(e) {
    return e === null || typeof e != "object" ? null : (e = A0 && e[A0] || e["@@iterator"], typeof e == "function" ? e : null)
}
var D1 = {
        isMounted: function() {
            return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
    },
    z1 = Object.assign,
    I1 = {};

function Vo(e, t, n) {
    this.props = e, this.context = t, this.refs = I1, this.updater = n || D1
}
Vo.prototype.isReactComponent = {};
Vo.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState")
};
Vo.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
};

function F1() {}
F1.prototype = Vo.prototype;

function Mp(e, t, n) {
    this.props = e, this.context = t, this.refs = I1, this.updater = n || D1
}
var Op = Mp.prototype = new F1;
Op.constructor = Mp;
z1(Op, Vo.prototype);
Op.isPureReactComponent = !0;
var R0 = Array.isArray,
    B1 = Object.prototype.hasOwnProperty,
    Lp = {
        current: null
    },
    j1 = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function V1(e, t, n) {
    var r, i = {},
        o = null,
        s = null;
    if (t != null)
        for (r in t.ref !== void 0 && (s = t.ref), t.key !== void 0 && (o = "" + t.key), t) B1.call(t, r) && !j1.hasOwnProperty(r) && (i[r] = t[r]);
    var l = arguments.length - 2;
    if (l === 1) i.children = n;
    else if (1 < l) {
        for (var a = Array(l), u = 0; u < l; u++) a[u] = arguments[u + 2];
        i.children = a
    }
    if (e && e.defaultProps)
        for (r in l = e.defaultProps, l) i[r] === void 0 && (i[r] = l[r]);
    return {
        $$typeof: pl,
        type: e,
        key: o,
        ref: s,
        props: i,
        _owner: Lp.current
    }
}

function bw(e, t) {
    return {
        $$typeof: pl,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}

function Np(e) {
    return typeof e == "object" && e !== null && e.$$typeof === pl
}

function Mw(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var D0 = /\/+/g;

function gf(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? Mw("" + e.key) : t.toString(36)
}

function xa(e, t, n, r, i) {
    var o = typeof e;
    (o === "undefined" || o === "boolean") && (e = null);
    var s = !1;
    if (e === null) s = !0;
    else switch (o) {
        case "string":
        case "number":
            s = !0;
            break;
        case "object":
            switch (e.$$typeof) {
                case pl:
                case gw:
                    s = !0
            }
    }
    if (s) return s = e, i = i(s), e = r === "" ? "." + gf(s, 0) : r, R0(i) ? (n = "", e != null && (n = e.replace(D0, "$&/") + "/"), xa(i, t, n, "", function(u) {
        return u
    })) : i != null && (Np(i) && (i = bw(i, n + (!i.key || s && s.key === i.key ? "" : ("" + i.key).replace(D0, "$&/") + "/") + e)), t.push(i)), 1;
    if (s = 0, r = r === "" ? "." : r + ":", R0(e))
        for (var l = 0; l < e.length; l++) {
            o = e[l];
            var a = r + gf(o, l);
            s += xa(o, t, n, a, i)
        } else if (a = kw(e), typeof a == "function")
            for (e = a.call(e), l = 0; !(o = e.next()).done;) o = o.value, a = r + gf(o, l++), s += xa(o, t, n, a, i);
        else if (o === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return s
}

function ta(e, t, n) {
    if (e == null) return e;
    var r = [],
        i = 0;
    return xa(e, r, "", "", function(o) {
        return t.call(n, o, i++)
    }), r
}

function Ow(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(), t.then(function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
        }, function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
        }), e._status === -1 && (e._status = 0, e._result = t)
    }
    if (e._status === 1) return e._result.default;
    throw e._result
}
var At = {
        current: null
    },
    Ea = {
        transition: null
    },
    Lw = {
        ReactCurrentDispatcher: At,
        ReactCurrentBatchConfig: Ea,
        ReactCurrentOwner: Lp
    };
he.Children = {
    map: ta,
    forEach: function(e, t, n) {
        ta(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return ta(e, function() {
            t++
        }), t
    },
    toArray: function(e) {
        return ta(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!Np(e)) throw Error("React.Children.only expected to receive a single React element child.");
        return e
    }
};
he.Component = Vo;
he.Fragment = yw;
he.Profiler = Sw;
he.PureComponent = Mp;
he.StrictMode = _w;
he.Suspense = Cw;
he.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Lw;
he.cloneElement = function(e, t, n) {
    if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = z1({}, e.props),
        i = e.key,
        o = e.ref,
        s = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (o = t.ref, s = Lp.current), t.key !== void 0 && (i = "" + t.key), e.type && e.type.defaultProps) var l = e.type.defaultProps;
        for (a in t) B1.call(t, a) && !j1.hasOwnProperty(a) && (r[a] = t[a] === void 0 && l !== void 0 ? l[a] : t[a])
    }
    var a = arguments.length - 2;
    if (a === 1) r.children = n;
    else if (1 < a) {
        l = Array(a);
        for (var u = 0; u < a; u++) l[u] = arguments[u + 2];
        r.children = l
    }
    return {
        $$typeof: pl,
        type: e.type,
        key: i,
        ref: o,
        props: r,
        _owner: s
    }
};
he.createContext = function(e) {
    return e = {
        $$typeof: xw,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
    }, e.Provider = {
        $$typeof: ww,
        _context: e
    }, e.Consumer = e
};
he.createElement = V1;
he.createFactory = function(e) {
    var t = V1.bind(null, e);
    return t.type = e, t
};
he.createRef = function() {
    return {
        current: null
    }
};
he.forwardRef = function(e) {
    return {
        $$typeof: Ew,
        render: e
    }
};
he.isValidElement = Np;
he.lazy = function(e) {
    return {
        $$typeof: Pw,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: Ow
    }
};
he.memo = function(e, t) {
    return {
        $$typeof: Tw,
        type: e,
        compare: t === void 0 ? null : t
    }
};
he.startTransition = function(e) {
    var t = Ea.transition;
    Ea.transition = {};
    try {
        e()
    } finally {
        Ea.transition = t
    }
};
he.unstable_act = function() {
    throw Error("act(...) is not supported in production builds of React.")
};
he.useCallback = function(e, t) {
    return At.current.useCallback(e, t)
};
he.useContext = function(e) {
    return At.current.useContext(e)
};
he.useDebugValue = function() {};
he.useDeferredValue = function(e) {
    return At.current.useDeferredValue(e)
};
he.useEffect = function(e, t) {
    return At.current.useEffect(e, t)
};
he.useId = function() {
    return At.current.useId()
};
he.useImperativeHandle = function(e, t, n) {
    return At.current.useImperativeHandle(e, t, n)
};
he.useInsertionEffect = function(e, t) {
    return At.current.useInsertionEffect(e, t)
};
he.useLayoutEffect = function(e, t) {
    return At.current.useLayoutEffect(e, t)
};
he.useMemo = function(e, t) {
    return At.current.useMemo(e, t)
};
he.useReducer = function(e, t, n) {
    return At.current.useReducer(e, t, n)
};
he.useRef = function(e) {
    return At.current.useRef(e)
};
he.useState = function(e) {
    return At.current.useState(e)
};
he.useSyncExternalStore = function(e, t, n) {
    return At.current.useSyncExternalStore(e, t, n)
};
he.useTransition = function() {
    return At.current.useTransition()
};
he.version = "18.2.0";
R1.exports = he;
var R = R1.exports;
const Ge = N1(R);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Nw = R,
    Aw = Symbol.for("react.element"),
    Rw = Symbol.for("react.fragment"),
    Dw = Object.prototype.hasOwnProperty,
    zw = Nw.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    Iw = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function U1(e, t, n) {
    var r, i = {},
        o = null,
        s = null;
    n !== void 0 && (o = "" + n), t.key !== void 0 && (o = "" + t.key), t.ref !== void 0 && (s = t.ref);
    for (r in t) Dw.call(t, r) && !Iw.hasOwnProperty(r) && (i[r] = t[r]);
    if (e && e.defaultProps)
        for (r in t = e.defaultProps, t) i[r] === void 0 && (i[r] = t[r]);
    return {
        $$typeof: Aw,
        type: e,
        key: o,
        ref: s,
        props: i,
        _owner: zw.current
    }
}
Cu.Fragment = Rw;
Cu.jsx = U1;
Cu.jsxs = U1;
A1.exports = Cu;
var Ap = A1.exports;
const Kn = Ap.Fragment,
    O = Ap.jsx,
    oe = Ap.jsxs;
var fd = {},
    $1 = {
        exports: {}
    },
    sn = {},
    H1 = {
        exports: {}
    },
    W1 = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    function t(D, V) {
        var U = D.length;
        D.push(V);
        e: for (; 0 < U;) {
            var q = U - 1 >>> 1,
                ne = D[q];
            if (0 < i(ne, V)) D[q] = V, D[U] = ne, U = q;
            else break e
        }
    }

    function n(D) {
        return D.length === 0 ? null : D[0]
    }

    function r(D) {
        if (D.length === 0) return null;
        var V = D[0],
            U = D.pop();
        if (U !== V) {
            D[0] = U;
            e: for (var q = 0, ne = D.length, xe = ne >>> 1; q < xe;) {
                var fe = 2 * (q + 1) - 1,
                    te = D[fe],
                    Te = fe + 1,
                    Ve = D[Te];
                if (0 > i(te, U)) Te < ne && 0 > i(Ve, te) ? (D[q] = Ve, D[Te] = U, q = Te) : (D[q] = te, D[fe] = U, q = fe);
                else if (Te < ne && 0 > i(Ve, U)) D[q] = Ve, D[Te] = U, q = Te;
                else break e
            }
        }
        return V
    }

    function i(D, V) {
        var U = D.sortIndex - V.sortIndex;
        return U !== 0 ? U : D.id - V.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var o = performance;
        e.unstable_now = function() {
            return o.now()
        }
    } else {
        var s = Date,
            l = s.now();
        e.unstable_now = function() {
            return s.now() - l
        }
    }
    var a = [],
        u = [],
        f = 1,
        d = null,
        h = 3,
        y = !1,
        _ = !1,
        v = !1,
        E = typeof setTimeout == "function" ? setTimeout : null,
        m = typeof clearTimeout == "function" ? clearTimeout : null,
        g = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

    function S(D) {
        for (var V = n(u); V !== null;) {
            if (V.callback === null) r(u);
            else if (V.startTime <= D) r(u), V.sortIndex = V.expirationTime, t(a, V);
            else break;
            V = n(u)
        }
    }

    function x(D) {
        if (v = !1, S(D), !_)
            if (n(a) !== null) _ = !0, le(P);
            else {
                var V = n(u);
                V !== null && ie(x, V.startTime - D)
            }
    }

    function P(D, V) {
        _ = !1, v && (v = !1, m(b), b = -1), y = !0;
        var U = h;
        try {
            for (S(V), d = n(a); d !== null && (!(d.expirationTime > V) || D && !A());) {
                var q = d.callback;
                if (typeof q == "function") {
                    d.callback = null, h = d.priorityLevel;
                    var ne = q(d.expirationTime <= V);
                    V = e.unstable_now(), typeof ne == "function" ? d.callback = ne : d === n(a) && r(a), S(V)
                } else r(a);
                d = n(a)
            }
            if (d !== null) var xe = !0;
            else {
                var fe = n(u);
                fe !== null && ie(x, fe.startTime - V), xe = !1
            }
            return xe
        } finally {
            d = null, h = U, y = !1
        }
    }
    var T = !1,
        L = null,
        b = -1,
        N = 5,
        H = -1;

    function A() {
        return !(e.unstable_now() - H < N)
    }

    function I() {
        if (L !== null) {
            var D = e.unstable_now();
            H = D;
            var V = !0;
            try {
                V = L(!0, D)
            } finally {
                V ? B() : (T = !1, L = null)
            }
        } else T = !1
    }
    var B;
    if (typeof g == "function") B = function() {
        g(I)
    };
    else if (typeof MessageChannel < "u") {
        var G = new MessageChannel,
            Q = G.port2;
        G.port1.onmessage = I, B = function() {
            Q.postMessage(null)
        }
    } else B = function() {
        E(I, 0)
    };

    function le(D) {
        L = D, T || (T = !0, B())
    }

    function ie(D, V) {
        b = E(function() {
            D(e.unstable_now())
        }, V)
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(D) {
        D.callback = null
    }, e.unstable_continueExecution = function() {
        _ || y || (_ = !0, le(P))
    }, e.unstable_forceFrameRate = function(D) {
        0 > D || 125 < D ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : N = 0 < D ? Math.floor(1e3 / D) : 5
    }, e.unstable_getCurrentPriorityLevel = function() {
        return h
    }, e.unstable_getFirstCallbackNode = function() {
        return n(a)
    }, e.unstable_next = function(D) {
        switch (h) {
            case 1:
            case 2:
            case 3:
                var V = 3;
                break;
            default:
                V = h
        }
        var U = h;
        h = V;
        try {
            return D()
        } finally {
            h = U
        }
    }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(D, V) {
        switch (D) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                D = 3
        }
        var U = h;
        h = D;
        try {
            return V()
        } finally {
            h = U
        }
    }, e.unstable_scheduleCallback = function(D, V, U) {
        var q = e.unstable_now();
        switch (typeof U == "object" && U !== null ? (U = U.delay, U = typeof U == "number" && 0 < U ? q + U : q) : U = q, D) {
            case 1:
                var ne = -1;
                break;
            case 2:
                ne = 250;
                break;
            case 5:
                ne = 1073741823;
                break;
            case 4:
                ne = 1e4;
                break;
            default:
                ne = 5e3
        }
        return ne = U + ne, D = {
            id: f++,
            callback: V,
            priorityLevel: D,
            startTime: U,
            expirationTime: ne,
            sortIndex: -1
        }, U > q ? (D.sortIndex = U, t(u, D), n(a) === null && D === n(u) && (v ? (m(b), b = -1) : v = !0, ie(x, U - q))) : (D.sortIndex = ne, t(a, D), _ || y || (_ = !0, le(P))), D
    }, e.unstable_shouldYield = A, e.unstable_wrapCallback = function(D) {
        var V = h;
        return function() {
            var U = h;
            h = V;
            try {
                return D.apply(this, arguments)
            } finally {
                h = U
            }
        }
    }
})(W1);
H1.exports = W1;
var Fw = H1.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var G1 = R,
    rn = Fw;

function W(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var Y1 = new Set,
    Us = {};

function zi(e, t) {
    To(e, t), To(e + "Capture", t)
}

function To(e, t) {
    for (Us[e] = t, e = 0; e < t.length; e++) Y1.add(t[e])
}
var vr = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
    dd = Object.prototype.hasOwnProperty,
    Bw = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    z0 = {},
    I0 = {};

function jw(e) {
    return dd.call(I0, e) ? !0 : dd.call(z0, e) ? !1 : Bw.test(e) ? I0[e] = !0 : (z0[e] = !0, !1)
}

function Vw(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
        case "function":
        case "symbol":
            return !0;
        case "boolean":
            return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
        default:
            return !1
    }
}

function Uw(e, t, n, r) {
    if (t === null || typeof t > "u" || Vw(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null) switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
    }
    return !1
}

function Rt(e, t, n, r, i, o, s) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = i, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = o, this.removeEmptyString = s
}
var gt = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    gt[e] = new Rt(e, 0, !1, e, null, !1, !1)
});
[
    ["acceptCharset", "accept-charset"],
    ["className", "class"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"]
].forEach(function(e) {
    var t = e[0];
    gt[t] = new Rt(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    gt[e] = new Rt(e, 2, !1, e.toLowerCase(), null, !1, !1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    gt[e] = new Rt(e, 2, !1, e, null, !1, !1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    gt[e] = new Rt(e, 3, !1, e.toLowerCase(), null, !1, !1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    gt[e] = new Rt(e, 3, !0, e, null, !1, !1)
});
["capture", "download"].forEach(function(e) {
    gt[e] = new Rt(e, 4, !1, e, null, !1, !1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    gt[e] = new Rt(e, 6, !1, e, null, !1, !1)
});
["rowSpan", "start"].forEach(function(e) {
    gt[e] = new Rt(e, 5, !1, e.toLowerCase(), null, !1, !1)
});
var Rp = /[\-:]([a-z])/g;

function Dp(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(Rp, Dp);
    gt[t] = new Rt(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(Rp, Dp);
    gt[t] = new Rt(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(Rp, Dp);
    gt[t] = new Rt(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    gt[e] = new Rt(e, 1, !1, e.toLowerCase(), null, !1, !1)
});
gt.xlinkHref = new Rt("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
    gt[e] = new Rt(e, 1, !1, e.toLowerCase(), null, !0, !0)
});

function zp(e, t, n, r) {
    var i = gt.hasOwnProperty(t) ? gt[t] : null;
    (i !== null ? i.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (Uw(t, n, i, r) && (n = null), r || i === null ? jw(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : i.mustUseProperty ? e[i.propertyName] = n === null ? i.type === 3 ? !1 : "" : n : (t = i.attributeName, r = i.attributeNamespace, n === null ? e.removeAttribute(t) : (i = i.type, n = i === 3 || i === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var xr = G1.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    na = Symbol.for("react.element"),
    eo = Symbol.for("react.portal"),
    to = Symbol.for("react.fragment"),
    Ip = Symbol.for("react.strict_mode"),
    pd = Symbol.for("react.profiler"),
    X1 = Symbol.for("react.provider"),
    q1 = Symbol.for("react.context"),
    Fp = Symbol.for("react.forward_ref"),
    hd = Symbol.for("react.suspense"),
    md = Symbol.for("react.suspense_list"),
    Bp = Symbol.for("react.memo"),
    Or = Symbol.for("react.lazy"),
    K1 = Symbol.for("react.offscreen"),
    F0 = Symbol.iterator;

function cs(e) {
    return e === null || typeof e != "object" ? null : (e = F0 && e[F0] || e["@@iterator"], typeof e == "function" ? e : null)
}
var je = Object.assign,
    yf;

function Es(e) {
    if (yf === void 0) try {
        throw Error()
    } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        yf = t && t[1] || ""
    }
    return `
` + yf + e
}
var _f = !1;

function Sf(e, t) {
    if (!e || _f) return "";
    _f = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                    throw Error()
                }, Object.defineProperty(t.prototype, "props", {
                    set: function() {
                        throw Error()
                    }
                }), typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (u) {
                    var r = u
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (u) {
                    r = u
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (u) {
                r = u
            }
            e()
        }
    } catch (u) {
        if (u && r && typeof u.stack == "string") {
            for (var i = u.stack.split(`
`), o = r.stack.split(`
`), s = i.length - 1, l = o.length - 1; 1 <= s && 0 <= l && i[s] !== o[l];) l--;
            for (; 1 <= s && 0 <= l; s--, l--)
                if (i[s] !== o[l]) {
                    if (s !== 1 || l !== 1)
                        do
                            if (s--, l--, 0 > l || i[s] !== o[l]) {
                                var a = `
` + i[s].replace(" at new ", " at ");
                                return e.displayName && a.includes("<anonymous>") && (a = a.replace("<anonymous>", e.displayName)), a
                            }
                    while (1 <= s && 0 <= l);
                    break
                }
        }
    } finally {
        _f = !1, Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? Es(e) : ""
}

function $w(e) {
    switch (e.tag) {
        case 5:
            return Es(e.type);
        case 16:
            return Es("Lazy");
        case 13:
            return Es("Suspense");
        case 19:
            return Es("SuspenseList");
        case 0:
        case 2:
        case 15:
            return e = Sf(e.type, !1), e;
        case 11:
            return e = Sf(e.type.render, !1), e;
        case 1:
            return e = Sf(e.type, !0), e;
        default:
            return ""
    }
}

function vd(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
        case to:
            return "Fragment";
        case eo:
            return "Portal";
        case pd:
            return "Profiler";
        case Ip:
            return "StrictMode";
        case hd:
            return "Suspense";
        case md:
            return "SuspenseList"
    }
    if (typeof e == "object") switch (e.$$typeof) {
        case q1:
            return (e.displayName || "Context") + ".Consumer";
        case X1:
            return (e._context.displayName || "Context") + ".Provider";
        case Fp:
            var t = e.render;
            return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case Bp:
            return t = e.displayName || null, t !== null ? t : vd(e.type) || "Memo";
        case Or:
            t = e._payload, e = e._init;
            try {
                return vd(e(t))
            } catch {}
    }
    return null
}

function Hw(e) {
    var t = e.type;
    switch (e.tag) {
        case 24:
            return "Cache";
        case 9:
            return (t.displayName || "Context") + ".Consumer";
        case 10:
            return (t._context.displayName || "Context") + ".Provider";
        case 18:
            return "DehydratedFragment";
        case 11:
            return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
        case 7:
            return "Fragment";
        case 5:
            return t;
        case 4:
            return "Portal";
        case 3:
            return "Root";
        case 6:
            return "Text";
        case 16:
            return vd(t);
        case 8:
            return t === Ip ? "StrictMode" : "Mode";
        case 22:
            return "Offscreen";
        case 12:
            return "Profiler";
        case 21:
            return "Scope";
        case 13:
            return "Suspense";
        case 19:
            return "SuspenseList";
        case 25:
            return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
            if (typeof t == "function") return t.displayName || t.name || null;
            if (typeof t == "string") return t
    }
    return null
}

function Zr(e) {
    switch (typeof e) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
            return e;
        case "object":
            return e;
        default:
            return ""
    }
}

function Q1(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}

function Ww(e) {
    var t = Q1(e) ? "checked" : "value",
        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
        r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var i = n.get,
            o = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return i.call(this)
            },
            set: function(s) {
                r = "" + s, o.call(this, s)
            }
        }), Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }), {
            getValue: function() {
                return r
            },
            setValue: function(s) {
                r = "" + s
            },
            stopTracking: function() {
                e._valueTracker = null, delete e[t]
            }
        }
    }
}

function ra(e) {
    e._valueTracker || (e._valueTracker = Ww(e))
}

function Z1(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
        r = "";
    return e && (r = Q1(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function Ua(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}

function gd(e, t) {
    var n = t.checked;
    return je({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n ? ? e._wrapperState.initialChecked
    })
}

function B0(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
        r = t.checked != null ? t.checked : t.defaultChecked;
    n = Zr(t.value != null ? t.value : n), e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}

function J1(e, t) {
    t = t.checked, t != null && zp(e, "checked", t, !1)
}

function yd(e, t) {
    J1(e, t);
    var n = Zr(t.value),
        r = t.type;
    if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? _d(e, t.type, n) : t.hasOwnProperty("defaultValue") && _d(e, t.type, Zr(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function j0(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function _d(e, t, n) {
    (t !== "number" || Ua(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var Cs = Array.isArray;

function mo(e, t, n, r) {
    if (e = e.options, t) {
        t = {};
        for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
        for (n = 0; n < e.length; n++) i = t.hasOwnProperty("$" + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + Zr(n), t = null, i = 0; i < e.length; i++) {
            if (e[i].value === n) {
                e[i].selected = !0, r && (e[i].defaultSelected = !0);
                return
            }
            t !== null || e[i].disabled || (t = e[i])
        }
        t !== null && (t.selected = !0)
    }
}

function Sd(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(W(91));
    return je({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}

function V0(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children, t = t.defaultValue, n != null) {
            if (t != null) throw Error(W(92));
            if (Cs(n)) {
                if (1 < n.length) throw Error(W(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""), n = t
    }
    e._wrapperState = {
        initialValue: Zr(n)
    }
}

function eg(e, t) {
    var n = Zr(t.value),
        r = Zr(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function U0(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}

function tg(e) {
    switch (e) {
        case "svg":
            return "http://www.w3.org/2000/svg";
        case "math":
            return "http://www.w3.org/1998/Math/MathML";
        default:
            return "http://www.w3.org/1999/xhtml"
    }
}

function wd(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? tg(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var ia, ng = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, i) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, i)
        })
    } : e
}(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
    else {
        for (ia = ia || document.createElement("div"), ia.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = ia.firstChild; e.firstChild;) e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild)
    }
});

function $s(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var Ms = {
        animationIterationCount: !0,
        aspectRatio: !0,
        borderImageOutset: !0,
        borderImageSlice: !0,
        borderImageWidth: !0,
        boxFlex: !0,
        boxFlexGroup: !0,
        boxOrdinalGroup: !0,
        columnCount: !0,
        columns: !0,
        flex: !0,
        flexGrow: !0,
        flexPositive: !0,
        flexShrink: !0,
        flexNegative: !0,
        flexOrder: !0,
        gridArea: !0,
        gridRow: !0,
        gridRowEnd: !0,
        gridRowSpan: !0,
        gridRowStart: !0,
        gridColumn: !0,
        gridColumnEnd: !0,
        gridColumnSpan: !0,
        gridColumnStart: !0,
        fontWeight: !0,
        lineClamp: !0,
        lineHeight: !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        tabSize: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
        fillOpacity: !0,
        floodOpacity: !0,
        stopOpacity: !0,
        strokeDasharray: !0,
        strokeDashoffset: !0,
        strokeMiterlimit: !0,
        strokeOpacity: !0,
        strokeWidth: !0
    },
    Gw = ["Webkit", "ms", "Moz", "O"];
Object.keys(Ms).forEach(function(e) {
    Gw.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1), Ms[t] = Ms[e]
    })
});

function rg(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Ms.hasOwnProperty(e) && Ms[e] ? ("" + t).trim() : t + "px"
}

function ig(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0,
                i = rg(n, t[n], r);
            n === "float" && (n = "cssFloat"), r ? e.setProperty(n, i) : e[n] = i
        }
}
var Yw = je({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});

function xd(e, t) {
    if (t) {
        if (Yw[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(W(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null) throw Error(W(60));
            if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(W(61))
        }
        if (t.style != null && typeof t.style != "object") throw Error(W(62))
    }
}

function Ed(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
            return !1;
        default:
            return !0
    }
}
var Cd = null;

function jp(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
}
var Td = null,
    vo = null,
    go = null;

function $0(e) {
    if (e = vl(e)) {
        if (typeof Td != "function") throw Error(W(280));
        var t = e.stateNode;
        t && (t = Mu(t), Td(e.stateNode, e.type, t))
    }
}

function og(e) {
    vo ? go ? go.push(e) : go = [e] : vo = e
}

function sg() {
    if (vo) {
        var e = vo,
            t = go;
        if (go = vo = null, $0(e), t)
            for (e = 0; e < t.length; e++) $0(t[e])
    }
}

function lg(e, t) {
    return e(t)
}

function ag() {}
var wf = !1;

function ug(e, t, n) {
    if (wf) return e(t, n);
    wf = !0;
    try {
        return lg(e, t, n)
    } finally {
        wf = !1, (vo !== null || go !== null) && (ag(), sg())
    }
}

function Hs(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = Mu(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
            (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
            break e;
        default:
            e = !1
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(W(231, t, typeof n));
    return n
}
var Pd = !1;
if (vr) try {
    var fs = {};
    Object.defineProperty(fs, "passive", {
        get: function() {
            Pd = !0
        }
    }), window.addEventListener("test", fs, fs), window.removeEventListener("test", fs, fs)
} catch {
    Pd = !1
}

function Xw(e, t, n, r, i, o, s, l, a) {
    var u = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, u)
    } catch (f) {
        this.onError(f)
    }
}
var Os = !1,
    $a = null,
    Ha = !1,
    kd = null,
    qw = {
        onError: function(e) {
            Os = !0, $a = e
        }
    };

function Kw(e, t, n, r, i, o, s, l, a) {
    Os = !1, $a = null, Xw.apply(qw, arguments)
}

function Qw(e, t, n, r, i, o, s, l, a) {
    if (Kw.apply(this, arguments), Os) {
        if (Os) {
            var u = $a;
            Os = !1, $a = null
        } else throw Error(W(198));
        Ha || (Ha = !0, kd = u)
    }
}

function Ii(e) {
    var t = e,
        n = e;
    if (e.alternate)
        for (; t.return;) t = t.return;
    else {
        e = t;
        do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
    }
    return t.tag === 3 ? n : null
}

function cg(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
    }
    return null
}

function H0(e) {
    if (Ii(e) !== e) throw Error(W(188))
}

function Zw(e) {
    var t = e.alternate;
    if (!t) {
        if (t = Ii(e), t === null) throw Error(W(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t;;) {
        var i = n.return;
        if (i === null) break;
        var o = i.alternate;
        if (o === null) {
            if (r = i.return, r !== null) {
                n = r;
                continue
            }
            break
        }
        if (i.child === o.child) {
            for (o = i.child; o;) {
                if (o === n) return H0(i), e;
                if (o === r) return H0(i), t;
                o = o.sibling
            }
            throw Error(W(188))
        }
        if (n.return !== r.return) n = i, r = o;
        else {
            for (var s = !1, l = i.child; l;) {
                if (l === n) {
                    s = !0, n = i, r = o;
                    break
                }
                if (l === r) {
                    s = !0, r = i, n = o;
                    break
                }
                l = l.sibling
            }
            if (!s) {
                for (l = o.child; l;) {
                    if (l === n) {
                        s = !0, n = o, r = i;
                        break
                    }
                    if (l === r) {
                        s = !0, r = o, n = i;
                        break
                    }
                    l = l.sibling
                }
                if (!s) throw Error(W(189))
            }
        }
        if (n.alternate !== r) throw Error(W(190))
    }
    if (n.tag !== 3) throw Error(W(188));
    return n.stateNode.current === n ? e : t
}

function fg(e) {
    return e = Zw(e), e !== null ? dg(e) : null
}

function dg(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
        var t = dg(e);
        if (t !== null) return t;
        e = e.sibling
    }
    return null
}
var pg = rn.unstable_scheduleCallback,
    W0 = rn.unstable_cancelCallback,
    Jw = rn.unstable_shouldYield,
    e2 = rn.unstable_requestPaint,
    Xe = rn.unstable_now,
    t2 = rn.unstable_getCurrentPriorityLevel,
    Vp = rn.unstable_ImmediatePriority,
    hg = rn.unstable_UserBlockingPriority,
    Wa = rn.unstable_NormalPriority,
    n2 = rn.unstable_LowPriority,
    mg = rn.unstable_IdlePriority,
    Tu = null,
    Yn = null;

function r2(e) {
    if (Yn && typeof Yn.onCommitFiberRoot == "function") try {
        Yn.onCommitFiberRoot(Tu, e, void 0, (e.current.flags & 128) === 128)
    } catch {}
}
var Ln = Math.clz32 ? Math.clz32 : s2,
    i2 = Math.log,
    o2 = Math.LN2;

function s2(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (i2(e) / o2 | 0) | 0
}
var oa = 64,
    sa = 4194304;

function Ts(e) {
    switch (e & -e) {
        case 1:
            return 1;
        case 2:
            return 2;
        case 4:
            return 4;
        case 8:
            return 8;
        case 16:
            return 16;
        case 32:
            return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return e & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return e & 130023424;
        case 134217728:
            return 134217728;
        case 268435456:
            return 268435456;
        case 536870912:
            return 536870912;
        case 1073741824:
            return 1073741824;
        default:
            return e
    }
}

function Ga(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
        i = e.suspendedLanes,
        o = e.pingedLanes,
        s = n & 268435455;
    if (s !== 0) {
        var l = s & ~i;
        l !== 0 ? r = Ts(l) : (o &= s, o !== 0 && (r = Ts(o)))
    } else s = n & ~i, s !== 0 ? r = Ts(s) : o !== 0 && (r = Ts(o));
    if (r === 0) return 0;
    if (t !== 0 && t !== r && !(t & i) && (i = r & -r, o = t & -t, i >= o || i === 16 && (o & 4194240) !== 0)) return t;
    if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
        for (e = e.entanglements, t &= r; 0 < t;) n = 31 - Ln(t), i = 1 << n, r |= e[n], t &= ~i;
    return r
}

function l2(e, t) {
    switch (e) {
        case 1:
        case 2:
        case 4:
            return t + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
            return -1;
        default:
            return -1
    }
}

function a2(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, o = e.pendingLanes; 0 < o;) {
        var s = 31 - Ln(o),
            l = 1 << s,
            a = i[s];
        a === -1 ? (!(l & n) || l & r) && (i[s] = l2(l, t)) : a <= t && (e.expiredLanes |= l), o &= ~l
    }
}

function bd(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}

function vg() {
    var e = oa;
    return oa <<= 1, !(oa & 4194240) && (oa = 64), e
}

function xf(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t
}

function hl(e, t, n) {
    e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Ln(t), e[t] = n
}

function u2(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
        var i = 31 - Ln(n),
            o = 1 << i;
        t[i] = 0, r[i] = -1, e[i] = -1, n &= ~o
    }
}

function Up(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n;) {
        var r = 31 - Ln(n),
            i = 1 << r;
        i & t | e[r] & t && (e[r] |= t), n &= ~i
    }
}
var Se = 0;

function gg(e) {
    return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
}
var yg, $p, _g, Sg, wg, Md = !1,
    la = [],
    Ur = null,
    $r = null,
    Hr = null,
    Ws = new Map,
    Gs = new Map,
    Nr = [],
    c2 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function G0(e, t) {
    switch (e) {
        case "focusin":
        case "focusout":
            Ur = null;
            break;
        case "dragenter":
        case "dragleave":
            $r = null;
            break;
        case "mouseover":
        case "mouseout":
            Hr = null;
            break;
        case "pointerover":
        case "pointerout":
            Ws.delete(t.pointerId);
            break;
        case "gotpointercapture":
        case "lostpointercapture":
            Gs.delete(t.pointerId)
    }
}

function ds(e, t, n, r, i, o) {
    return e === null || e.nativeEvent !== o ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: o,
        targetContainers: [i]
    }, t !== null && (t = vl(t), t !== null && $p(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e)
}

function f2(e, t, n, r, i) {
    switch (t) {
        case "focusin":
            return Ur = ds(Ur, e, t, n, r, i), !0;
        case "dragenter":
            return $r = ds($r, e, t, n, r, i), !0;
        case "mouseover":
            return Hr = ds(Hr, e, t, n, r, i), !0;
        case "pointerover":
            var o = i.pointerId;
            return Ws.set(o, ds(Ws.get(o) || null, e, t, n, r, i)), !0;
        case "gotpointercapture":
            return o = i.pointerId, Gs.set(o, ds(Gs.get(o) || null, e, t, n, r, i)), !0
    }
    return !1
}

function xg(e) {
    var t = Si(e.target);
    if (t !== null) {
        var n = Ii(t);
        if (n !== null) {
            if (t = n.tag, t === 13) {
                if (t = cg(n), t !== null) {
                    e.blockedOn = t, wg(e.priority, function() {
                        _g(n)
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}

function Ca(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
        var n = Od(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n === null) {
            n = e.nativeEvent;
            var r = new n.constructor(n.type, n);
            Cd = r, n.target.dispatchEvent(r), Cd = null
        } else return t = vl(n), t !== null && $p(t), e.blockedOn = n, !1;
        t.shift()
    }
    return !0
}

function Y0(e, t, n) {
    Ca(e) && n.delete(t)
}

function d2() {
    Md = !1, Ur !== null && Ca(Ur) && (Ur = null), $r !== null && Ca($r) && ($r = null), Hr !== null && Ca(Hr) && (Hr = null), Ws.forEach(Y0), Gs.forEach(Y0)
}

function ps(e, t) {
    e.blockedOn === t && (e.blockedOn = null, Md || (Md = !0, rn.unstable_scheduleCallback(rn.unstable_NormalPriority, d2)))
}

function Ys(e) {
    function t(i) {
        return ps(i, e)
    }
    if (0 < la.length) {
        ps(la[0], e);
        for (var n = 1; n < la.length; n++) {
            var r = la[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (Ur !== null && ps(Ur, e), $r !== null && ps($r, e), Hr !== null && ps(Hr, e), Ws.forEach(t), Gs.forEach(t), n = 0; n < Nr.length; n++) r = Nr[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < Nr.length && (n = Nr[0], n.blockedOn === null);) xg(n), n.blockedOn === null && Nr.shift()
}
var yo = xr.ReactCurrentBatchConfig,
    Ya = !0;

function p2(e, t, n, r) {
    var i = Se,
        o = yo.transition;
    yo.transition = null;
    try {
        Se = 1, Hp(e, t, n, r)
    } finally {
        Se = i, yo.transition = o
    }
}

function h2(e, t, n, r) {
    var i = Se,
        o = yo.transition;
    yo.transition = null;
    try {
        Se = 4, Hp(e, t, n, r)
    } finally {
        Se = i, yo.transition = o
    }
}

function Hp(e, t, n, r) {
    if (Ya) {
        var i = Od(e, t, n, r);
        if (i === null) Nf(e, t, r, Xa, n), G0(e, r);
        else if (f2(i, e, t, n, r)) r.stopPropagation();
        else if (G0(e, r), t & 4 && -1 < c2.indexOf(e)) {
            for (; i !== null;) {
                var o = vl(i);
                if (o !== null && yg(o), o = Od(e, t, n, r), o === null && Nf(e, t, r, Xa, n), o === i) break;
                i = o
            }
            i !== null && r.stopPropagation()
        } else Nf(e, t, r, null, n)
    }
}
var Xa = null;

function Od(e, t, n, r) {
    if (Xa = null, e = jp(r), e = Si(e), e !== null)
        if (t = Ii(e), t === null) e = null;
        else if (n = t.tag, n === 13) {
        if (e = cg(t), e !== null) return e;
        e = null
    } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null
    } else t !== e && (e = null);
    return Xa = e, null
}

function Eg(e) {
    switch (e) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
            return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
            return 4;
        case "message":
            switch (t2()) {
                case Vp:
                    return 1;
                case hg:
                    return 4;
                case Wa:
                case n2:
                    return 16;
                case mg:
                    return 536870912;
                default:
                    return 16
            }
        default:
            return 16
    }
}
var Rr = null,
    Wp = null,
    Ta = null;

function Cg() {
    if (Ta) return Ta;
    var e, t = Wp,
        n = t.length,
        r, i = "value" in Rr ? Rr.value : Rr.textContent,
        o = i.length;
    for (e = 0; e < n && t[e] === i[e]; e++);
    var s = n - e;
    for (r = 1; r <= s && t[n - r] === i[o - r]; r++);
    return Ta = i.slice(e, 1 < r ? 1 - r : void 0)
}

function Pa(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
}

function aa() {
    return !0
}

function X0() {
    return !1
}

function ln(e) {
    function t(n, r, i, o, s) {
        this._reactName = n, this._targetInst = i, this.type = r, this.nativeEvent = o, this.target = s, this.currentTarget = null;
        for (var l in e) e.hasOwnProperty(l) && (n = e[l], this[l] = n ? n(o) : o[l]);
        return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1) ? aa : X0, this.isPropagationStopped = X0, this
    }
    return je(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = aa)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = aa)
        },
        persist: function() {},
        isPersistent: aa
    }), t
}
var Uo = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
            return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
    },
    Gp = ln(Uo),
    ml = je({}, Uo, {
        view: 0,
        detail: 0
    }),
    m2 = ln(ml),
    Ef, Cf, hs, Pu = je({}, ml, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: Yp,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
            return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
            return "movementX" in e ? e.movementX : (e !== hs && (hs && e.type === "mousemove" ? (Ef = e.screenX - hs.screenX, Cf = e.screenY - hs.screenY) : Cf = Ef = 0, hs = e), Ef)
        },
        movementY: function(e) {
            return "movementY" in e ? e.movementY : Cf
        }
    }),
    q0 = ln(Pu),
    v2 = je({}, Pu, {
        dataTransfer: 0
    }),
    g2 = ln(v2),
    y2 = je({}, ml, {
        relatedTarget: 0
    }),
    Tf = ln(y2),
    _2 = je({}, Uo, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    S2 = ln(_2),
    w2 = je({}, Uo, {
        clipboardData: function(e) {
            return "clipboardData" in e ? e.clipboardData : window.clipboardData
        }
    }),
    x2 = ln(w2),
    E2 = je({}, Uo, {
        data: 0
    }),
    K0 = ln(E2),
    C2 = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
    },
    T2 = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
    },
    P2 = {
        Alt: "altKey",
        Control: "ctrlKey",
        Meta: "metaKey",
        Shift: "shiftKey"
    };

function k2(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = P2[e]) ? !!t[e] : !1
}

function Yp() {
    return k2
}
var b2 = je({}, ml, {
        key: function(e) {
            if (e.key) {
                var t = C2[e.key] || e.key;
                if (t !== "Unidentified") return t
            }
            return e.type === "keypress" ? (e = Pa(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? T2[e.keyCode] || "Unidentified" : ""
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: Yp,
        charCode: function(e) {
            return e.type === "keypress" ? Pa(e) : 0
        },
        keyCode: function(e) {
            return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        },
        which: function(e) {
            return e.type === "keypress" ? Pa(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        }
    }),
    M2 = ln(b2),
    O2 = je({}, Pu, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
    }),
    Q0 = ln(O2),
    L2 = je({}, ml, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: Yp
    }),
    N2 = ln(L2),
    A2 = je({}, Uo, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    R2 = ln(A2),
    D2 = je({}, Pu, {
        deltaX: function(e) {
            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
    }),
    z2 = ln(D2),
    I2 = [9, 13, 27, 32],
    Xp = vr && "CompositionEvent" in window,
    Ls = null;
vr && "documentMode" in document && (Ls = document.documentMode);
var F2 = vr && "TextEvent" in window && !Ls,
    Tg = vr && (!Xp || Ls && 8 < Ls && 11 >= Ls),
    Z0 = String.fromCharCode(32),
    J0 = !1;

function Pg(e, t) {
    switch (e) {
        case "keyup":
            return I2.indexOf(t.keyCode) !== -1;
        case "keydown":
            return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
            return !0;
        default:
            return !1
    }
}

function kg(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
}
var no = !1;

function B2(e, t) {
    switch (e) {
        case "compositionend":
            return kg(t);
        case "keypress":
            return t.which !== 32 ? null : (J0 = !0, Z0);
        case "textInput":
            return e = t.data, e === Z0 && J0 ? null : e;
        default:
            return null
    }
}

function j2(e, t) {
    if (no) return e === "compositionend" || !Xp && Pg(e, t) ? (e = Cg(), Ta = Wp = Rr = null, no = !1, e) : null;
    switch (e) {
        case "paste":
            return null;
        case "keypress":
            if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                if (t.char && 1 < t.char.length) return t.char;
                if (t.which) return String.fromCharCode(t.which)
            }
            return null;
        case "compositionend":
            return Tg && t.locale !== "ko" ? null : t.data;
        default:
            return null
    }
}
var V2 = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};

function ev(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!V2[e.type] : t === "textarea"
}

function bg(e, t, n, r) {
    og(r), t = qa(t, "onChange"), 0 < t.length && (n = new Gp("onChange", "change", null, n, r), e.push({
        event: n,
        listeners: t
    }))
}
var Ns = null,
    Xs = null;

function U2(e) {
    Bg(e, 0)
}

function ku(e) {
    var t = oo(e);
    if (Z1(t)) return e
}

function $2(e, t) {
    if (e === "change") return t
}
var Mg = !1;
if (vr) {
    var Pf;
    if (vr) {
        var kf = "oninput" in document;
        if (!kf) {
            var tv = document.createElement("div");
            tv.setAttribute("oninput", "return;"), kf = typeof tv.oninput == "function"
        }
        Pf = kf
    } else Pf = !1;
    Mg = Pf && (!document.documentMode || 9 < document.documentMode)
}

function nv() {
    Ns && (Ns.detachEvent("onpropertychange", Og), Xs = Ns = null)
}

function Og(e) {
    if (e.propertyName === "value" && ku(Xs)) {
        var t = [];
        bg(t, Xs, e, jp(e)), ug(U2, t)
    }
}

function H2(e, t, n) {
    e === "focusin" ? (nv(), Ns = t, Xs = n, Ns.attachEvent("onpropertychange", Og)) : e === "focusout" && nv()
}

function W2(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown") return ku(Xs)
}

function G2(e, t) {
    if (e === "click") return ku(t)
}

function Y2(e, t) {
    if (e === "input" || e === "change") return ku(t)
}

function X2(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var Rn = typeof Object.is == "function" ? Object.is : X2;

function qs(e, t) {
    if (Rn(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    var n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
        var i = n[r];
        if (!dd.call(t, i) || !Rn(e[i], t[i])) return !1
    }
    return !0
}

function rv(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e
}

function iv(e, t) {
    var n = rv(e);
    e = 0;
    for (var r; n;) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length, e <= t && r >= t) return {
                node: n,
                offset: t - e
            };
            e = r
        }
        e: {
            for (; n;) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = rv(n)
    }
}

function Lg(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Lg(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}

function Ng() {
    for (var e = window, t = Ua(); t instanceof e.HTMLIFrameElement;) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Ua(e.document)
    }
    return t
}

function qp(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}

function q2(e) {
    var t = Ng(),
        n = e.focusedElem,
        r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && Lg(n.ownerDocument.documentElement, n)) {
        if (r !== null && qp(n)) {
            if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
            else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
                e = e.getSelection();
                var i = n.textContent.length,
                    o = Math.min(r.start, i);
                r = r.end === void 0 ? o : Math.min(r.end, i), !e.extend && o > r && (i = r, r = o, o = i), i = iv(n, o);
                var s = iv(n, r);
                i && s && (e.rangeCount !== 1 || e.anchorNode !== i.node || e.anchorOffset !== i.offset || e.focusNode !== s.node || e.focusOffset !== s.offset) && (t = t.createRange(), t.setStart(i.node, i.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(s.node, s.offset)) : (t.setEnd(s.node, s.offset), e.addRange(t)))
            }
        }
        for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({
            element: e,
            left: e.scrollLeft,
            top: e.scrollTop
        });
        for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
    }
}
var K2 = vr && "documentMode" in document && 11 >= document.documentMode,
    ro = null,
    Ld = null,
    As = null,
    Nd = !1;

function ov(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Nd || ro == null || ro !== Ua(r) || (r = ro, "selectionStart" in r && qp(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }), As && qs(As, r) || (As = r, r = qa(Ld, "onSelect"), 0 < r.length && (t = new Gp("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: r
    }), t.target = ro)))
}

function ua(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
}
var io = {
        animationend: ua("Animation", "AnimationEnd"),
        animationiteration: ua("Animation", "AnimationIteration"),
        animationstart: ua("Animation", "AnimationStart"),
        transitionend: ua("Transition", "TransitionEnd")
    },
    bf = {},
    Ag = {};
vr && (Ag = document.createElement("div").style, "AnimationEvent" in window || (delete io.animationend.animation, delete io.animationiteration.animation, delete io.animationstart.animation), "TransitionEvent" in window || delete io.transitionend.transition);

function bu(e) {
    if (bf[e]) return bf[e];
    if (!io[e]) return e;
    var t = io[e],
        n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in Ag) return bf[e] = t[n];
    return e
}
var Rg = bu("animationend"),
    Dg = bu("animationiteration"),
    zg = bu("animationstart"),
    Ig = bu("transitionend"),
    Fg = new Map,
    sv = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

function ni(e, t) {
    Fg.set(e, t), zi(t, [e])
}
for (var Mf = 0; Mf < sv.length; Mf++) {
    var Of = sv[Mf],
        Q2 = Of.toLowerCase(),
        Z2 = Of[0].toUpperCase() + Of.slice(1);
    ni(Q2, "on" + Z2)
}
ni(Rg, "onAnimationEnd");
ni(Dg, "onAnimationIteration");
ni(zg, "onAnimationStart");
ni("dblclick", "onDoubleClick");
ni("focusin", "onFocus");
ni("focusout", "onBlur");
ni(Ig, "onTransitionEnd");
To("onMouseEnter", ["mouseout", "mouseover"]);
To("onMouseLeave", ["mouseout", "mouseover"]);
To("onPointerEnter", ["pointerout", "pointerover"]);
To("onPointerLeave", ["pointerout", "pointerover"]);
zi("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
zi("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
zi("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
zi("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
zi("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
zi("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Ps = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
    J2 = new Set("cancel close invalid load scroll toggle".split(" ").concat(Ps));

function lv(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, Qw(r, t, void 0, e), e.currentTarget = null
}

function Bg(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n],
            i = r.event;
        r = r.listeners;
        e: {
            var o = void 0;
            if (t)
                for (var s = r.length - 1; 0 <= s; s--) {
                    var l = r[s],
                        a = l.instance,
                        u = l.currentTarget;
                    if (l = l.listener, a !== o && i.isPropagationStopped()) break e;
                    lv(i, l, u), o = a
                } else
                    for (s = 0; s < r.length; s++) {
                        if (l = r[s], a = l.instance, u = l.currentTarget, l = l.listener, a !== o && i.isPropagationStopped()) break e;
                        lv(i, l, u), o = a
                    }
        }
    }
    if (Ha) throw e = kd, Ha = !1, kd = null, e
}

function be(e, t) {
    var n = t[Id];
    n === void 0 && (n = t[Id] = new Set);
    var r = e + "__bubble";
    n.has(r) || (jg(t, e, 2, !1), n.add(r))
}

function Lf(e, t, n) {
    var r = 0;
    t && (r |= 4), jg(n, e, r, t)
}
var ca = "_reactListening" + Math.random().toString(36).slice(2);

function Ks(e) {
    if (!e[ca]) {
        e[ca] = !0, Y1.forEach(function(n) {
            n !== "selectionchange" && (J2.has(n) || Lf(n, !1, e), Lf(n, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[ca] || (t[ca] = !0, Lf("selectionchange", !1, t))
    }
}

function jg(e, t, n, r) {
    switch (Eg(t)) {
        case 1:
            var i = p2;
            break;
        case 4:
            i = h2;
            break;
        default:
            i = Hp
    }
    n = i.bind(null, t, n, e), i = void 0, !Pd || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (i = !0), r ? i !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: i
    }) : e.addEventListener(t, n, !0) : i !== void 0 ? e.addEventListener(t, n, {
        passive: i
    }) : e.addEventListener(t, n, !1)
}

function Nf(e, t, n, r, i) {
    var o = r;
    if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
        if (r === null) return;
        var s = r.tag;
        if (s === 3 || s === 4) {
            var l = r.stateNode.containerInfo;
            if (l === i || l.nodeType === 8 && l.parentNode === i) break;
            if (s === 4)
                for (s = r.return; s !== null;) {
                    var a = s.tag;
                    if ((a === 3 || a === 4) && (a = s.stateNode.containerInfo, a === i || a.nodeType === 8 && a.parentNode === i)) return;
                    s = s.return
                }
            for (; l !== null;) {
                if (s = Si(l), s === null) return;
                if (a = s.tag, a === 5 || a === 6) {
                    r = o = s;
                    continue e
                }
                l = l.parentNode
            }
        }
        r = r.return
    }
    ug(function() {
        var u = o,
            f = jp(n),
            d = [];
        e: {
            var h = Fg.get(e);
            if (h !== void 0) {
                var y = Gp,
                    _ = e;
                switch (e) {
                    case "keypress":
                        if (Pa(n) === 0) break e;
                    case "keydown":
                    case "keyup":
                        y = M2;
                        break;
                    case "focusin":
                        _ = "focus", y = Tf;
                        break;
                    case "focusout":
                        _ = "blur", y = Tf;
                        break;
                    case "beforeblur":
                    case "afterblur":
                        y = Tf;
                        break;
                    case "click":
                        if (n.button === 2) break e;
                    case "auxclick":
                    case "dblclick":
                    case "mousedown":
                    case "mousemove":
                    case "mouseup":
                    case "mouseout":
                    case "mouseover":
                    case "contextmenu":
                        y = q0;
                        break;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                        y = g2;
                        break;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchstart":
                        y = N2;
                        break;
                    case Rg:
                    case Dg:
                    case zg:
                        y = S2;
                        break;
                    case Ig:
                        y = R2;
                        break;
                    case "scroll":
                        y = m2;
                        break;
                    case "wheel":
                        y = z2;
                        break;
                    case "copy":
                    case "cut":
                    case "paste":
                        y = x2;
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                        y = Q0
                }
                var v = (t & 4) !== 0,
                    E = !v && e === "scroll",
                    m = v ? h !== null ? h + "Capture" : null : h;
                v = [];
                for (var g = u, S; g !== null;) {
                    S = g;
                    var x = S.stateNode;
                    if (S.tag === 5 && x !== null && (S = x, m !== null && (x = Hs(g, m), x != null && v.push(Qs(g, x, S)))), E) break;
                    g = g.return
                }
                0 < v.length && (h = new y(h, _, null, n, f), d.push({
                    event: h,
                    listeners: v
                }))
            }
        }
        if (!(t & 7)) {
            e: {
                if (h = e === "mouseover" || e === "pointerover", y = e === "mouseout" || e === "pointerout", h && n !== Cd && (_ = n.relatedTarget || n.fromElement) && (Si(_) || _[gr])) break e;
                if ((y || h) && (h = f.window === f ? f : (h = f.ownerDocument) ? h.defaultView || h.parentWindow : window, y ? (_ = n.relatedTarget || n.toElement, y = u, _ = _ ? Si(_) : null, _ !== null && (E = Ii(_), _ !== E || _.tag !== 5 && _.tag !== 6) && (_ = null)) : (y = null, _ = u), y !== _)) {
                    if (v = q0, x = "onMouseLeave", m = "onMouseEnter", g = "mouse", (e === "pointerout" || e === "pointerover") && (v = Q0, x = "onPointerLeave", m = "onPointerEnter", g = "pointer"), E = y == null ? h : oo(y), S = _ == null ? h : oo(_), h = new v(x, g + "leave", y, n, f), h.target = E, h.relatedTarget = S, x = null, Si(f) === u && (v = new v(m, g + "enter", _, n, f), v.target = S, v.relatedTarget = E, x = v), E = x, y && _) t: {
                        for (v = y, m = _, g = 0, S = v; S; S = Zi(S)) g++;
                        for (S = 0, x = m; x; x = Zi(x)) S++;
                        for (; 0 < g - S;) v = Zi(v),
                        g--;
                        for (; 0 < S - g;) m = Zi(m),
                        S--;
                        for (; g--;) {
                            if (v === m || m !== null && v === m.alternate) break t;
                            v = Zi(v), m = Zi(m)
                        }
                        v = null
                    }
                    else v = null;
                    y !== null && av(d, h, y, v, !1), _ !== null && E !== null && av(d, E, _, v, !0)
                }
            }
            e: {
                if (h = u ? oo(u) : window, y = h.nodeName && h.nodeName.toLowerCase(), y === "select" || y === "input" && h.type === "file") var P = $2;
                else if (ev(h))
                    if (Mg) P = Y2;
                    else {
                        P = W2;
                        var T = H2
                    }
                else(y = h.nodeName) && y.toLowerCase() === "input" && (h.type === "checkbox" || h.type === "radio") && (P = G2);
                if (P && (P = P(e, u))) {
                    bg(d, P, n, f);
                    break e
                }
                T && T(e, h, u),
                e === "focusout" && (T = h._wrapperState) && T.controlled && h.type === "number" && _d(h, "number", h.value)
            }
            switch (T = u ? oo(u) : window, e) {
                case "focusin":
                    (ev(T) || T.contentEditable === "true") && (ro = T, Ld = u, As = null);
                    break;
                case "focusout":
                    As = Ld = ro = null;
                    break;
                case "mousedown":
                    Nd = !0;
                    break;
                case "contextmenu":
                case "mouseup":
                case "dragend":
                    Nd = !1, ov(d, n, f);
                    break;
                case "selectionchange":
                    if (K2) break;
                case "keydown":
                case "keyup":
                    ov(d, n, f)
            }
            var L;
            if (Xp) e: {
                switch (e) {
                    case "compositionstart":
                        var b = "onCompositionStart";
                        break e;
                    case "compositionend":
                        b = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        b = "onCompositionUpdate";
                        break e
                }
                b = void 0
            }
            else no ? Pg(e, n) && (b = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (b = "onCompositionStart");b && (Tg && n.locale !== "ko" && (no || b !== "onCompositionStart" ? b === "onCompositionEnd" && no && (L = Cg()) : (Rr = f, Wp = "value" in Rr ? Rr.value : Rr.textContent, no = !0)), T = qa(u, b), 0 < T.length && (b = new K0(b, e, null, n, f), d.push({
                event: b,
                listeners: T
            }), L ? b.data = L : (L = kg(n), L !== null && (b.data = L)))),
            (L = F2 ? B2(e, n) : j2(e, n)) && (u = qa(u, "onBeforeInput"), 0 < u.length && (f = new K0("onBeforeInput", "beforeinput", null, n, f), d.push({
                event: f,
                listeners: u
            }), f.data = L))
        }
        Bg(d, t)
    })
}

function Qs(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}

function qa(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
        var i = e,
            o = i.stateNode;
        i.tag === 5 && o !== null && (i = o, o = Hs(e, n), o != null && r.unshift(Qs(e, o, i)), o = Hs(e, t), o != null && r.push(Qs(e, o, i))), e = e.return
    }
    return r
}

function Zi(e) {
    if (e === null) return null;
    do e = e.return; while (e && e.tag !== 5);
    return e || null
}

function av(e, t, n, r, i) {
    for (var o = t._reactName, s = []; n !== null && n !== r;) {
        var l = n,
            a = l.alternate,
            u = l.stateNode;
        if (a !== null && a === r) break;
        l.tag === 5 && u !== null && (l = u, i ? (a = Hs(n, o), a != null && s.unshift(Qs(n, a, l))) : i || (a = Hs(n, o), a != null && s.push(Qs(n, a, l)))), n = n.return
    }
    s.length !== 0 && e.push({
        event: t,
        listeners: s
    })
}
var ex = /\r\n?/g,
    tx = /\u0000|\uFFFD/g;

function uv(e) {
    return (typeof e == "string" ? e : "" + e).replace(ex, `
`).replace(tx, "")
}

function fa(e, t, n) {
    if (t = uv(t), uv(e) !== t && n) throw Error(W(425))
}

function Ka() {}
var Ad = null,
    Rd = null;

function Dd(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var zd = typeof setTimeout == "function" ? setTimeout : void 0,
    nx = typeof clearTimeout == "function" ? clearTimeout : void 0,
    cv = typeof Promise == "function" ? Promise : void 0,
    rx = typeof queueMicrotask == "function" ? queueMicrotask : typeof cv < "u" ? function(e) {
        return cv.resolve(null).then(e).catch(ix)
    } : zd;

function ix(e) {
    setTimeout(function() {
        throw e
    })
}

function Af(e, t) {
    var n = t,
        r = 0;
    do {
        var i = n.nextSibling;
        if (e.removeChild(n), i && i.nodeType === 8)
            if (n = i.data, n === "/$") {
                if (r === 0) {
                    e.removeChild(i), Ys(t);
                    return
                }
                r--
            } else n !== "$" && n !== "$?" && n !== "$!" || r++;
        n = i
    } while (n);
    Ys(t)
}

function Wr(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
            if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
            if (t === "/$") return null
        }
    }
    return e
}

function fv(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0) return e;
                t--
            } else n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var $o = Math.random().toString(36).slice(2),
    Un = "__reactFiber$" + $o,
    Zs = "__reactProps$" + $o,
    gr = "__reactContainer$" + $o,
    Id = "__reactEvents$" + $o,
    ox = "__reactListeners$" + $o,
    sx = "__reactHandles$" + $o;

function Si(e) {
    var t = e[Un];
    if (t) return t;
    for (var n = e.parentNode; n;) {
        if (t = n[gr] || n[Un]) {
            if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                for (e = fv(e); e !== null;) {
                    if (n = e[Un]) return n;
                    e = fv(e)
                }
            return t
        }
        e = n, n = e.parentNode
    }
    return null
}

function vl(e) {
    return e = e[Un] || e[gr], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}

function oo(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(W(33))
}

function Mu(e) {
    return e[Zs] || null
}
var Fd = [],
    so = -1;

function ri(e) {
    return {
        current: e
    }
}

function Me(e) {
    0 > so || (e.current = Fd[so], Fd[so] = null, so--)
}

function Pe(e, t) {
    so++, Fd[so] = e.current, e.current = t
}
var Jr = {},
    kt = ri(Jr),
    jt = ri(!1),
    Mi = Jr;

function Po(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Jr;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
    var i = {},
        o;
    for (o in n) i[o] = t[o];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = i), i
}

function Vt(e) {
    return e = e.childContextTypes, e != null
}

function Qa() {
    Me(jt), Me(kt)
}

function dv(e, t, n) {
    if (kt.current !== Jr) throw Error(W(168));
    Pe(kt, t), Pe(jt, n)
}

function Vg(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
    r = r.getChildContext();
    for (var i in r)
        if (!(i in t)) throw Error(W(108, Hw(e) || "Unknown", i));
    return je({}, n, r)
}

function Za(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || Jr, Mi = kt.current, Pe(kt, e), Pe(jt, jt.current), !0
}

function pv(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(W(169));
    n ? (e = Vg(e, t, Mi), r.__reactInternalMemoizedMergedChildContext = e, Me(jt), Me(kt), Pe(kt, e)) : Me(jt), Pe(jt, n)
}
var cr = null,
    Ou = !1,
    Rf = !1;

function Ug(e) {
    cr === null ? cr = [e] : cr.push(e)
}

function lx(e) {
    Ou = !0, Ug(e)
}

function ii() {
    if (!Rf && cr !== null) {
        Rf = !0;
        var e = 0,
            t = Se;
        try {
            var n = cr;
            for (Se = 1; e < n.length; e++) {
                var r = n[e];
                do r = r(!0); while (r !== null)
            }
            cr = null, Ou = !1
        } catch (i) {
            throw cr !== null && (cr = cr.slice(e + 1)), pg(Vp, ii), i
        } finally {
            Se = t, Rf = !1
        }
    }
    return null
}
var lo = [],
    ao = 0,
    Ja = null,
    eu = 0,
    dn = [],
    pn = 0,
    Oi = null,
    dr = 1,
    pr = "";

function gi(e, t) {
    lo[ao++] = eu, lo[ao++] = Ja, Ja = e, eu = t
}

function $g(e, t, n) {
    dn[pn++] = dr, dn[pn++] = pr, dn[pn++] = Oi, Oi = e;
    var r = dr;
    e = pr;
    var i = 32 - Ln(r) - 1;
    r &= ~(1 << i), n += 1;
    var o = 32 - Ln(t) + i;
    if (30 < o) {
        var s = i - i % 5;
        o = (r & (1 << s) - 1).toString(32), r >>= s, i -= s, dr = 1 << 32 - Ln(t) + i | n << i | r, pr = o + e
    } else dr = 1 << o | n << i | r, pr = e
}

function Kp(e) {
    e.return !== null && (gi(e, 1), $g(e, 1, 0))
}

function Qp(e) {
    for (; e === Ja;) Ja = lo[--ao], lo[ao] = null, eu = lo[--ao], lo[ao] = null;
    for (; e === Oi;) Oi = dn[--pn], dn[pn] = null, pr = dn[--pn], dn[pn] = null, dr = dn[--pn], dn[pn] = null
}
var tn = null,
    en = null,
    Ae = !1,
    On = null;

function Hg(e, t) {
    var n = mn(5, null, null, 0);
    n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
}

function hv(e, t) {
    switch (e.tag) {
        case 5:
            var n = e.type;
            return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, tn = e, en = Wr(t.firstChild), !0) : !1;
        case 6:
            return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, tn = e, en = null, !0) : !1;
        case 13:
            return t = t.nodeType !== 8 ? null : t, t !== null ? (n = Oi !== null ? {
                id: dr,
                overflow: pr
            } : null, e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824
            }, n = mn(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, tn = e, en = null, !0) : !1;
        default:
            return !1
    }
}

function Bd(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0
}

function jd(e) {
    if (Ae) {
        var t = en;
        if (t) {
            var n = t;
            if (!hv(e, t)) {
                if (Bd(e)) throw Error(W(418));
                t = Wr(n.nextSibling);
                var r = tn;
                t && hv(e, t) ? Hg(r, n) : (e.flags = e.flags & -4097 | 2, Ae = !1, tn = e)
            }
        } else {
            if (Bd(e)) throw Error(W(418));
            e.flags = e.flags & -4097 | 2, Ae = !1, tn = e
        }
    }
}

function mv(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
    tn = e
}

function da(e) {
    if (e !== tn) return !1;
    if (!Ae) return mv(e), Ae = !0, !1;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !Dd(e.type, e.memoizedProps)), t && (t = en)) {
        if (Bd(e)) throw Wg(), Error(W(418));
        for (; t;) Hg(e, t), t = Wr(t.nextSibling)
    }
    if (mv(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(W(317));
        e: {
            for (e = e.nextSibling, t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            en = Wr(e.nextSibling);
                            break e
                        }
                        t--
                    } else n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            en = null
        }
    } else en = tn ? Wr(e.stateNode.nextSibling) : null;
    return !0
}

function Wg() {
    for (var e = en; e;) e = Wr(e.nextSibling)
}

function ko() {
    en = tn = null, Ae = !1
}

function Zp(e) {
    On === null ? On = [e] : On.push(e)
}
var ax = xr.ReactCurrentBatchConfig;

function bn(e, t) {
    if (e && e.defaultProps) {
        t = je({}, t), e = e.defaultProps;
        for (var n in e) t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}
var tu = ri(null),
    nu = null,
    uo = null,
    Jp = null;

function eh() {
    Jp = uo = nu = null
}

function th(e) {
    var t = tu.current;
    Me(tu), e._currentValue = t
}

function Vd(e, t, n) {
    for (; e !== null;) {
        var r = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
        e = e.return
    }
}

function _o(e, t) {
    nu = e, Jp = uo = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (Bt = !0), e.firstContext = null)
}

function wn(e) {
    var t = e._currentValue;
    if (Jp !== e)
        if (e = {
                context: e,
                memoizedValue: t,
                next: null
            }, uo === null) {
            if (nu === null) throw Error(W(308));
            uo = e, nu.dependencies = {
                lanes: 0,
                firstContext: e
            }
        } else uo = uo.next = e;
    return t
}
var wi = null;

function nh(e) {
    wi === null ? wi = [e] : wi.push(e)
}

function Gg(e, t, n, r) {
    var i = t.interleaved;
    return i === null ? (n.next = n, nh(t)) : (n.next = i.next, i.next = n), t.interleaved = n, yr(e, r)
}

function yr(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null
}
var Lr = !1;

function rh(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null,
            interleaved: null,
            lanes: 0
        },
        effects: null
    }
}

function Yg(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}

function hr(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}

function Gr(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (r = r.shared, ye & 2) {
        var i = r.pending;
        return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, yr(e, n)
    }
    return i = r.interleaved, i === null ? (t.next = t, nh(r)) : (t.next = i.next, i.next = t), r.interleaved = t, yr(e, n)
}

function ka(e, t, n) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, Up(e, n)
    }
}

function vv(e, t) {
    var n = e.updateQueue,
        r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
        var i = null,
            o = null;
        if (n = n.firstBaseUpdate, n !== null) {
            do {
                var s = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                o === null ? i = o = s : o = o.next = s, n = n.next
            } while (n !== null);
            o === null ? i = o = t : o = o.next = t
        } else i = o = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: i,
            lastBaseUpdate: o,
            shared: r.shared,
            effects: r.effects
        }, e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function ru(e, t, n, r) {
    var i = e.updateQueue;
    Lr = !1;
    var o = i.firstBaseUpdate,
        s = i.lastBaseUpdate,
        l = i.shared.pending;
    if (l !== null) {
        i.shared.pending = null;
        var a = l,
            u = a.next;
        a.next = null, s === null ? o = u : s.next = u, s = a;
        var f = e.alternate;
        f !== null && (f = f.updateQueue, l = f.lastBaseUpdate, l !== s && (l === null ? f.firstBaseUpdate = u : l.next = u, f.lastBaseUpdate = a))
    }
    if (o !== null) {
        var d = i.baseState;
        s = 0, f = u = a = null, l = o;
        do {
            var h = l.lane,
                y = l.eventTime;
            if ((r & h) === h) {
                f !== null && (f = f.next = {
                    eventTime: y,
                    lane: 0,
                    tag: l.tag,
                    payload: l.payload,
                    callback: l.callback,
                    next: null
                });
                e: {
                    var _ = e,
                        v = l;
                    switch (h = t, y = n, v.tag) {
                        case 1:
                            if (_ = v.payload, typeof _ == "function") {
                                d = _.call(y, d, h);
                                break e
                            }
                            d = _;
                            break e;
                        case 3:
                            _.flags = _.flags & -65537 | 128;
                        case 0:
                            if (_ = v.payload, h = typeof _ == "function" ? _.call(y, d, h) : _, h == null) break e;
                            d = je({}, d, h);
                            break e;
                        case 2:
                            Lr = !0
                    }
                }
                l.callback !== null && l.lane !== 0 && (e.flags |= 64, h = i.effects, h === null ? i.effects = [l] : h.push(l))
            } else y = {
                eventTime: y,
                lane: h,
                tag: l.tag,
                payload: l.payload,
                callback: l.callback,
                next: null
            }, f === null ? (u = f = y, a = d) : f = f.next = y, s |= h;
            if (l = l.next, l === null) {
                if (l = i.shared.pending, l === null) break;
                h = l, l = h.next, h.next = null, i.lastBaseUpdate = h, i.shared.pending = null
            }
        } while (1);
        if (f === null && (a = d), i.baseState = a, i.firstBaseUpdate = u, i.lastBaseUpdate = f, t = i.shared.interleaved, t !== null) {
            i = t;
            do s |= i.lane, i = i.next; while (i !== t)
        } else o === null && (i.shared.lanes = 0);
        Ni |= s, e.lanes = s, e.memoizedState = d
    }
}

function gv(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t],
                i = r.callback;
            if (i !== null) {
                if (r.callback = null, r = n, typeof i != "function") throw Error(W(191, i));
                i.call(r)
            }
        }
}
var Xg = new G1.Component().refs;

function Ud(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : je({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
}
var Lu = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? Ii(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = Nt(),
            i = Xr(e),
            o = hr(r, i);
        o.payload = t, n != null && (o.callback = n), t = Gr(e, o, i), t !== null && (Nn(t, e, i, r), ka(t, e, i))
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = Nt(),
            i = Xr(e),
            o = hr(r, i);
        o.tag = 1, o.payload = t, n != null && (o.callback = n), t = Gr(e, o, i), t !== null && (Nn(t, e, i, r), ka(t, e, i))
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = Nt(),
            r = Xr(e),
            i = hr(n, r);
        i.tag = 2, t != null && (i.callback = t), t = Gr(e, i, r), t !== null && (Nn(t, e, r, n), ka(t, e, r))
    }
};

function yv(e, t, n, r, i, o, s) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, o, s) : t.prototype && t.prototype.isPureReactComponent ? !qs(n, r) || !qs(i, o) : !0
}

function qg(e, t, n) {
    var r = !1,
        i = Jr,
        o = t.contextType;
    return typeof o == "object" && o !== null ? o = wn(o) : (i = Vt(t) ? Mi : kt.current, r = t.contextTypes, o = (r = r != null) ? Po(e, i) : Jr), t = new t(n, o), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = Lu, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = i, e.__reactInternalMemoizedMaskedChildContext = o), t
}

function _v(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Lu.enqueueReplaceState(t, t.state, null)
}

function $d(e, t, n, r) {
    var i = e.stateNode;
    i.props = n, i.state = e.memoizedState, i.refs = Xg, rh(e);
    var o = t.contextType;
    typeof o == "object" && o !== null ? i.context = wn(o) : (o = Vt(t) ? Mi : kt.current, i.context = Po(e, o)), i.state = e.memoizedState, o = t.getDerivedStateFromProps, typeof o == "function" && (Ud(e, t, o, n), i.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof i.getSnapshotBeforeUpdate == "function" || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (t = i.state, typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount(), t !== i.state && Lu.enqueueReplaceState(i, i.state, null), ru(e, n, i, r), i.state = e.memoizedState), typeof i.componentDidMount == "function" && (e.flags |= 4194308)
}

function ms(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner, n) {
                if (n.tag !== 1) throw Error(W(309));
                var r = n.stateNode
            }
            if (!r) throw Error(W(147, e));
            var i = r,
                o = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === o ? t.ref : (t = function(s) {
                var l = i.refs;
                l === Xg && (l = i.refs = {}), s === null ? delete l[o] : l[o] = s
            }, t._stringRef = o, t)
        }
        if (typeof e != "string") throw Error(W(284));
        if (!n._owner) throw Error(W(290, e))
    }
    return e
}

function pa(e, t) {
    throw e = Object.prototype.toString.call(t), Error(W(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
}

function Sv(e) {
    var t = e._init;
    return t(e._payload)
}

function Kg(e) {
    function t(m, g) {
        if (e) {
            var S = m.deletions;
            S === null ? (m.deletions = [g], m.flags |= 16) : S.push(g)
        }
    }

    function n(m, g) {
        if (!e) return null;
        for (; g !== null;) t(m, g), g = g.sibling;
        return null
    }

    function r(m, g) {
        for (m = new Map; g !== null;) g.key !== null ? m.set(g.key, g) : m.set(g.index, g), g = g.sibling;
        return m
    }

    function i(m, g) {
        return m = qr(m, g), m.index = 0, m.sibling = null, m
    }

    function o(m, g, S) {
        return m.index = S, e ? (S = m.alternate, S !== null ? (S = S.index, S < g ? (m.flags |= 2, g) : S) : (m.flags |= 2, g)) : (m.flags |= 1048576, g)
    }

    function s(m) {
        return e && m.alternate === null && (m.flags |= 2), m
    }

    function l(m, g, S, x) {
        return g === null || g.tag !== 6 ? (g = Vf(S, m.mode, x), g.return = m, g) : (g = i(g, S), g.return = m, g)
    }

    function a(m, g, S, x) {
        var P = S.type;
        return P === to ? f(m, g, S.props.children, x, S.key) : g !== null && (g.elementType === P || typeof P == "object" && P !== null && P.$$typeof === Or && Sv(P) === g.type) ? (x = i(g, S.props), x.ref = ms(m, g, S), x.return = m, x) : (x = Aa(S.type, S.key, S.props, null, m.mode, x), x.ref = ms(m, g, S), x.return = m, x)
    }

    function u(m, g, S, x) {
        return g === null || g.tag !== 4 || g.stateNode.containerInfo !== S.containerInfo || g.stateNode.implementation !== S.implementation ? (g = Uf(S, m.mode, x), g.return = m, g) : (g = i(g, S.children || []), g.return = m, g)
    }

    function f(m, g, S, x, P) {
        return g === null || g.tag !== 7 ? (g = Ti(S, m.mode, x, P), g.return = m, g) : (g = i(g, S), g.return = m, g)
    }

    function d(m, g, S) {
        if (typeof g == "string" && g !== "" || typeof g == "number") return g = Vf("" + g, m.mode, S), g.return = m, g;
        if (typeof g == "object" && g !== null) {
            switch (g.$$typeof) {
                case na:
                    return S = Aa(g.type, g.key, g.props, null, m.mode, S), S.ref = ms(m, null, g), S.return = m, S;
                case eo:
                    return g = Uf(g, m.mode, S), g.return = m, g;
                case Or:
                    var x = g._init;
                    return d(m, x(g._payload), S)
            }
            if (Cs(g) || cs(g)) return g = Ti(g, m.mode, S, null), g.return = m, g;
            pa(m, g)
        }
        return null
    }

    function h(m, g, S, x) {
        var P = g !== null ? g.key : null;
        if (typeof S == "string" && S !== "" || typeof S == "number") return P !== null ? null : l(m, g, "" + S, x);
        if (typeof S == "object" && S !== null) {
            switch (S.$$typeof) {
                case na:
                    return S.key === P ? a(m, g, S, x) : null;
                case eo:
                    return S.key === P ? u(m, g, S, x) : null;
                case Or:
                    return P = S._init, h(m, g, P(S._payload), x)
            }
            if (Cs(S) || cs(S)) return P !== null ? null : f(m, g, S, x, null);
            pa(m, S)
        }
        return null
    }

    function y(m, g, S, x, P) {
        if (typeof x == "string" && x !== "" || typeof x == "number") return m = m.get(S) || null, l(g, m, "" + x, P);
        if (typeof x == "object" && x !== null) {
            switch (x.$$typeof) {
                case na:
                    return m = m.get(x.key === null ? S : x.key) || null, a(g, m, x, P);
                case eo:
                    return m = m.get(x.key === null ? S : x.key) || null, u(g, m, x, P);
                case Or:
                    var T = x._init;
                    return y(m, g, S, T(x._payload), P)
            }
            if (Cs(x) || cs(x)) return m = m.get(S) || null, f(g, m, x, P, null);
            pa(g, x)
        }
        return null
    }

    function _(m, g, S, x) {
        for (var P = null, T = null, L = g, b = g = 0, N = null; L !== null && b < S.length; b++) {
            L.index > b ? (N = L, L = null) : N = L.sibling;
            var H = h(m, L, S[b], x);
            if (H === null) {
                L === null && (L = N);
                break
            }
            e && L && H.alternate === null && t(m, L), g = o(H, g, b), T === null ? P = H : T.sibling = H, T = H, L = N
        }
        if (b === S.length) return n(m, L), Ae && gi(m, b), P;
        if (L === null) {
            for (; b < S.length; b++) L = d(m, S[b], x), L !== null && (g = o(L, g, b), T === null ? P = L : T.sibling = L, T = L);
            return Ae && gi(m, b), P
        }
        for (L = r(m, L); b < S.length; b++) N = y(L, m, b, S[b], x), N !== null && (e && N.alternate !== null && L.delete(N.key === null ? b : N.key), g = o(N, g, b), T === null ? P = N : T.sibling = N, T = N);
        return e && L.forEach(function(A) {
            return t(m, A)
        }), Ae && gi(m, b), P
    }

    function v(m, g, S, x) {
        var P = cs(S);
        if (typeof P != "function") throw Error(W(150));
        if (S = P.call(S), S == null) throw Error(W(151));
        for (var T = P = null, L = g, b = g = 0, N = null, H = S.next(); L !== null && !H.done; b++, H = S.next()) {
            L.index > b ? (N = L, L = null) : N = L.sibling;
            var A = h(m, L, H.value, x);
            if (A === null) {
                L === null && (L = N);
                break
            }
            e && L && A.alternate === null && t(m, L), g = o(A, g, b), T === null ? P = A : T.sibling = A, T = A, L = N
        }
        if (H.done) return n(m, L), Ae && gi(m, b), P;
        if (L === null) {
            for (; !H.done; b++, H = S.next()) H = d(m, H.value, x), H !== null && (g = o(H, g, b), T === null ? P = H : T.sibling = H, T = H);
            return Ae && gi(m, b), P
        }
        for (L = r(m, L); !H.done; b++, H = S.next()) H = y(L, m, b, H.value, x), H !== null && (e && H.alternate !== null && L.delete(H.key === null ? b : H.key), g = o(H, g, b), T === null ? P = H : T.sibling = H, T = H);
        return e && L.forEach(function(I) {
            return t(m, I)
        }), Ae && gi(m, b), P
    }

    function E(m, g, S, x) {
        if (typeof S == "object" && S !== null && S.type === to && S.key === null && (S = S.props.children), typeof S == "object" && S !== null) {
            switch (S.$$typeof) {
                case na:
                    e: {
                        for (var P = S.key, T = g; T !== null;) {
                            if (T.key === P) {
                                if (P = S.type, P === to) {
                                    if (T.tag === 7) {
                                        n(m, T.sibling), g = i(T, S.props.children), g.return = m, m = g;
                                        break e
                                    }
                                } else if (T.elementType === P || typeof P == "object" && P !== null && P.$$typeof === Or && Sv(P) === T.type) {
                                    n(m, T.sibling), g = i(T, S.props), g.ref = ms(m, T, S), g.return = m, m = g;
                                    break e
                                }
                                n(m, T);
                                break
                            } else t(m, T);
                            T = T.sibling
                        }
                        S.type === to ? (g = Ti(S.props.children, m.mode, x, S.key), g.return = m, m = g) : (x = Aa(S.type, S.key, S.props, null, m.mode, x), x.ref = ms(m, g, S), x.return = m, m = x)
                    }
                    return s(m);
                case eo:
                    e: {
                        for (T = S.key; g !== null;) {
                            if (g.key === T)
                                if (g.tag === 4 && g.stateNode.containerInfo === S.containerInfo && g.stateNode.implementation === S.implementation) {
                                    n(m, g.sibling), g = i(g, S.children || []), g.return = m, m = g;
                                    break e
                                } else {
                                    n(m, g);
                                    break
                                }
                            else t(m, g);
                            g = g.sibling
                        }
                        g = Uf(S, m.mode, x),
                        g.return = m,
                        m = g
                    }
                    return s(m);
                case Or:
                    return T = S._init, E(m, g, T(S._payload), x)
            }
            if (Cs(S)) return _(m, g, S, x);
            if (cs(S)) return v(m, g, S, x);
            pa(m, S)
        }
        return typeof S == "string" && S !== "" || typeof S == "number" ? (S = "" + S, g !== null && g.tag === 6 ? (n(m, g.sibling), g = i(g, S), g.return = m, m = g) : (n(m, g), g = Vf(S, m.mode, x), g.return = m, m = g), s(m)) : n(m, g)
    }
    return E
}
var bo = Kg(!0),
    Qg = Kg(!1),
    gl = {},
    Xn = ri(gl),
    Js = ri(gl),
    el = ri(gl);

function xi(e) {
    if (e === gl) throw Error(W(174));
    return e
}

function ih(e, t) {
    switch (Pe(el, t), Pe(Js, e), Pe(Xn, gl), e = t.nodeType, e) {
        case 9:
        case 11:
            t = (t = t.documentElement) ? t.namespaceURI : wd(null, "");
            break;
        default:
            e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = wd(t, e)
    }
    Me(Xn), Pe(Xn, t)
}

function Mo() {
    Me(Xn), Me(Js), Me(el)
}

function Zg(e) {
    xi(el.current);
    var t = xi(Xn.current),
        n = wd(t, e.type);
    t !== n && (Pe(Js, e), Pe(Xn, n))
}

function oh(e) {
    Js.current === e && (Me(Xn), Me(Js))
}
var ze = ri(0);

function iu(e) {
    for (var t = e; t !== null;) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if (t.flags & 128) return t
        } else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return null;
            t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
    }
    return null
}
var Df = [];

function sh() {
    for (var e = 0; e < Df.length; e++) Df[e]._workInProgressVersionPrimary = null;
    Df.length = 0
}
var ba = xr.ReactCurrentDispatcher,
    zf = xr.ReactCurrentBatchConfig,
    Li = 0,
    Be = null,
    tt = null,
    at = null,
    ou = !1,
    Rs = !1,
    tl = 0,
    ux = 0;

function wt() {
    throw Error(W(321))
}

function lh(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!Rn(e[n], t[n])) return !1;
    return !0
}

function ah(e, t, n, r, i, o) {
    if (Li = o, Be = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, ba.current = e === null || e.memoizedState === null ? px : hx, e = n(r, i), Rs) {
        o = 0;
        do {
            if (Rs = !1, tl = 0, 25 <= o) throw Error(W(301));
            o += 1, at = tt = null, t.updateQueue = null, ba.current = mx, e = n(r, i)
        } while (Rs)
    }
    if (ba.current = su, t = tt !== null && tt.next !== null, Li = 0, at = tt = Be = null, ou = !1, t) throw Error(W(300));
    return e
}

function uh() {
    var e = tl !== 0;
    return tl = 0, e
}

function Vn() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return at === null ? Be.memoizedState = at = e : at = at.next = e, at
}

function xn() {
    if (tt === null) {
        var e = Be.alternate;
        e = e !== null ? e.memoizedState : null
    } else e = tt.next;
    var t = at === null ? Be.memoizedState : at.next;
    if (t !== null) at = t, tt = e;
    else {
        if (e === null) throw Error(W(310));
        tt = e, e = {
            memoizedState: tt.memoizedState,
            baseState: tt.baseState,
            baseQueue: tt.baseQueue,
            queue: tt.queue,
            next: null
        }, at === null ? Be.memoizedState = at = e : at = at.next = e
    }
    return at
}

function nl(e, t) {
    return typeof t == "function" ? t(e) : t
}

function If(e) {
    var t = xn(),
        n = t.queue;
    if (n === null) throw Error(W(311));
    n.lastRenderedReducer = e;
    var r = tt,
        i = r.baseQueue,
        o = n.pending;
    if (o !== null) {
        if (i !== null) {
            var s = i.next;
            i.next = o.next, o.next = s
        }
        r.baseQueue = i = o, n.pending = null
    }
    if (i !== null) {
        o = i.next, r = r.baseState;
        var l = s = null,
            a = null,
            u = o;
        do {
            var f = u.lane;
            if ((Li & f) === f) a !== null && (a = a.next = {
                lane: 0,
                action: u.action,
                hasEagerState: u.hasEagerState,
                eagerState: u.eagerState,
                next: null
            }), r = u.hasEagerState ? u.eagerState : e(r, u.action);
            else {
                var d = {
                    lane: f,
                    action: u.action,
                    hasEagerState: u.hasEagerState,
                    eagerState: u.eagerState,
                    next: null
                };
                a === null ? (l = a = d, s = r) : a = a.next = d, Be.lanes |= f, Ni |= f
            }
            u = u.next
        } while (u !== null && u !== o);
        a === null ? s = r : a.next = l, Rn(r, t.memoizedState) || (Bt = !0), t.memoizedState = r, t.baseState = s, t.baseQueue = a, n.lastRenderedState = r
    }
    if (e = n.interleaved, e !== null) {
        i = e;
        do o = i.lane, Be.lanes |= o, Ni |= o, i = i.next; while (i !== e)
    } else i === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch]
}

function Ff(e) {
    var t = xn(),
        n = t.queue;
    if (n === null) throw Error(W(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
        i = n.pending,
        o = t.memoizedState;
    if (i !== null) {
        n.pending = null;
        var s = i = i.next;
        do o = e(o, s.action), s = s.next; while (s !== i);
        Rn(o, t.memoizedState) || (Bt = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o
    }
    return [o, r]
}

function Jg() {}

function ey(e, t) {
    var n = Be,
        r = xn(),
        i = t(),
        o = !Rn(r.memoizedState, i);
    if (o && (r.memoizedState = i, Bt = !0), r = r.queue, ch(ry.bind(null, n, r, e), [e]), r.getSnapshot !== t || o || at !== null && at.memoizedState.tag & 1) {
        if (n.flags |= 2048, rl(9, ny.bind(null, n, r, i, t), void 0, null), ut === null) throw Error(W(349));
        Li & 30 || ty(n, t, i)
    }
    return i
}

function ty(e, t, n) {
    e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
    }, t = Be.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, Be.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
}

function ny(e, t, n, r) {
    t.value = n, t.getSnapshot = r, iy(t) && oy(e)
}

function ry(e, t, n) {
    return n(function() {
        iy(t) && oy(e)
    })
}

function iy(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var n = t();
        return !Rn(e, n)
    } catch {
        return !0
    }
}

function oy(e) {
    var t = yr(e, 1);
    t !== null && Nn(t, e, 1, -1)
}

function wv(e) {
    var t = Vn();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: nl,
        lastRenderedState: e
    }, t.queue = e, e = e.dispatch = dx.bind(null, Be, e), [t.memoizedState, e]
}

function rl(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    }, t = Be.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, Be.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
}

function sy() {
    return xn().memoizedState
}

function Ma(e, t, n, r) {
    var i = Vn();
    Be.flags |= e, i.memoizedState = rl(1 | t, n, void 0, r === void 0 ? null : r)
}

function Nu(e, t, n, r) {
    var i = xn();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (tt !== null) {
        var s = tt.memoizedState;
        if (o = s.destroy, r !== null && lh(r, s.deps)) {
            i.memoizedState = rl(t, n, o, r);
            return
        }
    }
    Be.flags |= e, i.memoizedState = rl(1 | t, n, o, r)
}

function xv(e, t) {
    return Ma(8390656, 8, e, t)
}

function ch(e, t) {
    return Nu(2048, 8, e, t)
}

function ly(e, t) {
    return Nu(4, 2, e, t)
}

function ay(e, t) {
    return Nu(4, 4, e, t)
}

function uy(e, t) {
    if (typeof t == "function") return e = e(), t(e),
        function() {
            t(null)
        };
    if (t != null) return e = e(), t.current = e,
        function() {
            t.current = null
        }
}

function cy(e, t, n) {
    return n = n != null ? n.concat([e]) : null, Nu(4, 4, uy.bind(null, t, e), n)
}

function fh() {}

function fy(e, t) {
    var n = xn();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && lh(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function dy(e, t) {
    var n = xn();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && lh(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function py(e, t, n) {
    return Li & 21 ? (Rn(n, t) || (n = vg(), Be.lanes |= n, Ni |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, Bt = !0), e.memoizedState = n)
}

function cx(e, t) {
    var n = Se;
    Se = n !== 0 && 4 > n ? n : 4, e(!0);
    var r = zf.transition;
    zf.transition = {};
    try {
        e(!1), t()
    } finally {
        Se = n, zf.transition = r
    }
}

function hy() {
    return xn().memoizedState
}

function fx(e, t, n) {
    var r = Xr(e);
    if (n = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, my(e)) vy(t, n);
    else if (n = Gg(e, t, n, r), n !== null) {
        var i = Nt();
        Nn(n, e, r, i), gy(n, t, r)
    }
}

function dx(e, t, n) {
    var r = Xr(e),
        i = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
    if (my(e)) vy(t, i);
    else {
        var o = e.alternate;
        if (e.lanes === 0 && (o === null || o.lanes === 0) && (o = t.lastRenderedReducer, o !== null)) try {
            var s = t.lastRenderedState,
                l = o(s, n);
            if (i.hasEagerState = !0, i.eagerState = l, Rn(l, s)) {
                var a = t.interleaved;
                a === null ? (i.next = i, nh(t)) : (i.next = a.next, a.next = i), t.interleaved = i;
                return
            }
        } catch {} finally {}
        n = Gg(e, t, i, r), n !== null && (i = Nt(), Nn(n, e, r, i), gy(n, t, r))
    }
}

function my(e) {
    var t = e.alternate;
    return e === Be || t !== null && t === Be
}

function vy(e, t) {
    Rs = ou = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
}

function gy(e, t, n) {
    if (n & 4194240) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, Up(e, n)
    }
}
var su = {
        readContext: wn,
        useCallback: wt,
        useContext: wt,
        useEffect: wt,
        useImperativeHandle: wt,
        useInsertionEffect: wt,
        useLayoutEffect: wt,
        useMemo: wt,
        useReducer: wt,
        useRef: wt,
        useState: wt,
        useDebugValue: wt,
        useDeferredValue: wt,
        useTransition: wt,
        useMutableSource: wt,
        useSyncExternalStore: wt,
        useId: wt,
        unstable_isNewReconciler: !1
    },
    px = {
        readContext: wn,
        useCallback: function(e, t) {
            return Vn().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: wn,
        useEffect: xv,
        useImperativeHandle: function(e, t, n) {
            return n = n != null ? n.concat([e]) : null, Ma(4194308, 4, uy.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
            return Ma(4194308, 4, e, t)
        },
        useInsertionEffect: function(e, t) {
            return Ma(4, 2, e, t)
        },
        useMemo: function(e, t) {
            var n = Vn();
            return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
        },
        useReducer: function(e, t, n) {
            var r = Vn();
            return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                pending: null,
                interleaved: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: e,
                lastRenderedState: t
            }, r.queue = e, e = e.dispatch = fx.bind(null, Be, e), [r.memoizedState, e]
        },
        useRef: function(e) {
            var t = Vn();
            return e = {
                current: e
            }, t.memoizedState = e
        },
        useState: wv,
        useDebugValue: fh,
        useDeferredValue: function(e) {
            return Vn().memoizedState = e
        },
        useTransition: function() {
            var e = wv(!1),
                t = e[0];
            return e = cx.bind(null, e[1]), Vn().memoizedState = e, [t, e]
        },
        useMutableSource: function() {},
        useSyncExternalStore: function(e, t, n) {
            var r = Be,
                i = Vn();
            if (Ae) {
                if (n === void 0) throw Error(W(407));
                n = n()
            } else {
                if (n = t(), ut === null) throw Error(W(349));
                Li & 30 || ty(r, t, n)
            }
            i.memoizedState = n;
            var o = {
                value: n,
                getSnapshot: t
            };
            return i.queue = o, xv(ry.bind(null, r, o, e), [e]), r.flags |= 2048, rl(9, ny.bind(null, r, o, n, t), void 0, null), n
        },
        useId: function() {
            var e = Vn(),
                t = ut.identifierPrefix;
            if (Ae) {
                var n = pr,
                    r = dr;
                n = (r & ~(1 << 32 - Ln(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = tl++, 0 < n && (t += "H" + n.toString(32)), t += ":"
            } else n = ux++, t = ":" + t + "r" + n.toString(32) + ":";
            return e.memoizedState = t
        },
        unstable_isNewReconciler: !1
    },
    hx = {
        readContext: wn,
        useCallback: fy,
        useContext: wn,
        useEffect: ch,
        useImperativeHandle: cy,
        useInsertionEffect: ly,
        useLayoutEffect: ay,
        useMemo: dy,
        useReducer: If,
        useRef: sy,
        useState: function() {
            return If(nl)
        },
        useDebugValue: fh,
        useDeferredValue: function(e) {
            var t = xn();
            return py(t, tt.memoizedState, e)
        },
        useTransition: function() {
            var e = If(nl)[0],
                t = xn().memoizedState;
            return [e, t]
        },
        useMutableSource: Jg,
        useSyncExternalStore: ey,
        useId: hy,
        unstable_isNewReconciler: !1
    },
    mx = {
        readContext: wn,
        useCallback: fy,
        useContext: wn,
        useEffect: ch,
        useImperativeHandle: cy,
        useInsertionEffect: ly,
        useLayoutEffect: ay,
        useMemo: dy,
        useReducer: Ff,
        useRef: sy,
        useState: function() {
            return Ff(nl)
        },
        useDebugValue: fh,
        useDeferredValue: function(e) {
            var t = xn();
            return tt === null ? t.memoizedState = e : py(t, tt.memoizedState, e)
        },
        useTransition: function() {
            var e = Ff(nl)[0],
                t = xn().memoizedState;
            return [e, t]
        },
        useMutableSource: Jg,
        useSyncExternalStore: ey,
        useId: hy,
        unstable_isNewReconciler: !1
    };

function Oo(e, t) {
    try {
        var n = "",
            r = t;
        do n += $w(r), r = r.return; while (r);
        var i = n
    } catch (o) {
        i = `
Error generating stack: ` + o.message + `
` + o.stack
    }
    return {
        value: e,
        source: t,
        stack: i,
        digest: null
    }
}

function Bf(e, t, n) {
    return {
        value: e,
        source: null,
        stack: n ? ? null,
        digest: t ? ? null
    }
}

function Hd(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var vx = typeof WeakMap == "function" ? WeakMap : Map;

function yy(e, t, n) {
    n = hr(-1, n), n.tag = 3, n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        au || (au = !0, ep = r), Hd(e, t)
    }, n
}

function _y(e, t, n) {
    n = hr(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var i = t.value;
        n.payload = function() {
            return r(i)
        }, n.callback = function() {
            Hd(e, t)
        }
    }
    var o = e.stateNode;
    return o !== null && typeof o.componentDidCatch == "function" && (n.callback = function() {
        Hd(e, t), typeof r != "function" && (Yr === null ? Yr = new Set([this]) : Yr.add(this));
        var s = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: s !== null ? s : ""
        })
    }), n
}

function Ev(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
        r = e.pingCache = new vx;
        var i = new Set;
        r.set(t, i)
    } else i = r.get(t), i === void 0 && (i = new Set, r.set(t, i));
    i.has(n) || (i.add(n), e = Ox.bind(null, e, t, n), t.then(e, e))
}

function Cv(e) {
    do {
        var t;
        if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
        e = e.return
    } while (e !== null);
    return null
}

function Tv(e, t, n, r, i) {
    return e.mode & 1 ? (e.flags |= 65536, e.lanes = i, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = hr(-1, 1), t.tag = 2, Gr(n, t, 1))), n.lanes |= 1), e)
}
var gx = xr.ReactCurrentOwner,
    Bt = !1;

function Ot(e, t, n, r) {
    t.child = e === null ? Qg(t, null, n, r) : bo(t, e.child, n, r)
}

function Pv(e, t, n, r, i) {
    n = n.render;
    var o = t.ref;
    return _o(t, i), r = ah(e, t, n, r, o, i), n = uh(), e !== null && !Bt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, _r(e, t, i)) : (Ae && n && Kp(t), t.flags |= 1, Ot(e, t, r, i), t.child)
}

function kv(e, t, n, r, i) {
    if (e === null) {
        var o = n.type;
        return typeof o == "function" && !_h(o) && o.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = o, Sy(e, t, o, r, i)) : (e = Aa(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e)
    }
    if (o = e.child, !(e.lanes & i)) {
        var s = o.memoizedProps;
        if (n = n.compare, n = n !== null ? n : qs, n(s, r) && e.ref === t.ref) return _r(e, t, i)
    }
    return t.flags |= 1, e = qr(o, r), e.ref = t.ref, e.return = t, t.child = e
}

function Sy(e, t, n, r, i) {
    if (e !== null) {
        var o = e.memoizedProps;
        if (qs(o, r) && e.ref === t.ref)
            if (Bt = !1, t.pendingProps = r = o, (e.lanes & i) !== 0) e.flags & 131072 && (Bt = !0);
            else return t.lanes = e.lanes, _r(e, t, i)
    }
    return Wd(e, t, n, r, i)
}

function wy(e, t, n) {
    var r = t.pendingProps,
        i = r.children,
        o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
        if (!(t.mode & 1)) t.memoizedState = {
            baseLanes: 0,
            cachePool: null,
            transitions: null
        }, Pe(fo, Kt), Kt |= n;
        else {
            if (!(n & 1073741824)) return e = o !== null ? o.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                baseLanes: e,
                cachePool: null,
                transitions: null
            }, t.updateQueue = null, Pe(fo, Kt), Kt |= e, null;
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            }, r = o !== null ? o.baseLanes : n, Pe(fo, Kt), Kt |= r
        }
    else o !== null ? (r = o.baseLanes | n, t.memoizedState = null) : r = n, Pe(fo, Kt), Kt |= r;
    return Ot(e, t, i, n), t.child
}

function xy(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
}

function Wd(e, t, n, r, i) {
    var o = Vt(n) ? Mi : kt.current;
    return o = Po(t, o), _o(t, i), n = ah(e, t, n, r, o, i), r = uh(), e !== null && !Bt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, _r(e, t, i)) : (Ae && r && Kp(t), t.flags |= 1, Ot(e, t, n, i), t.child)
}

function bv(e, t, n, r, i) {
    if (Vt(n)) {
        var o = !0;
        Za(t)
    } else o = !1;
    if (_o(t, i), t.stateNode === null) Oa(e, t), qg(t, n, r), $d(t, n, r, i), r = !0;
    else if (e === null) {
        var s = t.stateNode,
            l = t.memoizedProps;
        s.props = l;
        var a = s.context,
            u = n.contextType;
        typeof u == "object" && u !== null ? u = wn(u) : (u = Vt(n) ? Mi : kt.current, u = Po(t, u));
        var f = n.getDerivedStateFromProps,
            d = typeof f == "function" || typeof s.getSnapshotBeforeUpdate == "function";
        d || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (l !== r || a !== u) && _v(t, s, r, u), Lr = !1;
        var h = t.memoizedState;
        s.state = h, ru(t, r, s, i), a = t.memoizedState, l !== r || h !== a || jt.current || Lr ? (typeof f == "function" && (Ud(t, n, f, r), a = t.memoizedState), (l = Lr || yv(t, n, l, r, h, a, u)) ? (d || typeof s.UNSAFE_componentWillMount != "function" && typeof s.componentWillMount != "function" || (typeof s.componentWillMount == "function" && s.componentWillMount(), typeof s.UNSAFE_componentWillMount == "function" && s.UNSAFE_componentWillMount()), typeof s.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = a), s.props = r, s.state = a, s.context = u, r = l) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
    } else {
        s = t.stateNode, Yg(e, t), l = t.memoizedProps, u = t.type === t.elementType ? l : bn(t.type, l), s.props = u, d = t.pendingProps, h = s.context, a = n.contextType, typeof a == "object" && a !== null ? a = wn(a) : (a = Vt(n) ? Mi : kt.current, a = Po(t, a));
        var y = n.getDerivedStateFromProps;
        (f = typeof y == "function" || typeof s.getSnapshotBeforeUpdate == "function") || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (l !== d || h !== a) && _v(t, s, r, a), Lr = !1, h = t.memoizedState, s.state = h, ru(t, r, s, i);
        var _ = t.memoizedState;
        l !== d || h !== _ || jt.current || Lr ? (typeof y == "function" && (Ud(t, n, y, r), _ = t.memoizedState), (u = Lr || yv(t, n, u, r, h, _, a) || !1) ? (f || typeof s.UNSAFE_componentWillUpdate != "function" && typeof s.componentWillUpdate != "function" || (typeof s.componentWillUpdate == "function" && s.componentWillUpdate(r, _, a), typeof s.UNSAFE_componentWillUpdate == "function" && s.UNSAFE_componentWillUpdate(r, _, a)), typeof s.componentDidUpdate == "function" && (t.flags |= 4), typeof s.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof s.componentDidUpdate != "function" || l === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && h === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = _), s.props = r, s.state = _, s.context = a, r = u) : (typeof s.componentDidUpdate != "function" || l === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || l === e.memoizedProps && h === e.memoizedState || (t.flags |= 1024), r = !1)
    }
    return Gd(e, t, n, r, o, i)
}

function Gd(e, t, n, r, i, o) {
    xy(e, t);
    var s = (t.flags & 128) !== 0;
    if (!r && !s) return i && pv(t, n, !1), _r(e, t, o);
    r = t.stateNode, gx.current = t;
    var l = s && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && s ? (t.child = bo(t, e.child, null, o), t.child = bo(t, null, l, o)) : Ot(e, t, l, o), t.memoizedState = r.state, i && pv(t, n, !0), t.child
}

function Ey(e) {
    var t = e.stateNode;
    t.pendingContext ? dv(e, t.pendingContext, t.pendingContext !== t.context) : t.context && dv(e, t.context, !1), ih(e, t.containerInfo)
}

function Mv(e, t, n, r, i) {
    return ko(), Zp(i), t.flags |= 256, Ot(e, t, n, r), t.child
}
var Yd = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
};

function Xd(e) {
    return {
        baseLanes: e,
        cachePool: null,
        transitions: null
    }
}

function Cy(e, t, n) {
    var r = t.pendingProps,
        i = ze.current,
        o = !1,
        s = (t.flags & 128) !== 0,
        l;
    if ((l = s) || (l = e !== null && e.memoizedState === null ? !1 : (i & 2) !== 0), l ? (o = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (i |= 1), Pe(ze, i & 1), e === null) return jd(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (s = r.children, e = r.fallback, o ? (r = t.mode, o = t.child, s = {
        mode: "hidden",
        children: s
    }, !(r & 1) && o !== null ? (o.childLanes = 0, o.pendingProps = s) : o = Du(s, r, 0, null), e = Ti(e, r, n, null), o.return = t, e.return = t, o.sibling = e, t.child = o, t.child.memoizedState = Xd(n), t.memoizedState = Yd, e) : dh(t, s));
    if (i = e.memoizedState, i !== null && (l = i.dehydrated, l !== null)) return yx(e, t, s, r, l, i, n);
    if (o) {
        o = r.fallback, s = t.mode, i = e.child, l = i.sibling;
        var a = {
            mode: "hidden",
            children: r.children
        };
        return !(s & 1) && t.child !== i ? (r = t.child, r.childLanes = 0, r.pendingProps = a, t.deletions = null) : (r = qr(i, a), r.subtreeFlags = i.subtreeFlags & 14680064), l !== null ? o = qr(l, o) : (o = Ti(o, s, n, null), o.flags |= 2), o.return = t, r.return = t, r.sibling = o, t.child = r, r = o, o = t.child, s = e.child.memoizedState, s = s === null ? Xd(n) : {
            baseLanes: s.baseLanes | n,
            cachePool: null,
            transitions: s.transitions
        }, o.memoizedState = s, o.childLanes = e.childLanes & ~n, t.memoizedState = Yd, r
    }
    return o = e.child, e = o.sibling, r = qr(o, {
        mode: "visible",
        children: r.children
    }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
}

function dh(e, t) {
    return t = Du({
        mode: "visible",
        children: t
    }, e.mode, 0, null), t.return = e, e.child = t
}

function ha(e, t, n, r) {
    return r !== null && Zp(r), bo(t, e.child, null, n), e = dh(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
}

function yx(e, t, n, r, i, o, s) {
    if (n) return t.flags & 256 ? (t.flags &= -257, r = Bf(Error(W(422))), ha(e, t, s, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (o = r.fallback, i = t.mode, r = Du({
        mode: "visible",
        children: r.children
    }, i, 0, null), o = Ti(o, i, s, null), o.flags |= 2, r.return = t, o.return = t, r.sibling = o, t.child = r, t.mode & 1 && bo(t, e.child, null, s), t.child.memoizedState = Xd(s), t.memoizedState = Yd, o);
    if (!(t.mode & 1)) return ha(e, t, s, null);
    if (i.data === "$!") {
        if (r = i.nextSibling && i.nextSibling.dataset, r) var l = r.dgst;
        return r = l, o = Error(W(419)), r = Bf(o, r, void 0), ha(e, t, s, r)
    }
    if (l = (s & e.childLanes) !== 0, Bt || l) {
        if (r = ut, r !== null) {
            switch (s & -s) {
                case 4:
                    i = 2;
                    break;
                case 16:
                    i = 8;
                    break;
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                case 67108864:
                    i = 32;
                    break;
                case 536870912:
                    i = 268435456;
                    break;
                default:
                    i = 0
            }
            i = i & (r.suspendedLanes | s) ? 0 : i, i !== 0 && i !== o.retryLane && (o.retryLane = i, yr(e, i), Nn(r, e, i, -1))
        }
        return yh(), r = Bf(Error(W(421))), ha(e, t, s, r)
    }
    return i.data === "$?" ? (t.flags |= 128, t.child = e.child, t = Lx.bind(null, e), i._reactRetry = t, null) : (e = o.treeContext, en = Wr(i.nextSibling), tn = t, Ae = !0, On = null, e !== null && (dn[pn++] = dr, dn[pn++] = pr, dn[pn++] = Oi, dr = e.id, pr = e.overflow, Oi = t), t = dh(t, r.children), t.flags |= 4096, t)
}

function Ov(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t), Vd(e.return, t, n)
}

function jf(e, t, n, r, i) {
    var o = e.memoizedState;
    o === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: i
    } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i)
}

function Ty(e, t, n) {
    var r = t.pendingProps,
        i = r.revealOrder,
        o = r.tail;
    if (Ot(e, t, r.children, n), r = ze.current, r & 2) r = r & 1 | 2, t.flags |= 128;
    else {
        if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && Ov(e, n, t);
            else if (e.tag === 19) Ov(e, n, t);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        r &= 1
    }
    if (Pe(ze, r), !(t.mode & 1)) t.memoizedState = null;
    else switch (i) {
        case "forwards":
            for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && iu(e) === null && (i = n), n = n.sibling;
            n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), jf(t, !1, i, n, o);
            break;
        case "backwards":
            for (n = null, i = t.child, t.child = null; i !== null;) {
                if (e = i.alternate, e !== null && iu(e) === null) {
                    t.child = i;
                    break
                }
                e = i.sibling, i.sibling = n, n = i, i = e
            }
            jf(t, !0, n, null, o);
            break;
        case "together":
            jf(t, !1, null, null, void 0);
            break;
        default:
            t.memoizedState = null
    }
    return t.child
}

function Oa(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2)
}

function _r(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), Ni |= t.lanes, !(n & t.childLanes)) return null;
    if (e !== null && t.child !== e.child) throw Error(W(153));
    if (t.child !== null) {
        for (e = t.child, n = qr(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = qr(e, e.pendingProps), n.return = t;
        n.sibling = null
    }
    return t.child
}

function _x(e, t, n) {
    switch (t.tag) {
        case 3:
            Ey(t), ko();
            break;
        case 5:
            Zg(t);
            break;
        case 1:
            Vt(t.type) && Za(t);
            break;
        case 4:
            ih(t, t.stateNode.containerInfo);
            break;
        case 10:
            var r = t.type._context,
                i = t.memoizedProps.value;
            Pe(tu, r._currentValue), r._currentValue = i;
            break;
        case 13:
            if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (Pe(ze, ze.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? Cy(e, t, n) : (Pe(ze, ze.current & 1), e = _r(e, t, n), e !== null ? e.sibling : null);
            Pe(ze, ze.current & 1);
            break;
        case 19:
            if (r = (n & t.childLanes) !== 0, e.flags & 128) {
                if (r) return Ty(e, t, n);
                t.flags |= 128
            }
            if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), Pe(ze, ze.current), r) break;
            return null;
        case 22:
        case 23:
            return t.lanes = 0, wy(e, t, n)
    }
    return _r(e, t, n)
}
var Py, qd, ky, by;
Py = function(e, t) {
    for (var n = t.child; n !== null;) {
        if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
};
qd = function() {};
ky = function(e, t, n, r) {
    var i = e.memoizedProps;
    if (i !== r) {
        e = t.stateNode, xi(Xn.current);
        var o = null;
        switch (n) {
            case "input":
                i = gd(e, i), r = gd(e, r), o = [];
                break;
            case "select":
                i = je({}, i, {
                    value: void 0
                }), r = je({}, r, {
                    value: void 0
                }), o = [];
                break;
            case "textarea":
                i = Sd(e, i), r = Sd(e, r), o = [];
                break;
            default:
                typeof i.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Ka)
        }
        xd(n, r);
        var s;
        n = null;
        for (u in i)
            if (!r.hasOwnProperty(u) && i.hasOwnProperty(u) && i[u] != null)
                if (u === "style") {
                    var l = i[u];
                    for (s in l) l.hasOwnProperty(s) && (n || (n = {}), n[s] = "")
                } else u !== "dangerouslySetInnerHTML" && u !== "children" && u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && u !== "autoFocus" && (Us.hasOwnProperty(u) ? o || (o = []) : (o = o || []).push(u, null));
        for (u in r) {
            var a = r[u];
            if (l = i != null ? i[u] : void 0, r.hasOwnProperty(u) && a !== l && (a != null || l != null))
                if (u === "style")
                    if (l) {
                        for (s in l) !l.hasOwnProperty(s) || a && a.hasOwnProperty(s) || (n || (n = {}), n[s] = "");
                        for (s in a) a.hasOwnProperty(s) && l[s] !== a[s] && (n || (n = {}), n[s] = a[s])
                    } else n || (o || (o = []), o.push(u, n)), n = a;
            else u === "dangerouslySetInnerHTML" ? (a = a ? a.__html : void 0, l = l ? l.__html : void 0, a != null && l !== a && (o = o || []).push(u, a)) : u === "children" ? typeof a != "string" && typeof a != "number" || (o = o || []).push(u, "" + a) : u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && (Us.hasOwnProperty(u) ? (a != null && u === "onScroll" && be("scroll", e), o || l === a || (o = [])) : (o = o || []).push(u, a))
        }
        n && (o = o || []).push("style", n);
        var u = o;
        (t.updateQueue = u) && (t.flags |= 4)
    }
};
by = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
};

function vs(e, t) {
    if (!Ae) switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
    }
}

function xt(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
    if (t)
        for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 14680064, r |= i.flags & 14680064, i.return = e, i = i.sibling;
    else
        for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
    return e.subtreeFlags |= r, e.childLanes = n, t
}

function Sx(e, t, n) {
    var r = t.pendingProps;
    switch (Qp(t), t.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
            return xt(t), null;
        case 1:
            return Vt(t.type) && Qa(), xt(t), null;
        case 3:
            return r = t.stateNode, Mo(), Me(jt), Me(kt), sh(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (da(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, On !== null && (rp(On), On = null))), qd(e, t), xt(t), null;
        case 5:
            oh(t);
            var i = xi(el.current);
            if (n = t.type, e !== null && t.stateNode != null) ky(e, t, n, r, i), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
            else {
                if (!r) {
                    if (t.stateNode === null) throw Error(W(166));
                    return xt(t), null
                }
                if (e = xi(Xn.current), da(t)) {
                    r = t.stateNode, n = t.type;
                    var o = t.memoizedProps;
                    switch (r[Un] = t, r[Zs] = o, e = (t.mode & 1) !== 0, n) {
                        case "dialog":
                            be("cancel", r), be("close", r);
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            be("load", r);
                            break;
                        case "video":
                        case "audio":
                            for (i = 0; i < Ps.length; i++) be(Ps[i], r);
                            break;
                        case "source":
                            be("error", r);
                            break;
                        case "img":
                        case "image":
                        case "link":
                            be("error", r), be("load", r);
                            break;
                        case "details":
                            be("toggle", r);
                            break;
                        case "input":
                            B0(r, o), be("invalid", r);
                            break;
                        case "select":
                            r._wrapperState = {
                                wasMultiple: !!o.multiple
                            }, be("invalid", r);
                            break;
                        case "textarea":
                            V0(r, o), be("invalid", r)
                    }
                    xd(n, o), i = null;
                    for (var s in o)
                        if (o.hasOwnProperty(s)) {
                            var l = o[s];
                            s === "children" ? typeof l == "string" ? r.textContent !== l && (o.suppressHydrationWarning !== !0 && fa(r.textContent, l, e), i = ["children", l]) : typeof l == "number" && r.textContent !== "" + l && (o.suppressHydrationWarning !== !0 && fa(r.textContent, l, e), i = ["children", "" + l]) : Us.hasOwnProperty(s) && l != null && s === "onScroll" && be("scroll", r)
                        }
                    switch (n) {
                        case "input":
                            ra(r), j0(r, o, !0);
                            break;
                        case "textarea":
                            ra(r), U0(r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            typeof o.onClick == "function" && (r.onclick = Ka)
                    }
                    r = i, t.updateQueue = r, r !== null && (t.flags |= 4)
                } else {
                    s = i.nodeType === 9 ? i : i.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = tg(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = s.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = s.createElement(n, {
                        is: r.is
                    }) : (e = s.createElement(n), n === "select" && (s = e, r.multiple ? s.multiple = !0 : r.size && (s.size = r.size))) : e = s.createElementNS(e, n), e[Un] = t, e[Zs] = r, Py(e, t, !1, !1), t.stateNode = e;
                    e: {
                        switch (s = Ed(n, r), n) {
                            case "dialog":
                                be("cancel", e), be("close", e), i = r;
                                break;
                            case "iframe":
                            case "object":
                            case "embed":
                                be("load", e), i = r;
                                break;
                            case "video":
                            case "audio":
                                for (i = 0; i < Ps.length; i++) be(Ps[i], e);
                                i = r;
                                break;
                            case "source":
                                be("error", e), i = r;
                                break;
                            case "img":
                            case "image":
                            case "link":
                                be("error", e), be("load", e), i = r;
                                break;
                            case "details":
                                be("toggle", e), i = r;
                                break;
                            case "input":
                                B0(e, r), i = gd(e, r), be("invalid", e);
                                break;
                            case "option":
                                i = r;
                                break;
                            case "select":
                                e._wrapperState = {
                                    wasMultiple: !!r.multiple
                                }, i = je({}, r, {
                                    value: void 0
                                }), be("invalid", e);
                                break;
                            case "textarea":
                                V0(e, r), i = Sd(e, r), be("invalid", e);
                                break;
                            default:
                                i = r
                        }
                        xd(n, i),
                        l = i;
                        for (o in l)
                            if (l.hasOwnProperty(o)) {
                                var a = l[o];
                                o === "style" ? ig(e, a) : o === "dangerouslySetInnerHTML" ? (a = a ? a.__html : void 0, a != null && ng(e, a)) : o === "children" ? typeof a == "string" ? (n !== "textarea" || a !== "") && $s(e, a) : typeof a == "number" && $s(e, "" + a) : o !== "suppressContentEditableWarning" && o !== "suppressHydrationWarning" && o !== "autoFocus" && (Us.hasOwnProperty(o) ? a != null && o === "onScroll" && be("scroll", e) : a != null && zp(e, o, a, s))
                            }
                        switch (n) {
                            case "input":
                                ra(e), j0(e, r, !1);
                                break;
                            case "textarea":
                                ra(e), U0(e);
                                break;
                            case "option":
                                r.value != null && e.setAttribute("value", "" + Zr(r.value));
                                break;
                            case "select":
                                e.multiple = !!r.multiple, o = r.value, o != null ? mo(e, !!r.multiple, o, !1) : r.defaultValue != null && mo(e, !!r.multiple, r.defaultValue, !0);
                                break;
                            default:
                                typeof i.onClick == "function" && (e.onclick = Ka)
                        }
                        switch (n) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                r = !!r.autoFocus;
                                break e;
                            case "img":
                                r = !0;
                                break e;
                            default:
                                r = !1
                        }
                    }
                    r && (t.flags |= 4)
                }
                t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
            }
            return xt(t), null;
        case 6:
            if (e && t.stateNode != null) by(e, t, e.memoizedProps, r);
            else {
                if (typeof r != "string" && t.stateNode === null) throw Error(W(166));
                if (n = xi(el.current), xi(Xn.current), da(t)) {
                    if (r = t.stateNode, n = t.memoizedProps, r[Un] = t, (o = r.nodeValue !== n) && (e = tn, e !== null)) switch (e.tag) {
                        case 3:
                            fa(r.nodeValue, n, (e.mode & 1) !== 0);
                            break;
                        case 5:
                            e.memoizedProps.suppressHydrationWarning !== !0 && fa(r.nodeValue, n, (e.mode & 1) !== 0)
                    }
                    o && (t.flags |= 4)
                } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[Un] = t, t.stateNode = r
            }
            return xt(t), null;
        case 13:
            if (Me(ze), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                if (Ae && en !== null && t.mode & 1 && !(t.flags & 128)) Wg(), ko(), t.flags |= 98560, o = !1;
                else if (o = da(t), r !== null && r.dehydrated !== null) {
                    if (e === null) {
                        if (!o) throw Error(W(318));
                        if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(W(317));
                        o[Un] = t
                    } else ko(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                    xt(t), o = !1
                } else On !== null && (rp(On), On = null), o = !0;
                if (!o) return t.flags & 65536 ? t : null
            }
            return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || ze.current & 1 ? rt === 0 && (rt = 3) : yh())), t.updateQueue !== null && (t.flags |= 4), xt(t), null);
        case 4:
            return Mo(), qd(e, t), e === null && Ks(t.stateNode.containerInfo), xt(t), null;
        case 10:
            return th(t.type._context), xt(t), null;
        case 17:
            return Vt(t.type) && Qa(), xt(t), null;
        case 19:
            if (Me(ze), o = t.memoizedState, o === null) return xt(t), null;
            if (r = (t.flags & 128) !== 0, s = o.rendering, s === null)
                if (r) vs(o, !1);
                else {
                    if (rt !== 0 || e !== null && e.flags & 128)
                        for (e = t.child; e !== null;) {
                            if (s = iu(e), s !== null) {
                                for (t.flags |= 128, vs(o, !1), r = s.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) o = n, e = r, o.flags &= 14680066, s = o.alternate, s === null ? (o.childLanes = 0, o.lanes = e, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = s.childLanes, o.lanes = s.lanes, o.child = s.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = s.memoizedProps, o.memoizedState = s.memoizedState, o.updateQueue = s.updateQueue, o.type = s.type, e = s.dependencies, o.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }), n = n.sibling;
                                return Pe(ze, ze.current & 1 | 2), t.child
                            }
                            e = e.sibling
                        }
                    o.tail !== null && Xe() > Lo && (t.flags |= 128, r = !0, vs(o, !1), t.lanes = 4194304)
                }
            else {
                if (!r)
                    if (e = iu(s), e !== null) {
                        if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), vs(o, !0), o.tail === null && o.tailMode === "hidden" && !s.alternate && !Ae) return xt(t), null
                    } else 2 * Xe() - o.renderingStartTime > Lo && n !== 1073741824 && (t.flags |= 128, r = !0, vs(o, !1), t.lanes = 4194304);
                o.isBackwards ? (s.sibling = t.child, t.child = s) : (n = o.last, n !== null ? n.sibling = s : t.child = s, o.last = s)
            }
            return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = Xe(), t.sibling = null, n = ze.current, Pe(ze, r ? n & 1 | 2 : n & 1), t) : (xt(t), null);
        case 22:
        case 23:
            return gh(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? Kt & 1073741824 && (xt(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : xt(t), null;
        case 24:
            return null;
        case 25:
            return null
    }
    throw Error(W(156, t.tag))
}

function wx(e, t) {
    switch (Qp(t), t.tag) {
        case 1:
            return Vt(t.type) && Qa(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
            return Mo(), Me(jt), Me(kt), sh(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
        case 5:
            return oh(t), null;
        case 13:
            if (Me(ze), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                if (t.alternate === null) throw Error(W(340));
                ko()
            }
            return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
            return Me(ze), null;
        case 4:
            return Mo(), null;
        case 10:
            return th(t.type._context), null;
        case 22:
        case 23:
            return gh(), null;
        case 24:
            return null;
        default:
            return null
    }
}
var ma = !1,
    Et = !1,
    xx = typeof WeakSet == "function" ? WeakSet : Set,
    ee = null;

function co(e, t) {
    var n = e.ref;
    if (n !== null)
        if (typeof n == "function") try {
            n(null)
        } catch (r) {
            $e(e, t, r)
        } else n.current = null
}

function Kd(e, t, n) {
    try {
        n()
    } catch (r) {
        $e(e, t, r)
    }
}
var Lv = !1;

function Ex(e, t) {
    if (Ad = Ya, e = Ng(), qp(e)) {
        if ("selectionStart" in e) var n = {
            start: e.selectionStart,
            end: e.selectionEnd
        };
        else e: {
            n = (n = e.ownerDocument) && n.defaultView || window;
            var r = n.getSelection && n.getSelection();
            if (r && r.rangeCount !== 0) {
                n = r.anchorNode;
                var i = r.anchorOffset,
                    o = r.focusNode;
                r = r.focusOffset;
                try {
                    n.nodeType, o.nodeType
                } catch {
                    n = null;
                    break e
                }
                var s = 0,
                    l = -1,
                    a = -1,
                    u = 0,
                    f = 0,
                    d = e,
                    h = null;
                t: for (;;) {
                    for (var y; d !== n || i !== 0 && d.nodeType !== 3 || (l = s + i), d !== o || r !== 0 && d.nodeType !== 3 || (a = s + r), d.nodeType === 3 && (s += d.nodeValue.length), (y = d.firstChild) !== null;) h = d, d = y;
                    for (;;) {
                        if (d === e) break t;
                        if (h === n && ++u === i && (l = s), h === o && ++f === r && (a = s), (y = d.nextSibling) !== null) break;
                        d = h, h = d.parentNode
                    }
                    d = y
                }
                n = l === -1 || a === -1 ? null : {
                    start: l,
                    end: a
                }
            } else n = null
        }
        n = n || {
            start: 0,
            end: 0
        }
    } else n = null;
    for (Rd = {
            focusedElem: e,
            selectionRange: n
        }, Ya = !1, ee = t; ee !== null;)
        if (t = ee, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, ee = e;
        else
            for (; ee !== null;) {
                t = ee;
                try {
                    var _ = t.alternate;
                    if (t.flags & 1024) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if (_ !== null) {
                                var v = _.memoizedProps,
                                    E = _.memoizedState,
                                    m = t.stateNode,
                                    g = m.getSnapshotBeforeUpdate(t.elementType === t.type ? v : bn(t.type, v), E);
                                m.__reactInternalSnapshotBeforeUpdate = g
                            }
                            break;
                        case 3:
                            var S = t.stateNode.containerInfo;
                            S.nodeType === 1 ? S.textContent = "" : S.nodeType === 9 && S.documentElement && S.removeChild(S.documentElement);
                            break;
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            throw Error(W(163))
                    }
                } catch (x) {
                    $e(t, t.return, x)
                }
                if (e = t.sibling, e !== null) {
                    e.return = t.return, ee = e;
                    break
                }
                ee = t.return
            }
    return _ = Lv, Lv = !1, _
}

function Ds(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null, r !== null) {
        var i = r = r.next;
        do {
            if ((i.tag & e) === e) {
                var o = i.destroy;
                i.destroy = void 0, o !== void 0 && Kd(t, n, o)
            }
            i = i.next
        } while (i !== r)
    }
}

function Au(e, t) {
    if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
        var n = t = t.next;
        do {
            if ((n.tag & e) === e) {
                var r = n.create;
                n.destroy = r()
            }
            n = n.next
        } while (n !== t)
    }
}

function Qd(e) {
    var t = e.ref;
    if (t !== null) {
        var n = e.stateNode;
        switch (e.tag) {
            case 5:
                e = n;
                break;
            default:
                e = n
        }
        typeof t == "function" ? t(e) : t.current = e
    }
}

function My(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, My(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[Un], delete t[Zs], delete t[Id], delete t[ox], delete t[sx])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
}

function Oy(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}

function Nv(e) {
    e: for (;;) {
        for (; e.sibling === null;) {
            if (e.return === null || Oy(e.return)) return null;
            e = e.return
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
            if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
            e.child.return = e, e = e.child
        }
        if (!(e.flags & 2)) return e.stateNode
    }
}

function Zd(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Ka));
    else if (r !== 4 && (e = e.child, e !== null))
        for (Zd(e, t, n), e = e.sibling; e !== null;) Zd(e, t, n), e = e.sibling
}

function Jd(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
        for (Jd(e, t, n), e = e.sibling; e !== null;) Jd(e, t, n), e = e.sibling
}
var pt = null,
    Mn = !1;

function br(e, t, n) {
    for (n = n.child; n !== null;) Ly(e, t, n), n = n.sibling
}

function Ly(e, t, n) {
    if (Yn && typeof Yn.onCommitFiberUnmount == "function") try {
        Yn.onCommitFiberUnmount(Tu, n)
    } catch {}
    switch (n.tag) {
        case 5:
            Et || co(n, t);
        case 6:
            var r = pt,
                i = Mn;
            pt = null, br(e, t, n), pt = r, Mn = i, pt !== null && (Mn ? (e = pt, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : pt.removeChild(n.stateNode));
            break;
        case 18:
            pt !== null && (Mn ? (e = pt, n = n.stateNode, e.nodeType === 8 ? Af(e.parentNode, n) : e.nodeType === 1 && Af(e, n), Ys(e)) : Af(pt, n.stateNode));
            break;
        case 4:
            r = pt, i = Mn, pt = n.stateNode.containerInfo, Mn = !0, br(e, t, n), pt = r, Mn = i;
            break;
        case 0:
        case 11:
        case 14:
        case 15:
            if (!Et && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
                i = r = r.next;
                do {
                    var o = i,
                        s = o.destroy;
                    o = o.tag, s !== void 0 && (o & 2 || o & 4) && Kd(n, t, s), i = i.next
                } while (i !== r)
            }
            br(e, t, n);
            break;
        case 1:
            if (!Et && (co(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
                r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
            } catch (l) {
                $e(n, t, l)
            }
            br(e, t, n);
            break;
        case 21:
            br(e, t, n);
            break;
        case 22:
            n.mode & 1 ? (Et = (r = Et) || n.memoizedState !== null, br(e, t, n), Et = r) : br(e, t, n);
            break;
        default:
            br(e, t, n)
    }
}

function Av(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new xx), t.forEach(function(r) {
            var i = Nx.bind(null, e, r);
            n.has(r) || (n.add(r), r.then(i, i))
        })
    }
}

function kn(e, t) {
    var n = t.deletions;
    if (n !== null)
        for (var r = 0; r < n.length; r++) {
            var i = n[r];
            try {
                var o = e,
                    s = t,
                    l = s;
                e: for (; l !== null;) {
                    switch (l.tag) {
                        case 5:
                            pt = l.stateNode, Mn = !1;
                            break e;
                        case 3:
                            pt = l.stateNode.containerInfo, Mn = !0;
                            break e;
                        case 4:
                            pt = l.stateNode.containerInfo, Mn = !0;
                            break e
                    }
                    l = l.return
                }
                if (pt === null) throw Error(W(160));
                Ly(o, s, i), pt = null, Mn = !1;
                var a = i.alternate;
                a !== null && (a.return = null), i.return = null
            } catch (u) {
                $e(i, t, u)
            }
        }
    if (t.subtreeFlags & 12854)
        for (t = t.child; t !== null;) Ny(t, e), t = t.sibling
}

function Ny(e, t) {
    var n = e.alternate,
        r = e.flags;
    switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
            if (kn(t, e), Bn(e), r & 4) {
                try {
                    Ds(3, e, e.return), Au(3, e)
                } catch (v) {
                    $e(e, e.return, v)
                }
                try {
                    Ds(5, e, e.return)
                } catch (v) {
                    $e(e, e.return, v)
                }
            }
            break;
        case 1:
            kn(t, e), Bn(e), r & 512 && n !== null && co(n, n.return);
            break;
        case 5:
            if (kn(t, e), Bn(e), r & 512 && n !== null && co(n, n.return), e.flags & 32) {
                var i = e.stateNode;
                try {
                    $s(i, "")
                } catch (v) {
                    $e(e, e.return, v)
                }
            }
            if (r & 4 && (i = e.stateNode, i != null)) {
                var o = e.memoizedProps,
                    s = n !== null ? n.memoizedProps : o,
                    l = e.type,
                    a = e.updateQueue;
                if (e.updateQueue = null, a !== null) try {
                    l === "input" && o.type === "radio" && o.name != null && J1(i, o), Ed(l, s);
                    var u = Ed(l, o);
                    for (s = 0; s < a.length; s += 2) {
                        var f = a[s],
                            d = a[s + 1];
                        f === "style" ? ig(i, d) : f === "dangerouslySetInnerHTML" ? ng(i, d) : f === "children" ? $s(i, d) : zp(i, f, d, u)
                    }
                    switch (l) {
                        case "input":
                            yd(i, o);
                            break;
                        case "textarea":
                            eg(i, o);
                            break;
                        case "select":
                            var h = i._wrapperState.wasMultiple;
                            i._wrapperState.wasMultiple = !!o.multiple;
                            var y = o.value;
                            y != null ? mo(i, !!o.multiple, y, !1) : h !== !!o.multiple && (o.defaultValue != null ? mo(i, !!o.multiple, o.defaultValue, !0) : mo(i, !!o.multiple, o.multiple ? [] : "", !1))
                    }
                    i[Zs] = o
                } catch (v) {
                    $e(e, e.return, v)
                }
            }
            break;
        case 6:
            if (kn(t, e), Bn(e), r & 4) {
                if (e.stateNode === null) throw Error(W(162));
                i = e.stateNode, o = e.memoizedProps;
                try {
                    i.nodeValue = o
                } catch (v) {
                    $e(e, e.return, v)
                }
            }
            break;
        case 3:
            if (kn(t, e), Bn(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                Ys(t.containerInfo)
            } catch (v) {
                $e(e, e.return, v)
            }
            break;
        case 4:
            kn(t, e), Bn(e);
            break;
        case 13:
            kn(t, e), Bn(e), i = e.child, i.flags & 8192 && (o = i.memoizedState !== null, i.stateNode.isHidden = o, !o || i.alternate !== null && i.alternate.memoizedState !== null || (mh = Xe())), r & 4 && Av(e);
            break;
        case 22:
            if (f = n !== null && n.memoizedState !== null, e.mode & 1 ? (Et = (u = Et) || f, kn(t, e), Et = u) : kn(t, e), Bn(e), r & 8192) {
                if (u = e.memoizedState !== null, (e.stateNode.isHidden = u) && !f && e.mode & 1)
                    for (ee = e, f = e.child; f !== null;) {
                        for (d = ee = f; ee !== null;) {
                            switch (h = ee, y = h.child, h.tag) {
                                case 0:
                                case 11:
                                case 14:
                                case 15:
                                    Ds(4, h, h.return);
                                    break;
                                case 1:
                                    co(h, h.return);
                                    var _ = h.stateNode;
                                    if (typeof _.componentWillUnmount == "function") {
                                        r = h, n = h.return;
                                        try {
                                            t = r, _.props = t.memoizedProps, _.state = t.memoizedState, _.componentWillUnmount()
                                        } catch (v) {
                                            $e(r, n, v)
                                        }
                                    }
                                    break;
                                case 5:
                                    co(h, h.return);
                                    break;
                                case 22:
                                    if (h.memoizedState !== null) {
                                        Dv(d);
                                        continue
                                    }
                            }
                            y !== null ? (y.return = h, ee = y) : Dv(d)
                        }
                        f = f.sibling
                    }
                e: for (f = null, d = e;;) {
                    if (d.tag === 5) {
                        if (f === null) {
                            f = d;
                            try {
                                i = d.stateNode, u ? (o = i.style, typeof o.setProperty == "function" ? o.setProperty("display", "none", "important") : o.display = "none") : (l = d.stateNode, a = d.memoizedProps.style, s = a != null && a.hasOwnProperty("display") ? a.display : null, l.style.display = rg("display", s))
                            } catch (v) {
                                $e(e, e.return, v)
                            }
                        }
                    } else if (d.tag === 6) {
                        if (f === null) try {
                            d.stateNode.nodeValue = u ? "" : d.memoizedProps
                        } catch (v) {
                            $e(e, e.return, v)
                        }
                    } else if ((d.tag !== 22 && d.tag !== 23 || d.memoizedState === null || d === e) && d.child !== null) {
                        d.child.return = d, d = d.child;
                        continue
                    }
                    if (d === e) break e;
                    for (; d.sibling === null;) {
                        if (d.return === null || d.return === e) break e;
                        f === d && (f = null), d = d.return
                    }
                    f === d && (f = null), d.sibling.return = d.return, d = d.sibling
                }
            }
            break;
        case 19:
            kn(t, e), Bn(e), r & 4 && Av(e);
            break;
        case 21:
            break;
        default:
            kn(t, e), Bn(e)
    }
}

function Bn(e) {
    var t = e.flags;
    if (t & 2) {
        try {
            e: {
                for (var n = e.return; n !== null;) {
                    if (Oy(n)) {
                        var r = n;
                        break e
                    }
                    n = n.return
                }
                throw Error(W(160))
            }
            switch (r.tag) {
                case 5:
                    var i = r.stateNode;
                    r.flags & 32 && ($s(i, ""), r.flags &= -33);
                    var o = Nv(e);
                    Jd(e, o, i);
                    break;
                case 3:
                case 4:
                    var s = r.stateNode.containerInfo,
                        l = Nv(e);
                    Zd(e, l, s);
                    break;
                default:
                    throw Error(W(161))
            }
        }
        catch (a) {
            $e(e, e.return, a)
        }
        e.flags &= -3
    }
    t & 4096 && (e.flags &= -4097)
}

function Cx(e, t, n) {
    ee = e, Ay(e)
}

function Ay(e, t, n) {
    for (var r = (e.mode & 1) !== 0; ee !== null;) {
        var i = ee,
            o = i.child;
        if (i.tag === 22 && r) {
            var s = i.memoizedState !== null || ma;
            if (!s) {
                var l = i.alternate,
                    a = l !== null && l.memoizedState !== null || Et;
                l = ma;
                var u = Et;
                if (ma = s, (Et = a) && !u)
                    for (ee = i; ee !== null;) s = ee, a = s.child, s.tag === 22 && s.memoizedState !== null ? zv(i) : a !== null ? (a.return = s, ee = a) : zv(i);
                for (; o !== null;) ee = o, Ay(o), o = o.sibling;
                ee = i, ma = l, Et = u
            }
            Rv(e)
        } else i.subtreeFlags & 8772 && o !== null ? (o.return = i, ee = o) : Rv(e)
    }
}

function Rv(e) {
    for (; ee !== null;) {
        var t = ee;
        if (t.flags & 8772) {
            var n = t.alternate;
            try {
                if (t.flags & 8772) switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        Et || Au(5, t);
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (t.flags & 4 && !Et)
                            if (n === null) r.componentDidMount();
                            else {
                                var i = t.elementType === t.type ? n.memoizedProps : bn(t.type, n.memoizedProps);
                                r.componentDidUpdate(i, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                            }
                        var o = t.updateQueue;
                        o !== null && gv(t, o, r);
                        break;
                    case 3:
                        var s = t.updateQueue;
                        if (s !== null) {
                            if (n = null, t.child !== null) switch (t.child.tag) {
                                case 5:
                                    n = t.child.stateNode;
                                    break;
                                case 1:
                                    n = t.child.stateNode
                            }
                            gv(t, s, n)
                        }
                        break;
                    case 5:
                        var l = t.stateNode;
                        if (n === null && t.flags & 4) {
                            n = l;
                            var a = t.memoizedProps;
                            switch (t.type) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    a.autoFocus && n.focus();
                                    break;
                                case "img":
                                    a.src && (n.src = a.src)
                            }
                        }
                        break;
                    case 6:
                        break;
                    case 4:
                        break;
                    case 12:
                        break;
                    case 13:
                        if (t.memoizedState === null) {
                            var u = t.alternate;
                            if (u !== null) {
                                var f = u.memoizedState;
                                if (f !== null) {
                                    var d = f.dehydrated;
                                    d !== null && Ys(d)
                                }
                            }
                        }
                        break;
                    case 19:
                    case 17:
                    case 21:
                    case 22:
                    case 23:
                    case 25:
                        break;
                    default:
                        throw Error(W(163))
                }
                Et || t.flags & 512 && Qd(t)
            } catch (h) {
                $e(t, t.return, h)
            }
        }
        if (t === e) {
            ee = null;
            break
        }
        if (n = t.sibling, n !== null) {
            n.return = t.return, ee = n;
            break
        }
        ee = t.return
    }
}

function Dv(e) {
    for (; ee !== null;) {
        var t = ee;
        if (t === e) {
            ee = null;
            break
        }
        var n = t.sibling;
        if (n !== null) {
            n.return = t.return, ee = n;
            break
        }
        ee = t.return
    }
}

function zv(e) {
    for (; ee !== null;) {
        var t = ee;
        try {
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    var n = t.return;
                    try {
                        Au(4, t)
                    } catch (a) {
                        $e(t, n, a)
                    }
                    break;
                case 1:
                    var r = t.stateNode;
                    if (typeof r.componentDidMount == "function") {
                        var i = t.return;
                        try {
                            r.componentDidMount()
                        } catch (a) {
                            $e(t, i, a)
                        }
                    }
                    var o = t.return;
                    try {
                        Qd(t)
                    } catch (a) {
                        $e(t, o, a)
                    }
                    break;
                case 5:
                    var s = t.return;
                    try {
                        Qd(t)
                    } catch (a) {
                        $e(t, s, a)
                    }
            }
        } catch (a) {
            $e(t, t.return, a)
        }
        if (t === e) {
            ee = null;
            break
        }
        var l = t.sibling;
        if (l !== null) {
            l.return = t.return, ee = l;
            break
        }
        ee = t.return
    }
}
var Tx = Math.ceil,
    lu = xr.ReactCurrentDispatcher,
    ph = xr.ReactCurrentOwner,
    _n = xr.ReactCurrentBatchConfig,
    ye = 0,
    ut = null,
    Ze = null,
    vt = 0,
    Kt = 0,
    fo = ri(0),
    rt = 0,
    il = null,
    Ni = 0,
    Ru = 0,
    hh = 0,
    zs = null,
    It = null,
    mh = 0,
    Lo = 1 / 0,
    ar = null,
    au = !1,
    ep = null,
    Yr = null,
    va = !1,
    Dr = null,
    uu = 0,
    Is = 0,
    tp = null,
    La = -1,
    Na = 0;

function Nt() {
    return ye & 6 ? Xe() : La !== -1 ? La : La = Xe()
}

function Xr(e) {
    return e.mode & 1 ? ye & 2 && vt !== 0 ? vt & -vt : ax.transition !== null ? (Na === 0 && (Na = vg()), Na) : (e = Se, e !== 0 || (e = window.event, e = e === void 0 ? 16 : Eg(e.type)), e) : 1
}

function Nn(e, t, n, r) {
    if (50 < Is) throw Is = 0, tp = null, Error(W(185));
    hl(e, n, r), (!(ye & 2) || e !== ut) && (e === ut && (!(ye & 2) && (Ru |= n), rt === 4 && Ar(e, vt)), Ut(e, r), n === 1 && ye === 0 && !(t.mode & 1) && (Lo = Xe() + 500, Ou && ii()))
}

function Ut(e, t) {
    var n = e.callbackNode;
    a2(e, t);
    var r = Ga(e, e === ut ? vt : 0);
    if (r === 0) n !== null && W0(n), e.callbackNode = null, e.callbackPriority = 0;
    else if (t = r & -r, e.callbackPriority !== t) {
        if (n != null && W0(n), t === 1) e.tag === 0 ? lx(Iv.bind(null, e)) : Ug(Iv.bind(null, e)), rx(function() {
            !(ye & 6) && ii()
        }), n = null;
        else {
            switch (gg(r)) {
                case 1:
                    n = Vp;
                    break;
                case 4:
                    n = hg;
                    break;
                case 16:
                    n = Wa;
                    break;
                case 536870912:
                    n = mg;
                    break;
                default:
                    n = Wa
            }
            n = Vy(n, Ry.bind(null, e))
        }
        e.callbackPriority = t, e.callbackNode = n
    }
}

function Ry(e, t) {
    if (La = -1, Na = 0, ye & 6) throw Error(W(327));
    var n = e.callbackNode;
    if (So() && e.callbackNode !== n) return null;
    var r = Ga(e, e === ut ? vt : 0);
    if (r === 0) return null;
    if (r & 30 || r & e.expiredLanes || t) t = cu(e, r);
    else {
        t = r;
        var i = ye;
        ye |= 2;
        var o = zy();
        (ut !== e || vt !== t) && (ar = null, Lo = Xe() + 500, Ci(e, t));
        do try {
            bx();
            break
        } catch (l) {
            Dy(e, l)
        }
        while (1);
        eh(), lu.current = o, ye = i, Ze !== null ? t = 0 : (ut = null, vt = 0, t = rt)
    }
    if (t !== 0) {
        if (t === 2 && (i = bd(e), i !== 0 && (r = i, t = np(e, i))), t === 1) throw n = il, Ci(e, 0), Ar(e, r), Ut(e, Xe()), n;
        if (t === 6) Ar(e, r);
        else {
            if (i = e.current.alternate, !(r & 30) && !Px(i) && (t = cu(e, r), t === 2 && (o = bd(e), o !== 0 && (r = o, t = np(e, o))), t === 1)) throw n = il, Ci(e, 0), Ar(e, r), Ut(e, Xe()), n;
            switch (e.finishedWork = i, e.finishedLanes = r, t) {
                case 0:
                case 1:
                    throw Error(W(345));
                case 2:
                    yi(e, It, ar);
                    break;
                case 3:
                    if (Ar(e, r), (r & 130023424) === r && (t = mh + 500 - Xe(), 10 < t)) {
                        if (Ga(e, 0) !== 0) break;
                        if (i = e.suspendedLanes, (i & r) !== r) {
                            Nt(), e.pingedLanes |= e.suspendedLanes & i;
                            break
                        }
                        e.timeoutHandle = zd(yi.bind(null, e, It, ar), t);
                        break
                    }
                    yi(e, It, ar);
                    break;
                case 4:
                    if (Ar(e, r), (r & 4194240) === r) break;
                    for (t = e.eventTimes, i = -1; 0 < r;) {
                        var s = 31 - Ln(r);
                        o = 1 << s, s = t[s], s > i && (i = s), r &= ~o
                    }
                    if (r = i, r = Xe() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * Tx(r / 1960)) - r, 10 < r) {
                        e.timeoutHandle = zd(yi.bind(null, e, It, ar), r);
                        break
                    }
                    yi(e, It, ar);
                    break;
                case 5:
                    yi(e, It, ar);
                    break;
                default:
                    throw Error(W(329))
            }
        }
    }
    return Ut(e, Xe()), e.callbackNode === n ? Ry.bind(null, e) : null
}

function np(e, t) {
    var n = zs;
    return e.current.memoizedState.isDehydrated && (Ci(e, t).flags |= 256), e = cu(e, t), e !== 2 && (t = It, It = n, t !== null && rp(t)), e
}

function rp(e) {
    It === null ? It = e : It.push.apply(It, e)
}

function Px(e) {
    for (var t = e;;) {
        if (t.flags & 16384) {
            var n = t.updateQueue;
            if (n !== null && (n = n.stores, n !== null))
                for (var r = 0; r < n.length; r++) {
                    var i = n[r],
                        o = i.getSnapshot;
                    i = i.value;
                    try {
                        if (!Rn(o(), i)) return !1
                    } catch {
                        return !1
                    }
                }
        }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return !0;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
    }
    return !0
}

function Ar(e, t) {
    for (t &= ~hh, t &= ~Ru, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
        var n = 31 - Ln(t),
            r = 1 << n;
        e[n] = -1, t &= ~r
    }
}

function Iv(e) {
    if (ye & 6) throw Error(W(327));
    So();
    var t = Ga(e, 0);
    if (!(t & 1)) return Ut(e, Xe()), null;
    var n = cu(e, t);
    if (e.tag !== 0 && n === 2) {
        var r = bd(e);
        r !== 0 && (t = r, n = np(e, r))
    }
    if (n === 1) throw n = il, Ci(e, 0), Ar(e, t), Ut(e, Xe()), n;
    if (n === 6) throw Error(W(345));
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, yi(e, It, ar), Ut(e, Xe()), null
}

function vh(e, t) {
    var n = ye;
    ye |= 1;
    try {
        return e(t)
    } finally {
        ye = n, ye === 0 && (Lo = Xe() + 500, Ou && ii())
    }
}

function Ai(e) {
    Dr !== null && Dr.tag === 0 && !(ye & 6) && So();
    var t = ye;
    ye |= 1;
    var n = _n.transition,
        r = Se;
    try {
        if (_n.transition = null, Se = 1, e) return e()
    } finally {
        Se = r, _n.transition = n, ye = t, !(ye & 6) && ii()
    }
}

function gh() {
    Kt = fo.current, Me(fo)
}

function Ci(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, nx(n)), Ze !== null)
        for (n = Ze.return; n !== null;) {
            var r = n;
            switch (Qp(r), r.tag) {
                case 1:
                    r = r.type.childContextTypes, r != null && Qa();
                    break;
                case 3:
                    Mo(), Me(jt), Me(kt), sh();
                    break;
                case 5:
                    oh(r);
                    break;
                case 4:
                    Mo();
                    break;
                case 13:
                    Me(ze);
                    break;
                case 19:
                    Me(ze);
                    break;
                case 10:
                    th(r.type._context);
                    break;
                case 22:
                case 23:
                    gh()
            }
            n = n.return
        }
    if (ut = e, Ze = e = qr(e.current, null), vt = Kt = t, rt = 0, il = null, hh = Ru = Ni = 0, It = zs = null, wi !== null) {
        for (t = 0; t < wi.length; t++)
            if (n = wi[t], r = n.interleaved, r !== null) {
                n.interleaved = null;
                var i = r.next,
                    o = n.pending;
                if (o !== null) {
                    var s = o.next;
                    o.next = i, r.next = s
                }
                n.pending = r
            }
        wi = null
    }
    return e
}

function Dy(e, t) {
    do {
        var n = Ze;
        try {
            if (eh(), ba.current = su, ou) {
                for (var r = Be.memoizedState; r !== null;) {
                    var i = r.queue;
                    i !== null && (i.pending = null), r = r.next
                }
                ou = !1
            }
            if (Li = 0, at = tt = Be = null, Rs = !1, tl = 0, ph.current = null, n === null || n.return === null) {
                rt = 1, il = t, Ze = null;
                break
            }
            e: {
                var o = e,
                    s = n.return,
                    l = n,
                    a = t;
                if (t = vt, l.flags |= 32768, a !== null && typeof a == "object" && typeof a.then == "function") {
                    var u = a,
                        f = l,
                        d = f.tag;
                    if (!(f.mode & 1) && (d === 0 || d === 11 || d === 15)) {
                        var h = f.alternate;
                        h ? (f.updateQueue = h.updateQueue, f.memoizedState = h.memoizedState, f.lanes = h.lanes) : (f.updateQueue = null, f.memoizedState = null)
                    }
                    var y = Cv(s);
                    if (y !== null) {
                        y.flags &= -257, Tv(y, s, l, o, t), y.mode & 1 && Ev(o, u, t), t = y, a = u;
                        var _ = t.updateQueue;
                        if (_ === null) {
                            var v = new Set;
                            v.add(a), t.updateQueue = v
                        } else _.add(a);
                        break e
                    } else {
                        if (!(t & 1)) {
                            Ev(o, u, t), yh();
                            break e
                        }
                        a = Error(W(426))
                    }
                } else if (Ae && l.mode & 1) {
                    var E = Cv(s);
                    if (E !== null) {
                        !(E.flags & 65536) && (E.flags |= 256), Tv(E, s, l, o, t), Zp(Oo(a, l));
                        break e
                    }
                }
                o = a = Oo(a, l),
                rt !== 4 && (rt = 2),
                zs === null ? zs = [o] : zs.push(o),
                o = s;do {
                    switch (o.tag) {
                        case 3:
                            o.flags |= 65536, t &= -t, o.lanes |= t;
                            var m = yy(o, a, t);
                            vv(o, m);
                            break e;
                        case 1:
                            l = a;
                            var g = o.type,
                                S = o.stateNode;
                            if (!(o.flags & 128) && (typeof g.getDerivedStateFromError == "function" || S !== null && typeof S.componentDidCatch == "function" && (Yr === null || !Yr.has(S)))) {
                                o.flags |= 65536, t &= -t, o.lanes |= t;
                                var x = _y(o, l, t);
                                vv(o, x);
                                break e
                            }
                    }
                    o = o.return
                } while (o !== null)
            }
            Fy(n)
        } catch (P) {
            t = P, Ze === n && n !== null && (Ze = n = n.return);
            continue
        }
        break
    } while (1)
}

function zy() {
    var e = lu.current;
    return lu.current = su, e === null ? su : e
}

function yh() {
    (rt === 0 || rt === 3 || rt === 2) && (rt = 4), ut === null || !(Ni & 268435455) && !(Ru & 268435455) || Ar(ut, vt)
}

function cu(e, t) {
    var n = ye;
    ye |= 2;
    var r = zy();
    (ut !== e || vt !== t) && (ar = null, Ci(e, t));
    do try {
        kx();
        break
    } catch (i) {
        Dy(e, i)
    }
    while (1);
    if (eh(), ye = n, lu.current = r, Ze !== null) throw Error(W(261));
    return ut = null, vt = 0, rt
}

function kx() {
    for (; Ze !== null;) Iy(Ze)
}

function bx() {
    for (; Ze !== null && !Jw();) Iy(Ze)
}

function Iy(e) {
    var t = jy(e.alternate, e, Kt);
    e.memoizedProps = e.pendingProps, t === null ? Fy(e) : Ze = t, ph.current = null
}

function Fy(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return, t.flags & 32768) {
            if (n = wx(n, t), n !== null) {
                n.flags &= 32767, Ze = n;
                return
            }
            if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
            else {
                rt = 6, Ze = null;
                return
            }
        } else if (n = Sx(n, t, Kt), n !== null) {
            Ze = n;
            return
        }
        if (t = t.sibling, t !== null) {
            Ze = t;
            return
        }
        Ze = t = e
    } while (t !== null);
    rt === 0 && (rt = 5)
}

function yi(e, t, n) {
    var r = Se,
        i = _n.transition;
    try {
        _n.transition = null, Se = 1, Mx(e, t, n, r)
    } finally {
        _n.transition = i, Se = r
    }
    return null
}

function Mx(e, t, n, r) {
    do So(); while (Dr !== null);
    if (ye & 6) throw Error(W(327));
    n = e.finishedWork;
    var i = e.finishedLanes;
    if (n === null) return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(W(177));
    e.callbackNode = null, e.callbackPriority = 0;
    var o = n.lanes | n.childLanes;
    if (u2(e, o), e === ut && (Ze = ut = null, vt = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || va || (va = !0, Vy(Wa, function() {
            return So(), null
        })), o = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || o) {
        o = _n.transition, _n.transition = null;
        var s = Se;
        Se = 1;
        var l = ye;
        ye |= 4, ph.current = null, Ex(e, n), Ny(n, e), q2(Rd), Ya = !!Ad, Rd = Ad = null, e.current = n, Cx(n), e2(), ye = l, Se = s, _n.transition = o
    } else e.current = n;
    if (va && (va = !1, Dr = e, uu = i), o = e.pendingLanes, o === 0 && (Yr = null), r2(n.stateNode), Ut(e, Xe()), t !== null)
        for (r = e.onRecoverableError, n = 0; n < t.length; n++) i = t[n], r(i.value, {
            componentStack: i.stack,
            digest: i.digest
        });
    if (au) throw au = !1, e = ep, ep = null, e;
    return uu & 1 && e.tag !== 0 && So(), o = e.pendingLanes, o & 1 ? e === tp ? Is++ : (Is = 0, tp = e) : Is = 0, ii(), null
}

function So() {
    if (Dr !== null) {
        var e = gg(uu),
            t = _n.transition,
            n = Se;
        try {
            if (_n.transition = null, Se = 16 > e ? 16 : e, Dr === null) var r = !1;
            else {
                if (e = Dr, Dr = null, uu = 0, ye & 6) throw Error(W(331));
                var i = ye;
                for (ye |= 4, ee = e.current; ee !== null;) {
                    var o = ee,
                        s = o.child;
                    if (ee.flags & 16) {
                        var l = o.deletions;
                        if (l !== null) {
                            for (var a = 0; a < l.length; a++) {
                                var u = l[a];
                                for (ee = u; ee !== null;) {
                                    var f = ee;
                                    switch (f.tag) {
                                        case 0:
                                        case 11:
                                        case 15:
                                            Ds(8, f, o)
                                    }
                                    var d = f.child;
                                    if (d !== null) d.return = f, ee = d;
                                    else
                                        for (; ee !== null;) {
                                            f = ee;
                                            var h = f.sibling,
                                                y = f.return;
                                            if (My(f), f === u) {
                                                ee = null;
                                                break
                                            }
                                            if (h !== null) {
                                                h.return = y, ee = h;
                                                break
                                            }
                                            ee = y
                                        }
                                }
                            }
                            var _ = o.alternate;
                            if (_ !== null) {
                                var v = _.child;
                                if (v !== null) {
                                    _.child = null;
                                    do {
                                        var E = v.sibling;
                                        v.sibling = null, v = E
                                    } while (v !== null)
                                }
                            }
                            ee = o
                        }
                    }
                    if (o.subtreeFlags & 2064 && s !== null) s.return = o, ee = s;
                    else e: for (; ee !== null;) {
                        if (o = ee, o.flags & 2048) switch (o.tag) {
                            case 0:
                            case 11:
                            case 15:
                                Ds(9, o, o.return)
                        }
                        var m = o.sibling;
                        if (m !== null) {
                            m.return = o.return, ee = m;
                            break e
                        }
                        ee = o.return
                    }
                }
                var g = e.current;
                for (ee = g; ee !== null;) {
                    s = ee;
                    var S = s.child;
                    if (s.subtreeFlags & 2064 && S !== null) S.return = s, ee = S;
                    else e: for (s = g; ee !== null;) {
                        if (l = ee, l.flags & 2048) try {
                            switch (l.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    Au(9, l)
                            }
                        } catch (P) {
                            $e(l, l.return, P)
                        }
                        if (l === s) {
                            ee = null;
                            break e
                        }
                        var x = l.sibling;
                        if (x !== null) {
                            x.return = l.return, ee = x;
                            break e
                        }
                        ee = l.return
                    }
                }
                if (ye = i, ii(), Yn && typeof Yn.onPostCommitFiberRoot == "function") try {
                    Yn.onPostCommitFiberRoot(Tu, e)
                } catch {}
                r = !0
            }
            return r
        } finally {
            Se = n, _n.transition = t
        }
    }
    return !1
}

function Fv(e, t, n) {
    t = Oo(n, t), t = yy(e, t, 1), e = Gr(e, t, 1), t = Nt(), e !== null && (hl(e, 1, t), Ut(e, t))
}

function $e(e, t, n) {
    if (e.tag === 3) Fv(e, e, n);
    else
        for (; t !== null;) {
            if (t.tag === 3) {
                Fv(t, e, n);
                break
            } else if (t.tag === 1) {
                var r = t.stateNode;
                if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (Yr === null || !Yr.has(r))) {
                    e = Oo(n, e), e = _y(t, e, 1), t = Gr(t, e, 1), e = Nt(), t !== null && (hl(t, 1, e), Ut(t, e));
                    break
                }
            }
            t = t.return
        }
}

function Ox(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = Nt(), e.pingedLanes |= e.suspendedLanes & n, ut === e && (vt & n) === n && (rt === 4 || rt === 3 && (vt & 130023424) === vt && 500 > Xe() - mh ? Ci(e, 0) : hh |= n), Ut(e, t)
}

function By(e, t) {
    t === 0 && (e.mode & 1 ? (t = sa, sa <<= 1, !(sa & 130023424) && (sa = 4194304)) : t = 1);
    var n = Nt();
    e = yr(e, t), e !== null && (hl(e, t, n), Ut(e, n))
}

function Lx(e) {
    var t = e.memoizedState,
        n = 0;
    t !== null && (n = t.retryLane), By(e, n)
}

function Nx(e, t) {
    var n = 0;
    switch (e.tag) {
        case 13:
            var r = e.stateNode,
                i = e.memoizedState;
            i !== null && (n = i.retryLane);
            break;
        case 19:
            r = e.stateNode;
            break;
        default:
            throw Error(W(314))
    }
    r !== null && r.delete(t), By(e, n)
}
var jy;
jy = function(e, t, n) {
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || jt.current) Bt = !0;
        else {
            if (!(e.lanes & n) && !(t.flags & 128)) return Bt = !1, _x(e, t, n);
            Bt = !!(e.flags & 131072)
        }
    else Bt = !1, Ae && t.flags & 1048576 && $g(t, eu, t.index);
    switch (t.lanes = 0, t.tag) {
        case 2:
            var r = t.type;
            Oa(e, t), e = t.pendingProps;
            var i = Po(t, kt.current);
            _o(t, n), i = ah(null, t, r, e, i, n);
            var o = uh();
            return t.flags |= 1, typeof i == "object" && i !== null && typeof i.render == "function" && i.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Vt(r) ? (o = !0, Za(t)) : o = !1, t.memoizedState = i.state !== null && i.state !== void 0 ? i.state : null, rh(t), i.updater = Lu, t.stateNode = i, i._reactInternals = t, $d(t, r, e, n), t = Gd(null, t, r, !0, o, n)) : (t.tag = 0, Ae && o && Kp(t), Ot(null, t, i, n), t = t.child), t;
        case 16:
            r = t.elementType;
            e: {
                switch (Oa(e, t), e = t.pendingProps, i = r._init, r = i(r._payload), t.type = r, i = t.tag = Rx(r), e = bn(r, e), i) {
                    case 0:
                        t = Wd(null, t, r, e, n);
                        break e;
                    case 1:
                        t = bv(null, t, r, e, n);
                        break e;
                    case 11:
                        t = Pv(null, t, r, e, n);
                        break e;
                    case 14:
                        t = kv(null, t, r, bn(r.type, e), n);
                        break e
                }
                throw Error(W(306, r, ""))
            }
            return t;
        case 0:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : bn(r, i), Wd(e, t, r, i, n);
        case 1:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : bn(r, i), bv(e, t, r, i, n);
        case 3:
            e: {
                if (Ey(t), e === null) throw Error(W(387));r = t.pendingProps,
                o = t.memoizedState,
                i = o.element,
                Yg(e, t),
                ru(t, r, null, n);
                var s = t.memoizedState;
                if (r = s.element, o.isDehydrated)
                    if (o = {
                            element: r,
                            isDehydrated: !1,
                            cache: s.cache,
                            pendingSuspenseBoundaries: s.pendingSuspenseBoundaries,
                            transitions: s.transitions
                        }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
                        i = Oo(Error(W(423)), t), t = Mv(e, t, r, n, i);
                        break e
                    } else if (r !== i) {
                    i = Oo(Error(W(424)), t), t = Mv(e, t, r, n, i);
                    break e
                } else
                    for (en = Wr(t.stateNode.containerInfo.firstChild), tn = t, Ae = !0, On = null, n = Qg(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                else {
                    if (ko(), r === i) {
                        t = _r(e, t, n);
                        break e
                    }
                    Ot(e, t, r, n)
                }
                t = t.child
            }
            return t;
        case 5:
            return Zg(t), e === null && jd(t), r = t.type, i = t.pendingProps, o = e !== null ? e.memoizedProps : null, s = i.children, Dd(r, i) ? s = null : o !== null && Dd(r, o) && (t.flags |= 32), xy(e, t), Ot(e, t, s, n), t.child;
        case 6:
            return e === null && jd(t), null;
        case 13:
            return Cy(e, t, n);
        case 4:
            return ih(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = bo(t, null, r, n) : Ot(e, t, r, n), t.child;
        case 11:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : bn(r, i), Pv(e, t, r, i, n);
        case 7:
            return Ot(e, t, t.pendingProps, n), t.child;
        case 8:
            return Ot(e, t, t.pendingProps.children, n), t.child;
        case 12:
            return Ot(e, t, t.pendingProps.children, n), t.child;
        case 10:
            e: {
                if (r = t.type._context, i = t.pendingProps, o = t.memoizedProps, s = i.value, Pe(tu, r._currentValue), r._currentValue = s, o !== null)
                    if (Rn(o.value, s)) {
                        if (o.children === i.children && !jt.current) {
                            t = _r(e, t, n);
                            break e
                        }
                    } else
                        for (o = t.child, o !== null && (o.return = t); o !== null;) {
                            var l = o.dependencies;
                            if (l !== null) {
                                s = o.child;
                                for (var a = l.firstContext; a !== null;) {
                                    if (a.context === r) {
                                        if (o.tag === 1) {
                                            a = hr(-1, n & -n), a.tag = 2;
                                            var u = o.updateQueue;
                                            if (u !== null) {
                                                u = u.shared;
                                                var f = u.pending;
                                                f === null ? a.next = a : (a.next = f.next, f.next = a), u.pending = a
                                            }
                                        }
                                        o.lanes |= n, a = o.alternate, a !== null && (a.lanes |= n), Vd(o.return, n, t), l.lanes |= n;
                                        break
                                    }
                                    a = a.next
                                }
                            } else if (o.tag === 10) s = o.type === t.type ? null : o.child;
                            else if (o.tag === 18) {
                                if (s = o.return, s === null) throw Error(W(341));
                                s.lanes |= n, l = s.alternate, l !== null && (l.lanes |= n), Vd(s, n, t), s = o.sibling
                            } else s = o.child;
                            if (s !== null) s.return = o;
                            else
                                for (s = o; s !== null;) {
                                    if (s === t) {
                                        s = null;
                                        break
                                    }
                                    if (o = s.sibling, o !== null) {
                                        o.return = s.return, s = o;
                                        break
                                    }
                                    s = s.return
                                }
                            o = s
                        }
                Ot(e, t, i.children, n),
                t = t.child
            }
            return t;
        case 9:
            return i = t.type, r = t.pendingProps.children, _o(t, n), i = wn(i), r = r(i), t.flags |= 1, Ot(e, t, r, n), t.child;
        case 14:
            return r = t.type, i = bn(r, t.pendingProps), i = bn(r.type, i), kv(e, t, r, i, n);
        case 15:
            return Sy(e, t, t.type, t.pendingProps, n);
        case 17:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : bn(r, i), Oa(e, t), t.tag = 1, Vt(r) ? (e = !0, Za(t)) : e = !1, _o(t, n), qg(t, r, i), $d(t, r, i, n), Gd(null, t, r, !0, e, n);
        case 19:
            return Ty(e, t, n);
        case 22:
            return wy(e, t, n)
    }
    throw Error(W(156, t.tag))
};

function Vy(e, t) {
    return pg(e, t)
}

function Ax(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
}

function mn(e, t, n, r) {
    return new Ax(e, t, n, r)
}

function _h(e) {
    return e = e.prototype, !(!e || !e.isReactComponent)
}

function Rx(e) {
    if (typeof e == "function") return _h(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof, e === Fp) return 11;
        if (e === Bp) return 14
    }
    return 2
}

function qr(e, t) {
    var n = e.alternate;
    return n === null ? (n = mn(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
}

function Aa(e, t, n, r, i, o) {
    var s = 2;
    if (r = e, typeof e == "function") _h(e) && (s = 1);
    else if (typeof e == "string") s = 5;
    else e: switch (e) {
        case to:
            return Ti(n.children, i, o, t);
        case Ip:
            s = 8, i |= 8;
            break;
        case pd:
            return e = mn(12, n, t, i | 2), e.elementType = pd, e.lanes = o, e;
        case hd:
            return e = mn(13, n, t, i), e.elementType = hd, e.lanes = o, e;
        case md:
            return e = mn(19, n, t, i), e.elementType = md, e.lanes = o, e;
        case K1:
            return Du(n, i, o, t);
        default:
            if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                case X1:
                    s = 10;
                    break e;
                case q1:
                    s = 9;
                    break e;
                case Fp:
                    s = 11;
                    break e;
                case Bp:
                    s = 14;
                    break e;
                case Or:
                    s = 16, r = null;
                    break e
            }
            throw Error(W(130, e == null ? e : typeof e, ""))
    }
    return t = mn(s, n, t, i), t.elementType = e, t.type = r, t.lanes = o, t
}

function Ti(e, t, n, r) {
    return e = mn(7, e, r, t), e.lanes = n, e
}

function Du(e, t, n, r) {
    return e = mn(22, e, r, t), e.elementType = K1, e.lanes = n, e.stateNode = {
        isHidden: !1
    }, e
}

function Vf(e, t, n) {
    return e = mn(6, e, null, t), e.lanes = n, e
}

function Uf(e, t, n) {
    return t = mn(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    }, t
}

function Dx(e, t, n, r, i) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = xf(0), this.expirationTimes = xf(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = xf(0), this.identifierPrefix = r, this.onRecoverableError = i, this.mutableSourceEagerHydrationData = null
}

function Sh(e, t, n, r, i, o, s, l, a) {
    return e = new Dx(e, t, n, l, a), t === 1 ? (t = 1, o === !0 && (t |= 8)) : t = 0, o = mn(3, null, null, t), e.current = o, o.stateNode = e, o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null
    }, rh(o), e
}

function zx(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: eo,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}

function Uy(e) {
    if (!e) return Jr;
    e = e._reactInternals;
    e: {
        if (Ii(e) !== e || e.tag !== 1) throw Error(W(170));
        var t = e;do {
            switch (t.tag) {
                case 3:
                    t = t.stateNode.context;
                    break e;
                case 1:
                    if (Vt(t.type)) {
                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                        break e
                    }
            }
            t = t.return
        } while (t !== null);
        throw Error(W(171))
    }
    if (e.tag === 1) {
        var n = e.type;
        if (Vt(n)) return Vg(e, n, t)
    }
    return t
}

function $y(e, t, n, r, i, o, s, l, a) {
    return e = Sh(n, r, !0, e, i, o, s, l, a), e.context = Uy(null), n = e.current, r = Nt(), i = Xr(n), o = hr(r, i), o.callback = t ? ? null, Gr(n, o, i), e.current.lanes = i, hl(e, i, r), Ut(e, r), e
}

function zu(e, t, n, r) {
    var i = t.current,
        o = Nt(),
        s = Xr(i);
    return n = Uy(n), t.context === null ? t.context = n : t.pendingContext = n, t = hr(o, s), t.payload = {
        element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = Gr(i, t, s), e !== null && (Nn(e, i, s, o), ka(e, i, s)), s
}

function fu(e) {
    if (e = e.current, !e.child) return null;
    switch (e.child.tag) {
        case 5:
            return e.child.stateNode;
        default:
            return e.child.stateNode
    }
}

function Bv(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}

function wh(e, t) {
    Bv(e, t), (e = e.alternate) && Bv(e, t)
}

function Ix() {
    return null
}
var Hy = typeof reportError == "function" ? reportError : function(e) {
    console.error(e)
};

function xh(e) {
    this._internalRoot = e
}
Iu.prototype.render = xh.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(W(409));
    zu(e, t, null, null)
};
Iu.prototype.unmount = xh.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        Ai(function() {
            zu(null, e, null, null)
        }), t[gr] = null
    }
};

function Iu(e) {
    this._internalRoot = e
}
Iu.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
        var t = Sg();
        e = {
            blockedOn: null,
            target: e,
            priority: t
        };
        for (var n = 0; n < Nr.length && t !== 0 && t < Nr[n].priority; n++);
        Nr.splice(n, 0, e), n === 0 && xg(e)
    }
};

function Eh(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
}

function Fu(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}

function jv() {}

function Fx(e, t, n, r, i) {
    if (i) {
        if (typeof r == "function") {
            var o = r;
            r = function() {
                var u = fu(s);
                o.call(u)
            }
        }
        var s = $y(t, r, e, 0, null, !1, !1, "", jv);
        return e._reactRootContainer = s, e[gr] = s.current, Ks(e.nodeType === 8 ? e.parentNode : e), Ai(), s
    }
    for (; i = e.lastChild;) e.removeChild(i);
    if (typeof r == "function") {
        var l = r;
        r = function() {
            var u = fu(a);
            l.call(u)
        }
    }
    var a = Sh(e, 0, !1, null, null, !1, !1, "", jv);
    return e._reactRootContainer = a, e[gr] = a.current, Ks(e.nodeType === 8 ? e.parentNode : e), Ai(function() {
        zu(t, a, n, r)
    }), a
}

function Bu(e, t, n, r, i) {
    var o = n._reactRootContainer;
    if (o) {
        var s = o;
        if (typeof i == "function") {
            var l = i;
            i = function() {
                var a = fu(s);
                l.call(a)
            }
        }
        zu(t, s, e, i)
    } else s = Fx(n, t, e, i, r);
    return fu(s)
}
yg = function(e) {
    switch (e.tag) {
        case 3:
            var t = e.stateNode;
            if (t.current.memoizedState.isDehydrated) {
                var n = Ts(t.pendingLanes);
                n !== 0 && (Up(t, n | 1), Ut(t, Xe()), !(ye & 6) && (Lo = Xe() + 500, ii()))
            }
            break;
        case 13:
            Ai(function() {
                var r = yr(e, 1);
                if (r !== null) {
                    var i = Nt();
                    Nn(r, e, 1, i)
                }
            }), wh(e, 1)
    }
};
$p = function(e) {
    if (e.tag === 13) {
        var t = yr(e, 134217728);
        if (t !== null) {
            var n = Nt();
            Nn(t, e, 134217728, n)
        }
        wh(e, 134217728)
    }
};
_g = function(e) {
    if (e.tag === 13) {
        var t = Xr(e),
            n = yr(e, t);
        if (n !== null) {
            var r = Nt();
            Nn(n, e, t, r)
        }
        wh(e, t)
    }
};
Sg = function() {
    return Se
};
wg = function(e, t) {
    var n = Se;
    try {
        return Se = e, t()
    } finally {
        Se = n
    }
};
Td = function(e, t, n) {
    switch (t) {
        case "input":
            if (yd(e, n), t = n.name, n.type === "radio" && t != null) {
                for (n = e; n.parentNode;) n = n.parentNode;
                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (r !== e && r.form === e.form) {
                        var i = Mu(r);
                        if (!i) throw Error(W(90));
                        Z1(r), yd(r, i)
                    }
                }
            }
            break;
        case "textarea":
            eg(e, n);
            break;
        case "select":
            t = n.value, t != null && mo(e, !!n.multiple, t, !1)
    }
};
lg = vh;
ag = Ai;
var Bx = {
        usingClientEntryPoint: !1,
        Events: [vl, oo, Mu, og, sg, vh]
    },
    gs = {
        findFiberByHostInstance: Si,
        bundleType: 0,
        version: "18.2.0",
        rendererPackageName: "react-dom"
    },
    jx = {
        bundleType: gs.bundleType,
        version: gs.version,
        rendererPackageName: gs.rendererPackageName,
        rendererConfig: gs.rendererConfig,
        overrideHookState: null,
        overrideHookStateDeletePath: null,
        overrideHookStateRenamePath: null,
        overrideProps: null,
        overridePropsDeletePath: null,
        overridePropsRenamePath: null,
        setErrorHandler: null,
        setSuspenseHandler: null,
        scheduleUpdate: null,
        currentDispatcherRef: xr.ReactCurrentDispatcher,
        findHostInstanceByFiber: function(e) {
            return e = fg(e), e === null ? null : e.stateNode
        },
        findFiberByHostInstance: gs.findFiberByHostInstance || Ix,
        findHostInstancesForRefresh: null,
        scheduleRefresh: null,
        scheduleRoot: null,
        setRefreshHandler: null,
        getCurrentFiber: null,
        reconcilerVersion: "18.2.0-next-9e3b772b8-20220608"
    };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var ga = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!ga.isDisabled && ga.supportsFiber) try {
        Tu = ga.inject(jx), Yn = ga
    } catch {}
}
sn.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Bx;
sn.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!Eh(t)) throw Error(W(200));
    return zx(e, t, null, n)
};
sn.createRoot = function(e, t) {
    if (!Eh(e)) throw Error(W(299));
    var n = !1,
        r = "",
        i = Hy;
    return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (i = t.onRecoverableError)), t = Sh(e, 1, !1, null, null, n, !1, r, i), e[gr] = t.current, Ks(e.nodeType === 8 ? e.parentNode : e), new xh(t)
};
sn.findDOMNode = function(e) {
    if (e == null) return null;
    if (e.nodeType === 1) return e;
    var t = e._reactInternals;
    if (t === void 0) throw typeof e.render == "function" ? Error(W(188)) : (e = Object.keys(e).join(","), Error(W(268, e)));
    return e = fg(t), e = e === null ? null : e.stateNode, e
};
sn.flushSync = function(e) {
    return Ai(e)
};
sn.hydrate = function(e, t, n) {
    if (!Fu(t)) throw Error(W(200));
    return Bu(null, e, t, !0, n)
};
sn.hydrateRoot = function(e, t, n) {
    if (!Eh(e)) throw Error(W(405));
    var r = n != null && n.hydratedSources || null,
        i = !1,
        o = "",
        s = Hy;
    if (n != null && (n.unstable_strictMode === !0 && (i = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onRecoverableError !== void 0 && (s = n.onRecoverableError)), t = $y(t, null, e, 1, n ? ? null, i, !1, o, s), e[gr] = t.current, Ks(e), r)
        for (e = 0; e < r.length; e++) n = r[e], i = n._getVersion, i = i(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, i] : t.mutableSourceEagerHydrationData.push(n, i);
    return new Iu(t)
};
sn.render = function(e, t, n) {
    if (!Fu(t)) throw Error(W(200));
    return Bu(null, e, t, !1, n)
};
sn.unmountComponentAtNode = function(e) {
    if (!Fu(e)) throw Error(W(40));
    return e._reactRootContainer ? (Ai(function() {
        Bu(null, null, e, !1, function() {
            e._reactRootContainer = null, e[gr] = null
        })
    }), !0) : !1
};
sn.unstable_batchedUpdates = vh;
sn.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!Fu(n)) throw Error(W(200));
    if (e == null || e._reactInternals === void 0) throw Error(W(38));
    return Bu(e, t, n, !1, r)
};
sn.version = "18.2.0-next-9e3b772b8-20220608";

function Wy() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Wy)
    } catch (e) {
        console.error(e)
    }
}
Wy(), $1.exports = sn;
var Vx = $1.exports,
    Vv = Vx;
fd.createRoot = Vv.createRoot, fd.hydrateRoot = Vv.hydrateRoot;

function Gy(e) {
    var t, n, r = "";
    if (typeof e == "string" || typeof e == "number") r += e;
    else if (typeof e == "object")
        if (Array.isArray(e))
            for (t = 0; t < e.length; t++) e[t] && (n = Gy(e[t])) && (r && (r += " "), r += n);
        else
            for (t in e) e[t] && (r && (r += " "), r += t);
    return r
}

function de() {
    for (var e, t, n = 0, r = ""; n < arguments.length;)(e = arguments[n++]) && (t = Gy(e)) && (r && (r += " "), r += t);
    return r
}
const Ux = "_about_uognm_1",
    $x = "_spacer_uognm_11",
    Hx = "_wrapper_uognm_16",
    Wx = "_swiperArrow_uognm_29",
    Gx = "_press_uognm_42",
    Yx = "_line_uognm_65",
    Xx = "_articles_uognm_125",
    qx = "_row_uognm_136",
    Kx = "_article_uognm_125",
    Qx = "_content_uognm_174",
    Zx = "_img_uognm_201",
    Ue = {
        about: Ux,
        spacer: $x,
        wrapper: Hx,
        swiperArrow: Wx,
        press: Gx,
        line: Yx,
        articles: Xx,
        row: qx,
        article: Kx,
        content: Qx,
        img: Zx
    },
    Jx = "_banner_1c4g4_1",
    eE = "_content_1c4g4_13",
    tE = "_arrow_1c4g4_41",
    $f = {
        banner: Jx,
        content: eE,
        arrow: tE
    };

function Yy(e, t) {
    return function() {
        return e.apply(t, arguments)
    }
}
const {
    toString: nE
} = Object.prototype, {
    getPrototypeOf: Ch
} = Object, ju = (e => t => {
    const n = nE.call(t);
    return e[n] || (e[n] = n.slice(8, -1).toLowerCase())
})(Object.create(null)), Zn = e => (e = e.toLowerCase(), t => ju(t) === e), Vu = e => t => typeof t === e, {
    isArray: Ho
} = Array, ol = Vu("undefined");

function rE(e) {
    return e !== null && !ol(e) && e.constructor !== null && !ol(e.constructor) && Sn(e.constructor.isBuffer) && e.constructor.isBuffer(e)
}
const Xy = Zn("ArrayBuffer");

function iE(e) {
    let t;
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(e) : t = e && e.buffer && Xy(e.buffer), t
}
const oE = Vu("string"),
    Sn = Vu("function"),
    qy = Vu("number"),
    Uu = e => e !== null && typeof e == "object",
    sE = e => e === !0 || e === !1,
    Ra = e => {
        if (ju(e) !== "object") return !1;
        const t = Ch(e);
        return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
    },
    lE = Zn("Date"),
    aE = Zn("File"),
    uE = Zn("Blob"),
    cE = Zn("FileList"),
    fE = e => Uu(e) && Sn(e.pipe),
    dE = e => {
        let t;
        return e && (typeof FormData == "function" && e instanceof FormData || Sn(e.append) && ((t = ju(e)) === "formdata" || t === "object" && Sn(e.toString) && e.toString() === "[object FormData]"))
    },
    pE = Zn("URLSearchParams"),
    hE = e => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");

function yl(e, t, {
    allOwnKeys: n = !1
} = {}) {
    if (e === null || typeof e > "u") return;
    let r, i;
    if (typeof e != "object" && (e = [e]), Ho(e))
        for (r = 0, i = e.length; r < i; r++) t.call(null, e[r], r, e);
    else {
        const o = n ? Object.getOwnPropertyNames(e) : Object.keys(e),
            s = o.length;
        let l;
        for (r = 0; r < s; r++) l = o[r], t.call(null, e[l], l, e)
    }
}

function Ky(e, t) {
    t = t.toLowerCase();
    const n = Object.keys(e);
    let r = n.length,
        i;
    for (; r-- > 0;)
        if (i = n[r], t === i.toLowerCase()) return i;
    return null
}
const Qy = (() => typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global)(),
    Zy = e => !ol(e) && e !== Qy;

function ip() {
    const {
        caseless: e
    } = Zy(this) && this || {}, t = {}, n = (r, i) => {
        const o = e && Ky(t, i) || i;
        Ra(t[o]) && Ra(r) ? t[o] = ip(t[o], r) : Ra(r) ? t[o] = ip({}, r) : Ho(r) ? t[o] = r.slice() : t[o] = r
    };
    for (let r = 0, i = arguments.length; r < i; r++) arguments[r] && yl(arguments[r], n);
    return t
}
const mE = (e, t, n, {
        allOwnKeys: r
    } = {}) => (yl(t, (i, o) => {
        n && Sn(i) ? e[o] = Yy(i, n) : e[o] = i
    }, {
        allOwnKeys: r
    }), e),
    vE = e => (e.charCodeAt(0) === 65279 && (e = e.slice(1)), e),
    gE = (e, t, n, r) => {
        e.prototype = Object.create(t.prototype, r), e.prototype.constructor = e, Object.defineProperty(e, "super", {
            value: t.prototype
        }), n && Object.assign(e.prototype, n)
    },
    yE = (e, t, n, r) => {
        let i, o, s;
        const l = {};
        if (t = t || {}, e == null) return t;
        do {
            for (i = Object.getOwnPropertyNames(e), o = i.length; o-- > 0;) s = i[o], (!r || r(s, e, t)) && !l[s] && (t[s] = e[s], l[s] = !0);
            e = n !== !1 && Ch(e)
        } while (e && (!n || n(e, t)) && e !== Object.prototype);
        return t
    },
    _E = (e, t, n) => {
        e = String(e), (n === void 0 || n > e.length) && (n = e.length), n -= t.length;
        const r = e.indexOf(t, n);
        return r !== -1 && r === n
    },
    SE = e => {
        if (!e) return null;
        if (Ho(e)) return e;
        let t = e.length;
        if (!qy(t)) return null;
        const n = new Array(t);
        for (; t-- > 0;) n[t] = e[t];
        return n
    },
    wE = (e => t => e && t instanceof e)(typeof Uint8Array < "u" && Ch(Uint8Array)),
    xE = (e, t) => {
        const r = (e && e[Symbol.iterator]).call(e);
        let i;
        for (;
            (i = r.next()) && !i.done;) {
            const o = i.value;
            t.call(e, o[0], o[1])
        }
    },
    EE = (e, t) => {
        let n;
        const r = [];
        for (;
            (n = e.exec(t)) !== null;) r.push(n);
        return r
    },
    CE = Zn("HTMLFormElement"),
    TE = e => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(n, r, i) {
        return r.toUpperCase() + i
    }),
    Uv = (({
        hasOwnProperty: e
    }) => (t, n) => e.call(t, n))(Object.prototype),
    PE = Zn("RegExp"),
    Jy = (e, t) => {
        const n = Object.getOwnPropertyDescriptors(e),
            r = {};
        yl(n, (i, o) => {
            t(i, o, e) !== !1 && (r[o] = i)
        }), Object.defineProperties(e, r)
    },
    kE = e => {
        Jy(e, (t, n) => {
            if (Sn(e) && ["arguments", "caller", "callee"].indexOf(n) !== -1) return !1;
            const r = e[n];
            if (Sn(r)) {
                if (t.enumerable = !1, "writable" in t) {
                    t.writable = !1;
                    return
                }
                t.set || (t.set = () => {
                    throw Error("Can not rewrite read-only method '" + n + "'")
                })
            }
        })
    },
    bE = (e, t) => {
        const n = {},
            r = i => {
                i.forEach(o => {
                    n[o] = !0
                })
            };
        return Ho(e) ? r(e) : r(String(e).split(t)), n
    },
    ME = () => {},
    OE = (e, t) => (e = +e, Number.isFinite(e) ? e : t),
    Hf = "abcdefghijklmnopqrstuvwxyz",
    $v = "0123456789",
    e_ = {
        DIGIT: $v,
        ALPHA: Hf,
        ALPHA_DIGIT: Hf + Hf.toUpperCase() + $v
    },
    LE = (e = 16, t = e_.ALPHA_DIGIT) => {
        let n = "";
        const {
            length: r
        } = t;
        for (; e--;) n += t[Math.random() * r | 0];
        return n
    };

function NE(e) {
    return !!(e && Sn(e.append) && e[Symbol.toStringTag] === "FormData" && e[Symbol.iterator])
}
const AE = e => {
        const t = new Array(10),
            n = (r, i) => {
                if (Uu(r)) {
                    if (t.indexOf(r) >= 0) return;
                    if (!("toJSON" in r)) {
                        t[i] = r;
                        const o = Ho(r) ? [] : {};
                        return yl(r, (s, l) => {
                            const a = n(s, i + 1);
                            !ol(a) && (o[l] = a)
                        }), t[i] = void 0, o
                    }
                }
                return r
            };
        return n(e, 0)
    },
    RE = Zn("AsyncFunction"),
    DE = e => e && (Uu(e) || Sn(e)) && Sn(e.then) && Sn(e.catch),
    j = {
        isArray: Ho,
        isArrayBuffer: Xy,
        isBuffer: rE,
        isFormData: dE,
        isArrayBufferView: iE,
        isString: oE,
        isNumber: qy,
        isBoolean: sE,
        isObject: Uu,
        isPlainObject: Ra,
        isUndefined: ol,
        isDate: lE,
        isFile: aE,
        isBlob: uE,
        isRegExp: PE,
        isFunction: Sn,
        isStream: fE,
        isURLSearchParams: pE,
        isTypedArray: wE,
        isFileList: cE,
        forEach: yl,
        merge: ip,
        extend: mE,
        trim: hE,
        stripBOM: vE,
        inherits: gE,
        toFlatObject: yE,
        kindOf: ju,
        kindOfTest: Zn,
        endsWith: _E,
        toArray: SE,
        forEachEntry: xE,
        matchAll: EE,
        isHTMLForm: CE,
        hasOwnProperty: Uv,
        hasOwnProp: Uv,
        reduceDescriptors: Jy,
        freezeMethods: kE,
        toObjectSet: bE,
        toCamelCase: TE,
        noop: ME,
        toFiniteNumber: OE,
        findKey: Ky,
        global: Qy,
        isContextDefined: Zy,
        ALPHABET: e_,
        generateString: LE,
        isSpecCompliantForm: NE,
        toJSONObject: AE,
        isAsyncFn: RE,
        isThenable: DE
    };

function ge(e, t, n, r, i) {
    Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = e, this.name = "AxiosError", t && (this.code = t), n && (this.config = n), r && (this.request = r), i && (this.response = i)
}
j.inherits(ge, Error, {
    toJSON: function() {
        return {
            message: this.message,
            name: this.name,
            description: this.description,
            number: this.number,
            fileName: this.fileName,
            lineNumber: this.lineNumber,
            columnNumber: this.columnNumber,
            stack: this.stack,
            config: j.toJSONObject(this.config),
            code: this.code,
            status: this.response && this.response.status ? this.response.status : null
        }
    }
});
const t_ = ge.prototype,
    n_ = {};
["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach(e => {
    n_[e] = {
        value: e
    }
});
Object.defineProperties(ge, n_);
Object.defineProperty(t_, "isAxiosError", {
    value: !0
});
ge.from = (e, t, n, r, i, o) => {
    const s = Object.create(t_);
    return j.toFlatObject(e, s, function(a) {
        return a !== Error.prototype
    }, l => l !== "isAxiosError"), ge.call(s, e.message, t, n, r, i), s.cause = e, s.name = e.name, o && Object.assign(s, o), s
};
const zE = null;

function op(e) {
    return j.isPlainObject(e) || j.isArray(e)
}

function r_(e) {
    return j.endsWith(e, "[]") ? e.slice(0, -2) : e
}

function Hv(e, t, n) {
    return e ? e.concat(t).map(function(i, o) {
        return i = r_(i), !n && o ? "[" + i + "]" : i
    }).join(n ? "." : "") : t
}

function IE(e) {
    return j.isArray(e) && !e.some(op)
}
const FE = j.toFlatObject(j, {}, null, function(t) {
    return /^is[A-Z]/.test(t)
});

function $u(e, t, n) {
    if (!j.isObject(e)) throw new TypeError("target must be an object");
    t = t || new FormData, n = j.toFlatObject(n, {
        metaTokens: !0,
        dots: !1,
        indexes: !1
    }, !1, function(v, E) {
        return !j.isUndefined(E[v])
    });
    const r = n.metaTokens,
        i = n.visitor || f,
        o = n.dots,
        s = n.indexes,
        a = (n.Blob || typeof Blob < "u" && Blob) && j.isSpecCompliantForm(t);
    if (!j.isFunction(i)) throw new TypeError("visitor must be a function");

    function u(_) {
        if (_ === null) return "";
        if (j.isDate(_)) return _.toISOString();
        if (!a && j.isBlob(_)) throw new ge("Blob is not supported. Use a Buffer instead.");
        return j.isArrayBuffer(_) || j.isTypedArray(_) ? a && typeof Blob == "function" ? new Blob([_]) : Buffer.from(_) : _
    }

    function f(_, v, E) {
        let m = _;
        if (_ && !E && typeof _ == "object") {
            if (j.endsWith(v, "{}")) v = r ? v : v.slice(0, -2), _ = JSON.stringify(_);
            else if (j.isArray(_) && IE(_) || (j.isFileList(_) || j.endsWith(v, "[]")) && (m = j.toArray(_))) return v = r_(v), m.forEach(function(S, x) {
                !(j.isUndefined(S) || S === null) && t.append(s === !0 ? Hv([v], x, o) : s === null ? v : v + "[]", u(S))
            }), !1
        }
        return op(_) ? !0 : (t.append(Hv(E, v, o), u(_)), !1)
    }
    const d = [],
        h = Object.assign(FE, {
            defaultVisitor: f,
            convertValue: u,
            isVisitable: op
        });

    function y(_, v) {
        if (!j.isUndefined(_)) {
            if (d.indexOf(_) !== -1) throw Error("Circular reference detected in " + v.join("."));
            d.push(_), j.forEach(_, function(m, g) {
                (!(j.isUndefined(m) || m === null) && i.call(t, m, j.isString(g) ? g.trim() : g, v, h)) === !0 && y(m, v ? v.concat(g) : [g])
            }), d.pop()
        }
    }
    if (!j.isObject(e)) throw new TypeError("data must be an object");
    return y(e), t
}

function Wv(e) {
    const t = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
    };
    return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, function(r) {
        return t[r]
    })
}

function Th(e, t) {
    this._pairs = [], e && $u(e, this, t)
}
const i_ = Th.prototype;
i_.append = function(t, n) {
    this._pairs.push([t, n])
};
i_.toString = function(t) {
    const n = t ? function(r) {
        return t.call(this, r, Wv)
    } : Wv;
    return this._pairs.map(function(i) {
        return n(i[0]) + "=" + n(i[1])
    }, "").join("&")
};

function BE(e) {
    return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
}

function o_(e, t, n) {
    if (!t) return e;
    const r = n && n.encode || BE,
        i = n && n.serialize;
    let o;
    if (i ? o = i(t, n) : o = j.isURLSearchParams(t) ? t.toString() : new Th(t, n).toString(r), o) {
        const s = e.indexOf("#");
        s !== -1 && (e = e.slice(0, s)), e += (e.indexOf("?") === -1 ? "?" : "&") + o
    }
    return e
}
class jE {
    constructor() {
        this.handlers = []
    }
    use(t, n, r) {
        return this.handlers.push({
            fulfilled: t,
            rejected: n,
            synchronous: r ? r.synchronous : !1,
            runWhen: r ? r.runWhen : null
        }), this.handlers.length - 1
    }
    eject(t) {
        this.handlers[t] && (this.handlers[t] = null)
    }
    clear() {
        this.handlers && (this.handlers = [])
    }
    forEach(t) {
        j.forEach(this.handlers, function(r) {
            r !== null && t(r)
        })
    }
}
const Gv = jE,
    s_ = {
        silentJSONParsing: !0,
        forcedJSONParsing: !0,
        clarifyTimeoutError: !1
    },
    VE = typeof URLSearchParams < "u" ? URLSearchParams : Th,
    UE = typeof FormData < "u" ? FormData : null,
    $E = typeof Blob < "u" ? Blob : null,
    HE = (() => {
        let e;
        return typeof navigator < "u" && ((e = navigator.product) === "ReactNative" || e === "NativeScript" || e === "NS") ? !1 : typeof window < "u" && typeof document < "u"
    })(),
    WE = (() => typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function")(),
    Hn = {
        isBrowser: !0,
        classes: {
            URLSearchParams: VE,
            FormData: UE,
            Blob: $E
        },
        isStandardBrowserEnv: HE,
        isStandardBrowserWebWorkerEnv: WE,
        protocols: ["http", "https", "file", "blob", "url", "data"]
    };

function GE(e, t) {
    return $u(e, new Hn.classes.URLSearchParams, Object.assign({
        visitor: function(n, r, i, o) {
            return Hn.isNode && j.isBuffer(n) ? (this.append(r, n.toString("base64")), !1) : o.defaultVisitor.apply(this, arguments)
        }
    }, t))
}

function YE(e) {
    return j.matchAll(/\w+|\[(\w*)]/g, e).map(t => t[0] === "[]" ? "" : t[1] || t[0])
}

function XE(e) {
    const t = {},
        n = Object.keys(e);
    let r;
    const i = n.length;
    let o;
    for (r = 0; r < i; r++) o = n[r], t[o] = e[o];
    return t
}

function l_(e) {
    function t(n, r, i, o) {
        let s = n[o++];
        const l = Number.isFinite(+s),
            a = o >= n.length;
        return s = !s && j.isArray(i) ? i.length : s, a ? (j.hasOwnProp(i, s) ? i[s] = [i[s], r] : i[s] = r, !l) : ((!i[s] || !j.isObject(i[s])) && (i[s] = []), t(n, r, i[s], o) && j.isArray(i[s]) && (i[s] = XE(i[s])), !l)
    }
    if (j.isFormData(e) && j.isFunction(e.entries)) {
        const n = {};
        return j.forEachEntry(e, (r, i) => {
            t(YE(r), i, n, 0)
        }), n
    }
    return null
}
const qE = {
    "Content-Type": void 0
};

function KE(e, t, n) {
    if (j.isString(e)) try {
        return (t || JSON.parse)(e), j.trim(e)
    } catch (r) {
        if (r.name !== "SyntaxError") throw r
    }
    return (n || JSON.stringify)(e)
}
const Hu = {
    transitional: s_,
    adapter: ["xhr", "http"],
    transformRequest: [function(t, n) {
        const r = n.getContentType() || "",
            i = r.indexOf("application/json") > -1,
            o = j.isObject(t);
        if (o && j.isHTMLForm(t) && (t = new FormData(t)), j.isFormData(t)) return i && i ? JSON.stringify(l_(t)) : t;
        if (j.isArrayBuffer(t) || j.isBuffer(t) || j.isStream(t) || j.isFile(t) || j.isBlob(t)) return t;
        if (j.isArrayBufferView(t)) return t.buffer;
        if (j.isURLSearchParams(t)) return n.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), t.toString();
        let l;
        if (o) {
            if (r.indexOf("application/x-www-form-urlencoded") > -1) return GE(t, this.formSerializer).toString();
            if ((l = j.isFileList(t)) || r.indexOf("multipart/form-data") > -1) {
                const a = this.env && this.env.FormData;
                return $u(l ? {
                    "files[]": t
                } : t, a && new a, this.formSerializer)
            }
        }
        return o || i ? (n.setContentType("application/json", !1), KE(t)) : t
    }],
    transformResponse: [function(t) {
        const n = this.transitional || Hu.transitional,
            r = n && n.forcedJSONParsing,
            i = this.responseType === "json";
        if (t && j.isString(t) && (r && !this.responseType || i)) {
            const s = !(n && n.silentJSONParsing) && i;
            try {
                return JSON.parse(t)
            } catch (l) {
                if (s) throw l.name === "SyntaxError" ? ge.from(l, ge.ERR_BAD_RESPONSE, this, null, this.response) : l
            }
        }
        return t
    }],
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
        FormData: Hn.classes.FormData,
        Blob: Hn.classes.Blob
    },
    validateStatus: function(t) {
        return t >= 200 && t < 300
    },
    headers: {
        common: {
            Accept: "application/json, text/plain, */*"
        }
    }
};
j.forEach(["delete", "get", "head"], function(t) {
    Hu.headers[t] = {}
});
j.forEach(["post", "put", "patch"], function(t) {
    Hu.headers[t] = j.merge(qE)
});
const Ph = Hu,
    QE = j.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]),
    ZE = e => {
        const t = {};
        let n, r, i;
        return e && e.split(`
`).forEach(function(s) {
            i = s.indexOf(":"), n = s.substring(0, i).trim().toLowerCase(), r = s.substring(i + 1).trim(), !(!n || t[n] && QE[n]) && (n === "set-cookie" ? t[n] ? t[n].push(r) : t[n] = [r] : t[n] = t[n] ? t[n] + ", " + r : r)
        }), t
    },
    Yv = Symbol("internals");

function ys(e) {
    return e && String(e).trim().toLowerCase()
}

function Da(e) {
    return e === !1 || e == null ? e : j.isArray(e) ? e.map(Da) : String(e)
}

function JE(e) {
    const t = Object.create(null),
        n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let r;
    for (; r = n.exec(e);) t[r[1]] = r[2];
    return t
}
const e3 = e => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());

function Wf(e, t, n, r, i) {
    if (j.isFunction(r)) return r.call(this, t, n);
    if (i && (t = n), !!j.isString(t)) {
        if (j.isString(r)) return t.indexOf(r) !== -1;
        if (j.isRegExp(r)) return r.test(t)
    }
}

function t3(e) {
    return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (t, n, r) => n.toUpperCase() + r)
}

function n3(e, t) {
    const n = j.toCamelCase(" " + t);
    ["get", "set", "has"].forEach(r => {
        Object.defineProperty(e, r + n, {
            value: function(i, o, s) {
                return this[r].call(this, t, i, o, s)
            },
            configurable: !0
        })
    })
}
class Wu {
    constructor(t) {
        t && this.set(t)
    }
    set(t, n, r) {
        const i = this;

        function o(l, a, u) {
            const f = ys(a);
            if (!f) throw new Error("header name must be a non-empty string");
            const d = j.findKey(i, f);
            (!d || i[d] === void 0 || u === !0 || u === void 0 && i[d] !== !1) && (i[d || a] = Da(l))
        }
        const s = (l, a) => j.forEach(l, (u, f) => o(u, f, a));
        return j.isPlainObject(t) || t instanceof this.constructor ? s(t, n) : j.isString(t) && (t = t.trim()) && !e3(t) ? s(ZE(t), n) : t != null && o(n, t, r), this
    }
    get(t, n) {
        if (t = ys(t), t) {
            const r = j.findKey(this, t);
            if (r) {
                const i = this[r];
                if (!n) return i;
                if (n === !0) return JE(i);
                if (j.isFunction(n)) return n.call(this, i, r);
                if (j.isRegExp(n)) return n.exec(i);
                throw new TypeError("parser must be boolean|regexp|function")
            }
        }
    }
    has(t, n) {
        if (t = ys(t), t) {
            const r = j.findKey(this, t);
            return !!(r && this[r] !== void 0 && (!n || Wf(this, this[r], r, n)))
        }
        return !1
    }
    delete(t, n) {
        const r = this;
        let i = !1;

        function o(s) {
            if (s = ys(s), s) {
                const l = j.findKey(r, s);
                l && (!n || Wf(r, r[l], l, n)) && (delete r[l], i = !0)
            }
        }
        return j.isArray(t) ? t.forEach(o) : o(t), i
    }
    clear(t) {
        const n = Object.keys(this);
        let r = n.length,
            i = !1;
        for (; r--;) {
            const o = n[r];
            (!t || Wf(this, this[o], o, t, !0)) && (delete this[o], i = !0)
        }
        return i
    }
    normalize(t) {
        const n = this,
            r = {};
        return j.forEach(this, (i, o) => {
            const s = j.findKey(r, o);
            if (s) {
                n[s] = Da(i), delete n[o];
                return
            }
            const l = t ? t3(o) : String(o).trim();
            l !== o && delete n[o], n[l] = Da(i), r[l] = !0
        }), this
    }
    concat(...t) {
        return this.constructor.concat(this, ...t)
    }
    toJSON(t) {
        const n = Object.create(null);
        return j.forEach(this, (r, i) => {
            r != null && r !== !1 && (n[i] = t && j.isArray(r) ? r.join(", ") : r)
        }), n
    }[Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]()
    }
    toString() {
        return Object.entries(this.toJSON()).map(([t, n]) => t + ": " + n).join(`
`)
    }
    get[Symbol.toStringTag]() {
        return "AxiosHeaders"
    }
    static from(t) {
        return t instanceof this ? t : new this(t)
    }
    static concat(t, ...n) {
        const r = new this(t);
        return n.forEach(i => r.set(i)), r
    }
    static accessor(t) {
        const r = (this[Yv] = this[Yv] = {
                accessors: {}
            }).accessors,
            i = this.prototype;

        function o(s) {
            const l = ys(s);
            r[l] || (n3(i, s), r[l] = !0)
        }
        return j.isArray(t) ? t.forEach(o) : o(t), this
    }
}
Wu.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
j.freezeMethods(Wu.prototype);
j.freezeMethods(Wu);
const mr = Wu;

function Gf(e, t) {
    const n = this || Ph,
        r = t || n,
        i = mr.from(r.headers);
    let o = r.data;
    return j.forEach(e, function(l) {
        o = l.call(n, o, i.normalize(), t ? t.status : void 0)
    }), i.normalize(), o
}

function a_(e) {
    return !!(e && e.__CANCEL__)
}

function _l(e, t, n) {
    ge.call(this, e ? ? "canceled", ge.ERR_CANCELED, t, n), this.name = "CanceledError"
}
j.inherits(_l, ge, {
    __CANCEL__: !0
});

function r3(e, t, n) {
    const r = n.config.validateStatus;
    !n.status || !r || r(n.status) ? e(n) : t(new ge("Request failed with status code " + n.status, [ge.ERR_BAD_REQUEST, ge.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4], n.config, n.request, n))
}
const i3 = Hn.isStandardBrowserEnv ? function() {
    return {
        write: function(n, r, i, o, s, l) {
            const a = [];
            a.push(n + "=" + encodeURIComponent(r)), j.isNumber(i) && a.push("expires=" + new Date(i).toGMTString()), j.isString(o) && a.push("path=" + o), j.isString(s) && a.push("domain=" + s), l === !0 && a.push("secure"), document.cookie = a.join("; ")
        },
        read: function(n) {
            const r = document.cookie.match(new RegExp("(^|;\\s*)(" + n + ")=([^;]*)"));
            return r ? decodeURIComponent(r[3]) : null
        },
        remove: function(n) {
            this.write(n, "", Date.now() - 864e5)
        }
    }
}() : function() {
    return {
        write: function() {},
        read: function() {
            return null
        },
        remove: function() {}
    }
}();

function o3(e) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e)
}

function s3(e, t) {
    return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e
}

function u_(e, t) {
    return e && !o3(t) ? s3(e, t) : t
}
const l3 = Hn.isStandardBrowserEnv ? function() {
    const t = /(msie|trident)/i.test(navigator.userAgent),
        n = document.createElement("a");
    let r;

    function i(o) {
        let s = o;
        return t && (n.setAttribute("href", s), s = n.href), n.setAttribute("href", s), {
            href: n.href,
            protocol: n.protocol ? n.protocol.replace(/:$/, "") : "",
            host: n.host,
            search: n.search ? n.search.replace(/^\?/, "") : "",
            hash: n.hash ? n.hash.replace(/^#/, "") : "",
            hostname: n.hostname,
            port: n.port,
            pathname: n.pathname.charAt(0) === "/" ? n.pathname : "/" + n.pathname
        }
    }
    return r = i(window.location.href),
        function(s) {
            const l = j.isString(s) ? i(s) : s;
            return l.protocol === r.protocol && l.host === r.host
        }
}() : function() {
    return function() {
        return !0
    }
}();

function a3(e) {
    const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
    return t && t[1] || ""
}

function u3(e, t) {
    e = e || 10;
    const n = new Array(e),
        r = new Array(e);
    let i = 0,
        o = 0,
        s;
    return t = t !== void 0 ? t : 1e3,
        function(a) {
            const u = Date.now(),
                f = r[o];
            s || (s = u), n[i] = a, r[i] = u;
            let d = o,
                h = 0;
            for (; d !== i;) h += n[d++], d = d % e;
            if (i = (i + 1) % e, i === o && (o = (o + 1) % e), u - s < t) return;
            const y = f && u - f;
            return y ? Math.round(h * 1e3 / y) : void 0
        }
}

function Xv(e, t) {
    let n = 0;
    const r = u3(50, 250);
    return i => {
        const o = i.loaded,
            s = i.lengthComputable ? i.total : void 0,
            l = o - n,
            a = r(l),
            u = o <= s;
        n = o;
        const f = {
            loaded: o,
            total: s,
            progress: s ? o / s : void 0,
            bytes: l,
            rate: a || void 0,
            estimated: a && s && u ? (s - o) / a : void 0,
            event: i
        };
        f[t ? "download" : "upload"] = !0, e(f)
    }
}
const c3 = typeof XMLHttpRequest < "u",
    f3 = c3 && function(e) {
        return new Promise(function(n, r) {
            let i = e.data;
            const o = mr.from(e.headers).normalize(),
                s = e.responseType;
            let l;

            function a() {
                e.cancelToken && e.cancelToken.unsubscribe(l), e.signal && e.signal.removeEventListener("abort", l)
            }
            j.isFormData(i) && (Hn.isStandardBrowserEnv || Hn.isStandardBrowserWebWorkerEnv ? o.setContentType(!1) : o.setContentType("multipart/form-data;", !1));
            let u = new XMLHttpRequest;
            if (e.auth) {
                const y = e.auth.username || "",
                    _ = e.auth.password ? unescape(encodeURIComponent(e.auth.password)) : "";
                o.set("Authorization", "Basic " + btoa(y + ":" + _))
            }
            const f = u_(e.baseURL, e.url);
            u.open(e.method.toUpperCase(), o_(f, e.params, e.paramsSerializer), !0), u.timeout = e.timeout;

            function d() {
                if (!u) return;
                const y = mr.from("getAllResponseHeaders" in u && u.getAllResponseHeaders()),
                    v = {
                        data: !s || s === "text" || s === "json" ? u.responseText : u.response,
                        status: u.status,
                        statusText: u.statusText,
                        headers: y,
                        config: e,
                        request: u
                    };
                r3(function(m) {
                    n(m), a()
                }, function(m) {
                    r(m), a()
                }, v), u = null
            }
            if ("onloadend" in u ? u.onloadend = d : u.onreadystatechange = function() {
                    !u || u.readyState !== 4 || u.status === 0 && !(u.responseURL && u.responseURL.indexOf("file:") === 0) || setTimeout(d)
                }, u.onabort = function() {
                    u && (r(new ge("Request aborted", ge.ECONNABORTED, e, u)), u = null)
                }, u.onerror = function() {
                    r(new ge("Network Error", ge.ERR_NETWORK, e, u)), u = null
                }, u.ontimeout = function() {
                    let _ = e.timeout ? "timeout of " + e.timeout + "ms exceeded" : "timeout exceeded";
                    const v = e.transitional || s_;
                    e.timeoutErrorMessage && (_ = e.timeoutErrorMessage), r(new ge(_, v.clarifyTimeoutError ? ge.ETIMEDOUT : ge.ECONNABORTED, e, u)), u = null
                }, Hn.isStandardBrowserEnv) {
                const y = (e.withCredentials || l3(f)) && e.xsrfCookieName && i3.read(e.xsrfCookieName);
                y && o.set(e.xsrfHeaderName, y)
            }
            i === void 0 && o.setContentType(null), "setRequestHeader" in u && j.forEach(o.toJSON(), function(_, v) {
                u.setRequestHeader(v, _)
            }), j.isUndefined(e.withCredentials) || (u.withCredentials = !!e.withCredentials), s && s !== "json" && (u.responseType = e.responseType), typeof e.onDownloadProgress == "function" && u.addEventListener("progress", Xv(e.onDownloadProgress, !0)), typeof e.onUploadProgress == "function" && u.upload && u.upload.addEventListener("progress", Xv(e.onUploadProgress)), (e.cancelToken || e.signal) && (l = y => {
                u && (r(!y || y.type ? new _l(null, e, u) : y), u.abort(), u = null)
            }, e.cancelToken && e.cancelToken.subscribe(l), e.signal && (e.signal.aborted ? l() : e.signal.addEventListener("abort", l)));
            const h = a3(f);
            if (h && Hn.protocols.indexOf(h) === -1) {
                r(new ge("Unsupported protocol " + h + ":", ge.ERR_BAD_REQUEST, e));
                return
            }
            u.send(i || null)
        })
    },
    za = {
        http: zE,
        xhr: f3
    };
j.forEach(za, (e, t) => {
    if (e) {
        try {
            Object.defineProperty(e, "name", {
                value: t
            })
        } catch {}
        Object.defineProperty(e, "adapterName", {
            value: t
        })
    }
});
const d3 = {
    getAdapter: e => {
        e = j.isArray(e) ? e : [e];
        const {
            length: t
        } = e;
        let n, r;
        for (let i = 0; i < t && (n = e[i], !(r = j.isString(n) ? za[n.toLowerCase()] : n)); i++);
        if (!r) throw r === !1 ? new ge(`Adapter ${n} is not supported by the environment`, "ERR_NOT_SUPPORT") : new Error(j.hasOwnProp(za, n) ? `Adapter '${n}' is not available in the build` : `Unknown adapter '${n}'`);
        if (!j.isFunction(r)) throw new TypeError("adapter is not a function");
        return r
    },
    adapters: za
};

function Yf(e) {
    if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted) throw new _l(null, e)
}

function qv(e) {
    return Yf(e), e.headers = mr.from(e.headers), e.data = Gf.call(e, e.transformRequest), ["post", "put", "patch"].indexOf(e.method) !== -1 && e.headers.setContentType("application/x-www-form-urlencoded", !1), d3.getAdapter(e.adapter || Ph.adapter)(e).then(function(r) {
        return Yf(e), r.data = Gf.call(e, e.transformResponse, r), r.headers = mr.from(r.headers), r
    }, function(r) {
        return a_(r) || (Yf(e), r && r.response && (r.response.data = Gf.call(e, e.transformResponse, r.response), r.response.headers = mr.from(r.response.headers))), Promise.reject(r)
    })
}
const Kv = e => e instanceof mr ? e.toJSON() : e;

function No(e, t) {
    t = t || {};
    const n = {};

    function r(u, f, d) {
        return j.isPlainObject(u) && j.isPlainObject(f) ? j.merge.call({
            caseless: d
        }, u, f) : j.isPlainObject(f) ? j.merge({}, f) : j.isArray(f) ? f.slice() : f
    }

    function i(u, f, d) {
        if (j.isUndefined(f)) {
            if (!j.isUndefined(u)) return r(void 0, u, d)
        } else return r(u, f, d)
    }

    function o(u, f) {
        if (!j.isUndefined(f)) return r(void 0, f)
    }

    function s(u, f) {
        if (j.isUndefined(f)) {
            if (!j.isUndefined(u)) return r(void 0, u)
        } else return r(void 0, f)
    }

    function l(u, f, d) {
        if (d in t) return r(u, f);
        if (d in e) return r(void 0, u)
    }
    const a = {
        url: o,
        method: o,
        data: o,
        baseURL: s,
        transformRequest: s,
        transformResponse: s,
        paramsSerializer: s,
        timeout: s,
        timeoutMessage: s,
        withCredentials: s,
        adapter: s,
        responseType: s,
        xsrfCookieName: s,
        xsrfHeaderName: s,
        onUploadProgress: s,
        onDownloadProgress: s,
        decompress: s,
        maxContentLength: s,
        maxBodyLength: s,
        beforeRedirect: s,
        transport: s,
        httpAgent: s,
        httpsAgent: s,
        cancelToken: s,
        socketPath: s,
        responseEncoding: s,
        validateStatus: l,
        headers: (u, f) => i(Kv(u), Kv(f), !0)
    };
    return j.forEach(Object.keys(Object.assign({}, e, t)), function(f) {
        const d = a[f] || i,
            h = d(e[f], t[f], f);
        j.isUndefined(h) && d !== l || (n[f] = h)
    }), n
}
const c_ = "1.4.0",
    kh = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
    kh[e] = function(r) {
        return typeof r === e || "a" + (t < 1 ? "n " : " ") + e
    }
});
const Qv = {};
kh.transitional = function(t, n, r) {
    function i(o, s) {
        return "[Axios v" + c_ + "] Transitional option '" + o + "'" + s + (r ? ". " + r : "")
    }
    return (o, s, l) => {
        if (t === !1) throw new ge(i(s, " has been removed" + (n ? " in " + n : "")), ge.ERR_DEPRECATED);
        return n && !Qv[s] && (Qv[s] = !0, console.warn(i(s, " has been deprecated since v" + n + " and will be removed in the near future"))), t ? t(o, s, l) : !0
    }
};

function p3(e, t, n) {
    if (typeof e != "object") throw new ge("options must be an object", ge.ERR_BAD_OPTION_VALUE);
    const r = Object.keys(e);
    let i = r.length;
    for (; i-- > 0;) {
        const o = r[i],
            s = t[o];
        if (s) {
            const l = e[o],
                a = l === void 0 || s(l, o, e);
            if (a !== !0) throw new ge("option " + o + " must be " + a, ge.ERR_BAD_OPTION_VALUE);
            continue
        }
        if (n !== !0) throw new ge("Unknown option " + o, ge.ERR_BAD_OPTION)
    }
}
const sp = {
        assertOptions: p3,
        validators: kh
    },
    Mr = sp.validators;
class du {
    constructor(t) {
        this.defaults = t, this.interceptors = {
            request: new Gv,
            response: new Gv
        }
    }
    request(t, n) {
        typeof t == "string" ? (n = n || {}, n.url = t) : n = t || {}, n = No(this.defaults, n);
        const {
            transitional: r,
            paramsSerializer: i,
            headers: o
        } = n;
        r !== void 0 && sp.assertOptions(r, {
            silentJSONParsing: Mr.transitional(Mr.boolean),
            forcedJSONParsing: Mr.transitional(Mr.boolean),
            clarifyTimeoutError: Mr.transitional(Mr.boolean)
        }, !1), i != null && (j.isFunction(i) ? n.paramsSerializer = {
            serialize: i
        } : sp.assertOptions(i, {
            encode: Mr.function,
            serialize: Mr.function
        }, !0)), n.method = (n.method || this.defaults.method || "get").toLowerCase();
        let s;
        s = o && j.merge(o.common, o[n.method]), s && j.forEach(["delete", "get", "head", "post", "put", "patch", "common"], _ => {
            delete o[_]
        }), n.headers = mr.concat(s, o);
        const l = [];
        let a = !0;
        this.interceptors.request.forEach(function(v) {
            typeof v.runWhen == "function" && v.runWhen(n) === !1 || (a = a && v.synchronous, l.unshift(v.fulfilled, v.rejected))
        });
        const u = [];
        this.interceptors.response.forEach(function(v) {
            u.push(v.fulfilled, v.rejected)
        });
        let f, d = 0,
            h;
        if (!a) {
            const _ = [qv.bind(this), void 0];
            for (_.unshift.apply(_, l), _.push.apply(_, u), h = _.length, f = Promise.resolve(n); d < h;) f = f.then(_[d++], _[d++]);
            return f
        }
        h = l.length;
        let y = n;
        for (d = 0; d < h;) {
            const _ = l[d++],
                v = l[d++];
            try {
                y = _(y)
            } catch (E) {
                v.call(this, E);
                break
            }
        }
        try {
            f = qv.call(this, y)
        } catch (_) {
            return Promise.reject(_)
        }
        for (d = 0, h = u.length; d < h;) f = f.then(u[d++], u[d++]);
        return f
    }
    getUri(t) {
        t = No(this.defaults, t);
        const n = u_(t.baseURL, t.url);
        return o_(n, t.params, t.paramsSerializer)
    }
}
j.forEach(["delete", "get", "head", "options"], function(t) {
    du.prototype[t] = function(n, r) {
        return this.request(No(r || {}, {
            method: t,
            url: n,
            data: (r || {}).data
        }))
    }
});
j.forEach(["post", "put", "patch"], function(t) {
    function n(r) {
        return function(o, s, l) {
            return this.request(No(l || {}, {
                method: t,
                headers: r ? {
                    "Content-Type": "multipart/form-data"
                } : {},
                url: o,
                data: s
            }))
        }
    }
    du.prototype[t] = n(), du.prototype[t + "Form"] = n(!0)
});
const Ia = du;
class bh {
    constructor(t) {
        if (typeof t != "function") throw new TypeError("executor must be a function.");
        let n;
        this.promise = new Promise(function(o) {
            n = o
        });
        const r = this;
        this.promise.then(i => {
            if (!r._listeners) return;
            let o = r._listeners.length;
            for (; o-- > 0;) r._listeners[o](i);
            r._listeners = null
        }), this.promise.then = i => {
            let o;
            const s = new Promise(l => {
                r.subscribe(l), o = l
            }).then(i);
            return s.cancel = function() {
                r.unsubscribe(o)
            }, s
        }, t(function(o, s, l) {
            r.reason || (r.reason = new _l(o, s, l), n(r.reason))
        })
    }
    throwIfRequested() {
        if (this.reason) throw this.reason
    }
    subscribe(t) {
        if (this.reason) {
            t(this.reason);
            return
        }
        this._listeners ? this._listeners.push(t) : this._listeners = [t]
    }
    unsubscribe(t) {
        if (!this._listeners) return;
        const n = this._listeners.indexOf(t);
        n !== -1 && this._listeners.splice(n, 1)
    }
    static source() {
        let t;
        return {
            token: new bh(function(i) {
                t = i
            }),
            cancel: t
        }
    }
}
const h3 = bh;

function m3(e) {
    return function(n) {
        return e.apply(null, n)
    }
}

function v3(e) {
    return j.isObject(e) && e.isAxiosError === !0
}
const lp = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511
};
Object.entries(lp).forEach(([e, t]) => {
    lp[t] = e
});
const g3 = lp;

function f_(e) {
    const t = new Ia(e),
        n = Yy(Ia.prototype.request, t);
    return j.extend(n, Ia.prototype, t, {
        allOwnKeys: !0
    }), j.extend(n, t, null, {
        allOwnKeys: !0
    }), n.create = function(i) {
        return f_(No(e, i))
    }, n
}
const it = f_(Ph);
it.Axios = Ia;
it.CanceledError = _l;
it.CancelToken = h3;
it.isCancel = a_;
it.VERSION = c_;
it.toFormData = $u;
it.AxiosError = ge;
it.Cancel = it.CanceledError;
it.all = function(t) {
    return Promise.all(t)
};
it.spread = m3;
it.isAxiosError = v3;
it.mergeConfig = No;
it.AxiosHeaders = mr;
it.formToJSON = e => l_(j.isHTMLForm(e) ? new FormData(e) : e);
it.HttpStatusCode = g3;
it.default = it;
const Mh = it,
    d_ = "https://cms.stem.is",
    Oh = d_ + "/api",
    pu = function(e) {
        return d_ + e.url
    },
    y3 = {
        async get() {
            return (await Mh.get(`${Oh}/banner`)).data
        }
    },
    p_ = () => {
        const [e, t] = R.useState(!0), [n, r] = R.useState();
        return R.useEffect(() => {
            async function i() {
                const o = await y3.get();
                console.log(o), r(o[0])
            }
            i()
        }, []), R.useEffect(() => {
            n && t(n.active)
        }, [n]), O(Kn, {
            children: e && O("div", {
                className: de($f.banner, "banner"),
                children: oe("div", {
                    className: $f.content,
                    children: [n && n.text, " ", oe("a", {
                        href: n && n.link.href,
                        children: [O("u", {
                            children: n && n.link.text
                        }), O("img", {
                            className: $f.arrow,
                            src: "/images/icons/arrow-banner.svg",
                            alt: ""
                        })]
                    })]
                })
            })
        })
    };

function Zv(e) {
    return e !== null && typeof e == "object" && "constructor" in e && e.constructor === Object
}

function Lh(e = {}, t = {}) {
    Object.keys(t).forEach(n => {
        typeof e[n] > "u" ? e[n] = t[n] : Zv(t[n]) && Zv(e[n]) && Object.keys(t[n]).length > 0 && Lh(e[n], t[n])
    })
}
const h_ = {
    body: {},
    addEventListener() {},
    removeEventListener() {},
    activeElement: {
        blur() {},
        nodeName: ""
    },
    querySelector() {
        return null
    },
    querySelectorAll() {
        return []
    },
    getElementById() {
        return null
    },
    createEvent() {
        return {
            initEvent() {}
        }
    },
    createElement() {
        return {
            children: [],
            childNodes: [],
            style: {},
            setAttribute() {},
            getElementsByTagName() {
                return []
            }
        }
    },
    createElementNS() {
        return {}
    },
    importNode() {
        return null
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    }
};

function Er() {
    const e = typeof document < "u" ? document : {};
    return Lh(e, h_), e
}
const _3 = {
    document: h_,
    navigator: {
        userAgent: ""
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    },
    history: {
        replaceState() {},
        pushState() {},
        go() {},
        back() {}
    },
    CustomEvent: function() {
        return this
    },
    addEventListener() {},
    removeEventListener() {},
    getComputedStyle() {
        return {
            getPropertyValue() {
                return ""
            }
        }
    },
    Image() {},
    Date() {},
    screen: {},
    setTimeout() {},
    clearTimeout() {},
    matchMedia() {
        return {}
    },
    requestAnimationFrame(e) {
        return typeof setTimeout > "u" ? (e(), null) : setTimeout(e, 0)
    },
    cancelAnimationFrame(e) {
        typeof setTimeout > "u" || clearTimeout(e)
    }
};

function Dt() {
    const e = typeof window < "u" ? window : {};
    return Lh(e, _3), e
}

function S3(e) {
    const t = e;
    Object.keys(t).forEach(n => {
        try {
            t[n] = null
        } catch {}
        try {
            delete t[n]
        } catch {}
    })
}

function Ao(e, t = 0) {
    return setTimeout(e, t)
}

function hn() {
    return Date.now()
}

function w3(e) {
    const t = Dt();
    let n;
    return t.getComputedStyle && (n = t.getComputedStyle(e, null)), !n && e.currentStyle && (n = e.currentStyle), n || (n = e.style), n
}

function x3(e, t = "x") {
    const n = Dt();
    let r, i, o;
    const s = w3(e);
    return n.WebKitCSSMatrix ? (i = s.transform || s.webkitTransform, i.split(",").length > 6 && (i = i.split(", ").map(l => l.replace(",", ".")).join(", ")), o = new n.WebKitCSSMatrix(i === "none" ? "" : i)) : (o = s.MozTransform || s.OTransform || s.MsTransform || s.msTransform || s.transform || s.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), r = o.toString().split(",")), t === "x" && (n.WebKitCSSMatrix ? i = o.m41 : r.length === 16 ? i = parseFloat(r[12]) : i = parseFloat(r[4])), t === "y" && (n.WebKitCSSMatrix ? i = o.m42 : r.length === 16 ? i = parseFloat(r[13]) : i = parseFloat(r[5])), i || 0
}

function ya(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function E3(e) {
    return typeof window < "u" && typeof window.HTMLElement < "u" ? e instanceof HTMLElement : e && (e.nodeType === 1 || e.nodeType === 11)
}

function Qt(...e) {
    const t = Object(e[0]),
        n = ["__proto__", "constructor", "prototype"];
    for (let r = 1; r < e.length; r += 1) {
        const i = e[r];
        if (i != null && !E3(i)) {
            const o = Object.keys(Object(i)).filter(s => n.indexOf(s) < 0);
            for (let s = 0, l = o.length; s < l; s += 1) {
                const a = o[s],
                    u = Object.getOwnPropertyDescriptor(i, a);
                u !== void 0 && u.enumerable && (ya(t[a]) && ya(i[a]) ? i[a].__swiper__ ? t[a] = i[a] : Qt(t[a], i[a]) : !ya(t[a]) && ya(i[a]) ? (t[a] = {}, i[a].__swiper__ ? t[a] = i[a] : Qt(t[a], i[a])) : t[a] = i[a])
            }
        }
    }
    return t
}

function _a(e, t, n) {
    e.style.setProperty(t, n)
}

function m_({
    swiper: e,
    targetPosition: t,
    side: n
}) {
    const r = Dt(),
        i = -e.translate;
    let o = null,
        s;
    const l = e.params.speed;
    e.wrapperEl.style.scrollSnapType = "none", r.cancelAnimationFrame(e.cssModeFrameID);
    const a = t > i ? "next" : "prev",
        u = (d, h) => a === "next" && d >= h || a === "prev" && d <= h,
        f = () => {
            s = new Date().getTime(), o === null && (o = s);
            const d = Math.max(Math.min((s - o) / l, 1), 0),
                h = .5 - Math.cos(d * Math.PI) / 2;
            let y = i + h * (t - i);
            if (u(y, t) && (y = t), e.wrapperEl.scrollTo({
                    [n]: y
                }), u(y, t)) {
                e.wrapperEl.style.overflow = "hidden", e.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
                    e.wrapperEl.style.overflow = "", e.wrapperEl.scrollTo({
                        [n]: y
                    })
                }), r.cancelAnimationFrame(e.cssModeFrameID);
                return
            }
            e.cssModeFrameID = r.requestAnimationFrame(f)
        };
    f()
}

function Wn(e, t = "") {
    return [...e.children].filter(n => n.matches(t))
}

function Nh(e, t = []) {
    const n = document.createElement(e);
    return n.classList.add(...Array.isArray(t) ? t : [t]), n
}

function C3(e) {
    const t = Dt(),
        n = Er(),
        r = e.getBoundingClientRect(),
        i = n.body,
        o = e.clientTop || i.clientTop || 0,
        s = e.clientLeft || i.clientLeft || 0,
        l = e === t ? t.scrollY : e.scrollTop,
        a = e === t ? t.scrollX : e.scrollLeft;
    return {
        top: r.top + l - o,
        left: r.left + a - s
    }
}

function T3(e, t) {
    const n = [];
    for (; e.previousElementSibling;) {
        const r = e.previousElementSibling;
        t ? r.matches(t) && n.push(r) : n.push(r), e = r
    }
    return n
}

function P3(e, t) {
    const n = [];
    for (; e.nextElementSibling;) {
        const r = e.nextElementSibling;
        t ? r.matches(t) && n.push(r) : n.push(r), e = r
    }
    return n
}

function zr(e, t) {
    return Dt().getComputedStyle(e, null).getPropertyValue(t)
}

function Jv(e) {
    let t = e,
        n;
    if (t) {
        for (n = 0;
            (t = t.previousSibling) !== null;) t.nodeType === 1 && (n += 1);
        return n
    }
}

function k3(e, t) {
    const n = [];
    let r = e.parentElement;
    for (; r;) t ? r.matches(t) && n.push(r) : n.push(r), r = r.parentElement;
    return n
}

function Xf(e, t) {
    function n(r) {
        r.target === e && (t.call(e, r), e.removeEventListener("transitionend", n))
    }
    t && e.addEventListener("transitionend", n)
}

function e1(e, t, n) {
    const r = Dt();
    return n ? e[t === "width" ? "offsetWidth" : "offsetHeight"] + parseFloat(r.getComputedStyle(e, null).getPropertyValue(t === "width" ? "margin-right" : "margin-top")) + parseFloat(r.getComputedStyle(e, null).getPropertyValue(t === "width" ? "margin-left" : "margin-bottom")) : e.offsetWidth
}
let qf;

function b3() {
    const e = Dt(),
        t = Er();
    return {
        smoothScroll: t.documentElement && t.documentElement.style && "scrollBehavior" in t.documentElement.style,
        touch: !!("ontouchstart" in e || e.DocumentTouch && t instanceof e.DocumentTouch)
    }
}

function v_() {
    return qf || (qf = b3()), qf
}
let Kf;

function M3({
    userAgent: e
} = {}) {
    const t = v_(),
        n = Dt(),
        r = n.navigator.platform,
        i = e || n.navigator.userAgent,
        o = {
            ios: !1,
            android: !1
        },
        s = n.screen.width,
        l = n.screen.height,
        a = i.match(/(Android);?[\s\/]+([\d.]+)?/);
    let u = i.match(/(iPad).*OS\s([\d_]+)/);
    const f = i.match(/(iPod)(.*OS\s([\d_]+))?/),
        d = !u && i.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
        h = r === "Win32";
    let y = r === "MacIntel";
    const _ = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
    return !u && y && t.touch && _.indexOf(`${s}x${l}`) >= 0 && (u = i.match(/(Version)\/([\d.]+)/), u || (u = [0, 1, "13_0_0"]), y = !1), a && !h && (o.os = "android", o.android = !0), (u || d || f) && (o.os = "ios", o.ios = !0), o
}

function O3(e = {}) {
    return Kf || (Kf = M3(e)), Kf
}
let Qf;

function L3() {
    const e = Dt();
    let t = !1;

    function n() {
        const r = e.navigator.userAgent.toLowerCase();
        return r.indexOf("safari") >= 0 && r.indexOf("chrome") < 0 && r.indexOf("android") < 0
    }
    if (n()) {
        const r = String(e.navigator.userAgent);
        if (r.includes("Version/")) {
            const [i, o] = r.split("Version/")[1].split(" ")[0].split(".").map(s => Number(s));
            t = i < 16 || i === 16 && o < 2
        }
    }
    return {
        isSafari: t || n(),
        needPerspectiveFix: t,
        isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e.navigator.userAgent)
    }
}

function N3() {
    return Qf || (Qf = L3()), Qf
}

function A3({
    swiper: e,
    on: t,
    emit: n
}) {
    const r = Dt();
    let i = null,
        o = null;
    const s = () => {
            !e || e.destroyed || !e.initialized || (n("beforeResize"), n("resize"))
        },
        l = () => {
            !e || e.destroyed || !e.initialized || (i = new ResizeObserver(f => {
                o = r.requestAnimationFrame(() => {
                    const {
                        width: d,
                        height: h
                    } = e;
                    let y = d,
                        _ = h;
                    f.forEach(({
                        contentBoxSize: v,
                        contentRect: E,
                        target: m
                    }) => {
                        m && m !== e.el || (y = E ? E.width : (v[0] || v).inlineSize, _ = E ? E.height : (v[0] || v).blockSize)
                    }), (y !== d || _ !== h) && s()
                })
            }), i.observe(e.el))
        },
        a = () => {
            o && r.cancelAnimationFrame(o), i && i.unobserve && e.el && (i.unobserve(e.el), i = null)
        },
        u = () => {
            !e || e.destroyed || !e.initialized || n("orientationchange")
        };
    t("init", () => {
        if (e.params.resizeObserver && typeof r.ResizeObserver < "u") {
            l();
            return
        }
        r.addEventListener("resize", s), r.addEventListener("orientationchange", u)
    }), t("destroy", () => {
        a(), r.removeEventListener("resize", s), r.removeEventListener("orientationchange", u)
    })
}

function R3({
    swiper: e,
    extendParams: t,
    on: n,
    emit: r
}) {
    const i = [],
        o = Dt(),
        s = (u, f = {}) => {
            const d = o.MutationObserver || o.WebkitMutationObserver,
                h = new d(y => {
                    if (e.__preventObserver__) return;
                    if (y.length === 1) {
                        r("observerUpdate", y[0]);
                        return
                    }
                    const _ = function() {
                        r("observerUpdate", y[0])
                    };
                    o.requestAnimationFrame ? o.requestAnimationFrame(_) : o.setTimeout(_, 0)
                });
            h.observe(u, {
                attributes: typeof f.attributes > "u" ? !0 : f.attributes,
                childList: typeof f.childList > "u" ? !0 : f.childList,
                characterData: typeof f.characterData > "u" ? !0 : f.characterData
            }), i.push(h)
        },
        l = () => {
            if (e.params.observer) {
                if (e.params.observeParents) {
                    const u = k3(e.el);
                    for (let f = 0; f < u.length; f += 1) s(u[f])
                }
                s(e.el, {
                    childList: e.params.observeSlideChildren
                }), s(e.wrapperEl, {
                    attributes: !1
                })
            }
        },
        a = () => {
            i.forEach(u => {
                u.disconnect()
            }), i.splice(0, i.length)
        };
    t({
        observer: !1,
        observeParents: !1,
        observeSlideChildren: !1
    }), n("init", l), n("destroy", a)
}
const D3 = {
    on(e, t, n) {
        const r = this;
        if (!r.eventsListeners || r.destroyed || typeof t != "function") return r;
        const i = n ? "unshift" : "push";
        return e.split(" ").forEach(o => {
            r.eventsListeners[o] || (r.eventsListeners[o] = []), r.eventsListeners[o][i](t)
        }), r
    },
    once(e, t, n) {
        const r = this;
        if (!r.eventsListeners || r.destroyed || typeof t != "function") return r;

        function i(...o) {
            r.off(e, i), i.__emitterProxy && delete i.__emitterProxy, t.apply(r, o)
        }
        return i.__emitterProxy = t, r.on(e, i, n)
    },
    onAny(e, t) {
        const n = this;
        if (!n.eventsListeners || n.destroyed || typeof e != "function") return n;
        const r = t ? "unshift" : "push";
        return n.eventsAnyListeners.indexOf(e) < 0 && n.eventsAnyListeners[r](e), n
    },
    offAny(e) {
        const t = this;
        if (!t.eventsListeners || t.destroyed || !t.eventsAnyListeners) return t;
        const n = t.eventsAnyListeners.indexOf(e);
        return n >= 0 && t.eventsAnyListeners.splice(n, 1), t
    },
    off(e, t) {
        const n = this;
        return !n.eventsListeners || n.destroyed || !n.eventsListeners || e.split(" ").forEach(r => {
            typeof t > "u" ? n.eventsListeners[r] = [] : n.eventsListeners[r] && n.eventsListeners[r].forEach((i, o) => {
                (i === t || i.__emitterProxy && i.__emitterProxy === t) && n.eventsListeners[r].splice(o, 1)
            })
        }), n
    },
    emit(...e) {
        const t = this;
        if (!t.eventsListeners || t.destroyed || !t.eventsListeners) return t;
        let n, r, i;
        return typeof e[0] == "string" || Array.isArray(e[0]) ? (n = e[0], r = e.slice(1, e.length), i = t) : (n = e[0].events, r = e[0].data, i = e[0].context || t), r.unshift(i), (Array.isArray(n) ? n : n.split(" ")).forEach(s => {
            t.eventsAnyListeners && t.eventsAnyListeners.length && t.eventsAnyListeners.forEach(l => {
                l.apply(i, [s, ...r])
            }), t.eventsListeners && t.eventsListeners[s] && t.eventsListeners[s].forEach(l => {
                l.apply(i, r)
            })
        }), t
    }
};

function z3() {
    const e = this;
    let t, n;
    const r = e.el;
    typeof e.params.width < "u" && e.params.width !== null ? t = e.params.width : t = r.clientWidth, typeof e.params.height < "u" && e.params.height !== null ? n = e.params.height : n = r.clientHeight, !(t === 0 && e.isHorizontal() || n === 0 && e.isVertical()) && (t = t - parseInt(zr(r, "padding-left") || 0, 10) - parseInt(zr(r, "padding-right") || 0, 10), n = n - parseInt(zr(r, "padding-top") || 0, 10) - parseInt(zr(r, "padding-bottom") || 0, 10), Number.isNaN(t) && (t = 0), Number.isNaN(n) && (n = 0), Object.assign(e, {
        width: t,
        height: n,
        size: e.isHorizontal() ? t : n
    }))
}

function I3() {
    const e = this;

    function t(A) {
        return e.isHorizontal() ? A : {
            width: "height",
            "margin-top": "margin-left",
            "margin-bottom ": "margin-right",
            "margin-left": "margin-top",
            "margin-right": "margin-bottom",
            "padding-left": "padding-top",
            "padding-right": "padding-bottom",
            marginRight: "marginBottom"
        }[A]
    }

    function n(A, I) {
        return parseFloat(A.getPropertyValue(t(I)) || 0)
    }
    const r = e.params,
        {
            wrapperEl: i,
            slidesEl: o,
            size: s,
            rtlTranslate: l,
            wrongRTL: a
        } = e,
        u = e.virtual && r.virtual.enabled,
        f = u ? e.virtual.slides.length : e.slides.length,
        d = Wn(o, `.${e.params.slideClass}, swiper-slide`),
        h = u ? e.virtual.slides.length : d.length;
    let y = [];
    const _ = [],
        v = [];
    let E = r.slidesOffsetBefore;
    typeof E == "function" && (E = r.slidesOffsetBefore.call(e));
    let m = r.slidesOffsetAfter;
    typeof m == "function" && (m = r.slidesOffsetAfter.call(e));
    const g = e.snapGrid.length,
        S = e.slidesGrid.length;
    let x = r.spaceBetween,
        P = -E,
        T = 0,
        L = 0;
    if (typeof s > "u") return;
    typeof x == "string" && x.indexOf("%") >= 0 ? x = parseFloat(x.replace("%", "")) / 100 * s : typeof x == "string" && (x = parseFloat(x)), e.virtualSize = -x, d.forEach(A => {
        l ? A.style.marginLeft = "" : A.style.marginRight = "", A.style.marginBottom = "", A.style.marginTop = ""
    }), r.centeredSlides && r.cssMode && (_a(i, "--swiper-centered-offset-before", ""), _a(i, "--swiper-centered-offset-after", ""));
    const b = r.grid && r.grid.rows > 1 && e.grid;
    b && e.grid.initSlides(h);
    let N;
    const H = r.slidesPerView === "auto" && r.breakpoints && Object.keys(r.breakpoints).filter(A => typeof r.breakpoints[A].slidesPerView < "u").length > 0;
    for (let A = 0; A < h; A += 1) {
        N = 0;
        let I;
        if (d[A] && (I = d[A]), b && e.grid.updateSlide(A, I, h, t), !(d[A] && zr(I, "display") === "none")) {
            if (r.slidesPerView === "auto") {
                H && (d[A].style[t("width")] = "");
                const B = getComputedStyle(I),
                    G = I.style.transform,
                    Q = I.style.webkitTransform;
                if (G && (I.style.transform = "none"), Q && (I.style.webkitTransform = "none"), r.roundLengths) N = e.isHorizontal() ? e1(I, "width", !0) : e1(I, "height", !0);
                else {
                    const le = n(B, "width"),
                        ie = n(B, "padding-left"),
                        D = n(B, "padding-right"),
                        V = n(B, "margin-left"),
                        U = n(B, "margin-right"),
                        q = B.getPropertyValue("box-sizing");
                    if (q && q === "border-box") N = le + V + U;
                    else {
                        const {
                            clientWidth: ne,
                            offsetWidth: xe
                        } = I;
                        N = le + ie + D + V + U + (xe - ne)
                    }
                }
                G && (I.style.transform = G), Q && (I.style.webkitTransform = Q), r.roundLengths && (N = Math.floor(N))
            } else N = (s - (r.slidesPerView - 1) * x) / r.slidesPerView, r.roundLengths && (N = Math.floor(N)), d[A] && (d[A].style[t("width")] = `${N}px`);
            d[A] && (d[A].swiperSlideSize = N), v.push(N), r.centeredSlides ? (P = P + N / 2 + T / 2 + x, T === 0 && A !== 0 && (P = P - s / 2 - x), A === 0 && (P = P - s / 2 - x), Math.abs(P) < 1 / 1e3 && (P = 0), r.roundLengths && (P = Math.floor(P)), L % r.slidesPerGroup === 0 && y.push(P), _.push(P)) : (r.roundLengths && (P = Math.floor(P)), (L - Math.min(e.params.slidesPerGroupSkip, L)) % e.params.slidesPerGroup === 0 && y.push(P), _.push(P), P = P + N + x), e.virtualSize += N + x, T = N, L += 1
        }
    }
    if (e.virtualSize = Math.max(e.virtualSize, s) + m, l && a && (r.effect === "slide" || r.effect === "coverflow") && (i.style.width = `${e.virtualSize+x}px`), r.setWrapperSize && (i.style[t("width")] = `${e.virtualSize+x}px`), b && e.grid.updateWrapperSize(N, y, t), !r.centeredSlides) {
        const A = [];
        for (let I = 0; I < y.length; I += 1) {
            let B = y[I];
            r.roundLengths && (B = Math.floor(B)), y[I] <= e.virtualSize - s && A.push(B)
        }
        y = A, Math.floor(e.virtualSize - s) - Math.floor(y[y.length - 1]) > 1 && y.push(e.virtualSize - s)
    }
    if (u && r.loop) {
        const A = v[0] + x;
        if (r.slidesPerGroup > 1) {
            const I = Math.ceil((e.virtual.slidesBefore + e.virtual.slidesAfter) / r.slidesPerGroup),
                B = A * r.slidesPerGroup;
            for (let G = 0; G < I; G += 1) y.push(y[y.length - 1] + B)
        }
        for (let I = 0; I < e.virtual.slidesBefore + e.virtual.slidesAfter; I += 1) r.slidesPerGroup === 1 && y.push(y[y.length - 1] + A), _.push(_[_.length - 1] + A), e.virtualSize += A
    }
    if (y.length === 0 && (y = [0]), x !== 0) {
        const A = e.isHorizontal() && l ? "marginLeft" : t("marginRight");
        d.filter((I, B) => !r.cssMode || r.loop ? !0 : B !== d.length - 1).forEach(I => {
            I.style[A] = `${x}px`
        })
    }
    if (r.centeredSlides && r.centeredSlidesBounds) {
        let A = 0;
        v.forEach(B => {
            A += B + (x || 0)
        }), A -= x;
        const I = A - s;
        y = y.map(B => B <= 0 ? -E : B > I ? I + m : B)
    }
    if (r.centerInsufficientSlides) {
        let A = 0;
        if (v.forEach(I => {
                A += I + (x || 0)
            }), A -= x, A < s) {
            const I = (s - A) / 2;
            y.forEach((B, G) => {
                y[G] = B - I
            }), _.forEach((B, G) => {
                _[G] = B + I
            })
        }
    }
    if (Object.assign(e, {
            slides: d,
            snapGrid: y,
            slidesGrid: _,
            slidesSizesGrid: v
        }), r.centeredSlides && r.cssMode && !r.centeredSlidesBounds) {
        _a(i, "--swiper-centered-offset-before", `${-y[0]}px`), _a(i, "--swiper-centered-offset-after", `${e.size/2-v[v.length-1]/2}px`);
        const A = -e.snapGrid[0],
            I = -e.slidesGrid[0];
        e.snapGrid = e.snapGrid.map(B => B + A), e.slidesGrid = e.slidesGrid.map(B => B + I)
    }
    if (h !== f && e.emit("slidesLengthChange"), y.length !== g && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")), _.length !== S && e.emit("slidesGridLengthChange"), r.watchSlidesProgress && e.updateSlidesOffset(), !u && !r.cssMode && (r.effect === "slide" || r.effect === "fade")) {
        const A = `${r.containerModifierClass}backface-hidden`,
            I = e.el.classList.contains(A);
        h <= r.maxBackfaceHiddenSlides ? I || e.el.classList.add(A) : I && e.el.classList.remove(A)
    }
}

function F3(e) {
    const t = this,
        n = [],
        r = t.virtual && t.params.virtual.enabled;
    let i = 0,
        o;
    typeof e == "number" ? t.setTransition(e) : e === !0 && t.setTransition(t.params.speed);
    const s = l => r ? t.slides[t.getSlideIndexByData(l)] : t.slides[l];
    if (t.params.slidesPerView !== "auto" && t.params.slidesPerView > 1)
        if (t.params.centeredSlides)(t.visibleSlides || []).forEach(l => {
            n.push(l)
        });
        else
            for (o = 0; o < Math.ceil(t.params.slidesPerView); o += 1) {
                const l = t.activeIndex + o;
                if (l > t.slides.length && !r) break;
                n.push(s(l))
            } else n.push(s(t.activeIndex));
    for (o = 0; o < n.length; o += 1)
        if (typeof n[o] < "u") {
            const l = n[o].offsetHeight;
            i = l > i ? l : i
        }(i || i === 0) && (t.wrapperEl.style.height = `${i}px`)
}

function B3() {
    const e = this,
        t = e.slides,
        n = e.isElement ? e.isHorizontal() ? e.wrapperEl.offsetLeft : e.wrapperEl.offsetTop : 0;
    for (let r = 0; r < t.length; r += 1) t[r].swiperSlideOffset = (e.isHorizontal() ? t[r].offsetLeft : t[r].offsetTop) - n - e.cssOverflowAdjustment()
}

function j3(e = this && this.translate || 0) {
    const t = this,
        n = t.params,
        {
            slides: r,
            rtlTranslate: i,
            snapGrid: o
        } = t;
    if (r.length === 0) return;
    typeof r[0].swiperSlideOffset > "u" && t.updateSlidesOffset();
    let s = -e;
    i && (s = e), r.forEach(a => {
        a.classList.remove(n.slideVisibleClass)
    }), t.visibleSlidesIndexes = [], t.visibleSlides = [];
    let l = n.spaceBetween;
    typeof l == "string" && l.indexOf("%") >= 0 ? l = parseFloat(l.replace("%", "")) / 100 * t.size : typeof l == "string" && (l = parseFloat(l));
    for (let a = 0; a < r.length; a += 1) {
        const u = r[a];
        let f = u.swiperSlideOffset;
        n.cssMode && n.centeredSlides && (f -= r[0].swiperSlideOffset);
        const d = (s + (n.centeredSlides ? t.minTranslate() : 0) - f) / (u.swiperSlideSize + l),
            h = (s - o[0] + (n.centeredSlides ? t.minTranslate() : 0) - f) / (u.swiperSlideSize + l),
            y = -(s - f),
            _ = y + t.slidesSizesGrid[a];
        (y >= 0 && y < t.size - 1 || _ > 1 && _ <= t.size || y <= 0 && _ >= t.size) && (t.visibleSlides.push(u), t.visibleSlidesIndexes.push(a), r[a].classList.add(n.slideVisibleClass)), u.progress = i ? -d : d, u.originalProgress = i ? -h : h
    }
}

function V3(e) {
    const t = this;
    if (typeof e > "u") {
        const f = t.rtlTranslate ? -1 : 1;
        e = t && t.translate && t.translate * f || 0
    }
    const n = t.params,
        r = t.maxTranslate() - t.minTranslate();
    let {
        progress: i,
        isBeginning: o,
        isEnd: s,
        progressLoop: l
    } = t;
    const a = o,
        u = s;
    if (r === 0) i = 0, o = !0, s = !0;
    else {
        i = (e - t.minTranslate()) / r;
        const f = Math.abs(e - t.minTranslate()) < 1,
            d = Math.abs(e - t.maxTranslate()) < 1;
        o = f || i <= 0, s = d || i >= 1, f && (i = 0), d && (i = 1)
    }
    if (n.loop) {
        const f = t.getSlideIndexByData(0),
            d = t.getSlideIndexByData(t.slides.length - 1),
            h = t.slidesGrid[f],
            y = t.slidesGrid[d],
            _ = t.slidesGrid[t.slidesGrid.length - 1],
            v = Math.abs(e);
        v >= h ? l = (v - h) / _ : l = (v + _ - y) / _, l > 1 && (l -= 1)
    }
    Object.assign(t, {
        progress: i,
        progressLoop: l,
        isBeginning: o,
        isEnd: s
    }), (n.watchSlidesProgress || n.centeredSlides && n.autoHeight) && t.updateSlidesProgress(e), o && !a && t.emit("reachBeginning toEdge"), s && !u && t.emit("reachEnd toEdge"), (a && !o || u && !s) && t.emit("fromEdge"), t.emit("progress", i)
}

function U3() {
    const e = this,
        {
            slides: t,
            params: n,
            slidesEl: r,
            activeIndex: i
        } = e,
        o = e.virtual && n.virtual.enabled,
        s = a => Wn(r, `.${n.slideClass}${a}, swiper-slide${a}`)[0];
    t.forEach(a => {
        a.classList.remove(n.slideActiveClass, n.slideNextClass, n.slidePrevClass)
    });
    let l;
    if (o)
        if (n.loop) {
            let a = i - e.virtual.slidesBefore;
            a < 0 && (a = e.virtual.slides.length + a), a >= e.virtual.slides.length && (a -= e.virtual.slides.length), l = s(`[data-swiper-slide-index="${a}"]`)
        } else l = s(`[data-swiper-slide-index="${i}"]`);
    else l = t[i];
    if (l) {
        l.classList.add(n.slideActiveClass);
        let a = P3(l, `.${n.slideClass}, swiper-slide`)[0];
        n.loop && !a && (a = t[0]), a && a.classList.add(n.slideNextClass);
        let u = T3(l, `.${n.slideClass}, swiper-slide`)[0];
        n.loop && !u === 0 && (u = t[t.length - 1]), u && u.classList.add(n.slidePrevClass)
    }
    e.emitSlidesClasses()
}
const Fa = (e, t) => {
        if (!e || e.destroyed || !e.params) return;
        const n = () => e.isElement ? "swiper-slide" : `.${e.params.slideClass}`,
            r = t.closest(n());
        if (r) {
            const i = r.querySelector(`.${e.params.lazyPreloaderClass}`);
            i && i.remove()
        }
    },
    Zf = (e, t) => {
        if (!e.slides[t]) return;
        const n = e.slides[t].querySelector('[loading="lazy"]');
        n && n.removeAttribute("loading")
    },
    ap = e => {
        if (!e || e.destroyed || !e.params) return;
        let t = e.params.lazyPreloadPrevNext;
        const n = e.slides.length;
        if (!n || !t || t < 0) return;
        t = Math.min(t, n);
        const r = e.params.slidesPerView === "auto" ? e.slidesPerViewDynamic() : Math.ceil(e.params.slidesPerView),
            i = e.activeIndex;
        if (e.params.grid && e.params.grid.rows > 1) {
            const s = i,
                l = [s - t];
            l.push(...Array.from({
                length: t
            }).map((a, u) => s + r + u)), e.slides.forEach((a, u) => {
                l.includes(a.column) && Zf(e, u)
            });
            return
        }
        const o = i + r - 1;
        if (e.params.rewind || e.params.loop)
            for (let s = i - t; s <= o + t; s += 1) {
                const l = (s % n + n) % n;
                (l < i || l > o) && Zf(e, l)
            } else
                for (let s = Math.max(i - t, 0); s <= Math.min(o + t, n - 1); s += 1) s !== i && (s > o || s < i) && Zf(e, s)
    };

function $3(e) {
    const {
        slidesGrid: t,
        params: n
    } = e, r = e.rtlTranslate ? e.translate : -e.translate;
    let i;
    for (let o = 0; o < t.length; o += 1) typeof t[o + 1] < "u" ? r >= t[o] && r < t[o + 1] - (t[o + 1] - t[o]) / 2 ? i = o : r >= t[o] && r < t[o + 1] && (i = o + 1) : r >= t[o] && (i = o);
    return n.normalizeSlideIndex && (i < 0 || typeof i > "u") && (i = 0), i
}

function H3(e) {
    const t = this,
        n = t.rtlTranslate ? t.translate : -t.translate,
        {
            snapGrid: r,
            params: i,
            activeIndex: o,
            realIndex: s,
            snapIndex: l
        } = t;
    let a = e,
        u;
    const f = h => {
        let y = h - t.virtual.slidesBefore;
        return y < 0 && (y = t.virtual.slides.length + y), y >= t.virtual.slides.length && (y -= t.virtual.slides.length), y
    };
    if (typeof a > "u" && (a = $3(t)), r.indexOf(n) >= 0) u = r.indexOf(n);
    else {
        const h = Math.min(i.slidesPerGroupSkip, a);
        u = h + Math.floor((a - h) / i.slidesPerGroup)
    }
    if (u >= r.length && (u = r.length - 1), a === o) {
        u !== l && (t.snapIndex = u, t.emit("snapIndexChange")), t.params.loop && t.virtual && t.params.virtual.enabled && (t.realIndex = f(a));
        return
    }
    let d;
    t.virtual && i.virtual.enabled && i.loop ? d = f(a) : t.slides[a] ? d = parseInt(t.slides[a].getAttribute("data-swiper-slide-index") || a, 10) : d = a, Object.assign(t, {
        previousSnapIndex: l,
        snapIndex: u,
        previousRealIndex: s,
        realIndex: d,
        previousIndex: o,
        activeIndex: a
    }), t.initialized && ap(t), t.emit("activeIndexChange"), t.emit("snapIndexChange"), s !== d && t.emit("realIndexChange"), (t.initialized || t.params.runCallbacksOnInit) && t.emit("slideChange")
}

function W3(e) {
    const t = this,
        n = t.params,
        r = e.closest(`.${n.slideClass}, swiper-slide`);
    let i = !1,
        o;
    if (r) {
        for (let s = 0; s < t.slides.length; s += 1)
            if (t.slides[s] === r) {
                i = !0, o = s;
                break
            }
    }
    if (r && i) t.clickedSlide = r, t.virtual && t.params.virtual.enabled ? t.clickedIndex = parseInt(r.getAttribute("data-swiper-slide-index"), 10) : t.clickedIndex = o;
    else {
        t.clickedSlide = void 0, t.clickedIndex = void 0;
        return
    }
    n.slideToClickedSlide && t.clickedIndex !== void 0 && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide()
}
const G3 = {
    updateSize: z3,
    updateSlides: I3,
    updateAutoHeight: F3,
    updateSlidesOffset: B3,
    updateSlidesProgress: j3,
    updateProgress: V3,
    updateSlidesClasses: U3,
    updateActiveIndex: H3,
    updateClickedSlide: W3
};

function Y3(e = this.isHorizontal() ? "x" : "y") {
    const t = this,
        {
            params: n,
            rtlTranslate: r,
            translate: i,
            wrapperEl: o
        } = t;
    if (n.virtualTranslate) return r ? -i : i;
    if (n.cssMode) return i;
    let s = x3(o, e);
    return s += t.cssOverflowAdjustment(), r && (s = -s), s || 0
}

function X3(e, t) {
    const n = this,
        {
            rtlTranslate: r,
            params: i,
            wrapperEl: o,
            progress: s
        } = n;
    let l = 0,
        a = 0;
    const u = 0;
    n.isHorizontal() ? l = r ? -e : e : a = e, i.roundLengths && (l = Math.floor(l), a = Math.floor(a)), n.previousTranslate = n.translate, n.translate = n.isHorizontal() ? l : a, i.cssMode ? o[n.isHorizontal() ? "scrollLeft" : "scrollTop"] = n.isHorizontal() ? -l : -a : i.virtualTranslate || (n.isHorizontal() ? l -= n.cssOverflowAdjustment() : a -= n.cssOverflowAdjustment(), o.style.transform = `translate3d(${l}px, ${a}px, ${u}px)`);
    let f;
    const d = n.maxTranslate() - n.minTranslate();
    d === 0 ? f = 0 : f = (e - n.minTranslate()) / d, f !== s && n.updateProgress(e), n.emit("setTranslate", n.translate, t)
}

function q3() {
    return -this.snapGrid[0]
}

function K3() {
    return -this.snapGrid[this.snapGrid.length - 1]
}

function Q3(e = 0, t = this.params.speed, n = !0, r = !0, i) {
    const o = this,
        {
            params: s,
            wrapperEl: l
        } = o;
    if (o.animating && s.preventInteractionOnTransition) return !1;
    const a = o.minTranslate(),
        u = o.maxTranslate();
    let f;
    if (r && e > a ? f = a : r && e < u ? f = u : f = e, o.updateProgress(f), s.cssMode) {
        const d = o.isHorizontal();
        if (t === 0) l[d ? "scrollLeft" : "scrollTop"] = -f;
        else {
            if (!o.support.smoothScroll) return m_({
                swiper: o,
                targetPosition: -f,
                side: d ? "left" : "top"
            }), !0;
            l.scrollTo({
                [d ? "left" : "top"]: -f,
                behavior: "smooth"
            })
        }
        return !0
    }
    return t === 0 ? (o.setTransition(0), o.setTranslate(f), n && (o.emit("beforeTransitionStart", t, i), o.emit("transitionEnd"))) : (o.setTransition(t), o.setTranslate(f), n && (o.emit("beforeTransitionStart", t, i), o.emit("transitionStart")), o.animating || (o.animating = !0, o.onTranslateToWrapperTransitionEnd || (o.onTranslateToWrapperTransitionEnd = function(h) {
        !o || o.destroyed || h.target === this && (o.wrapperEl.removeEventListener("transitionend", o.onTranslateToWrapperTransitionEnd), o.onTranslateToWrapperTransitionEnd = null, delete o.onTranslateToWrapperTransitionEnd, n && o.emit("transitionEnd"))
    }), o.wrapperEl.addEventListener("transitionend", o.onTranslateToWrapperTransitionEnd))), !0
}
const Z3 = {
    getTranslate: Y3,
    setTranslate: X3,
    minTranslate: q3,
    maxTranslate: K3,
    translateTo: Q3
};

function J3(e, t) {
    const n = this;
    n.params.cssMode || (n.wrapperEl.style.transitionDuration = `${e}ms`), n.emit("setTransition", e, t)
}

function g_({
    swiper: e,
    runCallbacks: t,
    direction: n,
    step: r
}) {
    const {
        activeIndex: i,
        previousIndex: o
    } = e;
    let s = n;
    if (s || (i > o ? s = "next" : i < o ? s = "prev" : s = "reset"), e.emit(`transition${r}`), t && i !== o) {
        if (s === "reset") {
            e.emit(`slideResetTransition${r}`);
            return
        }
        e.emit(`slideChangeTransition${r}`), s === "next" ? e.emit(`slideNextTransition${r}`) : e.emit(`slidePrevTransition${r}`)
    }
}

function eC(e = !0, t) {
    const n = this,
        {
            params: r
        } = n;
    r.cssMode || (r.autoHeight && n.updateAutoHeight(), g_({
        swiper: n,
        runCallbacks: e,
        direction: t,
        step: "Start"
    }))
}

function tC(e = !0, t) {
    const n = this,
        {
            params: r
        } = n;
    n.animating = !1, !r.cssMode && (n.setTransition(0), g_({
        swiper: n,
        runCallbacks: e,
        direction: t,
        step: "End"
    }))
}
const nC = {
    setTransition: J3,
    transitionStart: eC,
    transitionEnd: tC
};

function rC(e = 0, t = this.params.speed, n = !0, r, i) {
    typeof e == "string" && (e = parseInt(e, 10));
    const o = this;
    let s = e;
    s < 0 && (s = 0);
    const {
        params: l,
        snapGrid: a,
        slidesGrid: u,
        previousIndex: f,
        activeIndex: d,
        rtlTranslate: h,
        wrapperEl: y,
        enabled: _
    } = o;
    if (o.animating && l.preventInteractionOnTransition || !_ && !r && !i) return !1;
    const v = Math.min(o.params.slidesPerGroupSkip, s);
    let E = v + Math.floor((s - v) / o.params.slidesPerGroup);
    E >= a.length && (E = a.length - 1);
    const m = -a[E];
    if (l.normalizeSlideIndex)
        for (let S = 0; S < u.length; S += 1) {
            const x = -Math.floor(m * 100),
                P = Math.floor(u[S] * 100),
                T = Math.floor(u[S + 1] * 100);
            typeof u[S + 1] < "u" ? x >= P && x < T - (T - P) / 2 ? s = S : x >= P && x < T && (s = S + 1) : x >= P && (s = S)
        }
    if (o.initialized && s !== d && (!o.allowSlideNext && (h ? m > o.translate && m > o.minTranslate() : m < o.translate && m < o.minTranslate()) || !o.allowSlidePrev && m > o.translate && m > o.maxTranslate() && (d || 0) !== s)) return !1;
    s !== (f || 0) && n && o.emit("beforeSlideChangeStart"), o.updateProgress(m);
    let g;
    if (s > d ? g = "next" : s < d ? g = "prev" : g = "reset", h && -m === o.translate || !h && m === o.translate) return o.updateActiveIndex(s), l.autoHeight && o.updateAutoHeight(), o.updateSlidesClasses(), l.effect !== "slide" && o.setTranslate(m), g !== "reset" && (o.transitionStart(n, g), o.transitionEnd(n, g)), !1;
    if (l.cssMode) {
        const S = o.isHorizontal(),
            x = h ? m : -m;
        if (t === 0) {
            const P = o.virtual && o.params.virtual.enabled;
            P && (o.wrapperEl.style.scrollSnapType = "none", o._immediateVirtual = !0), P && !o._cssModeVirtualInitialSet && o.params.initialSlide > 0 ? (o._cssModeVirtualInitialSet = !0, requestAnimationFrame(() => {
                y[S ? "scrollLeft" : "scrollTop"] = x
            })) : y[S ? "scrollLeft" : "scrollTop"] = x, P && requestAnimationFrame(() => {
                o.wrapperEl.style.scrollSnapType = "", o._immediateVirtual = !1
            })
        } else {
            if (!o.support.smoothScroll) return m_({
                swiper: o,
                targetPosition: x,
                side: S ? "left" : "top"
            }), !0;
            y.scrollTo({
                [S ? "left" : "top"]: x,
                behavior: "smooth"
            })
        }
        return !0
    }
    return o.setTransition(t), o.setTranslate(m), o.updateActiveIndex(s), o.updateSlidesClasses(), o.emit("beforeTransitionStart", t, r), o.transitionStart(n, g), t === 0 ? o.transitionEnd(n, g) : o.animating || (o.animating = !0, o.onSlideToWrapperTransitionEnd || (o.onSlideToWrapperTransitionEnd = function(x) {
        !o || o.destroyed || x.target === this && (o.wrapperEl.removeEventListener("transitionend", o.onSlideToWrapperTransitionEnd), o.onSlideToWrapperTransitionEnd = null, delete o.onSlideToWrapperTransitionEnd, o.transitionEnd(n, g))
    }), o.wrapperEl.addEventListener("transitionend", o.onSlideToWrapperTransitionEnd)), !0
}

function iC(e = 0, t = this.params.speed, n = !0, r) {
    typeof e == "string" && (e = parseInt(e, 10));
    const i = this;
    let o = e;
    return i.params.loop && (i.virtual && i.params.virtual.enabled ? o = o + i.virtual.slidesBefore : o = i.getSlideIndexByData(o)), i.slideTo(o, t, n, r)
}

function oC(e = this.params.speed, t = !0, n) {
    const r = this,
        {
            enabled: i,
            params: o,
            animating: s
        } = r;
    if (!i) return r;
    let l = o.slidesPerGroup;
    o.slidesPerView === "auto" && o.slidesPerGroup === 1 && o.slidesPerGroupAuto && (l = Math.max(r.slidesPerViewDynamic("current", !0), 1));
    const a = r.activeIndex < o.slidesPerGroupSkip ? 1 : l,
        u = r.virtual && o.virtual.enabled;
    if (o.loop) {
        if (s && !u && o.loopPreventsSliding) return !1;
        r.loopFix({
            direction: "next"
        }), r._clientLeft = r.wrapperEl.clientLeft
    }
    return o.rewind && r.isEnd ? r.slideTo(0, e, t, n) : r.slideTo(r.activeIndex + a, e, t, n)
}

function sC(e = this.params.speed, t = !0, n) {
    const r = this,
        {
            params: i,
            snapGrid: o,
            slidesGrid: s,
            rtlTranslate: l,
            enabled: a,
            animating: u
        } = r;
    if (!a) return r;
    const f = r.virtual && i.virtual.enabled;
    if (i.loop) {
        if (u && !f && i.loopPreventsSliding) return !1;
        r.loopFix({
            direction: "prev"
        }), r._clientLeft = r.wrapperEl.clientLeft
    }
    const d = l ? r.translate : -r.translate;

    function h(m) {
        return m < 0 ? -Math.floor(Math.abs(m)) : Math.floor(m)
    }
    const y = h(d),
        _ = o.map(m => h(m));
    let v = o[_.indexOf(y) - 1];
    if (typeof v > "u" && i.cssMode) {
        let m;
        o.forEach((g, S) => {
            y >= g && (m = S)
        }), typeof m < "u" && (v = o[m > 0 ? m - 1 : m])
    }
    let E = 0;
    if (typeof v < "u" && (E = s.indexOf(v), E < 0 && (E = r.activeIndex - 1), i.slidesPerView === "auto" && i.slidesPerGroup === 1 && i.slidesPerGroupAuto && (E = E - r.slidesPerViewDynamic("previous", !0) + 1, E = Math.max(E, 0))), i.rewind && r.isBeginning) {
        const m = r.params.virtual && r.params.virtual.enabled && r.virtual ? r.virtual.slides.length - 1 : r.slides.length - 1;
        return r.slideTo(m, e, t, n)
    }
    return r.slideTo(E, e, t, n)
}

function lC(e = this.params.speed, t = !0, n) {
    const r = this;
    return r.slideTo(r.activeIndex, e, t, n)
}

function aC(e = this.params.speed, t = !0, n, r = .5) {
    const i = this;
    let o = i.activeIndex;
    const s = Math.min(i.params.slidesPerGroupSkip, o),
        l = s + Math.floor((o - s) / i.params.slidesPerGroup),
        a = i.rtlTranslate ? i.translate : -i.translate;
    if (a >= i.snapGrid[l]) {
        const u = i.snapGrid[l],
            f = i.snapGrid[l + 1];
        a - u > (f - u) * r && (o += i.params.slidesPerGroup)
    } else {
        const u = i.snapGrid[l - 1],
            f = i.snapGrid[l];
        a - u <= (f - u) * r && (o -= i.params.slidesPerGroup)
    }
    return o = Math.max(o, 0), o = Math.min(o, i.slidesGrid.length - 1), i.slideTo(o, e, t, n)
}

function uC() {
    const e = this,
        {
            params: t,
            slidesEl: n
        } = e,
        r = t.slidesPerView === "auto" ? e.slidesPerViewDynamic() : t.slidesPerView;
    let i = e.clickedIndex,
        o;
    const s = e.isElement ? "swiper-slide" : `.${t.slideClass}`;
    if (t.loop) {
        if (e.animating) return;
        o = parseInt(e.clickedSlide.getAttribute("data-swiper-slide-index"), 10), t.centeredSlides ? i < e.loopedSlides - r / 2 || i > e.slides.length - e.loopedSlides + r / 2 ? (e.loopFix(), i = e.getSlideIndex(Wn(n, `${s}[data-swiper-slide-index="${o}"]`)[0]), Ao(() => {
            e.slideTo(i)
        })) : e.slideTo(i) : i > e.slides.length - r ? (e.loopFix(), i = e.getSlideIndex(Wn(n, `${s}[data-swiper-slide-index="${o}"]`)[0]), Ao(() => {
            e.slideTo(i)
        })) : e.slideTo(i)
    } else e.slideTo(i)
}
const cC = {
    slideTo: rC,
    slideToLoop: iC,
    slideNext: oC,
    slidePrev: sC,
    slideReset: lC,
    slideToClosest: aC,
    slideToClickedSlide: uC
};

function fC(e) {
    const t = this,
        {
            params: n,
            slidesEl: r
        } = t;
    if (!n.loop || t.virtual && t.params.virtual.enabled) return;
    Wn(r, `.${n.slideClass}, swiper-slide`).forEach((o, s) => {
        o.setAttribute("data-swiper-slide-index", s)
    }), t.loopFix({
        slideRealIndex: e,
        direction: n.centeredSlides ? void 0 : "next"
    })
}

function dC({
    slideRealIndex: e,
    slideTo: t = !0,
    direction: n,
    setTranslate: r,
    activeSlideIndex: i,
    byController: o,
    byMousewheel: s
} = {}) {
    const l = this;
    if (!l.params.loop) return;
    l.emit("beforeLoopFix");
    const {
        slides: a,
        allowSlidePrev: u,
        allowSlideNext: f,
        slidesEl: d,
        params: h
    } = l;
    if (l.allowSlidePrev = !0, l.allowSlideNext = !0, l.virtual && h.virtual.enabled) {
        t && (!h.centeredSlides && l.snapIndex === 0 ? l.slideTo(l.virtual.slides.length, 0, !1, !0) : h.centeredSlides && l.snapIndex < h.slidesPerView ? l.slideTo(l.virtual.slides.length + l.snapIndex, 0, !1, !0) : l.snapIndex === l.snapGrid.length - 1 && l.slideTo(l.virtual.slidesBefore, 0, !1, !0)), l.allowSlidePrev = u, l.allowSlideNext = f, l.emit("loopFix");
        return
    }
    const y = h.slidesPerView === "auto" ? l.slidesPerViewDynamic() : Math.ceil(parseFloat(h.slidesPerView, 10));
    let _ = h.loopedSlides || y;
    _ % h.slidesPerGroup !== 0 && (_ += h.slidesPerGroup - _ % h.slidesPerGroup), l.loopedSlides = _;
    const v = [],
        E = [];
    let m = l.activeIndex;
    typeof i > "u" ? i = l.getSlideIndex(l.slides.filter(T => T.classList.contains(h.slideActiveClass))[0]) : m = i;
    const g = n === "next" || !n,
        S = n === "prev" || !n;
    let x = 0,
        P = 0;
    if (i < _) {
        x = Math.max(_ - i, h.slidesPerGroup);
        for (let T = 0; T < _ - i; T += 1) {
            const L = T - Math.floor(T / a.length) * a.length;
            v.push(a.length - L - 1)
        }
    } else if (i > l.slides.length - _ * 2) {
        P = Math.max(i - (l.slides.length - _ * 2), h.slidesPerGroup);
        for (let T = 0; T < P; T += 1) {
            const L = T - Math.floor(T / a.length) * a.length;
            E.push(L)
        }
    }
    if (S && v.forEach(T => {
            l.slides[T].swiperLoopMoveDOM = !0, d.prepend(l.slides[T]), l.slides[T].swiperLoopMoveDOM = !1
        }), g && E.forEach(T => {
            l.slides[T].swiperLoopMoveDOM = !0, d.append(l.slides[T]), l.slides[T].swiperLoopMoveDOM = !1
        }), l.recalcSlides(), h.slidesPerView === "auto" && l.updateSlides(), h.watchSlidesProgress && l.updateSlidesOffset(), t) {
        if (v.length > 0 && S)
            if (typeof e > "u") {
                const T = l.slidesGrid[m],
                    b = l.slidesGrid[m + x] - T;
                s ? l.setTranslate(l.translate - b) : (l.slideTo(m + x, 0, !1, !0), r && (l.touches[l.isHorizontal() ? "startX" : "startY"] += b))
            } else r && l.slideToLoop(e, 0, !1, !0);
        else if (E.length > 0 && g)
            if (typeof e > "u") {
                const T = l.slidesGrid[m],
                    b = l.slidesGrid[m - P] - T;
                s ? l.setTranslate(l.translate - b) : (l.slideTo(m - P, 0, !1, !0), r && (l.touches[l.isHorizontal() ? "startX" : "startY"] += b))
            } else l.slideToLoop(e, 0, !1, !0)
    }
    if (l.allowSlidePrev = u, l.allowSlideNext = f, l.controller && l.controller.control && !o) {
        const T = {
            slideRealIndex: e,
            slideTo: !1,
            direction: n,
            setTranslate: r,
            activeSlideIndex: i,
            byController: !0
        };
        Array.isArray(l.controller.control) ? l.controller.control.forEach(L => {
            !L.destroyed && L.params.loop && L.loopFix(T)
        }) : l.controller.control instanceof l.constructor && l.controller.control.params.loop && l.controller.control.loopFix(T)
    }
    l.emit("loopFix")
}

function pC() {
    const e = this,
        {
            params: t,
            slidesEl: n
        } = e;
    if (!t.loop || e.virtual && e.params.virtual.enabled) return;
    e.recalcSlides();
    const r = [];
    e.slides.forEach(i => {
        const o = typeof i.swiperSlideIndex > "u" ? i.getAttribute("data-swiper-slide-index") * 1 : i.swiperSlideIndex;
        r[o] = i
    }), e.slides.forEach(i => {
        i.removeAttribute("data-swiper-slide-index")
    }), r.forEach(i => {
        n.append(i)
    }), e.recalcSlides(), e.slideTo(e.realIndex, 0)
}
const hC = {
    loopCreate: fC,
    loopFix: dC,
    loopDestroy: pC
};

function mC(e) {
    const t = this;
    if (!t.params.simulateTouch || t.params.watchOverflow && t.isLocked || t.params.cssMode) return;
    const n = t.params.touchEventsTarget === "container" ? t.el : t.wrapperEl;
    t.isElement && (t.__preventObserver__ = !0), n.style.cursor = "move", n.style.cursor = e ? "grabbing" : "grab", t.isElement && requestAnimationFrame(() => {
        t.__preventObserver__ = !1
    })
}

function vC() {
    const e = this;
    e.params.watchOverflow && e.isLocked || e.params.cssMode || (e.isElement && (e.__preventObserver__ = !0), e[e.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "", e.isElement && requestAnimationFrame(() => {
        e.__preventObserver__ = !1
    }))
}
const gC = {
    setGrabCursor: mC,
    unsetGrabCursor: vC
};

function yC(e, t = this) {
    function n(r) {
        if (!r || r === Er() || r === Dt()) return null;
        r.assignedSlot && (r = r.assignedSlot);
        const i = r.closest(e);
        return !i && !r.getRootNode ? null : i || n(r.getRootNode().host)
    }
    return n(t)
}

function _C(e) {
    const t = this,
        n = Er(),
        r = Dt(),
        i = t.touchEventsData;
    i.evCache.push(e);
    const {
        params: o,
        touches: s,
        enabled: l
    } = t;
    if (!l || !o.simulateTouch && e.pointerType === "mouse" || t.animating && o.preventInteractionOnTransition) return;
    !t.animating && o.cssMode && o.loop && t.loopFix();
    let a = e;
    a.originalEvent && (a = a.originalEvent);
    let u = a.target;
    if (o.touchEventsTarget === "wrapper" && !t.wrapperEl.contains(u) || "which" in a && a.which === 3 || "button" in a && a.button > 0 || i.isTouched && i.isMoved) return;
    const f = !!o.noSwipingClass && o.noSwipingClass !== "",
        d = e.composedPath ? e.composedPath() : e.path;
    f && a.target && a.target.shadowRoot && d && (u = d[0]);
    const h = o.noSwipingSelector ? o.noSwipingSelector : `.${o.noSwipingClass}`,
        y = !!(a.target && a.target.shadowRoot);
    if (o.noSwiping && (y ? yC(h, u) : u.closest(h))) {
        t.allowClick = !0;
        return
    }
    if (o.swipeHandler && !u.closest(o.swipeHandler)) return;
    s.currentX = a.pageX, s.currentY = a.pageY;
    const _ = s.currentX,
        v = s.currentY,
        E = o.edgeSwipeDetection || o.iOSEdgeSwipeDetection,
        m = o.edgeSwipeThreshold || o.iOSEdgeSwipeThreshold;
    if (E && (_ <= m || _ >= r.innerWidth - m))
        if (E === "prevent") e.preventDefault();
        else return;
    Object.assign(i, {
        isTouched: !0,
        isMoved: !1,
        allowTouchCallbacks: !0,
        isScrolling: void 0,
        startMoving: void 0
    }), s.startX = _, s.startY = v, i.touchStartTime = hn(), t.allowClick = !0, t.updateSize(), t.swipeDirection = void 0, o.threshold > 0 && (i.allowThresholdMove = !1);
    let g = !0;
    u.matches(i.focusableElements) && (g = !1, u.nodeName === "SELECT" && (i.isTouched = !1)), n.activeElement && n.activeElement.matches(i.focusableElements) && n.activeElement !== u && n.activeElement.blur();
    const S = g && t.allowTouchMove && o.touchStartPreventDefault;
    (o.touchStartForcePreventDefault || S) && !u.isContentEditable && a.preventDefault(), o.freeMode && o.freeMode.enabled && t.freeMode && t.animating && !o.cssMode && t.freeMode.onTouchStart(), t.emit("touchStart", a)
}

function SC(e) {
    const t = Er(),
        n = this,
        r = n.touchEventsData,
        {
            params: i,
            touches: o,
            rtlTranslate: s,
            enabled: l
        } = n;
    if (!l || !i.simulateTouch && e.pointerType === "mouse") return;
    let a = e;
    if (a.originalEvent && (a = a.originalEvent), !r.isTouched) {
        r.startMoving && r.isScrolling && n.emit("touchMoveOpposite", a);
        return
    }
    const u = r.evCache.findIndex(T => T.pointerId === a.pointerId);
    u >= 0 && (r.evCache[u] = a);
    const f = r.evCache.length > 1 ? r.evCache[0] : a,
        d = f.pageX,
        h = f.pageY;
    if (a.preventedByNestedSwiper) {
        o.startX = d, o.startY = h;
        return
    }
    if (!n.allowTouchMove) {
        a.target.matches(r.focusableElements) || (n.allowClick = !1), r.isTouched && (Object.assign(o, {
            startX: d,
            startY: h,
            prevX: n.touches.currentX,
            prevY: n.touches.currentY,
            currentX: d,
            currentY: h
        }), r.touchStartTime = hn());
        return
    }
    if (i.touchReleaseOnEdges && !i.loop) {
        if (n.isVertical()) {
            if (h < o.startY && n.translate <= n.maxTranslate() || h > o.startY && n.translate >= n.minTranslate()) {
                r.isTouched = !1, r.isMoved = !1;
                return
            }
        } else if (d < o.startX && n.translate <= n.maxTranslate() || d > o.startX && n.translate >= n.minTranslate()) return
    }
    if (t.activeElement && a.target === t.activeElement && a.target.matches(r.focusableElements)) {
        r.isMoved = !0, n.allowClick = !1;
        return
    }
    if (r.allowTouchCallbacks && n.emit("touchMove", a), a.targetTouches && a.targetTouches.length > 1) return;
    o.currentX = d, o.currentY = h;
    const y = o.currentX - o.startX,
        _ = o.currentY - o.startY;
    if (n.params.threshold && Math.sqrt(y ** 2 + _ ** 2) < n.params.threshold) return;
    if (typeof r.isScrolling > "u") {
        let T;
        n.isHorizontal() && o.currentY === o.startY || n.isVertical() && o.currentX === o.startX ? r.isScrolling = !1 : y * y + _ * _ >= 25 && (T = Math.atan2(Math.abs(_), Math.abs(y)) * 180 / Math.PI, r.isScrolling = n.isHorizontal() ? T > i.touchAngle : 90 - T > i.touchAngle)
    }
    if (r.isScrolling && n.emit("touchMoveOpposite", a), typeof r.startMoving > "u" && (o.currentX !== o.startX || o.currentY !== o.startY) && (r.startMoving = !0), r.isScrolling || n.zoom && n.params.zoom && n.params.zoom.enabled && r.evCache.length > 1) {
        r.isTouched = !1;
        return
    }
    if (!r.startMoving) return;
    n.allowClick = !1, !i.cssMode && a.cancelable && a.preventDefault(), i.touchMoveStopPropagation && !i.nested && a.stopPropagation();
    let v = n.isHorizontal() ? y : _,
        E = n.isHorizontal() ? o.currentX - o.previousX : o.currentY - o.previousY;
    i.oneWayMovement && (v = Math.abs(v) * (s ? 1 : -1), E = Math.abs(E) * (s ? 1 : -1)), o.diff = v, v *= i.touchRatio, s && (v = -v, E = -E);
    const m = n.touchesDirection;
    n.swipeDirection = v > 0 ? "prev" : "next", n.touchesDirection = E > 0 ? "prev" : "next";
    const g = n.params.loop && !i.cssMode;
    if (!r.isMoved) {
        if (g && n.loopFix({
                direction: n.swipeDirection
            }), r.startTranslate = n.getTranslate(), n.setTransition(0), n.animating) {
            const T = new window.CustomEvent("transitionend", {
                bubbles: !0,
                cancelable: !0
            });
            n.wrapperEl.dispatchEvent(T)
        }
        r.allowMomentumBounce = !1, i.grabCursor && (n.allowSlideNext === !0 || n.allowSlidePrev === !0) && n.setGrabCursor(!0), n.emit("sliderFirstMove", a)
    }
    let S;
    r.isMoved && m !== n.touchesDirection && g && Math.abs(v) >= 1 && (n.loopFix({
        direction: n.swipeDirection,
        setTranslate: !0
    }), S = !0), n.emit("sliderMove", a), r.isMoved = !0, r.currentTranslate = v + r.startTranslate;
    let x = !0,
        P = i.resistanceRatio;
    if (i.touchReleaseOnEdges && (P = 0), v > 0 ? (g && !S && r.currentTranslate > (i.centeredSlides ? n.minTranslate() - n.size / 2 : n.minTranslate()) && n.loopFix({
            direction: "prev",
            setTranslate: !0,
            activeSlideIndex: 0
        }), r.currentTranslate > n.minTranslate() && (x = !1, i.resistance && (r.currentTranslate = n.minTranslate() - 1 + (-n.minTranslate() + r.startTranslate + v) ** P))) : v < 0 && (g && !S && r.currentTranslate < (i.centeredSlides ? n.maxTranslate() + n.size / 2 : n.maxTranslate()) && n.loopFix({
            direction: "next",
            setTranslate: !0,
            activeSlideIndex: n.slides.length - (i.slidesPerView === "auto" ? n.slidesPerViewDynamic() : Math.ceil(parseFloat(i.slidesPerView, 10)))
        }), r.currentTranslate < n.maxTranslate() && (x = !1, i.resistance && (r.currentTranslate = n.maxTranslate() + 1 - (n.maxTranslate() - r.startTranslate - v) ** P))), x && (a.preventedByNestedSwiper = !0), !n.allowSlideNext && n.swipeDirection === "next" && r.currentTranslate < r.startTranslate && (r.currentTranslate = r.startTranslate), !n.allowSlidePrev && n.swipeDirection === "prev" && r.currentTranslate > r.startTranslate && (r.currentTranslate = r.startTranslate), !n.allowSlidePrev && !n.allowSlideNext && (r.currentTranslate = r.startTranslate), i.threshold > 0)
        if (Math.abs(v) > i.threshold || r.allowThresholdMove) {
            if (!r.allowThresholdMove) {
                r.allowThresholdMove = !0, o.startX = o.currentX, o.startY = o.currentY, r.currentTranslate = r.startTranslate, o.diff = n.isHorizontal() ? o.currentX - o.startX : o.currentY - o.startY;
                return
            }
        } else {
            r.currentTranslate = r.startTranslate;
            return
        }!i.followFinger || i.cssMode || ((i.freeMode && i.freeMode.enabled && n.freeMode || i.watchSlidesProgress) && (n.updateActiveIndex(), n.updateSlidesClasses()), i.freeMode && i.freeMode.enabled && n.freeMode && n.freeMode.onTouchMove(), n.updateProgress(r.currentTranslate), n.setTranslate(r.currentTranslate))
}

function wC(e) {
    const t = this,
        n = t.touchEventsData,
        r = n.evCache.findIndex(S => S.pointerId === e.pointerId);
    if (r >= 0 && n.evCache.splice(r, 1), ["pointercancel", "pointerout", "pointerleave"].includes(e.type) && !(e.type === "pointercancel" && (t.browser.isSafari || t.browser.isWebView))) return;
    const {
        params: i,
        touches: o,
        rtlTranslate: s,
        slidesGrid: l,
        enabled: a
    } = t;
    if (!a || !i.simulateTouch && e.pointerType === "mouse") return;
    let u = e;
    if (u.originalEvent && (u = u.originalEvent), n.allowTouchCallbacks && t.emit("touchEnd", u), n.allowTouchCallbacks = !1, !n.isTouched) {
        n.isMoved && i.grabCursor && t.setGrabCursor(!1), n.isMoved = !1, n.startMoving = !1;
        return
    }
    i.grabCursor && n.isMoved && n.isTouched && (t.allowSlideNext === !0 || t.allowSlidePrev === !0) && t.setGrabCursor(!1);
    const f = hn(),
        d = f - n.touchStartTime;
    if (t.allowClick) {
        const S = u.path || u.composedPath && u.composedPath();
        t.updateClickedSlide(S && S[0] || u.target), t.emit("tap click", u), d < 300 && f - n.lastClickTime < 300 && t.emit("doubleTap doubleClick", u)
    }
    if (n.lastClickTime = hn(), Ao(() => {
            t.destroyed || (t.allowClick = !0)
        }), !n.isTouched || !n.isMoved || !t.swipeDirection || o.diff === 0 || n.currentTranslate === n.startTranslate) {
        n.isTouched = !1, n.isMoved = !1, n.startMoving = !1;
        return
    }
    n.isTouched = !1, n.isMoved = !1, n.startMoving = !1;
    let h;
    if (i.followFinger ? h = s ? t.translate : -t.translate : h = -n.currentTranslate, i.cssMode) return;
    if (i.freeMode && i.freeMode.enabled) {
        t.freeMode.onTouchEnd({
            currentPos: h
        });
        return
    }
    let y = 0,
        _ = t.slidesSizesGrid[0];
    for (let S = 0; S < l.length; S += S < i.slidesPerGroupSkip ? 1 : i.slidesPerGroup) {
        const x = S < i.slidesPerGroupSkip - 1 ? 1 : i.slidesPerGroup;
        typeof l[S + x] < "u" ? h >= l[S] && h < l[S + x] && (y = S, _ = l[S + x] - l[S]) : h >= l[S] && (y = S, _ = l[l.length - 1] - l[l.length - 2])
    }
    let v = null,
        E = null;
    i.rewind && (t.isBeginning ? E = i.virtual && i.virtual.enabled && t.virtual ? t.virtual.slides.length - 1 : t.slides.length - 1 : t.isEnd && (v = 0));
    const m = (h - l[y]) / _,
        g = y < i.slidesPerGroupSkip - 1 ? 1 : i.slidesPerGroup;
    if (d > i.longSwipesMs) {
        if (!i.longSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.swipeDirection === "next" && (m >= i.longSwipesRatio ? t.slideTo(i.rewind && t.isEnd ? v : y + g) : t.slideTo(y)), t.swipeDirection === "prev" && (m > 1 - i.longSwipesRatio ? t.slideTo(y + g) : E !== null && m < 0 && Math.abs(m) > i.longSwipesRatio ? t.slideTo(E) : t.slideTo(y))
    } else {
        if (!i.shortSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.navigation && (u.target === t.navigation.nextEl || u.target === t.navigation.prevEl) ? u.target === t.navigation.nextEl ? t.slideTo(y + g) : t.slideTo(y) : (t.swipeDirection === "next" && t.slideTo(v !== null ? v : y + g), t.swipeDirection === "prev" && t.slideTo(E !== null ? E : y))
    }
}

function t1() {
    const e = this,
        {
            params: t,
            el: n
        } = e;
    if (n && n.offsetWidth === 0) return;
    t.breakpoints && e.setBreakpoint();
    const {
        allowSlideNext: r,
        allowSlidePrev: i,
        snapGrid: o
    } = e, s = e.virtual && e.params.virtual.enabled;
    e.allowSlideNext = !0, e.allowSlidePrev = !0, e.updateSize(), e.updateSlides(), e.updateSlidesClasses();
    const l = s && t.loop;
    (t.slidesPerView === "auto" || t.slidesPerView > 1) && e.isEnd && !e.isBeginning && !e.params.centeredSlides && !l ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.params.loop && !s ? e.slideToLoop(e.realIndex, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0), e.autoplay && e.autoplay.running && e.autoplay.paused && (clearTimeout(e.autoplay.resizeTimeout), e.autoplay.resizeTimeout = setTimeout(() => {
        e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.resume()
    }, 500)), e.allowSlidePrev = i, e.allowSlideNext = r, e.params.watchOverflow && o !== e.snapGrid && e.checkOverflow()
}

function xC(e) {
    const t = this;
    t.enabled && (t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation())))
}

function EC() {
    const e = this,
        {
            wrapperEl: t,
            rtlTranslate: n,
            enabled: r
        } = e;
    if (!r) return;
    e.previousTranslate = e.translate, e.isHorizontal() ? e.translate = -t.scrollLeft : e.translate = -t.scrollTop, e.translate === 0 && (e.translate = 0), e.updateActiveIndex(), e.updateSlidesClasses();
    let i;
    const o = e.maxTranslate() - e.minTranslate();
    o === 0 ? i = 0 : i = (e.translate - e.minTranslate()) / o, i !== e.progress && e.updateProgress(n ? -e.translate : e.translate), e.emit("setTranslate", e.translate, !1)
}

function CC(e) {
    const t = this;
    Fa(t, e.target), !(t.params.cssMode || t.params.slidesPerView !== "auto" && !t.params.autoHeight) && t.update()
}
let n1 = !1;

function TC() {}
const y_ = (e, t) => {
    const n = Er(),
        {
            params: r,
            el: i,
            wrapperEl: o,
            device: s
        } = e,
        l = !!r.nested,
        a = t === "on" ? "addEventListener" : "removeEventListener",
        u = t;
    i[a]("pointerdown", e.onTouchStart, {
        passive: !1
    }), n[a]("pointermove", e.onTouchMove, {
        passive: !1,
        capture: l
    }), n[a]("pointerup", e.onTouchEnd, {
        passive: !0
    }), n[a]("pointercancel", e.onTouchEnd, {
        passive: !0
    }), n[a]("pointerout", e.onTouchEnd, {
        passive: !0
    }), n[a]("pointerleave", e.onTouchEnd, {
        passive: !0
    }), (r.preventClicks || r.preventClicksPropagation) && i[a]("click", e.onClick, !0), r.cssMode && o[a]("scroll", e.onScroll), r.updateOnWindowResize ? e[u](s.ios || s.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", t1, !0) : e[u]("observerUpdate", t1, !0), i[a]("load", e.onLoad, {
        capture: !0
    })
};

function PC() {
    const e = this,
        t = Er(),
        {
            params: n
        } = e;
    e.onTouchStart = _C.bind(e), e.onTouchMove = SC.bind(e), e.onTouchEnd = wC.bind(e), n.cssMode && (e.onScroll = EC.bind(e)), e.onClick = xC.bind(e), e.onLoad = CC.bind(e), n1 || (t.addEventListener("touchstart", TC), n1 = !0), y_(e, "on")
}

function kC() {
    y_(this, "off")
}
const bC = {
        attachEvents: PC,
        detachEvents: kC
    },
    r1 = (e, t) => e.grid && t.grid && t.grid.rows > 1;

function MC() {
    const e = this,
        {
            realIndex: t,
            initialized: n,
            params: r,
            el: i
        } = e,
        o = r.breakpoints;
    if (!o || o && Object.keys(o).length === 0) return;
    const s = e.getBreakpoint(o, e.params.breakpointsBase, e.el);
    if (!s || e.currentBreakpoint === s) return;
    const a = (s in o ? o[s] : void 0) || e.originalParams,
        u = r1(e, r),
        f = r1(e, a),
        d = r.enabled;
    u && !f ? (i.classList.remove(`${r.containerModifierClass}grid`, `${r.containerModifierClass}grid-column`), e.emitContainerClasses()) : !u && f && (i.classList.add(`${r.containerModifierClass}grid`), (a.grid.fill && a.grid.fill === "column" || !a.grid.fill && r.grid.fill === "column") && i.classList.add(`${r.containerModifierClass}grid-column`), e.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach(v => {
        if (typeof a[v] > "u") return;
        const E = r[v] && r[v].enabled,
            m = a[v] && a[v].enabled;
        E && !m && e[v].disable(), !E && m && e[v].enable()
    });
    const h = a.direction && a.direction !== r.direction,
        y = r.loop && (a.slidesPerView !== r.slidesPerView || h);
    h && n && e.changeDirection(), Qt(e.params, a);
    const _ = e.params.enabled;
    Object.assign(e, {
        allowTouchMove: e.params.allowTouchMove,
        allowSlideNext: e.params.allowSlideNext,
        allowSlidePrev: e.params.allowSlidePrev
    }), d && !_ ? e.disable() : !d && _ && e.enable(), e.currentBreakpoint = s, e.emit("_beforeBreakpoint", a), y && n && (e.loopDestroy(), e.loopCreate(t), e.updateSlides()), e.emit("breakpoint", a)
}

function OC(e, t = "window", n) {
    if (!e || t === "container" && !n) return;
    let r = !1;
    const i = Dt(),
        o = t === "window" ? i.innerHeight : n.clientHeight,
        s = Object.keys(e).map(l => {
            if (typeof l == "string" && l.indexOf("@") === 0) {
                const a = parseFloat(l.substr(1));
                return {
                    value: o * a,
                    point: l
                }
            }
            return {
                value: l,
                point: l
            }
        });
    s.sort((l, a) => parseInt(l.value, 10) - parseInt(a.value, 10));
    for (let l = 0; l < s.length; l += 1) {
        const {
            point: a,
            value: u
        } = s[l];
        t === "window" ? i.matchMedia(`(min-width: ${u}px)`).matches && (r = a) : u <= n.clientWidth && (r = a)
    }
    return r || "max"
}
const LC = {
    setBreakpoint: MC,
    getBreakpoint: OC
};

function NC(e, t) {
    const n = [];
    return e.forEach(r => {
        typeof r == "object" ? Object.keys(r).forEach(i => {
            r[i] && n.push(t + i)
        }) : typeof r == "string" && n.push(t + r)
    }), n
}

function AC() {
    const e = this,
        {
            classNames: t,
            params: n,
            rtl: r,
            el: i,
            device: o
        } = e,
        s = NC(["initialized", n.direction, {
            "free-mode": e.params.freeMode && n.freeMode.enabled
        }, {
            autoheight: n.autoHeight
        }, {
            rtl: r
        }, {
            grid: n.grid && n.grid.rows > 1
        }, {
            "grid-column": n.grid && n.grid.rows > 1 && n.grid.fill === "column"
        }, {
            android: o.android
        }, {
            ios: o.ios
        }, {
            "css-mode": n.cssMode
        }, {
            centered: n.cssMode && n.centeredSlides
        }, {
            "watch-progress": n.watchSlidesProgress
        }], n.containerModifierClass);
    t.push(...s), i.classList.add(...t), e.emitContainerClasses()
}

function RC() {
    const e = this,
        {
            el: t,
            classNames: n
        } = e;
    t.classList.remove(...n), e.emitContainerClasses()
}
const DC = {
    addClasses: AC,
    removeClasses: RC
};

function zC() {
    const e = this,
        {
            isLocked: t,
            params: n
        } = e,
        {
            slidesOffsetBefore: r
        } = n;
    if (r) {
        const i = e.slides.length - 1,
            o = e.slidesGrid[i] + e.slidesSizesGrid[i] + r * 2;
        e.isLocked = e.size > o
    } else e.isLocked = e.snapGrid.length === 1;
    n.allowSlideNext === !0 && (e.allowSlideNext = !e.isLocked), n.allowSlidePrev === !0 && (e.allowSlidePrev = !e.isLocked), t && t !== e.isLocked && (e.isEnd = !1), t !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock")
}
const IC = {
        checkOverflow: zC
    },
    i1 = {
        init: !0,
        direction: "horizontal",
        oneWayMovement: !1,
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        resizeObserver: !0,
        nested: !1,
        createElements: !1,
        enabled: !0,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: !1,
        userAgent: null,
        url: null,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: !1,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        watchOverflow: !0,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 5,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        loop: !1,
        loopedSlides: null,
        loopPreventsSliding: !0,
        rewind: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideActiveClass: "swiper-slide-active",
        slideVisibleClass: "swiper-slide-visible",
        slideNextClass: "swiper-slide-next",
        slidePrevClass: "swiper-slide-prev",
        wrapperClass: "swiper-wrapper",
        lazyPreloaderClass: "swiper-lazy-preloader",
        lazyPreloadPrevNext: 0,
        runCallbacksOnInit: !0,
        _emitClasses: !1
    };

function FC(e, t) {
    return function(r = {}) {
        const i = Object.keys(r)[0],
            o = r[i];
        if (typeof o != "object" || o === null) {
            Qt(t, r);
            return
        }
        if (["navigation", "pagination", "scrollbar"].indexOf(i) >= 0 && e[i] === !0 && (e[i] = {
                auto: !0
            }), !(i in e && "enabled" in o)) {
            Qt(t, r);
            return
        }
        e[i] === !0 && (e[i] = {
            enabled: !0
        }), typeof e[i] == "object" && !("enabled" in e[i]) && (e[i].enabled = !0), e[i] || (e[i] = {
            enabled: !1
        }), Qt(t, r)
    }
}
const Jf = {
        eventsEmitter: D3,
        update: G3,
        translate: Z3,
        transition: nC,
        slide: cC,
        loop: hC,
        grabCursor: gC,
        events: bC,
        breakpoints: LC,
        checkOverflow: IC,
        classes: DC
    },
    ed = {};
let sl = class lr {
    constructor(...t) {
        let n, r;
        t.length === 1 && t[0].constructor && Object.prototype.toString.call(t[0]).slice(8, -1) === "Object" ? r = t[0] : [n, r] = t, r || (r = {}), r = Qt({}, r), n && !r.el && (r.el = n);
        const i = Er();
        if (r.el && typeof r.el == "string" && i.querySelectorAll(r.el).length > 1) {
            const a = [];
            return i.querySelectorAll(r.el).forEach(u => {
                const f = Qt({}, r, {
                    el: u
                });
                a.push(new lr(f))
            }), a
        }
        const o = this;
        o.__swiper__ = !0, o.support = v_(), o.device = O3({
            userAgent: r.userAgent
        }), o.browser = N3(), o.eventsListeners = {}, o.eventsAnyListeners = [], o.modules = [...o.__modules__], r.modules && Array.isArray(r.modules) && o.modules.push(...r.modules);
        const s = {};
        o.modules.forEach(a => {
            a({
                params: r,
                swiper: o,
                extendParams: FC(r, s),
                on: o.on.bind(o),
                once: o.once.bind(o),
                off: o.off.bind(o),
                emit: o.emit.bind(o)
            })
        });
        const l = Qt({}, i1, s);
        return o.params = Qt({}, l, ed, r), o.originalParams = Qt({}, o.params), o.passedParams = Qt({}, r), o.params && o.params.on && Object.keys(o.params.on).forEach(a => {
            o.on(a, o.params.on[a])
        }), o.params && o.params.onAny && o.onAny(o.params.onAny), Object.assign(o, {
            enabled: o.params.enabled,
            el: n,
            classNames: [],
            slides: [],
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal() {
                return o.params.direction === "horizontal"
            },
            isVertical() {
                return o.params.direction === "vertical"
            },
            activeIndex: 0,
            realIndex: 0,
            isBeginning: !0,
            isEnd: !1,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: !1,
            cssOverflowAdjustment() {
                return Math.trunc(this.translate / 2 ** 23) * 2 ** 23
            },
            allowSlideNext: o.params.allowSlideNext,
            allowSlidePrev: o.params.allowSlidePrev,
            touchEventsData: {
                isTouched: void 0,
                isMoved: void 0,
                allowTouchCallbacks: void 0,
                touchStartTime: void 0,
                isScrolling: void 0,
                currentTranslate: void 0,
                startTranslate: void 0,
                allowThresholdMove: void 0,
                focusableElements: o.params.focusableElements,
                lastClickTime: 0,
                clickTimeout: void 0,
                velocities: [],
                allowMomentumBounce: void 0,
                startMoving: void 0,
                evCache: []
            },
            allowClick: !0,
            allowTouchMove: o.params.allowTouchMove,
            touches: {
                startX: 0,
                startY: 0,
                currentX: 0,
                currentY: 0,
                diff: 0
            },
            imagesToLoad: [],
            imagesLoaded: 0
        }), o.emit("_swiper"), o.params.init && o.init(), o
    }
    getSlideIndex(t) {
        const {
            slidesEl: n,
            params: r
        } = this, i = Wn(n, `.${r.slideClass}, swiper-slide`), o = Jv(i[0]);
        return Jv(t) - o
    }
    getSlideIndexByData(t) {
        return this.getSlideIndex(this.slides.filter(n => n.getAttribute("data-swiper-slide-index") * 1 === t)[0])
    }
    recalcSlides() {
        const t = this,
            {
                slidesEl: n,
                params: r
            } = t;
        t.slides = Wn(n, `.${r.slideClass}, swiper-slide`)
    }
    enable() {
        const t = this;
        t.enabled || (t.enabled = !0, t.params.grabCursor && t.setGrabCursor(), t.emit("enable"))
    }
    disable() {
        const t = this;
        t.enabled && (t.enabled = !1, t.params.grabCursor && t.unsetGrabCursor(), t.emit("disable"))
    }
    setProgress(t, n) {
        const r = this;
        t = Math.min(Math.max(t, 0), 1);
        const i = r.minTranslate(),
            s = (r.maxTranslate() - i) * t + i;
        r.translateTo(s, typeof n > "u" ? 0 : n), r.updateActiveIndex(), r.updateSlidesClasses()
    }
    emitContainerClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const n = t.el.className.split(" ").filter(r => r.indexOf("swiper") === 0 || r.indexOf(t.params.containerModifierClass) === 0);
        t.emit("_containerClasses", n.join(" "))
    }
    getSlideClasses(t) {
        const n = this;
        return n.destroyed ? "" : t.className.split(" ").filter(r => r.indexOf("swiper-slide") === 0 || r.indexOf(n.params.slideClass) === 0).join(" ")
    }
    emitSlidesClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const n = [];
        t.slides.forEach(r => {
            const i = t.getSlideClasses(r);
            n.push({
                slideEl: r,
                classNames: i
            }), t.emit("_slideClass", r, i)
        }), t.emit("_slideClasses", n)
    }
    slidesPerViewDynamic(t = "current", n = !1) {
        const r = this,
            {
                params: i,
                slides: o,
                slidesGrid: s,
                slidesSizesGrid: l,
                size: a,
                activeIndex: u
            } = r;
        let f = 1;
        if (i.centeredSlides) {
            let d = o[u] ? o[u].swiperSlideSize : 0,
                h;
            for (let y = u + 1; y < o.length; y += 1) o[y] && !h && (d += o[y].swiperSlideSize, f += 1, d > a && (h = !0));
            for (let y = u - 1; y >= 0; y -= 1) o[y] && !h && (d += o[y].swiperSlideSize, f += 1, d > a && (h = !0))
        } else if (t === "current")
            for (let d = u + 1; d < o.length; d += 1)(n ? s[d] + l[d] - s[u] < a : s[d] - s[u] < a) && (f += 1);
        else
            for (let d = u - 1; d >= 0; d -= 1) s[u] - s[d] < a && (f += 1);
        return f
    }
    update() {
        const t = this;
        if (!t || t.destroyed) return;
        const {
            snapGrid: n,
            params: r
        } = t;
        r.breakpoints && t.setBreakpoint(), [...t.el.querySelectorAll('[loading="lazy"]')].forEach(s => {
            s.complete && Fa(t, s)
        }), t.updateSize(), t.updateSlides(), t.updateProgress(), t.updateSlidesClasses();

        function i() {
            const s = t.rtlTranslate ? t.translate * -1 : t.translate,
                l = Math.min(Math.max(s, t.maxTranslate()), t.minTranslate());
            t.setTranslate(l), t.updateActiveIndex(), t.updateSlidesClasses()
        }
        let o;
        if (r.freeMode && r.freeMode.enabled && !r.cssMode) i(), r.autoHeight && t.updateAutoHeight();
        else {
            if ((r.slidesPerView === "auto" || r.slidesPerView > 1) && t.isEnd && !r.centeredSlides) {
                const s = t.virtual && r.virtual.enabled ? t.virtual.slides : t.slides;
                o = t.slideTo(s.length - 1, 0, !1, !0)
            } else o = t.slideTo(t.activeIndex, 0, !1, !0);
            o || i()
        }
        r.watchOverflow && n !== t.snapGrid && t.checkOverflow(), t.emit("update")
    }
    changeDirection(t, n = !0) {
        const r = this,
            i = r.params.direction;
        return t || (t = i === "horizontal" ? "vertical" : "horizontal"), t === i || t !== "horizontal" && t !== "vertical" || (r.el.classList.remove(`${r.params.containerModifierClass}${i}`), r.el.classList.add(`${r.params.containerModifierClass}${t}`), r.emitContainerClasses(), r.params.direction = t, r.slides.forEach(o => {
            t === "vertical" ? o.style.width = "" : o.style.height = ""
        }), r.emit("changeDirection"), n && r.update()), r
    }
    changeLanguageDirection(t) {
        const n = this;
        n.rtl && t === "rtl" || !n.rtl && t === "ltr" || (n.rtl = t === "rtl", n.rtlTranslate = n.params.direction === "horizontal" && n.rtl, n.rtl ? (n.el.classList.add(`${n.params.containerModifierClass}rtl`), n.el.dir = "rtl") : (n.el.classList.remove(`${n.params.containerModifierClass}rtl`), n.el.dir = "ltr"), n.update())
    }
    mount(t) {
        const n = this;
        if (n.mounted) return !0;
        let r = t || n.params.el;
        if (typeof r == "string" && (r = document.querySelector(r)), !r) return !1;
        r.swiper = n, r.shadowEl && (n.isElement = !0);
        const i = () => `.${(n.params.wrapperClass||"").trim().split(" ").join(".")}`;
        let s = (() => r && r.shadowRoot && r.shadowRoot.querySelector ? r.shadowRoot.querySelector(i()) : Wn(r, i())[0])();
        return !s && n.params.createElements && (s = Nh("div", n.params.wrapperClass), r.append(s), Wn(r, `.${n.params.slideClass}`).forEach(l => {
            s.append(l)
        })), Object.assign(n, {
            el: r,
            wrapperEl: s,
            slidesEl: n.isElement ? r : s,
            mounted: !0,
            rtl: r.dir.toLowerCase() === "rtl" || zr(r, "direction") === "rtl",
            rtlTranslate: n.params.direction === "horizontal" && (r.dir.toLowerCase() === "rtl" || zr(r, "direction") === "rtl"),
            wrongRTL: zr(s, "display") === "-webkit-box"
        }), !0
    }
    init(t) {
        const n = this;
        return n.initialized || n.mount(t) === !1 || (n.emit("beforeInit"), n.params.breakpoints && n.setBreakpoint(), n.addClasses(), n.updateSize(), n.updateSlides(), n.params.watchOverflow && n.checkOverflow(), n.params.grabCursor && n.enabled && n.setGrabCursor(), n.params.loop && n.virtual && n.params.virtual.enabled ? n.slideTo(n.params.initialSlide + n.virtual.slidesBefore, 0, n.params.runCallbacksOnInit, !1, !0) : n.slideTo(n.params.initialSlide, 0, n.params.runCallbacksOnInit, !1, !0), n.params.loop && n.loopCreate(), n.attachEvents(), [...n.el.querySelectorAll('[loading="lazy"]')].forEach(i => {
            i.complete ? Fa(n, i) : i.addEventListener("load", o => {
                Fa(n, o.target)
            })
        }), ap(n), n.initialized = !0, ap(n), n.emit("init"), n.emit("afterInit")), n
    }
    destroy(t = !0, n = !0) {
        const r = this,
            {
                params: i,
                el: o,
                wrapperEl: s,
                slides: l
            } = r;
        return typeof r.params > "u" || r.destroyed || (r.emit("beforeDestroy"), r.initialized = !1, r.detachEvents(), i.loop && r.loopDestroy(), n && (r.removeClasses(), o.removeAttribute("style"), s.removeAttribute("style"), l && l.length && l.forEach(a => {
            a.classList.remove(i.slideVisibleClass, i.slideActiveClass, i.slideNextClass, i.slidePrevClass), a.removeAttribute("style"), a.removeAttribute("data-swiper-slide-index")
        })), r.emit("destroy"), Object.keys(r.eventsListeners).forEach(a => {
            r.off(a)
        }), t !== !1 && (r.el.swiper = null, S3(r)), r.destroyed = !0), null
    }
    static extendDefaults(t) {
        Qt(ed, t)
    }
    static get extendedDefaults() {
        return ed
    }
    static get defaults() {
        return i1
    }
    static installModule(t) {
        lr.prototype.__modules__ || (lr.prototype.__modules__ = []);
        const n = lr.prototype.__modules__;
        typeof t == "function" && n.indexOf(t) < 0 && n.push(t)
    }
    static use(t) {
        return Array.isArray(t) ? (t.forEach(n => lr.installModule(n)), lr) : (lr.installModule(t), lr)
    }
};
Object.keys(Jf).forEach(e => {
    Object.keys(Jf[e]).forEach(t => {
        sl.prototype[t] = Jf[e][t]
    })
});
sl.use([A3, R3]);

function BC({
    swiper: e,
    extendParams: t,
    on: n,
    emit: r
}) {
    const i = Dt();
    t({
        mousewheel: {
            enabled: !1,
            releaseOnEdges: !1,
            invert: !1,
            forceToAxis: !1,
            sensitivity: 1,
            eventsTarget: "container",
            thresholdDelta: null,
            thresholdTime: null,
            noMousewheelClass: "swiper-no-mousewheel"
        }
    }), e.mousewheel = {
        enabled: !1
    };
    let o, s = hn(),
        l;
    const a = [];

    function u(g) {
        let T = 0,
            L = 0,
            b = 0,
            N = 0;
        return "detail" in g && (L = g.detail), "wheelDelta" in g && (L = -g.wheelDelta / 120), "wheelDeltaY" in g && (L = -g.wheelDeltaY / 120), "wheelDeltaX" in g && (T = -g.wheelDeltaX / 120), "axis" in g && g.axis === g.HORIZONTAL_AXIS && (T = L, L = 0), b = T * 10, N = L * 10, "deltaY" in g && (N = g.deltaY), "deltaX" in g && (b = g.deltaX), g.shiftKey && !b && (b = N, N = 0), (b || N) && g.deltaMode && (g.deltaMode === 1 ? (b *= 40, N *= 40) : (b *= 800, N *= 800)), b && !T && (T = b < 1 ? -1 : 1), N && !L && (L = N < 1 ? -1 : 1), {
            spinX: T,
            spinY: L,
            pixelX: b,
            pixelY: N
        }
    }

    function f() {
        e.enabled && (e.mouseEntered = !0)
    }

    function d() {
        e.enabled && (e.mouseEntered = !1)
    }

    function h(g) {
        return e.params.mousewheel.thresholdDelta && g.delta < e.params.mousewheel.thresholdDelta || e.params.mousewheel.thresholdTime && hn() - s < e.params.mousewheel.thresholdTime ? !1 : g.delta >= 6 && hn() - s < 60 ? !0 : (g.direction < 0 ? (!e.isEnd || e.params.loop) && !e.animating && (e.slideNext(), r("scroll", g.raw)) : (!e.isBeginning || e.params.loop) && !e.animating && (e.slidePrev(), r("scroll", g.raw)), s = new i.Date().getTime(), !1)
    }

    function y(g) {
        const S = e.params.mousewheel;
        if (g.direction < 0) {
            if (e.isEnd && !e.params.loop && S.releaseOnEdges) return !0
        } else if (e.isBeginning && !e.params.loop && S.releaseOnEdges) return !0;
        return !1
    }

    function _(g) {
        let S = g,
            x = !0;
        if (!e.enabled || g.target.closest(`.${e.params.mousewheel.noMousewheelClass}`)) return;
        const P = e.params.mousewheel;
        e.params.cssMode && S.preventDefault();
        let T = e.el;
        e.params.mousewheel.eventsTarget !== "container" && (T = document.querySelector(e.params.mousewheel.eventsTarget));
        const L = T && T.contains(S.target);
        if (!e.mouseEntered && !L && !P.releaseOnEdges) return !0;
        S.originalEvent && (S = S.originalEvent);
        let b = 0;
        const N = e.rtlTranslate ? -1 : 1,
            H = u(S);
        if (P.forceToAxis)
            if (e.isHorizontal())
                if (Math.abs(H.pixelX) > Math.abs(H.pixelY)) b = -H.pixelX * N;
                else return !0;
        else if (Math.abs(H.pixelY) > Math.abs(H.pixelX)) b = -H.pixelY;
        else return !0;
        else b = Math.abs(H.pixelX) > Math.abs(H.pixelY) ? -H.pixelX * N : -H.pixelY;
        if (b === 0) return !0;
        P.invert && (b = -b);
        let A = e.getTranslate() + b * P.sensitivity;
        if (A >= e.minTranslate() && (A = e.minTranslate()), A <= e.maxTranslate() && (A = e.maxTranslate()), x = e.params.loop ? !0 : !(A === e.minTranslate() || A === e.maxTranslate()), x && e.params.nested && S.stopPropagation(), !e.params.freeMode || !e.params.freeMode.enabled) {
            const I = {
                time: hn(),
                delta: Math.abs(b),
                direction: Math.sign(b),
                raw: g
            };
            a.length >= 2 && a.shift();
            const B = a.length ? a[a.length - 1] : void 0;
            if (a.push(I), B ? (I.direction !== B.direction || I.delta > B.delta || I.time > B.time + 150) && h(I) : h(I), y(I)) return !0
        } else {
            const I = {
                    time: hn(),
                    delta: Math.abs(b),
                    direction: Math.sign(b)
                },
                B = l && I.time < l.time + 500 && I.delta <= l.delta && I.direction === l.direction;
            if (!B) {
                l = void 0;
                let G = e.getTranslate() + b * P.sensitivity;
                const Q = e.isBeginning,
                    le = e.isEnd;
                if (G >= e.minTranslate() && (G = e.minTranslate()), G <= e.maxTranslate() && (G = e.maxTranslate()), e.setTransition(0), e.setTranslate(G), e.updateProgress(), e.updateActiveIndex(), e.updateSlidesClasses(), (!Q && e.isBeginning || !le && e.isEnd) && e.updateSlidesClasses(), e.params.loop && e.loopFix({
                        direction: I.direction < 0 ? "next" : "prev",
                        byMousewheel: !0
                    }), e.params.freeMode.sticky) {
                    clearTimeout(o), o = void 0, a.length >= 15 && a.shift();
                    const ie = a.length ? a[a.length - 1] : void 0,
                        D = a[0];
                    if (a.push(I), ie && (I.delta > ie.delta || I.direction !== ie.direction)) a.splice(0);
                    else if (a.length >= 15 && I.time - D.time < 500 && D.delta - I.delta >= 1 && I.delta <= 6) {
                        const V = b > 0 ? .8 : .2;
                        l = I, a.splice(0), o = Ao(() => {
                            e.slideToClosest(e.params.speed, !0, void 0, V)
                        }, 0)
                    }
                    o || (o = Ao(() => {
                        l = I, a.splice(0), e.slideToClosest(e.params.speed, !0, void 0, .5)
                    }, 500))
                }
                if (B || r("scroll", S), e.params.autoplay && e.params.autoplayDisableOnInteraction && e.autoplay.stop(), G === e.minTranslate() || G === e.maxTranslate()) return !0
            }
        }
        return S.preventDefault ? S.preventDefault() : S.returnValue = !1, !1
    }

    function v(g) {
        let S = e.el;
        e.params.mousewheel.eventsTarget !== "container" && (S = document.querySelector(e.params.mousewheel.eventsTarget)), S[g]("mouseenter", f), S[g]("mouseleave", d), S[g]("wheel", _)
    }

    function E() {
        return e.params.cssMode ? (e.wrapperEl.removeEventListener("wheel", _), !0) : e.mousewheel.enabled ? !1 : (v("addEventListener"), e.mousewheel.enabled = !0, !0)
    }

    function m() {
        return e.params.cssMode ? (e.wrapperEl.addEventListener(event, _), !0) : e.mousewheel.enabled ? (v("removeEventListener"), e.mousewheel.enabled = !1, !0) : !1
    }
    n("init", () => {
        !e.params.mousewheel.enabled && e.params.cssMode && m(), e.params.mousewheel.enabled && E()
    }), n("destroy", () => {
        e.params.cssMode && E(), e.mousewheel.enabled && m()
    }), Object.assign(e.mousewheel, {
        enable: E,
        disable: m
    })
}

function jC(e, t, n, r) {
    return e.params.createElements && Object.keys(r).forEach(i => {
        if (!n[i] && n.auto === !0) {
            let o = Wn(e.el, `.${r[i]}`)[0];
            o || (o = Nh("div", r[i]), o.className = r[i], e.el.append(o)), n[i] = o, t[i] = o
        }
    }), n
}

function VC({
    swiper: e,
    extendParams: t,
    on: n,
    emit: r
}) {
    const i = Er();
    let o = !1,
        s = null,
        l = null,
        a, u, f, d;
    t({
        scrollbar: {
            el: null,
            dragSize: "auto",
            hide: !1,
            draggable: !1,
            snapOnRelease: !0,
            lockClass: "swiper-scrollbar-lock",
            dragClass: "swiper-scrollbar-drag",
            scrollbarDisabledClass: "swiper-scrollbar-disabled",
            horizontalClass: "swiper-scrollbar-horizontal",
            verticalClass: "swiper-scrollbar-vertical"
        }
    }), e.scrollbar = {
        el: null,
        dragEl: null
    };

    function h() {
        if (!e.params.scrollbar.el || !e.scrollbar.el) return;
        const {
            scrollbar: A,
            rtlTranslate: I
        } = e, {
            dragEl: B,
            el: G
        } = A, Q = e.params.scrollbar, le = e.params.loop ? e.progressLoop : e.progress;
        let ie = u,
            D = (f - u) * le;
        I ? (D = -D, D > 0 ? (ie = u - D, D = 0) : -D + u > f && (ie = f + D)) : D < 0 ? (ie = u + D, D = 0) : D + u > f && (ie = f - D), e.isHorizontal() ? (B.style.transform = `translate3d(${D}px, 0, 0)`, B.style.width = `${ie}px`) : (B.style.transform = `translate3d(0px, ${D}px, 0)`, B.style.height = `${ie}px`), Q.hide && (clearTimeout(s), G.style.opacity = 1, s = setTimeout(() => {
            G.style.opacity = 0, G.style.transitionDuration = "400ms"
        }, 1e3))
    }

    function y(A) {
        !e.params.scrollbar.el || !e.scrollbar.el || (e.scrollbar.dragEl.style.transitionDuration = `${A}ms`)
    }

    function _() {
        if (!e.params.scrollbar.el || !e.scrollbar.el) return;
        const {
            scrollbar: A
        } = e, {
            dragEl: I,
            el: B
        } = A;
        I.style.width = "", I.style.height = "", f = e.isHorizontal() ? B.offsetWidth : B.offsetHeight, d = e.size / (e.virtualSize + e.params.slidesOffsetBefore - (e.params.centeredSlides ? e.snapGrid[0] : 0)), e.params.scrollbar.dragSize === "auto" ? u = f * d : u = parseInt(e.params.scrollbar.dragSize, 10), e.isHorizontal() ? I.style.width = `${u}px` : I.style.height = `${u}px`, d >= 1 ? B.style.display = "none" : B.style.display = "", e.params.scrollbar.hide && (B.style.opacity = 0), e.params.watchOverflow && e.enabled && A.el.classList[e.isLocked ? "add" : "remove"](e.params.scrollbar.lockClass)
    }

    function v(A) {
        return e.isHorizontal() ? A.clientX : A.clientY
    }

    function E(A) {
        const {
            scrollbar: I,
            rtlTranslate: B
        } = e, {
            el: G
        } = I;
        let Q;
        Q = (v(A) - C3(G)[e.isHorizontal() ? "left" : "top"] - (a !== null ? a : u / 2)) / (f - u), Q = Math.max(Math.min(Q, 1), 0), B && (Q = 1 - Q);
        const le = e.minTranslate() + (e.maxTranslate() - e.minTranslate()) * Q;
        e.updateProgress(le), e.setTranslate(le), e.updateActiveIndex(), e.updateSlidesClasses()
    }

    function m(A) {
        const I = e.params.scrollbar,
            {
                scrollbar: B,
                wrapperEl: G
            } = e,
            {
                el: Q,
                dragEl: le
            } = B;
        o = !0, a = A.target === le ? v(A) - A.target.getBoundingClientRect()[e.isHorizontal() ? "left" : "top"] : null, A.preventDefault(), A.stopPropagation(), G.style.transitionDuration = "100ms", le.style.transitionDuration = "100ms", E(A), clearTimeout(l), Q.style.transitionDuration = "0ms", I.hide && (Q.style.opacity = 1), e.params.cssMode && (e.wrapperEl.style["scroll-snap-type"] = "none"), r("scrollbarDragStart", A)
    }

    function g(A) {
        const {
            scrollbar: I,
            wrapperEl: B
        } = e, {
            el: G,
            dragEl: Q
        } = I;
        o && (A.preventDefault ? A.preventDefault() : A.returnValue = !1, E(A), B.style.transitionDuration = "0ms", G.style.transitionDuration = "0ms", Q.style.transitionDuration = "0ms", r("scrollbarDragMove", A))
    }

    function S(A) {
        const I = e.params.scrollbar,
            {
                scrollbar: B,
                wrapperEl: G
            } = e,
            {
                el: Q
            } = B;
        o && (o = !1, e.params.cssMode && (e.wrapperEl.style["scroll-snap-type"] = "", G.style.transitionDuration = ""), I.hide && (clearTimeout(l), l = Ao(() => {
            Q.style.opacity = 0, Q.style.transitionDuration = "400ms"
        }, 1e3)), r("scrollbarDragEnd", A), I.snapOnRelease && e.slideToClosest())
    }

    function x(A) {
        const {
            scrollbar: I,
            params: B
        } = e, G = I.el;
        if (!G) return;
        const Q = G,
            le = B.passiveListeners ? {
                passive: !1,
                capture: !1
            } : !1,
            ie = B.passiveListeners ? {
                passive: !0,
                capture: !1
            } : !1;
        if (!Q) return;
        const D = A === "on" ? "addEventListener" : "removeEventListener";
        Q[D]("pointerdown", m, le), i[D]("pointermove", g, le), i[D]("pointerup", S, ie)
    }

    function P() {
        !e.params.scrollbar.el || !e.scrollbar.el || x("on")
    }

    function T() {
        !e.params.scrollbar.el || !e.scrollbar.el || x("off")
    }

    function L() {
        const {
            scrollbar: A,
            el: I
        } = e;
        e.params.scrollbar = jC(e, e.originalParams.scrollbar, e.params.scrollbar, {
            el: "swiper-scrollbar"
        });
        const B = e.params.scrollbar;
        if (!B.el) return;
        let G;
        typeof B.el == "string" && e.isElement && (G = e.el.shadowRoot.querySelector(B.el)), !G && typeof B.el == "string" ? G = i.querySelectorAll(B.el) : G || (G = B.el), e.params.uniqueNavElements && typeof B.el == "string" && G.length > 1 && I.querySelectorAll(B.el).length === 1 && (G = I.querySelector(B.el)), G.length > 0 && (G = G[0]), G.classList.add(e.isHorizontal() ? B.horizontalClass : B.verticalClass);
        let Q;
        G && (Q = G.querySelector(`.${e.params.scrollbar.dragClass}`), Q || (Q = Nh("div", e.params.scrollbar.dragClass), G.append(Q))), Object.assign(A, {
            el: G,
            dragEl: Q
        }), B.draggable && P(), G && G.classList[e.enabled ? "remove" : "add"](e.params.scrollbar.lockClass)
    }

    function b() {
        const A = e.params.scrollbar,
            I = e.scrollbar.el;
        I && I.classList.remove(e.isHorizontal() ? A.horizontalClass : A.verticalClass), T()
    }
    n("init", () => {
        e.params.scrollbar.enabled === !1 ? H() : (L(), _(), h())
    }), n("update resize observerUpdate lock unlock", () => {
        _()
    }), n("setTranslate", () => {
        h()
    }), n("setTransition", (A, I) => {
        y(I)
    }), n("enable disable", () => {
        const {
            el: A
        } = e.scrollbar;
        A && A.classList[e.enabled ? "remove" : "add"](e.params.scrollbar.lockClass)
    }), n("destroy", () => {
        b()
    });
    const N = () => {
            e.el.classList.remove(e.params.scrollbar.scrollbarDisabledClass), e.scrollbar.el && e.scrollbar.el.classList.remove(e.params.scrollbar.scrollbarDisabledClass), L(), _(), h()
        },
        H = () => {
            e.el.classList.add(e.params.scrollbar.scrollbarDisabledClass), e.scrollbar.el && e.scrollbar.el.classList.add(e.params.scrollbar.scrollbarDisabledClass), b()
        };
    Object.assign(e.scrollbar, {
        enable: N,
        disable: H,
        updateSize: _,
        setTranslate: h,
        init: L,
        destroy: b
    })
}

function UC({
    swiper: e,
    extendParams: t,
    emit: n,
    once: r
}) {
    t({
        freeMode: {
            enabled: !1,
            momentum: !0,
            momentumRatio: 1,
            momentumBounce: !0,
            momentumBounceRatio: 1,
            momentumVelocityRatio: 1,
            sticky: !1,
            minimumVelocity: .02
        }
    });

    function i() {
        if (e.params.cssMode) return;
        const l = e.getTranslate();
        e.setTranslate(l), e.setTransition(0), e.touchEventsData.velocities.length = 0, e.freeMode.onTouchEnd({
            currentPos: e.rtl ? e.translate : -e.translate
        })
    }

    function o() {
        if (e.params.cssMode) return;
        const {
            touchEventsData: l,
            touches: a
        } = e;
        l.velocities.length === 0 && l.velocities.push({
            position: a[e.isHorizontal() ? "startX" : "startY"],
            time: l.touchStartTime
        }), l.velocities.push({
            position: a[e.isHorizontal() ? "currentX" : "currentY"],
            time: hn()
        })
    }

    function s({
        currentPos: l
    }) {
        if (e.params.cssMode) return;
        const {
            params: a,
            wrapperEl: u,
            rtlTranslate: f,
            snapGrid: d,
            touchEventsData: h
        } = e, _ = hn() - h.touchStartTime;
        if (l < -e.minTranslate()) {
            e.slideTo(e.activeIndex);
            return
        }
        if (l > -e.maxTranslate()) {
            e.slides.length < d.length ? e.slideTo(d.length - 1) : e.slideTo(e.slides.length - 1);
            return
        }
        if (a.freeMode.momentum) {
            if (h.velocities.length > 1) {
                const T = h.velocities.pop(),
                    L = h.velocities.pop(),
                    b = T.position - L.position,
                    N = T.time - L.time;
                e.velocity = b / N, e.velocity /= 2, Math.abs(e.velocity) < a.freeMode.minimumVelocity && (e.velocity = 0), (N > 150 || hn() - T.time > 300) && (e.velocity = 0)
            } else e.velocity = 0;
            e.velocity *= a.freeMode.momentumVelocityRatio, h.velocities.length = 0;
            let v = 1e3 * a.freeMode.momentumRatio;
            const E = e.velocity * v;
            let m = e.translate + E;
            f && (m = -m);
            let g = !1,
                S;
            const x = Math.abs(e.velocity) * 20 * a.freeMode.momentumBounceRatio;
            let P;
            if (m < e.maxTranslate()) a.freeMode.momentumBounce ? (m + e.maxTranslate() < -x && (m = e.maxTranslate() - x), S = e.maxTranslate(), g = !0, h.allowMomentumBounce = !0) : m = e.maxTranslate(), a.loop && a.centeredSlides && (P = !0);
            else if (m > e.minTranslate()) a.freeMode.momentumBounce ? (m - e.minTranslate() > x && (m = e.minTranslate() + x), S = e.minTranslate(), g = !0, h.allowMomentumBounce = !0) : m = e.minTranslate(), a.loop && a.centeredSlides && (P = !0);
            else if (a.freeMode.sticky) {
                let T;
                for (let L = 0; L < d.length; L += 1)
                    if (d[L] > -m) {
                        T = L;
                        break
                    }
                Math.abs(d[T] - m) < Math.abs(d[T - 1] - m) || e.swipeDirection === "next" ? m = d[T] : m = d[T - 1], m = -m
            }
            if (P && r("transitionEnd", () => {
                    e.loopFix()
                }), e.velocity !== 0) {
                if (f ? v = Math.abs((-m - e.translate) / e.velocity) : v = Math.abs((m - e.translate) / e.velocity), a.freeMode.sticky) {
                    const T = Math.abs((f ? -m : m) - e.translate),
                        L = e.slidesSizesGrid[e.activeIndex];
                    T < L ? v = a.speed : T < 2 * L ? v = a.speed * 1.5 : v = a.speed * 2.5
                }
            } else if (a.freeMode.sticky) {
                e.slideToClosest();
                return
            }
            a.freeMode.momentumBounce && g ? (e.updateProgress(S), e.setTransition(v), e.setTranslate(m), e.transitionStart(!0, e.swipeDirection), e.animating = !0, Xf(u, () => {
                !e || e.destroyed || !h.allowMomentumBounce || (n("momentumBounce"), e.setTransition(a.speed), setTimeout(() => {
                    e.setTranslate(S), Xf(u, () => {
                        !e || e.destroyed || e.transitionEnd()
                    })
                }, 0))
            })) : e.velocity ? (n("_freeModeNoMomentumRelease"), e.updateProgress(m), e.setTransition(v), e.setTranslate(m), e.transitionStart(!0, e.swipeDirection), e.animating || (e.animating = !0, Xf(u, () => {
                !e || e.destroyed || e.transitionEnd()
            }))) : e.updateProgress(m), e.updateActiveIndex(), e.updateSlidesClasses()
        } else if (a.freeMode.sticky) {
            e.slideToClosest();
            return
        } else a.freeMode && n("_freeModeNoMomentumRelease");
        (!a.freeMode.momentum || _ >= a.longSwipesMs) && (e.updateProgress(), e.updateActiveIndex(), e.updateSlidesClasses())
    }
    Object.assign(e, {
        freeMode: {
            onTouchStart: i,
            onTouchMove: o,
            onTouchEnd: s
        }
    })
}
const $C = "_footer_298ip_1",
    HC = "_body_298ip_11",
    WC = "_block_298ip_25",
    GC = "_col_298ip_32",
    YC = "_socials_298ip_46",
    XC = "_social_298ip_46",
    qC = "_logo_298ip_59",
    KC = "_bottom_298ip_63",
    jn = {
        footer: $C,
        body: HC,
        block: WC,
        col: GC,
        socials: YC,
        social: XC,
        logo: qC,
        bottom: KC
    },
    QC = "_logo_407ah_1",
    ZC = {
        logo: QC
    },
    __ = () => O("div", {
        className: de(ZC.logo, "logo"),
        children: oe("svg", {
            width: "1145",
            height: "296",
            viewBox: "0 0 1145 296",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [O("path", {
                d: "M620.641 184.297C620.641 121.458 663.49 73.5157 723.224 73.5157C785.714 73.5157 819.359 120.651 819.359 180.266V197.151H674.271C678.339 229.625 697.979 249.089 725.599 249.089C747.24 249.089 764.5 238.573 770.87 217.88L818.135 234.771C802.786 273.729 767.266 295.651 725.219 295.651C663.109 295.224 620.641 250.432 620.641 184.297ZM676.229 158.349H763.771C763.391 137.271 750.151 118.927 722.953 118.927C700.74 118.927 683.323 132.474 676.536 158.349H676.229Z",
                fill: "white"
            }), O("path", {
                d: "M893.708 292.615H837.547V79.2344H893.708V101.151C897.203 96.9636 901.12 93.2188 905.458 89.9167C909.797 86.6094 914.448 83.8334 919.411 81.5781C924.359 79.3177 929.5 77.6459 934.833 76.5625C940.161 75.4792 945.547 75.0156 950.984 75.1667C976.688 75.1667 996.328 86.4531 1007.88 104.417C1009.92 102.12 1012.07 99.9323 1014.34 97.8646C1016.61 95.7917 1018.98 93.849 1021.46 92.0313C1023.94 90.2136 1026.51 88.5313 1029.16 86.9844C1031.81 85.4375 1034.54 84.0365 1037.34 82.7813C1040.15 81.5209 1043.01 80.4167 1045.93 79.4636C1048.85 78.5104 1051.81 77.7136 1054.82 77.0729C1057.82 76.4323 1060.85 75.9531 1063.91 75.6354C1066.96 75.3177 1070.03 75.1615 1073.09 75.1667C1116.37 75.1667 1144.38 105.604 1144.38 151.938V292.807H1088.44V168.094C1088.44 144.146 1079.58 127.099 1056.37 127.099C1037.92 127.099 1019.12 141.302 1019.12 169.323V292.422H963.068V168.094C963.068 144.146 954.245 127.099 931 127.099C912.583 127.099 893.708 141.302 893.708 169.323V292.615Z",
                fill: "white"
            }), O("path", {
                d: "M270.307 204.563L324.781 192.854C329.614 225.714 348.833 247.63 388.005 247.63C419.651 247.63 437.875 233.427 437.875 211.125C437.875 152.703 279.625 187.214 279.625 83.0729C279.437 30.7552 319.526 0.354187 385.167 0.354187C438.875 0.354187 480.114 27.9167 488.13 74.5521L437.224 90.8281C430.432 65.2656 413.552 46.9948 381.906 46.9948C353.515 46.9948 335.062 58.2761 335.062 77.6979C335.062 133.667 493.312 96.8906 493.312 208.208C493.312 261.297 457.635 295.38 387.62 295.38C323.937 295.224 277.594 265.208 270.307 204.563Z",
                fill: "white"
            }), O("path", {
                d: "M608.745 146.755V92.0573H560.333V39.7761H509.422V210.052C509.422 263.557 535.089 294.495 581.547 294.495C590.734 294.432 599.797 293.359 608.745 291.271V244.057C604.021 245.229 599.224 245.766 594.359 245.672C574.719 245.672 560.333 236.38 560.333 214.964V146.755H608.745Z",
                fill: "white"
            }), O("path", {
                d: "M20.4064 178.693L1.57302 205.177C1.2501 205.62 0.979271 206.089 0.755312 206.589C0.531355 207.083 0.359478 207.599 0.239687 208.13C0.119895 208.661 0.0521864 209.203 0.0417704 209.75C0.026145 210.297 0.0678117 210.833 0.16677 211.375C0.26052 211.911 0.411562 212.432 0.614687 212.938C0.812603 213.448 1.0626 213.927 1.36469 214.385C1.66156 214.844 2.00531 215.266 2.38552 215.651C2.77094 216.042 3.1876 216.385 3.64073 216.693L111.365 290.927C111.818 291.224 112.287 291.479 112.787 291.688C113.281 291.896 113.797 292.052 114.323 292.161C114.849 292.271 115.386 292.333 115.922 292.339C116.464 292.349 116.995 292.307 117.526 292.214C118.057 292.12 118.573 291.974 119.078 291.781C119.583 291.589 120.063 291.349 120.521 291.068C120.979 290.781 121.406 290.458 121.802 290.094C122.198 289.729 122.557 289.328 122.875 288.891L141.672 262.448C141.99 262.005 142.261 261.531 142.484 261.036C142.708 260.542 142.88 260.026 143 259.495C143.12 258.964 143.188 258.427 143.203 257.88C143.214 257.339 143.172 256.797 143.078 256.26C142.984 255.724 142.839 255.203 142.641 254.693C142.438 254.188 142.193 253.703 141.896 253.25C141.604 252.792 141.266 252.365 140.886 251.974C140.505 251.589 140.089 251.24 139.641 250.932L32.0314 176.693C31.5834 176.38 31.1095 176.115 30.6095 175.896C30.1095 175.677 29.5886 175.505 29.0574 175.391C28.5209 175.271 27.9845 175.203 27.4376 175.188C26.8907 175.177 26.3491 175.219 25.8126 175.307C25.2709 175.401 24.7449 175.547 24.2345 175.74C23.7241 175.932 23.2397 176.177 22.7761 176.469C22.3126 176.755 21.8803 177.089 21.4845 177.464C21.0834 177.839 20.7241 178.245 20.4064 178.693Z",
                fill: "white"
            }), O("path", {
                d: "M98.5156 7.10938L79.7188 33.5573C79.3959 34 79.125 34.4688 78.9011 34.9688C78.6771 35.4688 78.5052 35.9792 78.3854 36.5156C78.2656 37.0469 78.1979 37.5833 78.1875 38.1302C78.1719 38.6771 78.2136 39.2188 78.3125 39.7552C78.4063 40.2917 78.5573 40.8125 78.7604 41.3229C78.9584 41.8281 79.2136 42.3125 79.5104 42.7656C79.8073 43.224 80.1511 43.6458 80.5313 44.0365C80.9167 44.4219 81.3334 44.7708 81.7865 45.0729L186.714 117.391C187.161 117.693 187.63 117.948 188.13 118.156C188.625 118.365 189.141 118.526 189.667 118.635C190.198 118.75 190.729 118.807 191.271 118.818C191.807 118.823 192.344 118.781 192.875 118.688C193.406 118.594 193.922 118.453 194.427 118.26C194.932 118.063 195.411 117.823 195.87 117.542C196.328 117.255 196.755 116.927 197.151 116.563C197.547 116.193 197.901 115.792 198.219 115.354L217.057 88.9063C217.375 88.4635 217.646 87.9948 217.87 87.5C218.094 87 218.271 86.4844 218.391 85.9531C218.51 85.4219 218.578 84.8802 218.589 84.3333C218.599 83.7917 218.557 83.25 218.464 82.7135C218.365 82.1719 218.214 81.651 218.016 81.1458C217.813 80.6354 217.563 80.1563 217.266 79.6979C216.964 79.2396 216.625 78.8177 216.24 78.4323C215.859 78.0417 215.438 77.6979 214.984 77.3958L110.177 5.07813C109.724 4.76563 109.25 4.50521 108.745 4.28646C108.24 4.06771 107.724 3.90105 107.188 3.78646C106.651 3.67188 106.109 3.60938 105.563 3.59376C105.016 3.58334 104.474 3.62501 103.932 3.71876C103.391 3.81251 102.865 3.95834 102.354 4.15626C101.844 4.34896 101.354 4.59376 100.891 4.88542C100.427 5.17709 99.9948 5.51042 99.5938 5.88021C99.1979 6.25521 98.8334 6.66667 98.5156 7.10938Z",
                fill: "white"
            }), O("path", {
                d: "M25.7395 32.0625L6.90097 58.5104C6.58326 58.9531 6.31243 59.4219 6.08847 59.9167C5.86451 60.4167 5.69264 60.9323 5.57285 61.4635C5.44785 61.9948 5.38535 62.5365 5.36972 63.0833C5.3593 63.625 5.40097 64.1667 5.49993 64.7031C5.59368 65.2448 5.74472 65.7656 5.94785 66.2708C6.14576 66.7813 6.39576 67.2604 6.69785 67.7188C6.99472 68.1771 7.33326 68.599 7.71868 68.9844C8.1041 69.375 8.52076 69.7188 8.97389 70.0208L187.75 193.276C188.198 193.578 188.667 193.828 189.161 194.036C189.661 194.25 190.172 194.406 190.698 194.521C191.224 194.63 191.76 194.693 192.297 194.703C192.833 194.714 193.37 194.672 193.901 194.578C194.432 194.484 194.948 194.344 195.453 194.156C195.953 193.964 196.437 193.729 196.896 193.443C197.354 193.161 197.781 192.839 198.177 192.474C198.578 192.109 198.937 191.714 199.255 191.281L218.094 164.797C218.411 164.354 218.682 163.88 218.906 163.385C219.13 162.885 219.302 162.37 219.427 161.839C219.547 161.307 219.609 160.766 219.625 160.224C219.635 159.677 219.594 159.135 219.5 158.599C219.401 158.063 219.25 157.536 219.052 157.031C218.849 156.526 218.599 156.042 218.302 155.583C218 155.13 217.661 154.708 217.276 154.318C216.891 153.932 216.474 153.583 216.021 153.281L37.3645 30.026C36.9114 29.7188 36.4374 29.4531 35.9374 29.2396C35.4322 29.0208 34.9166 28.8542 34.3801 28.7396C33.8489 28.625 33.3072 28.5573 32.7603 28.5469C32.2187 28.5365 31.677 28.5781 31.1353 28.6719C30.5989 28.7656 30.0728 28.9115 29.5676 29.1094C29.0572 29.3021 28.5676 29.5469 28.1041 29.8385C27.6458 30.1302 27.2135 30.4583 26.8124 30.8333C26.4166 31.2083 26.0572 31.6198 25.7395 32.0625Z",
                fill: "white"
            }), O("path", {
                d: "M20.7499 103.995L1.91653 130.25C1.59883 130.693 1.32279 131.161 1.09883 131.661C0.874868 132.156 0.702994 132.672 0.583202 133.203C0.46341 133.74 0.395702 134.276 0.385285 134.823C0.369661 135.37 0.416536 135.911 0.510285 136.448C0.609244 136.984 0.755076 137.505 0.958202 138.01C1.16133 138.521 1.41133 139 1.7082 139.458C2.00508 139.917 2.34883 140.339 2.73424 140.724C3.11445 141.115 3.53633 141.458 3.98945 141.766L182.76 265.016C183.208 265.318 183.682 265.573 184.177 265.781C184.677 265.99 185.187 266.151 185.719 266.266C186.245 266.375 186.776 266.438 187.318 266.443C187.859 266.453 188.391 266.411 188.922 266.318C189.453 266.224 189.974 266.078 190.474 265.885C190.979 265.693 191.458 265.453 191.917 265.167C192.375 264.88 192.802 264.557 193.198 264.188C193.594 263.823 193.953 263.417 194.271 262.984L213.104 236.536C213.422 236.094 213.698 235.625 213.922 235.125C214.146 234.63 214.318 234.115 214.437 233.578C214.557 233.047 214.625 232.51 214.635 231.964C214.651 231.417 214.609 230.875 214.51 230.339C214.411 229.802 214.266 229.281 214.062 228.771C213.859 228.266 213.609 227.781 213.312 227.328C213.016 226.87 212.672 226.448 212.286 226.057C211.906 225.672 211.489 225.323 211.036 225.021L32.3749 101.766C31.9217 101.464 31.4374 101.208 30.9322 100.995C30.427 100.786 29.9061 100.625 29.3645 100.516C28.828 100.406 28.2863 100.354 27.7395 100.349C27.1926 100.349 26.6457 100.396 26.1092 100.5C25.5676 100.604 25.0467 100.755 24.5363 100.964C24.0311 101.167 23.5467 101.422 23.0884 101.719C22.6301 102.021 22.203 102.359 21.8072 102.745C21.4165 103.125 21.0624 103.542 20.7499 103.995Z",
                fill: "white"
            })]
        })
    }),
    JC = "_button_1q164_1",
    eT = {
        button: JC
    },
    Ah = ({
        children: e,
        className: t
    }) => O("button", {
        className: de(eT.button, t && t),
        children: e
    }),
    tT = "_newsletterForm_1u3ec_1",
    nT = {
        newsletterForm: tT
    },
    rT = () => {
        const [e, t] = R.useState("");
        return oe("form", {
            name: "newsletter",
            method: "POST",
            className: nT.newsletterForm,
            "data-netlify": "true",
            children: [O("label", {
                htmlFor: "#email",
                children: "Sign up for our newsletter"
            }), O("input", {
                type: "hidden",
                name: "form-name",
                value: "newsletter"
            }), O("input", {
                value: e,
                onChange: n => t(n.target.value),
                placeholder: "Email",
                type: "email",
                name: "email",
                id: "email"
            }), O(Ah, {
                type: "submit",
                children: "Submit"
            })]
        })
    },
    Dn = R.createContext({}),
    iT = () => {
        const {
            setAnchorScrolling: e
        } = R.useContext(Dn);
        return oe("footer", {
            id: "footer",
            className: de(jn.footer),
            children: [oe("div", {
                className: jn.body,
                children: [oe("div", {
                    className: jn.block,
                    children: [O("div", {
                        onClick: () => window.fullpage_api.moveTo(2),
                        className: jn.logo,
                        children: O(__, {})
                    }), O("p", {
                        children: "Where music makes money."
                    }), oe("div", {
                        className: jn.socials,
                        children: [O("a", {
                            href: "https://www.instagram.com/stem/",
                            target: "_blank",
                            className: jn.social,
                            children: O("img", {
                                src: "/images/icons/insta.svg",
                                alt: ""
                            })
                        }), O("a", {
                            href: "https://twitter.com/stem?lang=en",
                            target: "_blank",
                            className: jn.social,
                            children: O("img", {
                                src: "/images/icons/twitter.svg",
                                alt: ""
                            })
                        })]
                    })]
                }), oe("ul", {
                    className: jn.col,
                    children: [O("li", {
                        onClick: t => {
                            var n;
                            t.preventDefault(), window.fullpage_api.moveTo(4), (n = document.querySelector(".services .fp-overflow")) == null || n.scrollTo({
                                left: 0,
                                top: 0,
                                behavior: "smooth"
                            })
                        },
                        children: O("a", {
                            href: "#services",
                            children: "What we do"
                        })
                    }), O("li", {
                        onClick: t => {
                            var n;
                            t.preventDefault(), window.fullpage_api.moveTo(2), e(!0), (n = document.querySelector(".home .fp-overflow")) == null || n.scrollTo({
                                left: 0,
                                top: window.innerHeight,
                                behavior: "smooth"
                            }), setTimeout(() => e(!1), 1e3)
                        },
                        children: O("a", {
                            href: "#about",
                            children: "About Us"
                        })
                    })]
                }), oe("ul", {
                    className: jn.col,
                    children: [O("li", {
                        children: O("a", {
                            href: "https://app.stem.is/login",
                            children: "Log in"
                        })
                    }), O("li", {
                        children: O("a", {
                            href: "https://apply.stem.is/apply-now",
                            children: "Apply"
                        })
                    })]
                }), O(rT, {})]
            }), oe("div", {
                className: jn.bottom,
                children: [O("span", {
                    children: "© 2023 Stem Disintermedia Inc. All rights reserved."
                }), oe("div", {
                    className: "flex items-center",
                    children: [O("a", {
                        href: "https://apply.stem.is/terms-of-service/",
                        children: "Terms of Service"
                    }), O("a", {
                        href: "https://apply.stem.is/privacy-policy",
                        children: "Privacy Policy"
                    }), O("a", {
                        href: "https://apply.stem.is/copyright-policy/",
                        children: "Copyright Policy"
                    })]
                })]
            })]
        })
    },
    oT = {
        async getAll() {
            return (await Mh.get(`${Oh}/articles`)).data
        }
    };

function Ri(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function Ir(e, t) {
    const n = ["__proto__", "constructor", "prototype"];
    Object.keys(t).filter(r => n.indexOf(r) < 0).forEach(r => {
        typeof e[r] > "u" ? e[r] = t[r] : Ri(t[r]) && Ri(e[r]) && Object.keys(t[r]).length > 0 ? t[r].__swiper__ ? e[r] = t[r] : Ir(e[r], t[r]) : e[r] = t[r]
    })
}

function S_(e = {}) {
    return e.navigation && typeof e.navigation.nextEl > "u" && typeof e.navigation.prevEl > "u"
}

function w_(e = {}) {
    return e.pagination && typeof e.pagination.el > "u"
}

function x_(e = {}) {
    return e.scrollbar && typeof e.scrollbar.el > "u"
}

function E_(e = "") {
    const t = e.split(" ").map(r => r.trim()).filter(r => !!r),
        n = [];
    return t.forEach(r => {
        n.indexOf(r) < 0 && n.push(r)
    }), n.join(" ")
}

function sT(e = "") {
    return e ? e.includes("swiper-wrapper") ? e : `swiper-wrapper ${e}` : "swiper-wrapper"
}
const C_ = ["eventsPrefix", "injectStyles", "injectStylesUrls", "modules", "init", "_direction", "oneWayMovement", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_loop", "loopedSlides", "loopPreventsSliding", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideActiveClass", "slideVisibleClass", "slideNextClass", "slidePrevClass", "wrapperClass", "lazyPreloaderClass", "lazyPreloadPrevNext", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom", "control"];

function lT(e = {}, t = !0) {
    const n = {
            on: {}
        },
        r = {},
        i = {};
    Ir(n, sl.defaults), Ir(n, sl.extendedDefaults), n._emitClasses = !0, n.init = !1;
    const o = {},
        s = C_.map(a => a.replace(/_/, "")),
        l = Object.assign({}, e);
    return Object.keys(l).forEach(a => {
        typeof e[a] > "u" || (s.indexOf(a) >= 0 ? Ri(e[a]) ? (n[a] = {}, i[a] = {}, Ir(n[a], e[a]), Ir(i[a], e[a])) : (n[a] = e[a], i[a] = e[a]) : a.search(/on[A-Z]/) === 0 && typeof e[a] == "function" ? t ? r[`${a[2].toLowerCase()}${a.substr(3)}`] = e[a] : n.on[`${a[2].toLowerCase()}${a.substr(3)}`] = e[a] : o[a] = e[a])
    }), ["navigation", "pagination", "scrollbar"].forEach(a => {
        n[a] === !0 && (n[a] = {}), n[a] === !1 && delete n[a]
    }), {
        params: n,
        passedParams: i,
        rest: o,
        events: r
    }
}

function aT({
    el: e,
    nextEl: t,
    prevEl: n,
    paginationEl: r,
    scrollbarEl: i,
    swiper: o
}, s) {
    S_(s) && t && n && (o.params.navigation.nextEl = t, o.originalParams.navigation.nextEl = t, o.params.navigation.prevEl = n, o.originalParams.navigation.prevEl = n), w_(s) && r && (o.params.pagination.el = r, o.originalParams.pagination.el = r), x_(s) && i && (o.params.scrollbar.el = i, o.originalParams.scrollbar.el = i), o.init(e)
}

function uT(e, t, n, r, i) {
    const o = [];
    if (!t) return o;
    const s = a => {
        o.indexOf(a) < 0 && o.push(a)
    };
    if (n && r) {
        const a = r.map(i),
            u = n.map(i);
        a.join("") !== u.join("") && s("children"), r.length !== n.length && s("children")
    }
    return C_.filter(a => a[0] === "_").map(a => a.replace(/_/, "")).forEach(a => {
        if (a in e && a in t)
            if (Ri(e[a]) && Ri(t[a])) {
                const u = Object.keys(e[a]),
                    f = Object.keys(t[a]);
                u.length !== f.length ? s(a) : (u.forEach(d => {
                    e[a][d] !== t[a][d] && s(a)
                }), f.forEach(d => {
                    e[a][d] !== t[a][d] && s(a)
                }))
            } else e[a] !== t[a] && s(a)
    }), o
}

function T_(e) {
    return e.type && e.type.displayName && e.type.displayName.includes("SwiperSlide")
}

function P_(e) {
    const t = [];
    return Ge.Children.toArray(e).forEach(n => {
        T_(n) ? t.push(n) : n.props && n.props.children && P_(n.props.children).forEach(r => t.push(r))
    }), t
}

function cT(e) {
    const t = [],
        n = {
            "container-start": [],
            "container-end": [],
            "wrapper-start": [],
            "wrapper-end": []
        };
    return Ge.Children.toArray(e).forEach(r => {
        if (T_(r)) t.push(r);
        else if (r.props && r.props.slot && n[r.props.slot]) n[r.props.slot].push(r);
        else if (r.props && r.props.children) {
            const i = P_(r.props.children);
            i.length > 0 ? i.forEach(o => t.push(o)) : n["container-end"].push(r)
        } else n["container-end"].push(r)
    }), {
        slides: t,
        slots: n
    }
}

function fT({
    swiper: e,
    slides: t,
    passedParams: n,
    changedParams: r,
    nextEl: i,
    prevEl: o,
    scrollbarEl: s,
    paginationEl: l
}) {
    const a = r.filter(b => b !== "children" && b !== "direction" && b !== "wrapperClass"),
        {
            params: u,
            pagination: f,
            navigation: d,
            scrollbar: h,
            virtual: y,
            thumbs: _
        } = e;
    let v, E, m, g, S, x, P, T;
    r.includes("thumbs") && n.thumbs && n.thumbs.swiper && u.thumbs && !u.thumbs.swiper && (v = !0), r.includes("controller") && n.controller && n.controller.control && u.controller && !u.controller.control && (E = !0), r.includes("pagination") && n.pagination && (n.pagination.el || l) && (u.pagination || u.pagination === !1) && f && !f.el && (m = !0), r.includes("scrollbar") && n.scrollbar && (n.scrollbar.el || s) && (u.scrollbar || u.scrollbar === !1) && h && !h.el && (g = !0), r.includes("navigation") && n.navigation && (n.navigation.prevEl || o) && (n.navigation.nextEl || i) && (u.navigation || u.navigation === !1) && d && !d.prevEl && !d.nextEl && (S = !0);
    const L = b => {
        e[b] && (e[b].destroy(), b === "navigation" ? (e.isElement && (e[b].prevEl.remove(), e[b].nextEl.remove()), u[b].prevEl = void 0, u[b].nextEl = void 0, e[b].prevEl = void 0, e[b].nextEl = void 0) : (e.isElement && e[b].el.remove(), u[b].el = void 0, e[b].el = void 0))
    };
    r.includes("loop") && e.isElement && (u.loop && !n.loop ? x = !0 : !u.loop && n.loop ? P = !0 : T = !0), a.forEach(b => {
        if (Ri(u[b]) && Ri(n[b])) Ir(u[b], n[b]), (b === "navigation" || b === "pagination" || b === "scrollbar") && "enabled" in n[b] && !n[b].enabled && L(b);
        else {
            const N = n[b];
            (N === !0 || N === !1) && (b === "navigation" || b === "pagination" || b === "scrollbar") ? N === !1 && L(b): u[b] = n[b]
        }
    }), a.includes("controller") && !E && e.controller && e.controller.control && u.controller && u.controller.control && (e.controller.control = u.controller.control), r.includes("children") && t && y && u.virtual.enabled && (y.slides = t, y.update(!0)), r.includes("children") && t && u.loop && (T = !0), v && _.init() && _.update(!0), E && (e.controller.control = u.controller.control), m && (e.isElement && (!l || typeof l == "string") && (l = document.createElement("div"), l.classList.add("swiper-pagination"), e.el.shadowEl.appendChild(l)), l && (u.pagination.el = l), f.init(), f.render(), f.update()), g && (e.isElement && (!s || typeof s == "string") && (s = document.createElement("div"), s.classList.add("swiper-scrollbar"), e.el.shadowEl.appendChild(s)), s && (u.scrollbar.el = s), h.init(), h.updateSize(), h.setTranslate()), S && (e.isElement && ((!i || typeof i == "string") && (i = document.createElement("div"), i.classList.add("swiper-button-next"), e.el.shadowEl.appendChild(i)), (!o || typeof o == "string") && (o = document.createElement("div"), o.classList.add("swiper-button-prev"), e.el.shadowEl.appendChild(o))), i && (u.navigation.nextEl = i), o && (u.navigation.prevEl = o), d.init(), d.update()), r.includes("allowSlideNext") && (e.allowSlideNext = n.allowSlideNext), r.includes("allowSlidePrev") && (e.allowSlidePrev = n.allowSlidePrev), r.includes("direction") && e.changeDirection(n.direction, !1), (x || T) && e.loopDestroy(), (P || T) && e.loopCreate(), e.update()
}

function dT(e, t, n) {
    if (!n) return null;
    const r = f => {
            let d = f;
            return f < 0 ? d = t.length + f : d >= t.length && (d = d - t.length), d
        },
        i = e.isHorizontal() ? {
            [e.rtlTranslate ? "right" : "left"]: `${n.offset}px`
        } : {
            top: `${n.offset}px`
        },
        {
            from: o,
            to: s
        } = n,
        l = e.params.loop ? -t.length : 0,
        a = e.params.loop ? t.length * 2 : t.length,
        u = [];
    for (let f = l; f < a; f += 1) f >= o && f <= s && u.push(t[r(f)]);
    return u.map((f, d) => Ge.cloneElement(f, {
        swiper: e,
        style: i,
        key: `slide-${d}`
    }))
}
const pT = e => {
    !e || e.destroyed || !e.params.virtual || e.params.virtual && !e.params.virtual.enabled || (e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.parallax && e.params.parallax && e.params.parallax.enabled && e.parallax.setTranslate())
};

function Fs(e, t) {
    return typeof window > "u" ? R.useEffect(e, t) : R.useLayoutEffect(e, t)
}
const o1 = R.createContext(null),
    hT = R.createContext(null);

function up() {
    return up = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, up.apply(this, arguments)
}
const Rh = R.forwardRef(function(e, t) {
    let {
        className: n,
        tag: r = "div",
        wrapperTag: i = "div",
        children: o,
        onSwiper: s,
        ...l
    } = e === void 0 ? {} : e, a = !1;
    const [u, f] = R.useState("swiper"), [d, h] = R.useState(null), [y, _] = R.useState(!1), v = R.useRef(!1), E = R.useRef(null), m = R.useRef(null), g = R.useRef(null), S = R.useRef(null), x = R.useRef(null), P = R.useRef(null), T = R.useRef(null), L = R.useRef(null), {
        params: b,
        passedParams: N,
        rest: H,
        events: A
    } = lT(l), {
        slides: I,
        slots: B
    } = cT(o), G = () => {
        _(!y)
    };
    Object.assign(b.on, {
        _containerClasses(V, U) {
            f(U)
        }
    });
    const Q = () => {
        Object.assign(b.on, A), a = !0;
        const V = { ...b
        };
        if (delete V.wrapperClass, m.current = new sl(V), m.current.virtual && m.current.params.virtual.enabled) {
            m.current.virtual.slides = I;
            const U = {
                cache: !1,
                slides: I,
                renderExternal: h,
                renderExternalUpdate: !1
            };
            Ir(m.current.params.virtual, U), Ir(m.current.originalParams.virtual, U)
        }
    };
    E.current || Q(), m.current && m.current.on("_beforeBreakpoint", G);
    const le = () => {
            a || !A || !m.current || Object.keys(A).forEach(V => {
                m.current.on(V, A[V])
            })
        },
        ie = () => {
            !A || !m.current || Object.keys(A).forEach(V => {
                m.current.off(V, A[V])
            })
        };
    R.useEffect(() => () => {
        m.current && m.current.off("_beforeBreakpoint", G)
    }), R.useEffect(() => {
        !v.current && m.current && (m.current.emitSlidesClasses(), v.current = !0)
    }), Fs(() => {
        if (t && (t.current = E.current), !!E.current) return m.current.destroyed && Q(), aT({
            el: E.current,
            nextEl: x.current,
            prevEl: P.current,
            paginationEl: T.current,
            scrollbarEl: L.current,
            swiper: m.current
        }, b), s && s(m.current), () => {
            m.current && !m.current.destroyed && m.current.destroy(!0, !1)
        }
    }, []), Fs(() => {
        le();
        const V = uT(N, g.current, I, S.current, U => U.key);
        return g.current = N, S.current = I, V.length && m.current && !m.current.destroyed && fT({
            swiper: m.current,
            slides: I,
            passedParams: N,
            changedParams: V,
            nextEl: x.current,
            prevEl: P.current,
            scrollbarEl: L.current,
            paginationEl: T.current
        }), () => {
            ie()
        }
    }), Fs(() => {
        pT(m.current)
    }, [d]);

    function D() {
        return b.virtual ? dT(m.current, I, d) : I.map((V, U) => Ge.cloneElement(V, {
            swiper: m.current,
            swiperSlideIndex: U
        }))
    }
    return Ge.createElement(r, up({
        ref: E,
        className: E_(`${u}${n?` ${n}`:""}`)
    }, H), Ge.createElement(hT.Provider, {
        value: m.current
    }, B["container-start"], Ge.createElement(i, {
        className: sT(b.wrapperClass)
    }, B["wrapper-start"], D(), B["wrapper-end"]), S_(b) && Ge.createElement(Ge.Fragment, null, Ge.createElement("div", {
        ref: P,
        className: "swiper-button-prev"
    }), Ge.createElement("div", {
        ref: x,
        className: "swiper-button-next"
    })), x_(b) && Ge.createElement("div", {
        ref: L,
        className: "swiper-scrollbar"
    }), w_(b) && Ge.createElement("div", {
        ref: T,
        className: "swiper-pagination"
    }), B["container-end"]))
});
Rh.displayName = "Swiper";

function cp() {
    return cp = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, cp.apply(this, arguments)
}
const Dh = R.forwardRef(function(e, t) {
    let {
        tag: n = "div",
        children: r,
        className: i = "",
        swiper: o,
        zoom: s,
        lazy: l,
        virtualIndex: a,
        swiperSlideIndex: u,
        ...f
    } = e === void 0 ? {} : e;
    const d = R.useRef(null),
        [h, y] = R.useState("swiper-slide"),
        [_, v] = R.useState(!1);

    function E(x, P, T) {
        P === d.current && y(T)
    }
    Fs(() => {
        if (typeof u < "u" && (d.current.swiperSlideIndex = u), t && (t.current = d.current), !(!d.current || !o)) {
            if (o.destroyed) {
                h !== "swiper-slide" && y("swiper-slide");
                return
            }
            return o.on("_slideClass", E), () => {
                o && o.off("_slideClass", E)
            }
        }
    }), Fs(() => {
        o && d.current && !o.destroyed && y(o.getSlideClasses(d.current))
    }, [o]);
    const m = {
            isActive: h.indexOf("swiper-slide-active") >= 0,
            isVisible: h.indexOf("swiper-slide-visible") >= 0,
            isPrev: h.indexOf("swiper-slide-prev") >= 0,
            isNext: h.indexOf("swiper-slide-next") >= 0
        },
        g = () => typeof r == "function" ? r(m) : r,
        S = () => {
            v(!0)
        };
    return Ge.createElement(n, cp({
        ref: d,
        className: E_(`${h}${i?` ${i}`:""}`),
        "data-swiper-slide-index": a,
        onLoad: S
    }, f), s && Ge.createElement(o1.Provider, {
        value: m
    }, Ge.createElement("div", {
        className: "swiper-zoom-container",
        "data-swiper-zoom": typeof s == "number" ? s : void 0
    }, g(), l && !_ && Ge.createElement("div", {
        className: "swiper-lazy-preloader"
    }))), !s && Ge.createElement(o1.Provider, {
        value: m
    }, g(), l && !_ && Ge.createElement("div", {
        className: "swiper-lazy-preloader"
    })))
});
Dh.displayName = "SwiperSlide";
const mT = () => {
        const {
            articlesProgress: e,
            setArticlesProgress: t
        } = R.useContext(Dn), n = R.useRef(null), [r, i] = R.useState(), [o, s] = R.useState();
        return R.useEffect(() => {
            async function l() {
                const a = await oT.getAll();
                a.results && s(a.results)
            }
            l()
        }, []), R.useEffect(() => {
            console.log(e)
        }, [e]), O("section", {
            className: de("section about", Ue.about),
            children: oe("div", {
                className: Ue.container,
                children: [oe("div", {
                    className: Ue.wrapper,
                    children: [oe("div", {
                        className: Ue.press,
                        children: [O("div", {
                            className: de(Ue.line, "press-line"),
                            children: O("img", {
                                src: "/images/about/press.svg",
                                alt: ""
                            })
                        }), O("div", {
                            className: de(Ue.line, "press-line"),
                            children: O("img", {
                                src: "/images/about/press.svg",
                                alt: ""
                            })
                        }), O("div", {
                            className: de(Ue.line, "press-line"),
                            children: O("img", {
                                src: "/images/about/press.svg",
                                alt: ""
                            })
                        }), window.innerWidth <= 768 && oe(Kn, {
                            children: [O("div", {
                                className: de(Ue.line, "press-line"),
                                children: O("img", {
                                    src: "/images/about/press.svg",
                                    alt: ""
                                })
                            }), O("div", {
                                className: de(Ue.line, "press-line"),
                                children: O("img", {
                                    src: "/images/about/press.svg",
                                    alt: ""
                                })
                            }), O("div", {
                                className: de(Ue.line, "press-line"),
                                children: O("img", {
                                    src: "/images/about/press.svg",
                                    alt: ""
                                })
                            })]
                        })]
                    }), O("div", {
                        ref: n,
                        className: de(Ue.articles, "articles"),
                        children: O("div", {
                            className: Ue.row,
                            children: window.innerWidth > 768 ? O(Rh, {
                                onProgress: () => {
                                    r && (console.log(r.progress), t(r.progress))
                                },
                                mousewheel: {
                                    releaseOnEdges: !0
                                },
                                scrollbar: {
                                    hide: !0
                                },
                                onSwiper: l => i(l),
                                allowTouchMove: !0,
                                slidesPerView: 4,
                                freeMode: !0,
                                className: "articles-swiper",
                                modules: [UC, VC, BC],
                                children: o && o.map((l, a) => O(Dh, {
                                    children: O("div", {
                                        style: {
                                            transitionDelay: `${(a+1)*.155+1}s`
                                        },
                                        className: de(Ue.article, "article fade"),
                                        children: O("div", {
                                            className: Ue.content,
                                            children: oe("a", {
                                                className: Ue.spacer,
                                                href: l.link,
                                                children: [O("img", {
                                                    src: pu(l.logo),
                                                    className: Ue.img,
                                                    alt: ""
                                                }), O("h4", {
                                                    className: Ue.title,
                                                    children: l.title
                                                }), O("small", {
                                                    children: l.date
                                                })]
                                            })
                                        })
                                    }, a)
                                }, a))
                            }) : O(Kn, {
                                children: o && o.map((l, a) => O("div", {
                                    style: {
                                        transitionDelay: `${(a+1)*.155+1}s`
                                    },
                                    className: de(Ue.article, "article fade"),
                                    children: oe("div", {
                                        className: Ue.content,
                                        children: [O("img", {
                                            src: pu(l.logo),
                                            className: Ue.img,
                                            alt: ""
                                        }), O("h4", {
                                            className: Ue.title,
                                            children: O("a", {
                                                href: l.link,
                                                children: l.title
                                            })
                                        }), O("small", {
                                            children: l.date
                                        })]
                                    })
                                }, a))
                            })
                        })
                    }), O("div", {
                        className: "banner-wrapper bottom",
                        children: O(p_, {})
                    }), O("div", {
                        onClick: () => {
                            r && r.slideNext()
                        },
                        className: Ue.swiperArrow,
                        children: O("img", {
                            src: "/images/icons/swiper-arrow.svg",
                            alt: ""
                        })
                    })]
                }), O(iT, {})]
            })
        })
    },
    vT = "_hero_1jewr_1",
    gT = "_container_1jewr_7",
    yT = "_content_1jewr_21",
    _T = "_block_1jewr_26",
    ST = "_blockRight_1jewr_33",
    wT = "_text_1jewr_33",
    ir = {
        hero: vT,
        container: gT,
        content: yT,
        block: _T,
        blockRight: ST,
        text: wT
    },
    ht = (e, t = !0, n = !0) => {
        const r = e.split(" ");
        return O(Kn, {
            children: t === !0 ? r.map((i, o) => O("div", {
                className: n ? "word" : "s-word",
                style: {
                    marginRight: "0.2em"
                },
                children: Array.from(i).map((s, l) => O("div", {
                    className: n ? "char" : "s-char",
                    style: {
                        transitionDelay: n ? `${(o+1)*.065+1}s` : `${(o+1)*.015}s`
                    },
                    children: s
                }, l))
            }, o)) : r.map((i, o) => O("div", {
                style: {
                    position: "relative",
                    display: "inline-block",
                    marginRight: o !== -1 ? "0.2em" : "",
                    opacity: "0",
                    translate: "0 100%",
                    transition: n ? `1s ease ${(o+1)*.025+1}s` : `1s ease ${(o+1)*.015}s`,
                    transitionProperty: "rotate, translate, opacity"
                },
                children: i
            }, o))
        })
    },
    xT = "_realeses_obgpf_1",
    ET = "_hovered_obgpf_8",
    CT = "_albumInfo_obgpf_8",
    TT = "_toStatic_obgpf_1",
    PT = "_container_obgpf_13",
    kT = "_desc_obgpf_91",
    bT = "_albums_obgpf_131",
    MT = "_album_obgpf_8",
    OT = "_cover_obgpf_211",
    LT = "_toHidden_obgpf_1",
    NT = "_title_obgpf_274",
    AT = "_artist_obgpf_282",
    RT = "_date_obgpf_291",
    et = {
        realeses: xT,
        hovered: ET,
        albumInfo: CT,
        toStatic: TT,
        container: PT,
        desc: kT,
        albums: bT,
        album: MT,
        cover: OT,
        toHidden: LT,
        title: NT,
        artist: AT,
        date: RT
    };

function ur(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function k_(e, t) {
    e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
}
/*!
 * GSAP 3.11.5
 * https://greensock.com
 *
 * @license Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var nn = {
        autoSleep: 120,
        force3D: "auto",
        nullTargetWarn: 1,
        units: {
            lineHeight: ""
        }
    },
    Ro = {
        duration: .5,
        overwrite: !1,
        delay: 0
    },
    zh, Tt, Qe, vn = 1e8,
    Ce = 1 / vn,
    fp = Math.PI * 2,
    DT = fp / 4,
    zT = 0,
    b_ = Math.sqrt,
    IT = Math.cos,
    FT = Math.sin,
    ct = function(t) {
        return typeof t == "string"
    },
    He = function(t) {
        return typeof t == "function"
    },
    Sr = function(t) {
        return typeof t == "number"
    },
    Ih = function(t) {
        return typeof t > "u"
    },
    Qn = function(t) {
        return typeof t == "object"
    },
    $t = function(t) {
        return t !== !1
    },
    Fh = function() {
        return typeof window < "u"
    },
    Sa = function(t) {
        return He(t) || ct(t)
    },
    M_ = typeof ArrayBuffer == "function" && ArrayBuffer.isView || function() {},
    Pt = Array.isArray,
    dp = /(?:-?\.?\d|\.)+/gi,
    O_ = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,
    po = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g,
    td = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,
    L_ = /[+-]=-?[.\d]+/,
    N_ = /[^,'"\[\]\s]+/gi,
    BT = /^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,
    Ie, fn, pp, Bh, on = {},
    hu = {},
    A_, R_ = function(t) {
        return (hu = Di(t, on)) && Gt
    },
    jh = function(t, n) {
        return console.warn("Invalid property", t, "set to", n, "Missing plugin? gsap.registerPlugin()")
    },
    mu = function(t, n) {
        return !n && console.warn(t)
    },
    D_ = function(t, n) {
        return t && (on[t] = n) && hu && (hu[t] = n) || on
    },
    ll = function() {
        return 0
    },
    jT = {
        suppressEvents: !0,
        isStart: !0,
        kill: !1
    },
    Ba = {
        suppressEvents: !0,
        kill: !1
    },
    VT = {
        suppressEvents: !0
    },
    Vh = {},
    Kr = [],
    hp = {},
    z_, Zt = {},
    nd = {},
    s1 = 30,
    ja = [],
    Uh = "",
    $h = function(t) {
        var n = t[0],
            r, i;
        if (Qn(n) || He(n) || (t = [t]), !(r = (n._gsap || {}).harness)) {
            for (i = ja.length; i-- && !ja[i].targetTest(n););
            r = ja[i]
        }
        for (i = t.length; i--;) t[i] && (t[i]._gsap || (t[i]._gsap = new sS(t[i], r))) || t.splice(i, 1);
        return t
    },
    Pi = function(t) {
        return t._gsap || $h(gn(t))[0]._gsap
    },
    I_ = function(t, n, r) {
        return (r = t[n]) && He(r) ? t[n]() : Ih(r) && t.getAttribute && t.getAttribute(n) || r
    },
    Ht = function(t, n) {
        return (t = t.split(",")).forEach(n) || t
    },
    Ye = function(t) {
        return Math.round(t * 1e5) / 1e5 || 0
    },
    mt = function(t) {
        return Math.round(t * 1e7) / 1e7 || 0
    },
    wo = function(t, n) {
        var r = n.charAt(0),
            i = parseFloat(n.substr(2));
        return t = parseFloat(t), r === "+" ? t + i : r === "-" ? t - i : r === "*" ? t * i : t / i
    },
    UT = function(t, n) {
        for (var r = n.length, i = 0; t.indexOf(n[i]) < 0 && ++i < r;);
        return i < r
    },
    vu = function() {
        var t = Kr.length,
            n = Kr.slice(0),
            r, i;
        for (hp = {}, Kr.length = 0, r = 0; r < t; r++) i = n[r], i && i._lazy && (i.render(i._lazy[0], i._lazy[1], !0)._lazy = 0)
    },
    F_ = function(t, n, r, i) {
        Kr.length && !Tt && vu(), t.render(n, r, i || Tt && n < 0 && (t._initted || t._startAt)), Kr.length && !Tt && vu()
    },
    B_ = function(t) {
        var n = parseFloat(t);
        return (n || n === 0) && (t + "").match(N_).length < 2 ? n : ct(t) ? t.trim() : t
    },
    j_ = function(t) {
        return t
    },
    En = function(t, n) {
        for (var r in n) r in t || (t[r] = n[r]);
        return t
    },
    $T = function(t) {
        return function(n, r) {
            for (var i in r) i in n || i === "duration" && t || i === "ease" || (n[i] = r[i])
        }
    },
    Di = function(t, n) {
        for (var r in n) t[r] = n[r];
        return t
    },
    l1 = function e(t, n) {
        for (var r in n) r !== "__proto__" && r !== "constructor" && r !== "prototype" && (t[r] = Qn(n[r]) ? e(t[r] || (t[r] = {}), n[r]) : n[r]);
        return t
    },
    gu = function(t, n) {
        var r = {},
            i;
        for (i in t) i in n || (r[i] = t[i]);
        return r
    },
    Bs = function(t) {
        var n = t.parent || Ie,
            r = t.keyframes ? $T(Pt(t.keyframes)) : En;
        if ($t(t.inherit))
            for (; n;) r(t, n.vars.defaults), n = n.parent || n._dp;
        return t
    },
    HT = function(t, n) {
        for (var r = t.length, i = r === n.length; i && r-- && t[r] === n[r];);
        return r < 0
    },
    V_ = function(t, n, r, i, o) {
        r === void 0 && (r = "_first"), i === void 0 && (i = "_last");
        var s = t[i],
            l;
        if (o)
            for (l = n[o]; s && s[o] > l;) s = s._prev;
        return s ? (n._next = s._next, s._next = n) : (n._next = t[r], t[r] = n), n._next ? n._next._prev = n : t[i] = n, n._prev = s, n.parent = n._dp = t, n
    },
    Gu = function(t, n, r, i) {
        r === void 0 && (r = "_first"), i === void 0 && (i = "_last");
        var o = n._prev,
            s = n._next;
        o ? o._next = s : t[r] === n && (t[r] = s), s ? s._prev = o : t[i] === n && (t[i] = o), n._next = n._prev = n.parent = null
    },
    ei = function(t, n) {
        t.parent && (!n || t.parent.autoRemoveChildren) && t.parent.remove(t), t._act = 0
    },
    ki = function(t, n) {
        if (t && (!n || n._end > t._dur || n._start < 0))
            for (var r = t; r;) r._dirty = 1, r = r.parent;
        return t
    },
    WT = function(t) {
        for (var n = t.parent; n && n.parent;) n._dirty = 1, n.totalDuration(), n = n.parent;
        return t
    },
    mp = function(t, n, r, i) {
        return t._startAt && (Tt ? t._startAt.revert(Ba) : t.vars.immediateRender && !t.vars.autoRevert || t._startAt.render(n, !0, i))
    },
    GT = function e(t) {
        return !t || t._ts && e(t.parent)
    },
    a1 = function(t) {
        return t._repeat ? Do(t._tTime, t = t.duration() + t._rDelay) * t : 0
    },
    Do = function(t, n) {
        var r = Math.floor(t /= n);
        return t && r === t ? r - 1 : r
    },
    yu = function(t, n) {
        return (t - n._start) * n._ts + (n._ts >= 0 ? 0 : n._dirty ? n.totalDuration() : n._tDur)
    },
    Yu = function(t) {
        return t._end = mt(t._start + (t._tDur / Math.abs(t._ts || t._rts || Ce) || 0))
    },
    Xu = function(t, n) {
        var r = t._dp;
        return r && r.smoothChildTiming && t._ts && (t._start = mt(r._time - (t._ts > 0 ? n / t._ts : ((t._dirty ? t.totalDuration() : t._tDur) - n) / -t._ts)), Yu(t), r._dirty || ki(r, t)), t
    },
    U_ = function(t, n) {
        var r;
        if ((n._time || n._initted && !n._dur) && (r = yu(t.rawTime(), n), (!n._dur || Sl(0, n.totalDuration(), r) - n._tTime > Ce) && n.render(r, !0)), ki(t, n)._dp && t._initted && t._time >= t._dur && t._ts) {
            if (t._dur < t.duration())
                for (r = t; r._dp;) r.rawTime() >= 0 && r.totalTime(r._tTime), r = r._dp;
            t._zTime = -Ce
        }
    },
    $n = function(t, n, r, i) {
        return n.parent && ei(n), n._start = mt((Sr(r) ? r : r || t !== Ie ? cn(t, r, n) : t._time) + n._delay), n._end = mt(n._start + (n.totalDuration() / Math.abs(n.timeScale()) || 0)), V_(t, n, "_first", "_last", t._sort ? "_start" : 0), vp(n) || (t._recent = n), i || U_(t, n), t._ts < 0 && Xu(t, t._tTime), t
    },
    $_ = function(t, n) {
        return (on.ScrollTrigger || jh("scrollTrigger", n)) && on.ScrollTrigger.create(n, t)
    },
    H_ = function(t, n, r, i, o) {
        if (Wh(t, n, o), !t._initted) return 1;
        if (!r && t._pt && !Tt && (t._dur && t.vars.lazy !== !1 || !t._dur && t.vars.lazy) && z_ !== Jt.frame) return Kr.push(t), t._lazy = [o, i], 1
    },
    YT = function e(t) {
        var n = t.parent;
        return n && n._ts && n._initted && !n._lock && (n.rawTime() < 0 || e(n))
    },
    vp = function(t) {
        var n = t.data;
        return n === "isFromStart" || n === "isStart"
    },
    XT = function(t, n, r, i) {
        var o = t.ratio,
            s = n < 0 || !n && (!t._start && YT(t) && !(!t._initted && vp(t)) || (t._ts < 0 || t._dp._ts < 0) && !vp(t)) ? 0 : 1,
            l = t._rDelay,
            a = 0,
            u, f, d;
        if (l && t._repeat && (a = Sl(0, t._tDur, n), f = Do(a, l), t._yoyo && f & 1 && (s = 1 - s), f !== Do(t._tTime, l) && (o = 1 - s, t.vars.repeatRefresh && t._initted && t.invalidate())), s !== o || Tt || i || t._zTime === Ce || !n && t._zTime) {
            if (!t._initted && H_(t, n, i, r, a)) return;
            for (d = t._zTime, t._zTime = n || (r ? Ce : 0), r || (r = n && !d), t.ratio = s, t._from && (s = 1 - s), t._time = 0, t._tTime = a, u = t._pt; u;) u.r(s, u.d), u = u._next;
            n < 0 && mp(t, n, r, !0), t._onUpdate && !r && yn(t, "onUpdate"), a && t._repeat && !r && t.parent && yn(t, "onRepeat"), (n >= t._tDur || n < 0) && t.ratio === s && (s && ei(t, 1), !r && !Tt && (yn(t, s ? "onComplete" : "onReverseComplete", !0), t._prom && t._prom()))
        } else t._zTime || (t._zTime = n)
    },
    qT = function(t, n, r) {
        var i;
        if (r > n)
            for (i = t._first; i && i._start <= r;) {
                if (i.data === "isPause" && i._start > n) return i;
                i = i._next
            } else
                for (i = t._last; i && i._start >= r;) {
                    if (i.data === "isPause" && i._start < n) return i;
                    i = i._prev
                }
    },
    zo = function(t, n, r, i) {
        var o = t._repeat,
            s = mt(n) || 0,
            l = t._tTime / t._tDur;
        return l && !i && (t._time *= s / t._dur), t._dur = s, t._tDur = o ? o < 0 ? 1e10 : mt(s * (o + 1) + t._rDelay * o) : s, l > 0 && !i && Xu(t, t._tTime = t._tDur * l), t.parent && Yu(t), r || ki(t.parent, t), t
    },
    u1 = function(t) {
        return t instanceof Ft ? ki(t) : zo(t, t._dur)
    },
    KT = {
        _start: 0,
        endTime: ll,
        totalDuration: ll
    },
    cn = function e(t, n, r) {
        var i = t.labels,
            o = t._recent || KT,
            s = t.duration() >= vn ? o.endTime(!1) : t._dur,
            l, a, u;
        return ct(n) && (isNaN(n) || n in i) ? (a = n.charAt(0), u = n.substr(-1) === "%", l = n.indexOf("="), a === "<" || a === ">" ? (l >= 0 && (n = n.replace(/=/, "")), (a === "<" ? o._start : o.endTime(o._repeat >= 0)) + (parseFloat(n.substr(1)) || 0) * (u ? (l < 0 ? o : r).totalDuration() / 100 : 1)) : l < 0 ? (n in i || (i[n] = s), i[n]) : (a = parseFloat(n.charAt(l - 1) + n.substr(l + 1)), u && r && (a = a / 100 * (Pt(r) ? r[0] : r).totalDuration()), l > 1 ? e(t, n.substr(0, l - 1), r) + a : s + a)) : n == null ? s : +n
    },
    js = function(t, n, r) {
        var i = Sr(n[1]),
            o = (i ? 2 : 1) + (t < 2 ? 0 : 1),
            s = n[o],
            l, a;
        if (i && (s.duration = n[1]), s.parent = r, t) {
            for (l = s, a = r; a && !("immediateRender" in l);) l = a.vars.defaults || {}, a = $t(a.vars.inherit) && a.parent;
            s.immediateRender = $t(l.immediateRender), t < 2 ? s.runBackwards = 1 : s.startAt = n[o - 1]
        }
        return new nt(n[0], s, n[o + 1])
    },
    oi = function(t, n) {
        return t || t === 0 ? n(t) : n
    },
    Sl = function(t, n, r) {
        return r < t ? t : r > n ? n : r
    },
    Ct = function(t, n) {
        return !ct(t) || !(n = BT.exec(t)) ? "" : n[1]
    },
    QT = function(t, n, r) {
        return oi(r, function(i) {
            return Sl(t, n, i)
        })
    },
    gp = [].slice,
    W_ = function(t, n) {
        return t && Qn(t) && "length" in t && (!n && !t.length || t.length - 1 in t && Qn(t[0])) && !t.nodeType && t !== fn
    },
    ZT = function(t, n, r) {
        return r === void 0 && (r = []), t.forEach(function(i) {
            var o;
            return ct(i) && !n || W_(i, 1) ? (o = r).push.apply(o, gn(i)) : r.push(i)
        }) || r
    },
    gn = function(t, n, r) {
        return Qe && !n && Qe.selector ? Qe.selector(t) : ct(t) && !r && (pp || !Io()) ? gp.call((n || Bh).querySelectorAll(t), 0) : Pt(t) ? ZT(t, r) : W_(t) ? gp.call(t, 0) : t ? [t] : []
    },
    yp = function(t) {
        return t = gn(t)[0] || mu("Invalid scope") || {},
            function(n) {
                var r = t.current || t.nativeElement || t;
                return gn(n, r.querySelectorAll ? r : r === t ? mu("Invalid scope") || Bh.createElement("div") : t)
            }
    },
    G_ = function(t) {
        return t.sort(function() {
            return .5 - Math.random()
        })
    },
    Y_ = function(t) {
        if (He(t)) return t;
        var n = Qn(t) ? t : {
                each: t
            },
            r = bi(n.ease),
            i = n.from || 0,
            o = parseFloat(n.base) || 0,
            s = {},
            l = i > 0 && i < 1,
            a = isNaN(i) || l,
            u = n.axis,
            f = i,
            d = i;
        return ct(i) ? f = d = {
                center: .5,
                edges: .5,
                end: 1
            }[i] || 0 : !l && a && (f = i[0], d = i[1]),
            function(h, y, _) {
                var v = (_ || n).length,
                    E = s[v],
                    m, g, S, x, P, T, L, b, N;
                if (!E) {
                    if (N = n.grid === "auto" ? 0 : (n.grid || [1, vn])[1], !N) {
                        for (L = -vn; L < (L = _[N++].getBoundingClientRect().left) && N < v;);
                        N--
                    }
                    for (E = s[v] = [], m = a ? Math.min(N, v) * f - .5 : i % N, g = N === vn ? 0 : a ? v * d / N - .5 : i / N | 0, L = 0, b = vn, T = 0; T < v; T++) S = T % N - m, x = g - (T / N | 0), E[T] = P = u ? Math.abs(u === "y" ? x : S) : b_(S * S + x * x), P > L && (L = P), P < b && (b = P);
                    i === "random" && G_(E), E.max = L - b, E.min = b, E.v = v = (parseFloat(n.amount) || parseFloat(n.each) * (N > v ? v - 1 : u ? u === "y" ? v / N : N : Math.max(N, v / N)) || 0) * (i === "edges" ? -1 : 1), E.b = v < 0 ? o - v : o, E.u = Ct(n.amount || n.each) || 0, r = r && v < 0 ? rS(r) : r
                }
                return v = (E[h] - E.min) / E.max || 0, mt(E.b + (r ? r(v) : v) * E.v) + E.u
            }
    },
    _p = function(t) {
        var n = Math.pow(10, ((t + "").split(".")[1] || "").length);
        return function(r) {
            var i = mt(Math.round(parseFloat(r) / t) * t * n);
            return (i - i % 1) / n + (Sr(r) ? 0 : Ct(r))
        }
    },
    X_ = function(t, n) {
        var r = Pt(t),
            i, o;
        return !r && Qn(t) && (i = r = t.radius || vn, t.values ? (t = gn(t.values), (o = !Sr(t[0])) && (i *= i)) : t = _p(t.increment)), oi(n, r ? He(t) ? function(s) {
            return o = t(s), Math.abs(o - s) <= i ? o : s
        } : function(s) {
            for (var l = parseFloat(o ? s.x : s), a = parseFloat(o ? s.y : 0), u = vn, f = 0, d = t.length, h, y; d--;) o ? (h = t[d].x - l, y = t[d].y - a, h = h * h + y * y) : h = Math.abs(t[d] - l), h < u && (u = h, f = d);
            return f = !i || u <= i ? t[f] : s, o || f === s || Sr(s) ? f : f + Ct(s)
        } : _p(t))
    },
    q_ = function(t, n, r, i) {
        return oi(Pt(t) ? !n : r === !0 ? !!(r = 0) : !i, function() {
            return Pt(t) ? t[~~(Math.random() * t.length)] : (r = r || 1e-5) && (i = r < 1 ? Math.pow(10, (r + "").length - 2) : 1) && Math.floor(Math.round((t - r / 2 + Math.random() * (n - t + r * .99)) / r) * r * i) / i
        })
    },
    JT = function() {
        for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
        return function(i) {
            return n.reduce(function(o, s) {
                return s(o)
            }, i)
        }
    },
    e4 = function(t, n) {
        return function(r) {
            return t(parseFloat(r)) + (n || Ct(r))
        }
    },
    t4 = function(t, n, r) {
        return Q_(t, n, 0, 1, r)
    },
    K_ = function(t, n, r) {
        return oi(r, function(i) {
            return t[~~n(i)]
        })
    },
    n4 = function e(t, n, r) {
        var i = n - t;
        return Pt(t) ? K_(t, e(0, t.length), n) : oi(r, function(o) {
            return (i + (o - t) % i) % i + t
        })
    },
    r4 = function e(t, n, r) {
        var i = n - t,
            o = i * 2;
        return Pt(t) ? K_(t, e(0, t.length - 1), n) : oi(r, function(s) {
            return s = (o + (s - t) % o) % o || 0, t + (s > i ? o - s : s)
        })
    },
    al = function(t) {
        for (var n = 0, r = "", i, o, s, l; ~(i = t.indexOf("random(", n));) s = t.indexOf(")", i), l = t.charAt(i + 7) === "[", o = t.substr(i + 7, s - i - 7).match(l ? N_ : dp), r += t.substr(n, i - n) + q_(l ? o : +o[0], l ? 0 : +o[1], +o[2] || 1e-5), n = s + 1;
        return r + t.substr(n, t.length - n)
    },
    Q_ = function(t, n, r, i, o) {
        var s = n - t,
            l = i - r;
        return oi(o, function(a) {
            return r + ((a - t) / s * l || 0)
        })
    },
    i4 = function e(t, n, r, i) {
        var o = isNaN(t + n) ? 0 : function(y) {
            return (1 - y) * t + y * n
        };
        if (!o) {
            var s = ct(t),
                l = {},
                a, u, f, d, h;
            if (r === !0 && (i = 1) && (r = null), s) t = {
                p: t
            }, n = {
                p: n
            };
            else if (Pt(t) && !Pt(n)) {
                for (f = [], d = t.length, h = d - 2, u = 1; u < d; u++) f.push(e(t[u - 1], t[u]));
                d--, o = function(_) {
                    _ *= d;
                    var v = Math.min(h, ~~_);
                    return f[v](_ - v)
                }, r = n
            } else i || (t = Di(Pt(t) ? [] : {}, t));
            if (!f) {
                for (a in n) Hh.call(l, t, a, "get", n[a]);
                o = function(_) {
                    return Xh(_, l) || (s ? t.p : t)
                }
            }
        }
        return oi(r, o)
    },
    c1 = function(t, n, r) {
        var i = t.labels,
            o = vn,
            s, l, a;
        for (s in i) l = i[s] - n, l < 0 == !!r && l && o > (l = Math.abs(l)) && (a = s, o = l);
        return a
    },
    yn = function(t, n, r) {
        var i = t.vars,
            o = i[n],
            s = Qe,
            l = t._ctx,
            a, u, f;
        if (o) return a = i[n + "Params"], u = i.callbackScope || t, r && Kr.length && vu(), l && (Qe = l), f = a ? o.apply(u, a) : o.call(u), Qe = s, f
    },
    ks = function(t) {
        return ei(t), t.scrollTrigger && t.scrollTrigger.kill(!!Tt), t.progress() < 1 && yn(t, "onInterrupt"), t
    },
    ho, Z_ = [],
    J_ = function(t) {
        if (!Fh()) {
            Z_.push(t);
            return
        }
        t = !t.name && t.default || t;
        var n = t.name,
            r = He(t),
            i = n && !r && t.init ? function() {
                this._props = []
            } : t,
            o = {
                init: ll,
                render: Xh,
                add: Hh,
                kill: S4,
                modifier: _4,
                rawVars: 0
            },
            s = {
                targetTest: 0,
                get: 0,
                getSetter: Yh,
                aliases: {},
                register: 0
            };
        if (Io(), t !== i) {
            if (Zt[n]) return;
            En(i, En(gu(t, o), s)), Di(i.prototype, Di(o, gu(t, s))), Zt[i.prop = n] = i, t.targetTest && (ja.push(i), Vh[n] = 1), n = (n === "css" ? "CSS" : n.charAt(0).toUpperCase() + n.substr(1)) + "Plugin"
        }
        D_(n, i), t.register && t.register(Gt, i, Wt)
    },
    Ee = 255,
    bs = {
        aqua: [0, Ee, Ee],
        lime: [0, Ee, 0],
        silver: [192, 192, 192],
        black: [0, 0, 0],
        maroon: [128, 0, 0],
        teal: [0, 128, 128],
        blue: [0, 0, Ee],
        navy: [0, 0, 128],
        white: [Ee, Ee, Ee],
        olive: [128, 128, 0],
        yellow: [Ee, Ee, 0],
        orange: [Ee, 165, 0],
        gray: [128, 128, 128],
        purple: [128, 0, 128],
        green: [0, 128, 0],
        red: [Ee, 0, 0],
        pink: [Ee, 192, 203],
        cyan: [0, Ee, Ee],
        transparent: [Ee, Ee, Ee, 0]
    },
    rd = function(t, n, r) {
        return t += t < 0 ? 1 : t > 1 ? -1 : 0, (t * 6 < 1 ? n + (r - n) * t * 6 : t < .5 ? r : t * 3 < 2 ? n + (r - n) * (2 / 3 - t) * 6 : n) * Ee + .5 | 0
    },
    eS = function(t, n, r) {
        var i = t ? Sr(t) ? [t >> 16, t >> 8 & Ee, t & Ee] : 0 : bs.black,
            o, s, l, a, u, f, d, h, y, _;
        if (!i) {
            if (t.substr(-1) === "," && (t = t.substr(0, t.length - 1)), bs[t]) i = bs[t];
            else if (t.charAt(0) === "#") {
                if (t.length < 6 && (o = t.charAt(1), s = t.charAt(2), l = t.charAt(3), t = "#" + o + o + s + s + l + l + (t.length === 5 ? t.charAt(4) + t.charAt(4) : "")), t.length === 9) return i = parseInt(t.substr(1, 6), 16), [i >> 16, i >> 8 & Ee, i & Ee, parseInt(t.substr(7), 16) / 255];
                t = parseInt(t.substr(1), 16), i = [t >> 16, t >> 8 & Ee, t & Ee]
            } else if (t.substr(0, 3) === "hsl") {
                if (i = _ = t.match(dp), !n) a = +i[0] % 360 / 360, u = +i[1] / 100, f = +i[2] / 100, s = f <= .5 ? f * (u + 1) : f + u - f * u, o = f * 2 - s, i.length > 3 && (i[3] *= 1), i[0] = rd(a + 1 / 3, o, s), i[1] = rd(a, o, s), i[2] = rd(a - 1 / 3, o, s);
                else if (~t.indexOf("=")) return i = t.match(O_), r && i.length < 4 && (i[3] = 1), i
            } else i = t.match(dp) || bs.transparent;
            i = i.map(Number)
        }
        return n && !_ && (o = i[0] / Ee, s = i[1] / Ee, l = i[2] / Ee, d = Math.max(o, s, l), h = Math.min(o, s, l), f = (d + h) / 2, d === h ? a = u = 0 : (y = d - h, u = f > .5 ? y / (2 - d - h) : y / (d + h), a = d === o ? (s - l) / y + (s < l ? 6 : 0) : d === s ? (l - o) / y + 2 : (o - s) / y + 4, a *= 60), i[0] = ~~(a + .5), i[1] = ~~(u * 100 + .5), i[2] = ~~(f * 100 + .5)), r && i.length < 4 && (i[3] = 1), i
    },
    tS = function(t) {
        var n = [],
            r = [],
            i = -1;
        return t.split(Qr).forEach(function(o) {
            var s = o.match(po) || [];
            n.push.apply(n, s), r.push(i += s.length + 1)
        }), n.c = r, n
    },
    f1 = function(t, n, r) {
        var i = "",
            o = (t + i).match(Qr),
            s = n ? "hsla(" : "rgba(",
            l = 0,
            a, u, f, d;
        if (!o) return t;
        if (o = o.map(function(h) {
                return (h = eS(h, n, 1)) && s + (n ? h[0] + "," + h[1] + "%," + h[2] + "%," + h[3] : h.join(",")) + ")"
            }), r && (f = tS(t), a = r.c, a.join(i) !== f.c.join(i)))
            for (u = t.replace(Qr, "1").split(po), d = u.length - 1; l < d; l++) i += u[l] + (~a.indexOf(l) ? o.shift() || s + "0,0,0,0)" : (f.length ? f : o.length ? o : r).shift());
        if (!u)
            for (u = t.split(Qr), d = u.length - 1; l < d; l++) i += u[l] + o[l];
        return i + u[d]
    },
    Qr = function() {
        var e = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b",
            t;
        for (t in bs) e += "|" + t + "\\b";
        return new RegExp(e + ")", "gi")
    }(),
    o4 = /hsl[a]?\(/,
    nS = function(t) {
        var n = t.join(" "),
            r;
        if (Qr.lastIndex = 0, Qr.test(n)) return r = o4.test(n), t[1] = f1(t[1], r), t[0] = f1(t[0], r, tS(t[1])), !0
    },
    ul, Jt = function() {
        var e = Date.now,
            t = 500,
            n = 33,
            r = e(),
            i = r,
            o = 1e3 / 240,
            s = o,
            l = [],
            a, u, f, d, h, y, _ = function v(E) {
                var m = e() - i,
                    g = E === !0,
                    S, x, P, T;
                if (m > t && (r += m - n), i += m, P = i - r, S = P - s, (S > 0 || g) && (T = ++d.frame, h = P - d.time * 1e3, d.time = P = P / 1e3, s += S + (S >= o ? 4 : o - S), x = 1), g || (a = u(v)), x)
                    for (y = 0; y < l.length; y++) l[y](P, h, T, E)
            };
        return d = {
            time: 0,
            frame: 0,
            tick: function() {
                _(!0)
            },
            deltaRatio: function(E) {
                return h / (1e3 / (E || 60))
            },
            wake: function() {
                A_ && (!pp && Fh() && (fn = pp = window, Bh = fn.document || {}, on.gsap = Gt, (fn.gsapVersions || (fn.gsapVersions = [])).push(Gt.version), R_(hu || fn.GreenSockGlobals || !fn.gsap && fn || {}), f = fn.requestAnimationFrame, Z_.forEach(J_)), a && d.sleep(), u = f || function(E) {
                    return setTimeout(E, s - d.time * 1e3 + 1 | 0)
                }, ul = 1, _(2))
            },
            sleep: function() {
                (f ? fn.cancelAnimationFrame : clearTimeout)(a), ul = 0, u = ll
            },
            lagSmoothing: function(E, m) {
                t = E || 1 / 0, n = Math.min(m || 33, t)
            },
            fps: function(E) {
                o = 1e3 / (E || 240), s = d.time * 1e3 + o
            },
            add: function(E, m, g) {
                var S = m ? function(x, P, T, L) {
                    E(x, P, T, L), d.remove(S)
                } : E;
                return d.remove(E), l[g ? "unshift" : "push"](S), Io(), S
            },
            remove: function(E, m) {
                ~(m = l.indexOf(E)) && l.splice(m, 1) && y >= m && y--
            },
            _listeners: l
        }, d
    }(),
    Io = function() {
        return !ul && Jt.wake()
    },
    ve = {},
    s4 = /^[\d.\-M][\d.\-,\s]/,
    l4 = /["']/g,
    a4 = function(t) {
        for (var n = {}, r = t.substr(1, t.length - 3).split(":"), i = r[0], o = 1, s = r.length, l, a, u; o < s; o++) a = r[o], l = o !== s - 1 ? a.lastIndexOf(",") : a.length, u = a.substr(0, l), n[i] = isNaN(u) ? u.replace(l4, "").trim() : +u, i = a.substr(l + 1).trim();
        return n
    },
    u4 = function(t) {
        var n = t.indexOf("(") + 1,
            r = t.indexOf(")"),
            i = t.indexOf("(", n);
        return t.substring(n, ~i && i < r ? t.indexOf(")", r + 1) : r)
    },
    c4 = function(t) {
        var n = (t + "").split("("),
            r = ve[n[0]];
        return r && n.length > 1 && r.config ? r.config.apply(null, ~t.indexOf("{") ? [a4(n[1])] : u4(t).split(",").map(B_)) : ve._CE && s4.test(t) ? ve._CE("", t) : r
    },
    rS = function(t) {
        return function(n) {
            return 1 - t(1 - n)
        }
    },
    iS = function e(t, n) {
        for (var r = t._first, i; r;) r instanceof Ft ? e(r, n) : r.vars.yoyoEase && (!r._yoyo || !r._repeat) && r._yoyo !== n && (r.timeline ? e(r.timeline, n) : (i = r._ease, r._ease = r._yEase, r._yEase = i, r._yoyo = n)), r = r._next
    },
    bi = function(t, n) {
        return t && (He(t) ? t : ve[t] || c4(t)) || n
    },
    Fi = function(t, n, r, i) {
        r === void 0 && (r = function(a) {
            return 1 - n(1 - a)
        }), i === void 0 && (i = function(a) {
            return a < .5 ? n(a * 2) / 2 : 1 - n((1 - a) * 2) / 2
        });
        var o = {
                easeIn: n,
                easeOut: r,
                easeInOut: i
            },
            s;
        return Ht(t, function(l) {
            ve[l] = on[l] = o, ve[s = l.toLowerCase()] = r;
            for (var a in o) ve[s + (a === "easeIn" ? ".in" : a === "easeOut" ? ".out" : ".inOut")] = ve[l + "." + a] = o[a]
        }), o
    },
    oS = function(t) {
        return function(n) {
            return n < .5 ? (1 - t(1 - n * 2)) / 2 : .5 + t((n - .5) * 2) / 2
        }
    },
    id = function e(t, n, r) {
        var i = n >= 1 ? n : 1,
            o = (r || (t ? .3 : .45)) / (n < 1 ? n : 1),
            s = o / fp * (Math.asin(1 / i) || 0),
            l = function(f) {
                return f === 1 ? 1 : i * Math.pow(2, -10 * f) * FT((f - s) * o) + 1
            },
            a = t === "out" ? l : t === "in" ? function(u) {
                return 1 - l(1 - u)
            } : oS(l);
        return o = fp / o, a.config = function(u, f) {
            return e(t, u, f)
        }, a
    },
    od = function e(t, n) {
        n === void 0 && (n = 1.70158);
        var r = function(s) {
                return s ? --s * s * ((n + 1) * s + n) + 1 : 0
            },
            i = t === "out" ? r : t === "in" ? function(o) {
                return 1 - r(1 - o)
            } : oS(r);
        return i.config = function(o) {
            return e(t, o)
        }, i
    };
Ht("Linear,Quad,Cubic,Quart,Quint,Strong", function(e, t) {
    var n = t < 5 ? t + 1 : t;
    Fi(e + ",Power" + (n - 1), t ? function(r) {
        return Math.pow(r, n)
    } : function(r) {
        return r
    }, function(r) {
        return 1 - Math.pow(1 - r, n)
    }, function(r) {
        return r < .5 ? Math.pow(r * 2, n) / 2 : 1 - Math.pow((1 - r) * 2, n) / 2
    })
});
ve.Linear.easeNone = ve.none = ve.Linear.easeIn;
Fi("Elastic", id("in"), id("out"), id());
(function(e, t) {
    var n = 1 / t,
        r = 2 * n,
        i = 2.5 * n,
        o = function(l) {
            return l < n ? e * l * l : l < r ? e * Math.pow(l - 1.5 / t, 2) + .75 : l < i ? e * (l -= 2.25 / t) * l + .9375 : e * Math.pow(l - 2.625 / t, 2) + .984375
        };
    Fi("Bounce", function(s) {
        return 1 - o(1 - s)
    }, o)
})(7.5625, 2.75);
Fi("Expo", function(e) {
    return e ? Math.pow(2, 10 * (e - 1)) : 0
});
Fi("Circ", function(e) {
    return -(b_(1 - e * e) - 1)
});
Fi("Sine", function(e) {
    return e === 1 ? 1 : -IT(e * DT) + 1
});
Fi("Back", od("in"), od("out"), od());
ve.SteppedEase = ve.steps = on.SteppedEase = {
    config: function(t, n) {
        t === void 0 && (t = 1);
        var r = 1 / t,
            i = t + (n ? 0 : 1),
            o = n ? 1 : 0,
            s = 1 - Ce;
        return function(l) {
            return ((i * Sl(0, s, l) | 0) + o) * r
        }
    }
};
Ro.ease = ve["quad.out"];
Ht("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function(e) {
    return Uh += e + "," + e + "Params,"
});
var sS = function(t, n) {
        this.id = zT++, t._gsap = this, this.target = t, this.harness = n, this.get = n ? n.get : I_, this.set = n ? n.getSetter : Yh
    },
    Fo = function() {
        function e(n) {
            this.vars = n, this._delay = +n.delay || 0, (this._repeat = n.repeat === 1 / 0 ? -2 : n.repeat || 0) && (this._rDelay = n.repeatDelay || 0, this._yoyo = !!n.yoyo || !!n.yoyoEase), this._ts = 1, zo(this, +n.duration, 1, 1), this.data = n.data, Qe && (this._ctx = Qe, Qe.data.push(this)), ul || Jt.wake()
        }
        var t = e.prototype;
        return t.delay = function(r) {
            return r || r === 0 ? (this.parent && this.parent.smoothChildTiming && this.startTime(this._start + r - this._delay), this._delay = r, this) : this._delay
        }, t.duration = function(r) {
            return arguments.length ? this.totalDuration(this._repeat > 0 ? r + (r + this._rDelay) * this._repeat : r) : this.totalDuration() && this._dur
        }, t.totalDuration = function(r) {
            return arguments.length ? (this._dirty = 0, zo(this, this._repeat < 0 ? r : (r - this._repeat * this._rDelay) / (this._repeat + 1))) : this._tDur
        }, t.totalTime = function(r, i) {
            if (Io(), !arguments.length) return this._tTime;
            var o = this._dp;
            if (o && o.smoothChildTiming && this._ts) {
                for (Xu(this, r), !o._dp || o.parent || U_(o, this); o && o.parent;) o.parent._time !== o._start + (o._ts >= 0 ? o._tTime / o._ts : (o.totalDuration() - o._tTime) / -o._ts) && o.totalTime(o._tTime, !0), o = o.parent;
                !this.parent && this._dp.autoRemoveChildren && (this._ts > 0 && r < this._tDur || this._ts < 0 && r > 0 || !this._tDur && !r) && $n(this._dp, this, this._start - this._delay)
            }
            return (this._tTime !== r || !this._dur && !i || this._initted && Math.abs(this._zTime) === Ce || !r && !this._initted && (this.add || this._ptLookup)) && (this._ts || (this._pTime = r), F_(this, r, i)), this
        }, t.time = function(r, i) {
            return arguments.length ? this.totalTime(Math.min(this.totalDuration(), r + a1(this)) % (this._dur + this._rDelay) || (r ? this._dur : 0), i) : this._time
        }, t.totalProgress = function(r, i) {
            return arguments.length ? this.totalTime(this.totalDuration() * r, i) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.ratio
        }, t.progress = function(r, i) {
            return arguments.length ? this.totalTime(this.duration() * (this._yoyo && !(this.iteration() & 1) ? 1 - r : r) + a1(this), i) : this.duration() ? Math.min(1, this._time / this._dur) : this.ratio
        }, t.iteration = function(r, i) {
            var o = this.duration() + this._rDelay;
            return arguments.length ? this.totalTime(this._time + (r - 1) * o, i) : this._repeat ? Do(this._tTime, o) + 1 : 1
        }, t.timeScale = function(r) {
            if (!arguments.length) return this._rts === -Ce ? 0 : this._rts;
            if (this._rts === r) return this;
            var i = this.parent && this._ts ? yu(this.parent._time, this) : this._tTime;
            return this._rts = +r || 0, this._ts = this._ps || r === -Ce ? 0 : this._rts, this.totalTime(Sl(-Math.abs(this._delay), this._tDur, i), !0), Yu(this), WT(this)
        }, t.paused = function(r) {
            return arguments.length ? (this._ps !== r && (this._ps = r, r ? (this._pTime = this._tTime || Math.max(-this._delay, this.rawTime()), this._ts = this._act = 0) : (Io(), this._ts = this._rts, this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, this.progress() === 1 && Math.abs(this._zTime) !== Ce && (this._tTime -= Ce)))), this) : this._ps
        }, t.startTime = function(r) {
            if (arguments.length) {
                this._start = r;
                var i = this.parent || this._dp;
                return i && (i._sort || !this.parent) && $n(i, this, r - this._delay), this
            }
            return this._start
        }, t.endTime = function(r) {
            return this._start + ($t(r) ? this.totalDuration() : this.duration()) / Math.abs(this._ts || 1)
        }, t.rawTime = function(r) {
            var i = this.parent || this._dp;
            return i ? r && (!this._ts || this._repeat && this._time && this.totalProgress() < 1) ? this._tTime % (this._dur + this._rDelay) : this._ts ? yu(i.rawTime(r), this) : this._tTime : this._tTime
        }, t.revert = function(r) {
            r === void 0 && (r = VT);
            var i = Tt;
            return Tt = r, (this._initted || this._startAt) && (this.timeline && this.timeline.revert(r), this.totalTime(-.01, r.suppressEvents)), this.data !== "nested" && r.kill !== !1 && this.kill(), Tt = i, this
        }, t.globalTime = function(r) {
            for (var i = this, o = arguments.length ? r : i.rawTime(); i;) o = i._start + o / (i._ts || 1), i = i._dp;
            return !this.parent && this._sat ? this._sat.vars.immediateRender ? -1 : this._sat.globalTime(r) : o
        }, t.repeat = function(r) {
            return arguments.length ? (this._repeat = r === 1 / 0 ? -2 : r, u1(this)) : this._repeat === -2 ? 1 / 0 : this._repeat
        }, t.repeatDelay = function(r) {
            if (arguments.length) {
                var i = this._time;
                return this._rDelay = r, u1(this), i ? this.time(i) : this
            }
            return this._rDelay
        }, t.yoyo = function(r) {
            return arguments.length ? (this._yoyo = r, this) : this._yoyo
        }, t.seek = function(r, i) {
            return this.totalTime(cn(this, r), $t(i))
        }, t.restart = function(r, i) {
            return this.play().totalTime(r ? -this._delay : 0, $t(i))
        }, t.play = function(r, i) {
            return r != null && this.seek(r, i), this.reversed(!1).paused(!1)
        }, t.reverse = function(r, i) {
            return r != null && this.seek(r || this.totalDuration(), i), this.reversed(!0).paused(!1)
        }, t.pause = function(r, i) {
            return r != null && this.seek(r, i), this.paused(!0)
        }, t.resume = function() {
            return this.paused(!1)
        }, t.reversed = function(r) {
            return arguments.length ? (!!r !== this.reversed() && this.timeScale(-this._rts || (r ? -Ce : 0)), this) : this._rts < 0
        }, t.invalidate = function() {
            return this._initted = this._act = 0, this._zTime = -Ce, this
        }, t.isActive = function() {
            var r = this.parent || this._dp,
                i = this._start,
                o;
            return !!(!r || this._ts && this._initted && r.isActive() && (o = r.rawTime(!0)) >= i && o < this.endTime(!0) - Ce)
        }, t.eventCallback = function(r, i, o) {
            var s = this.vars;
            return arguments.length > 1 ? (i ? (s[r] = i, o && (s[r + "Params"] = o), r === "onUpdate" && (this._onUpdate = i)) : delete s[r], this) : s[r]
        }, t.then = function(r) {
            var i = this;
            return new Promise(function(o) {
                var s = He(r) ? r : j_,
                    l = function() {
                        var u = i.then;
                        i.then = null, He(s) && (s = s(i)) && (s.then || s === i) && (i.then = u), o(s), i.then = u
                    };
                i._initted && i.totalProgress() === 1 && i._ts >= 0 || !i._tTime && i._ts < 0 ? l() : i._prom = l
            })
        }, t.kill = function() {
            ks(this)
        }, e
    }();
En(Fo.prototype, {
    _time: 0,
    _start: 0,
    _end: 0,
    _tTime: 0,
    _tDur: 0,
    _dirty: 0,
    _repeat: 0,
    _yoyo: !1,
    parent: null,
    _initted: !1,
    _rDelay: 0,
    _ts: 1,
    _dp: 0,
    ratio: 0,
    _zTime: -Ce,
    _prom: 0,
    _ps: !1,
    _rts: 1
});
var Ft = function(e) {
    k_(t, e);

    function t(r, i) {
        var o;
        return r === void 0 && (r = {}), o = e.call(this, r) || this, o.labels = {}, o.smoothChildTiming = !!r.smoothChildTiming, o.autoRemoveChildren = !!r.autoRemoveChildren, o._sort = $t(r.sortChildren), Ie && $n(r.parent || Ie, ur(o), i), r.reversed && o.reverse(), r.paused && o.paused(!0), r.scrollTrigger && $_(ur(o), r.scrollTrigger), o
    }
    var n = t.prototype;
    return n.to = function(i, o, s) {
        return js(0, arguments, this), this
    }, n.from = function(i, o, s) {
        return js(1, arguments, this), this
    }, n.fromTo = function(i, o, s, l) {
        return js(2, arguments, this), this
    }, n.set = function(i, o, s) {
        return o.duration = 0, o.parent = this, Bs(o).repeatDelay || (o.repeat = 0), o.immediateRender = !!o.immediateRender, new nt(i, o, cn(this, s), 1), this
    }, n.call = function(i, o, s) {
        return $n(this, nt.delayedCall(0, i, o), s)
    }, n.staggerTo = function(i, o, s, l, a, u, f) {
        return s.duration = o, s.stagger = s.stagger || l, s.onComplete = u, s.onCompleteParams = f, s.parent = this, new nt(i, s, cn(this, a)), this
    }, n.staggerFrom = function(i, o, s, l, a, u, f) {
        return s.runBackwards = 1, Bs(s).immediateRender = $t(s.immediateRender), this.staggerTo(i, o, s, l, a, u, f)
    }, n.staggerFromTo = function(i, o, s, l, a, u, f, d) {
        return l.startAt = s, Bs(l).immediateRender = $t(l.immediateRender), this.staggerTo(i, o, l, a, u, f, d)
    }, n.render = function(i, o, s) {
        var l = this._time,
            a = this._dirty ? this.totalDuration() : this._tDur,
            u = this._dur,
            f = i <= 0 ? 0 : mt(i),
            d = this._zTime < 0 != i < 0 && (this._initted || !u),
            h, y, _, v, E, m, g, S, x, P, T, L;
        if (this !== Ie && f > a && i >= 0 && (f = a), f !== this._tTime || s || d) {
            if (l !== this._time && u && (f += this._time - l, i += this._time - l), h = f, x = this._start, S = this._ts, m = !S, d && (u || (l = this._zTime), (i || !o) && (this._zTime = i)), this._repeat) {
                if (T = this._yoyo, E = u + this._rDelay, this._repeat < -1 && i < 0) return this.totalTime(E * 100 + i, o, s);
                if (h = mt(f % E), f === a ? (v = this._repeat, h = u) : (v = ~~(f / E), v && v === f / E && (h = u, v--), h > u && (h = u)), P = Do(this._tTime, E), !l && this._tTime && P !== v && this._tTime - P * E - this._dur <= 0 && (P = v), T && v & 1 && (h = u - h, L = 1), v !== P && !this._lock) {
                    var b = T && P & 1,
                        N = b === (T && v & 1);
                    if (v < P && (b = !b), l = b ? 0 : u, this._lock = 1, this.render(l || (L ? 0 : mt(v * E)), o, !u)._lock = 0, this._tTime = f, !o && this.parent && yn(this, "onRepeat"), this.vars.repeatRefresh && !L && (this.invalidate()._lock = 1), l && l !== this._time || m !== !this._ts || this.vars.onRepeat && !this.parent && !this._act) return this;
                    if (u = this._dur, a = this._tDur, N && (this._lock = 2, l = b ? u : -1e-4, this.render(l, !0), this.vars.repeatRefresh && !L && this.invalidate()), this._lock = 0, !this._ts && !m) return this;
                    iS(this, L)
                }
            }
            if (this._hasPause && !this._forcing && this._lock < 2 && (g = qT(this, mt(l), mt(h)), g && (f -= h - (h = g._start))), this._tTime = f, this._time = h, this._act = !S, this._initted || (this._onUpdate = this.vars.onUpdate, this._initted = 1, this._zTime = i, l = 0), !l && h && !o && !v && (yn(this, "onStart"), this._tTime !== f)) return this;
            if (h >= l && i >= 0)
                for (y = this._first; y;) {
                    if (_ = y._next, (y._act || h >= y._start) && y._ts && g !== y) {
                        if (y.parent !== this) return this.render(i, o, s);
                        if (y.render(y._ts > 0 ? (h - y._start) * y._ts : (y._dirty ? y.totalDuration() : y._tDur) + (h - y._start) * y._ts, o, s), h !== this._time || !this._ts && !m) {
                            g = 0, _ && (f += this._zTime = -Ce);
                            break
                        }
                    }
                    y = _
                } else {
                    y = this._last;
                    for (var H = i < 0 ? i : h; y;) {
                        if (_ = y._prev, (y._act || H <= y._end) && y._ts && g !== y) {
                            if (y.parent !== this) return this.render(i, o, s);
                            if (y.render(y._ts > 0 ? (H - y._start) * y._ts : (y._dirty ? y.totalDuration() : y._tDur) + (H - y._start) * y._ts, o, s || Tt && (y._initted || y._startAt)), h !== this._time || !this._ts && !m) {
                                g = 0, _ && (f += this._zTime = H ? -Ce : Ce);
                                break
                            }
                        }
                        y = _
                    }
                }
            if (g && !o && (this.pause(), g.render(h >= l ? 0 : -Ce)._zTime = h >= l ? 1 : -1, this._ts)) return this._start = x, Yu(this), this.render(i, o, s);
            this._onUpdate && !o && yn(this, "onUpdate", !0), (f === a && this._tTime >= this.totalDuration() || !f && l) && (x === this._start || Math.abs(S) !== Math.abs(this._ts)) && (this._lock || ((i || !u) && (f === a && this._ts > 0 || !f && this._ts < 0) && ei(this, 1), !o && !(i < 0 && !l) && (f || l || !a) && (yn(this, f === a && i >= 0 ? "onComplete" : "onReverseComplete", !0), this._prom && !(f < a && this.timeScale() > 0) && this._prom())))
        }
        return this
    }, n.add = function(i, o) {
        var s = this;
        if (Sr(o) || (o = cn(this, o, i)), !(i instanceof Fo)) {
            if (Pt(i)) return i.forEach(function(l) {
                return s.add(l, o)
            }), this;
            if (ct(i)) return this.addLabel(i, o);
            if (He(i)) i = nt.delayedCall(0, i);
            else return this
        }
        return this !== i ? $n(this, i, o) : this
    }, n.getChildren = function(i, o, s, l) {
        i === void 0 && (i = !0), o === void 0 && (o = !0), s === void 0 && (s = !0), l === void 0 && (l = -vn);
        for (var a = [], u = this._first; u;) u._start >= l && (u instanceof nt ? o && a.push(u) : (s && a.push(u), i && a.push.apply(a, u.getChildren(!0, o, s)))), u = u._next;
        return a
    }, n.getById = function(i) {
        for (var o = this.getChildren(1, 1, 1), s = o.length; s--;)
            if (o[s].vars.id === i) return o[s]
    }, n.remove = function(i) {
        return ct(i) ? this.removeLabel(i) : He(i) ? this.killTweensOf(i) : (Gu(this, i), i === this._recent && (this._recent = this._last), ki(this))
    }, n.totalTime = function(i, o) {
        return arguments.length ? (this._forcing = 1, !this._dp && this._ts && (this._start = mt(Jt.time - (this._ts > 0 ? i / this._ts : (this.totalDuration() - i) / -this._ts))), e.prototype.totalTime.call(this, i, o), this._forcing = 0, this) : this._tTime
    }, n.addLabel = function(i, o) {
        return this.labels[i] = cn(this, o), this
    }, n.removeLabel = function(i) {
        return delete this.labels[i], this
    }, n.addPause = function(i, o, s) {
        var l = nt.delayedCall(0, o || ll, s);
        return l.data = "isPause", this._hasPause = 1, $n(this, l, cn(this, i))
    }, n.removePause = function(i) {
        var o = this._first;
        for (i = cn(this, i); o;) o._start === i && o.data === "isPause" && ei(o), o = o._next
    }, n.killTweensOf = function(i, o, s) {
        for (var l = this.getTweensOf(i, s), a = l.length; a--;) Fr !== l[a] && l[a].kill(i, o);
        return this
    }, n.getTweensOf = function(i, o) {
        for (var s = [], l = gn(i), a = this._first, u = Sr(o), f; a;) a instanceof nt ? UT(a._targets, l) && (u ? (!Fr || a._initted && a._ts) && a.globalTime(0) <= o && a.globalTime(a.totalDuration()) > o : !o || a.isActive()) && s.push(a) : (f = a.getTweensOf(l, o)).length && s.push.apply(s, f), a = a._next;
        return s
    }, n.tweenTo = function(i, o) {
        o = o || {};
        var s = this,
            l = cn(s, i),
            a = o,
            u = a.startAt,
            f = a.onStart,
            d = a.onStartParams,
            h = a.immediateRender,
            y, _ = nt.to(s, En({
                ease: o.ease || "none",
                lazy: !1,
                immediateRender: !1,
                time: l,
                overwrite: "auto",
                duration: o.duration || Math.abs((l - (u && "time" in u ? u.time : s._time)) / s.timeScale()) || Ce,
                onStart: function() {
                    if (s.pause(), !y) {
                        var E = o.duration || Math.abs((l - (u && "time" in u ? u.time : s._time)) / s.timeScale());
                        _._dur !== E && zo(_, E, 0, 1).render(_._time, !0, !0), y = 1
                    }
                    f && f.apply(_, d || [])
                }
            }, o));
        return h ? _.render(0) : _
    }, n.tweenFromTo = function(i, o, s) {
        return this.tweenTo(o, En({
            startAt: {
                time: cn(this, i)
            }
        }, s))
    }, n.recent = function() {
        return this._recent
    }, n.nextLabel = function(i) {
        return i === void 0 && (i = this._time), c1(this, cn(this, i))
    }, n.previousLabel = function(i) {
        return i === void 0 && (i = this._time), c1(this, cn(this, i), 1)
    }, n.currentLabel = function(i) {
        return arguments.length ? this.seek(i, !0) : this.previousLabel(this._time + Ce)
    }, n.shiftChildren = function(i, o, s) {
        s === void 0 && (s = 0);
        for (var l = this._first, a = this.labels, u; l;) l._start >= s && (l._start += i, l._end += i), l = l._next;
        if (o)
            for (u in a) a[u] >= s && (a[u] += i);
        return ki(this)
    }, n.invalidate = function(i) {
        var o = this._first;
        for (this._lock = 0; o;) o.invalidate(i), o = o._next;
        return e.prototype.invalidate.call(this, i)
    }, n.clear = function(i) {
        i === void 0 && (i = !0);
        for (var o = this._first, s; o;) s = o._next, this.remove(o), o = s;
        return this._dp && (this._time = this._tTime = this._pTime = 0), i && (this.labels = {}), ki(this)
    }, n.totalDuration = function(i) {
        var o = 0,
            s = this,
            l = s._last,
            a = vn,
            u, f, d;
        if (arguments.length) return s.timeScale((s._repeat < 0 ? s.duration() : s.totalDuration()) / (s.reversed() ? -i : i));
        if (s._dirty) {
            for (d = s.parent; l;) u = l._prev, l._dirty && l.totalDuration(), f = l._start, f > a && s._sort && l._ts && !s._lock ? (s._lock = 1, $n(s, l, f - l._delay, 1)._lock = 0) : a = f, f < 0 && l._ts && (o -= f, (!d && !s._dp || d && d.smoothChildTiming) && (s._start += f / s._ts, s._time -= f, s._tTime -= f), s.shiftChildren(-f, !1, -1 / 0), a = 0), l._end > o && l._ts && (o = l._end), l = u;
            zo(s, s === Ie && s._time > o ? s._time : o, 1, 1), s._dirty = 0
        }
        return s._tDur
    }, t.updateRoot = function(i) {
        if (Ie._ts && (F_(Ie, yu(i, Ie)), z_ = Jt.frame), Jt.frame >= s1) {
            s1 += nn.autoSleep || 120;
            var o = Ie._first;
            if ((!o || !o._ts) && nn.autoSleep && Jt._listeners.length < 2) {
                for (; o && !o._ts;) o = o._next;
                o || Jt.sleep()
            }
        }
    }, t
}(Fo);
En(Ft.prototype, {
    _lock: 0,
    _hasPause: 0,
    _forcing: 0
});
var f4 = function(t, n, r, i, o, s, l) {
        var a = new Wt(this._pt, t, n, 0, 1, dS, null, o),
            u = 0,
            f = 0,
            d, h, y, _, v, E, m, g;
        for (a.b = r, a.e = i, r += "", i += "", (m = ~i.indexOf("random(")) && (i = al(i)), s && (g = [r, i], s(g, t, n), r = g[0], i = g[1]), h = r.match(td) || []; d = td.exec(i);) _ = d[0], v = i.substring(u, d.index), y ? y = (y + 1) % 5 : v.substr(-5) === "rgba(" && (y = 1), _ !== h[f++] && (E = parseFloat(h[f - 1]) || 0, a._pt = {
            _next: a._pt,
            p: v || f === 1 ? v : ",",
            s: E,
            c: _.charAt(1) === "=" ? wo(E, _) - E : parseFloat(_) - E,
            m: y && y < 4 ? Math.round : 0
        }, u = td.lastIndex);
        return a.c = u < i.length ? i.substring(u, i.length) : "", a.fp = l, (L_.test(i) || m) && (a.e = 0), this._pt = a, a
    },
    Hh = function(t, n, r, i, o, s, l, a, u, f) {
        He(i) && (i = i(o || 0, t, s));
        var d = t[n],
            h = r !== "get" ? r : He(d) ? u ? t[n.indexOf("set") || !He(t["get" + n.substr(3)]) ? n : "get" + n.substr(3)](u) : t[n]() : d,
            y = He(d) ? u ? v4 : cS : Gh,
            _;
        if (ct(i) && (~i.indexOf("random(") && (i = al(i)), i.charAt(1) === "=" && (_ = wo(h, i) + (Ct(h) || 0), (_ || _ === 0) && (i = _))), !f || h !== i || Sp) return !isNaN(h * i) && i !== "" ? (_ = new Wt(this._pt, t, n, +h || 0, i - (h || 0), typeof d == "boolean" ? y4 : fS, 0, y), u && (_.fp = u), l && _.modifier(l, this, t), this._pt = _) : (!d && !(n in t) && jh(n, i), f4.call(this, t, n, h, i, y, a || nn.stringFilter, u))
    },
    d4 = function(t, n, r, i, o) {
        if (He(t) && (t = Vs(t, o, n, r, i)), !Qn(t) || t.style && t.nodeType || Pt(t) || M_(t)) return ct(t) ? Vs(t, o, n, r, i) : t;
        var s = {},
            l;
        for (l in t) s[l] = Vs(t[l], o, n, r, i);
        return s
    },
    lS = function(t, n, r, i, o, s) {
        var l, a, u, f;
        if (Zt[t] && (l = new Zt[t]).init(o, l.rawVars ? n[t] : d4(n[t], i, o, s, r), r, i, s) !== !1 && (r._pt = a = new Wt(r._pt, o, t, 0, 1, l.render, l, 0, l.priority), r !== ho))
            for (u = r._ptLookup[r._targets.indexOf(o)], f = l._props.length; f--;) u[l._props[f]] = a;
        return l
    },
    Fr, Sp, Wh = function e(t, n, r) {
        var i = t.vars,
            o = i.ease,
            s = i.startAt,
            l = i.immediateRender,
            a = i.lazy,
            u = i.onUpdate,
            f = i.onUpdateParams,
            d = i.callbackScope,
            h = i.runBackwards,
            y = i.yoyoEase,
            _ = i.keyframes,
            v = i.autoRevert,
            E = t._dur,
            m = t._startAt,
            g = t._targets,
            S = t.parent,
            x = S && S.data === "nested" ? S.vars.targets : g,
            P = t._overwrite === "auto" && !zh,
            T = t.timeline,
            L, b, N, H, A, I, B, G, Q, le, ie, D, V;
        if (T && (!_ || !o) && (o = "none"), t._ease = bi(o, Ro.ease), t._yEase = y ? rS(bi(y === !0 ? o : y, Ro.ease)) : 0, y && t._yoyo && !t._repeat && (y = t._yEase, t._yEase = t._ease, t._ease = y), t._from = !T && !!i.runBackwards, !T || _ && !i.stagger) {
            if (G = g[0] ? Pi(g[0]).harness : 0, D = G && i[G.prop], L = gu(i, Vh), m && (m._zTime < 0 && m.progress(1), n < 0 && h && l && !v ? m.render(-1, !0) : m.revert(h && E ? Ba : jT), m._lazy = 0), s) {
                if (ei(t._startAt = nt.set(g, En({
                        data: "isStart",
                        overwrite: !1,
                        parent: S,
                        immediateRender: !0,
                        lazy: !m && $t(a),
                        startAt: null,
                        delay: 0,
                        onUpdate: u,
                        onUpdateParams: f,
                        callbackScope: d,
                        stagger: 0
                    }, s))), t._startAt._dp = 0, t._startAt._sat = t, n < 0 && (Tt || !l && !v) && t._startAt.revert(Ba), l && E && n <= 0 && r <= 0) {
                    n && (t._zTime = n);
                    return
                }
            } else if (h && E && !m) {
                if (n && (l = !1), N = En({
                        overwrite: !1,
                        data: "isFromStart",
                        lazy: l && !m && $t(a),
                        immediateRender: l,
                        stagger: 0,
                        parent: S
                    }, L), D && (N[G.prop] = D), ei(t._startAt = nt.set(g, N)), t._startAt._dp = 0, t._startAt._sat = t, n < 0 && (Tt ? t._startAt.revert(Ba) : t._startAt.render(-1, !0)), t._zTime = n, !l) e(t._startAt, Ce, Ce);
                else if (!n) return
            }
            for (t._pt = t._ptCache = 0, a = E && $t(a) || a && !E, b = 0; b < g.length; b++) {
                if (A = g[b], B = A._gsap || $h(g)[b]._gsap, t._ptLookup[b] = le = {}, hp[B.id] && Kr.length && vu(), ie = x === g ? b : x.indexOf(A), G && (Q = new G).init(A, D || L, t, ie, x) !== !1 && (t._pt = H = new Wt(t._pt, A, Q.name, 0, 1, Q.render, Q, 0, Q.priority), Q._props.forEach(function(U) {
                        le[U] = H
                    }), Q.priority && (I = 1)), !G || D)
                    for (N in L) Zt[N] && (Q = lS(N, L, t, ie, A, x)) ? Q.priority && (I = 1) : le[N] = H = Hh.call(t, A, N, "get", L[N], ie, x, 0, i.stringFilter);
                t._op && t._op[b] && t.kill(A, t._op[b]), P && t._pt && (Fr = t, Ie.killTweensOf(A, le, t.globalTime(n)), V = !t.parent, Fr = 0), t._pt && a && (hp[B.id] = 1)
            }
            I && pS(t), t._onInit && t._onInit(t)
        }
        t._onUpdate = u, t._initted = (!t._op || t._pt) && !V, _ && n <= 0 && T.render(vn, !0, !0)
    },
    p4 = function(t, n, r, i, o, s, l) {
        var a = (t._pt && t._ptCache || (t._ptCache = {}))[n],
            u, f, d, h;
        if (!a)
            for (a = t._ptCache[n] = [], d = t._ptLookup, h = t._targets.length; h--;) {
                if (u = d[h][n], u && u.d && u.d._pt)
                    for (u = u.d._pt; u && u.p !== n && u.fp !== n;) u = u._next;
                if (!u) return Sp = 1, t.vars[n] = "+=0", Wh(t, l), Sp = 0, 1;
                a.push(u)
            }
        for (h = a.length; h--;) f = a[h], u = f._pt || f, u.s = (i || i === 0) && !o ? i : u.s + (i || 0) + s * u.c, u.c = r - u.s, f.e && (f.e = Ye(r) + Ct(f.e)), f.b && (f.b = u.s + Ct(f.b))
    },
    h4 = function(t, n) {
        var r = t[0] ? Pi(t[0]).harness : 0,
            i = r && r.aliases,
            o, s, l, a;
        if (!i) return n;
        o = Di({}, n);
        for (s in i)
            if (s in o)
                for (a = i[s].split(","), l = a.length; l--;) o[a[l]] = o[s];
        return o
    },
    m4 = function(t, n, r, i) {
        var o = n.ease || i || "power1.inOut",
            s, l;
        if (Pt(n)) l = r[t] || (r[t] = []), n.forEach(function(a, u) {
            return l.push({
                t: u / (n.length - 1) * 100,
                v: a,
                e: o
            })
        });
        else
            for (s in n) l = r[s] || (r[s] = []), s === "ease" || l.push({
                t: parseFloat(t),
                v: n[s],
                e: o
            })
    },
    Vs = function(t, n, r, i, o) {
        return He(t) ? t.call(n, r, i, o) : ct(t) && ~t.indexOf("random(") ? al(t) : t
    },
    aS = Uh + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,autoRevert",
    uS = {};
Ht(aS + ",id,stagger,delay,duration,paused,scrollTrigger", function(e) {
    return uS[e] = 1
});
var nt = function(e) {
    k_(t, e);

    function t(r, i, o, s) {
        var l;
        typeof i == "number" && (o.duration = i, i = o, o = null), l = e.call(this, s ? i : Bs(i)) || this;
        var a = l.vars,
            u = a.duration,
            f = a.delay,
            d = a.immediateRender,
            h = a.stagger,
            y = a.overwrite,
            _ = a.keyframes,
            v = a.defaults,
            E = a.scrollTrigger,
            m = a.yoyoEase,
            g = i.parent || Ie,
            S = (Pt(r) || M_(r) ? Sr(r[0]) : "length" in i) ? [r] : gn(r),
            x, P, T, L, b, N, H, A;
        if (l._targets = S.length ? $h(S) : mu("GSAP target " + r + " not found. https://greensock.com", !nn.nullTargetWarn) || [], l._ptLookup = [], l._overwrite = y, _ || h || Sa(u) || Sa(f)) {
            if (i = l.vars, x = l.timeline = new Ft({
                    data: "nested",
                    defaults: v || {},
                    targets: g && g.data === "nested" ? g.vars.targets : S
                }), x.kill(), x.parent = x._dp = ur(l), x._start = 0, h || Sa(u) || Sa(f)) {
                if (L = S.length, H = h && Y_(h), Qn(h))
                    for (b in h) ~aS.indexOf(b) && (A || (A = {}), A[b] = h[b]);
                for (P = 0; P < L; P++) T = gu(i, uS), T.stagger = 0, m && (T.yoyoEase = m), A && Di(T, A), N = S[P], T.duration = +Vs(u, ur(l), P, N, S), T.delay = (+Vs(f, ur(l), P, N, S) || 0) - l._delay, !h && L === 1 && T.delay && (l._delay = f = T.delay, l._start += f, T.delay = 0), x.to(N, T, H ? H(P, N, S) : 0), x._ease = ve.none;
                x.duration() ? u = f = 0 : l.timeline = 0
            } else if (_) {
                Bs(En(x.vars.defaults, {
                    ease: "none"
                })), x._ease = bi(_.ease || i.ease || "none");
                var I = 0,
                    B, G, Q;
                if (Pt(_)) _.forEach(function(le) {
                    return x.to(S, le, ">")
                }), x.duration();
                else {
                    T = {};
                    for (b in _) b === "ease" || b === "easeEach" || m4(b, _[b], T, _.easeEach);
                    for (b in T)
                        for (B = T[b].sort(function(le, ie) {
                                return le.t - ie.t
                            }), I = 0, P = 0; P < B.length; P++) G = B[P], Q = {
                            ease: G.e,
                            duration: (G.t - (P ? B[P - 1].t : 0)) / 100 * u
                        }, Q[b] = G.v, x.to(S, Q, I), I += Q.duration;
                    x.duration() < u && x.to({}, {
                        duration: u - x.duration()
                    })
                }
            }
            u || l.duration(u = x.duration())
        } else l.timeline = 0;
        return y === !0 && !zh && (Fr = ur(l), Ie.killTweensOf(S), Fr = 0), $n(g, ur(l), o), i.reversed && l.reverse(), i.paused && l.paused(!0), (d || !u && !_ && l._start === mt(g._time) && $t(d) && GT(ur(l)) && g.data !== "nested") && (l._tTime = -Ce, l.render(Math.max(0, -f) || 0)), E && $_(ur(l), E), l
    }
    var n = t.prototype;
    return n.render = function(i, o, s) {
        var l = this._time,
            a = this._tDur,
            u = this._dur,
            f = i < 0,
            d = i > a - Ce && !f ? a : i < Ce ? 0 : i,
            h, y, _, v, E, m, g, S, x;
        if (!u) XT(this, i, o, s);
        else if (d !== this._tTime || !i || s || !this._initted && this._tTime || this._startAt && this._zTime < 0 !== f) {
            if (h = d, S = this.timeline, this._repeat) {
                if (v = u + this._rDelay, this._repeat < -1 && f) return this.totalTime(v * 100 + i, o, s);
                if (h = mt(d % v), d === a ? (_ = this._repeat, h = u) : (_ = ~~(d / v), _ && _ === d / v && (h = u, _--), h > u && (h = u)), m = this._yoyo && _ & 1, m && (x = this._yEase, h = u - h), E = Do(this._tTime, v), h === l && !s && this._initted) return this._tTime = d, this;
                _ !== E && (S && this._yEase && iS(S, m), this.vars.repeatRefresh && !m && !this._lock && (this._lock = s = 1, this.render(mt(v * _), !0).invalidate()._lock = 0))
            }
            if (!this._initted) {
                if (H_(this, f ? i : h, s, o, d)) return this._tTime = 0, this;
                if (l !== this._time) return this;
                if (u !== this._dur) return this.render(i, o, s)
            }
            if (this._tTime = d, this._time = h, !this._act && this._ts && (this._act = 1, this._lazy = 0), this.ratio = g = (x || this._ease)(h / u), this._from && (this.ratio = g = 1 - g), h && !l && !o && !_ && (yn(this, "onStart"), this._tTime !== d)) return this;
            for (y = this._pt; y;) y.r(g, y.d), y = y._next;
            S && S.render(i < 0 ? i : !h && m ? -Ce : S._dur * S._ease(h / this._dur), o, s) || this._startAt && (this._zTime = i), this._onUpdate && !o && (f && mp(this, i, o, s), yn(this, "onUpdate")), this._repeat && _ !== E && this.vars.onRepeat && !o && this.parent && yn(this, "onRepeat"), (d === this._tDur || !d) && this._tTime === d && (f && !this._onUpdate && mp(this, i, !0, !0), (i || !u) && (d === this._tDur && this._ts > 0 || !d && this._ts < 0) && ei(this, 1), !o && !(f && !l) && (d || l || m) && (yn(this, d === a ? "onComplete" : "onReverseComplete", !0), this._prom && !(d < a && this.timeScale() > 0) && this._prom()))
        }
        return this
    }, n.targets = function() {
        return this._targets
    }, n.invalidate = function(i) {
        return (!i || !this.vars.runBackwards) && (this._startAt = 0), this._pt = this._op = this._onUpdate = this._lazy = this.ratio = 0, this._ptLookup = [], this.timeline && this.timeline.invalidate(i), e.prototype.invalidate.call(this, i)
    }, n.resetTo = function(i, o, s, l) {
        ul || Jt.wake(), this._ts || this.play();
        var a = Math.min(this._dur, (this._dp._time - this._start) * this._ts),
            u;
        return this._initted || Wh(this, a), u = this._ease(a / this._dur), p4(this, i, o, s, l, u, a) ? this.resetTo(i, o, s, l) : (Xu(this, 0), this.parent || V_(this._dp, this, "_first", "_last", this._dp._sort ? "_start" : 0), this.render(0))
    }, n.kill = function(i, o) {
        if (o === void 0 && (o = "all"), !i && (!o || o === "all")) return this._lazy = this._pt = 0, this.parent ? ks(this) : this;
        if (this.timeline) {
            var s = this.timeline.totalDuration();
            return this.timeline.killTweensOf(i, o, Fr && Fr.vars.overwrite !== !0)._first || ks(this), this.parent && s !== this.timeline.totalDuration() && zo(this, this._dur * this.timeline._tDur / s, 0, 1), this
        }
        var l = this._targets,
            a = i ? gn(i) : l,
            u = this._ptLookup,
            f = this._pt,
            d, h, y, _, v, E, m;
        if ((!o || o === "all") && HT(l, a)) return o === "all" && (this._pt = 0), ks(this);
        for (d = this._op = this._op || [], o !== "all" && (ct(o) && (v = {}, Ht(o, function(g) {
                return v[g] = 1
            }), o = v), o = h4(l, o)), m = l.length; m--;)
            if (~a.indexOf(l[m])) {
                h = u[m], o === "all" ? (d[m] = o, _ = h, y = {}) : (y = d[m] = d[m] || {}, _ = o);
                for (v in _) E = h && h[v], E && ((!("kill" in E.d) || E.d.kill(v) === !0) && Gu(this, E, "_pt"), delete h[v]), y !== "all" && (y[v] = 1)
            }
        return this._initted && !this._pt && f && ks(this), this
    }, t.to = function(i, o) {
        return new t(i, o, arguments[2])
    }, t.from = function(i, o) {
        return js(1, arguments)
    }, t.delayedCall = function(i, o, s, l) {
        return new t(o, 0, {
            immediateRender: !1,
            lazy: !1,
            overwrite: !1,
            delay: i,
            onComplete: o,
            onReverseComplete: o,
            onCompleteParams: s,
            onReverseCompleteParams: s,
            callbackScope: l
        })
    }, t.fromTo = function(i, o, s) {
        return js(2, arguments)
    }, t.set = function(i, o) {
        return o.duration = 0, o.repeatDelay || (o.repeat = 0), new t(i, o)
    }, t.killTweensOf = function(i, o, s) {
        return Ie.killTweensOf(i, o, s)
    }, t
}(Fo);
En(nt.prototype, {
    _targets: [],
    _lazy: 0,
    _startAt: 0,
    _op: 0,
    _onInit: 0
});
Ht("staggerTo,staggerFrom,staggerFromTo", function(e) {
    nt[e] = function() {
        var t = new Ft,
            n = gp.call(arguments, 0);
        return n.splice(e === "staggerFromTo" ? 5 : 4, 0, 0), t[e].apply(t, n)
    }
});
var Gh = function(t, n, r) {
        return t[n] = r
    },
    cS = function(t, n, r) {
        return t[n](r)
    },
    v4 = function(t, n, r, i) {
        return t[n](i.fp, r)
    },
    g4 = function(t, n, r) {
        return t.setAttribute(n, r)
    },
    Yh = function(t, n) {
        return He(t[n]) ? cS : Ih(t[n]) && t.setAttribute ? g4 : Gh
    },
    fS = function(t, n) {
        return n.set(n.t, n.p, Math.round((n.s + n.c * t) * 1e6) / 1e6, n)
    },
    y4 = function(t, n) {
        return n.set(n.t, n.p, !!(n.s + n.c * t), n)
    },
    dS = function(t, n) {
        var r = n._pt,
            i = "";
        if (!t && n.b) i = n.b;
        else if (t === 1 && n.e) i = n.e;
        else {
            for (; r;) i = r.p + (r.m ? r.m(r.s + r.c * t) : Math.round((r.s + r.c * t) * 1e4) / 1e4) + i, r = r._next;
            i += n.c
        }
        n.set(n.t, n.p, i, n)
    },
    Xh = function(t, n) {
        for (var r = n._pt; r;) r.r(t, r.d), r = r._next
    },
    _4 = function(t, n, r, i) {
        for (var o = this._pt, s; o;) s = o._next, o.p === i && o.modifier(t, n, r), o = s
    },
    S4 = function(t) {
        for (var n = this._pt, r, i; n;) i = n._next, n.p === t && !n.op || n.op === t ? Gu(this, n, "_pt") : n.dep || (r = 1), n = i;
        return !r
    },
    w4 = function(t, n, r, i) {
        i.mSet(t, n, i.m.call(i.tween, r, i.mt), i)
    },
    pS = function(t) {
        for (var n = t._pt, r, i, o, s; n;) {
            for (r = n._next, i = o; i && i.pr > n.pr;) i = i._next;
            (n._prev = i ? i._prev : s) ? n._prev._next = n: o = n, (n._next = i) ? i._prev = n : s = n, n = r
        }
        t._pt = o
    },
    Wt = function() {
        function e(n, r, i, o, s, l, a, u, f) {
            this.t = r, this.s = o, this.c = s, this.p = i, this.r = l || fS, this.d = a || this, this.set = u || Gh, this.pr = f || 0, this._next = n, n && (n._prev = this)
        }
        var t = e.prototype;
        return t.modifier = function(r, i, o) {
            this.mSet = this.mSet || this.set, this.set = w4, this.m = r, this.mt = o, this.tween = i
        }, e
    }();
Ht(Uh + "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger", function(e) {
    return Vh[e] = 1
});
on.TweenMax = on.TweenLite = nt;
on.TimelineLite = on.TimelineMax = Ft;
Ie = new Ft({
    sortChildren: !1,
    defaults: Ro,
    autoRemoveChildren: !0,
    id: "root",
    smoothChildTiming: !0
});
nn.stringFilter = nS;
var Bo = [],
    Va = {},
    x4 = [],
    d1 = 0,
    sd = function(t) {
        return (Va[t] || x4).map(function(n) {
            return n()
        })
    },
    wp = function() {
        var t = Date.now(),
            n = [];
        t - d1 > 2 && (sd("matchMediaInit"), Bo.forEach(function(r) {
            var i = r.queries,
                o = r.conditions,
                s, l, a, u;
            for (l in i) s = fn.matchMedia(i[l]).matches, s && (a = 1), s !== o[l] && (o[l] = s, u = 1);
            u && (r.revert(), a && n.push(r))
        }), sd("matchMediaRevert"), n.forEach(function(r) {
            return r.onMatch(r)
        }), d1 = t, sd("matchMedia"))
    },
    hS = function() {
        function e(n, r) {
            this.selector = r && yp(r), this.data = [], this._r = [], this.isReverted = !1, n && this.add(n)
        }
        var t = e.prototype;
        return t.add = function(r, i, o) {
            He(r) && (o = i, i = r, r = He);
            var s = this,
                l = function() {
                    var u = Qe,
                        f = s.selector,
                        d;
                    return u && u !== s && u.data.push(s), o && (s.selector = yp(o)), Qe = s, d = i.apply(s, arguments), He(d) && s._r.push(d), Qe = u, s.selector = f, s.isReverted = !1, d
                };
            return s.last = l, r === He ? l(s) : r ? s[r] = l : l
        }, t.ignore = function(r) {
            var i = Qe;
            Qe = null, r(this), Qe = i
        }, t.getTweens = function() {
            var r = [];
            return this.data.forEach(function(i) {
                return i instanceof e ? r.push.apply(r, i.getTweens()) : i instanceof nt && !(i.parent && i.parent.data === "nested") && r.push(i)
            }), r
        }, t.clear = function() {
            this._r.length = this.data.length = 0
        }, t.kill = function(r, i) {
            var o = this;
            if (r) {
                var s = this.getTweens();
                this.data.forEach(function(a) {
                    a.data === "isFlip" && (a.revert(), a.getChildren(!0, !0, !1).forEach(function(u) {
                        return s.splice(s.indexOf(u), 1)
                    }))
                }), s.map(function(a) {
                    return {
                        g: a.globalTime(0),
                        t: a
                    }
                }).sort(function(a, u) {
                    return u.g - a.g || -1
                }).forEach(function(a) {
                    return a.t.revert(r)
                }), this.data.forEach(function(a) {
                    return !(a instanceof Fo) && a.revert && a.revert(r)
                }), this._r.forEach(function(a) {
                    return a(r, o)
                }), this.isReverted = !0
            } else this.data.forEach(function(a) {
                return a.kill && a.kill()
            });
            if (this.clear(), i) {
                var l = Bo.indexOf(this);
                ~l && Bo.splice(l, 1)
            }
        }, t.revert = function(r) {
            this.kill(r || {})
        }, e
    }(),
    E4 = function() {
        function e(n) {
            this.contexts = [], this.scope = n
        }
        var t = e.prototype;
        return t.add = function(r, i, o) {
            Qn(r) || (r = {
                matches: r
            });
            var s = new hS(0, o || this.scope),
                l = s.conditions = {},
                a, u, f;
            this.contexts.push(s), i = s.add("onMatch", i), s.queries = r;
            for (u in r) u === "all" ? f = 1 : (a = fn.matchMedia(r[u]), a && (Bo.indexOf(s) < 0 && Bo.push(s), (l[u] = a.matches) && (f = 1), a.addListener ? a.addListener(wp) : a.addEventListener("change", wp)));
            return f && i(s), this
        }, t.revert = function(r) {
            this.kill(r || {})
        }, t.kill = function(r) {
            this.contexts.forEach(function(i) {
                return i.kill(r, !0)
            })
        }, e
    }(),
    _u = {
        registerPlugin: function() {
            for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
            n.forEach(function(i) {
                return J_(i)
            })
        },
        timeline: function(t) {
            return new Ft(t)
        },
        getTweensOf: function(t, n) {
            return Ie.getTweensOf(t, n)
        },
        getProperty: function(t, n, r, i) {
            ct(t) && (t = gn(t)[0]);
            var o = Pi(t || {}).get,
                s = r ? j_ : B_;
            return r === "native" && (r = ""), t && (n ? s((Zt[n] && Zt[n].get || o)(t, n, r, i)) : function(l, a, u) {
                return s((Zt[l] && Zt[l].get || o)(t, l, a, u))
            })
        },
        quickSetter: function(t, n, r) {
            if (t = gn(t), t.length > 1) {
                var i = t.map(function(f) {
                        return Gt.quickSetter(f, n, r)
                    }),
                    o = i.length;
                return function(f) {
                    for (var d = o; d--;) i[d](f)
                }
            }
            t = t[0] || {};
            var s = Zt[n],
                l = Pi(t),
                a = l.harness && (l.harness.aliases || {})[n] || n,
                u = s ? function(f) {
                    var d = new s;
                    ho._pt = 0, d.init(t, r ? f + r : f, ho, 0, [t]), d.render(1, d), ho._pt && Xh(1, ho)
                } : l.set(t, a);
            return s ? u : function(f) {
                return u(t, a, r ? f + r : f, l, 1)
            }
        },
        quickTo: function(t, n, r) {
            var i, o = Gt.to(t, Di((i = {}, i[n] = "+=0.1", i.paused = !0, i), r || {})),
                s = function(a, u, f) {
                    return o.resetTo(n, a, u, f)
                };
            return s.tween = o, s
        },
        isTweening: function(t) {
            return Ie.getTweensOf(t, !0).length > 0
        },
        defaults: function(t) {
            return t && t.ease && (t.ease = bi(t.ease, Ro.ease)), l1(Ro, t || {})
        },
        config: function(t) {
            return l1(nn, t || {})
        },
        registerEffect: function(t) {
            var n = t.name,
                r = t.effect,
                i = t.plugins,
                o = t.defaults,
                s = t.extendTimeline;
            (i || "").split(",").forEach(function(l) {
                return l && !Zt[l] && !on[l] && mu(n + " effect requires " + l + " plugin.")
            }), nd[n] = function(l, a, u) {
                return r(gn(l), En(a || {}, o), u)
            }, s && (Ft.prototype[n] = function(l, a, u) {
                return this.add(nd[n](l, Qn(a) ? a : (u = a) && {}, this), u)
            })
        },
        registerEase: function(t, n) {
            ve[t] = bi(n)
        },
        parseEase: function(t, n) {
            return arguments.length ? bi(t, n) : ve
        },
        getById: function(t) {
            return Ie.getById(t)
        },
        exportRoot: function(t, n) {
            t === void 0 && (t = {});
            var r = new Ft(t),
                i, o;
            for (r.smoothChildTiming = $t(t.smoothChildTiming), Ie.remove(r), r._dp = 0, r._time = r._tTime = Ie._time, i = Ie._first; i;) o = i._next, (n || !(!i._dur && i instanceof nt && i.vars.onComplete === i._targets[0])) && $n(r, i, i._start - i._delay), i = o;
            return $n(Ie, r, 0), r
        },
        context: function(t, n) {
            return t ? new hS(t, n) : Qe
        },
        matchMedia: function(t) {
            return new E4(t)
        },
        matchMediaRefresh: function() {
            return Bo.forEach(function(t) {
                var n = t.conditions,
                    r, i;
                for (i in n) n[i] && (n[i] = !1, r = 1);
                r && t.revert()
            }) || wp()
        },
        addEventListener: function(t, n) {
            var r = Va[t] || (Va[t] = []);
            ~r.indexOf(n) || r.push(n)
        },
        removeEventListener: function(t, n) {
            var r = Va[t],
                i = r && r.indexOf(n);
            i >= 0 && r.splice(i, 1)
        },
        utils: {
            wrap: n4,
            wrapYoyo: r4,
            distribute: Y_,
            random: q_,
            snap: X_,
            normalize: t4,
            getUnit: Ct,
            clamp: QT,
            splitColor: eS,
            toArray: gn,
            selector: yp,
            mapRange: Q_,
            pipe: JT,
            unitize: e4,
            interpolate: i4,
            shuffle: G_
        },
        install: R_,
        effects: nd,
        ticker: Jt,
        updateRoot: Ft.updateRoot,
        plugins: Zt,
        globalTimeline: Ie,
        core: {
            PropTween: Wt,
            globals: D_,
            Tween: nt,
            Timeline: Ft,
            Animation: Fo,
            getCache: Pi,
            _removeLinkedListItem: Gu,
            reverting: function() {
                return Tt
            },
            context: function(t) {
                return t && Qe && (Qe.data.push(t), t._ctx = Qe), Qe
            },
            suppressOverwrites: function(t) {
                return zh = t
            }
        }
    };
Ht("to,from,fromTo,delayedCall,set,killTweensOf", function(e) {
    return _u[e] = nt[e]
});
Jt.add(Ft.updateRoot);
ho = _u.to({}, {
    duration: 0
});
var C4 = function(t, n) {
        for (var r = t._pt; r && r.p !== n && r.op !== n && r.fp !== n;) r = r._next;
        return r
    },
    T4 = function(t, n) {
        var r = t._targets,
            i, o, s;
        for (i in n)
            for (o = r.length; o--;) s = t._ptLookup[o][i], s && (s = s.d) && (s._pt && (s = C4(s, i)), s && s.modifier && s.modifier(n[i], t, r[o], i))
    },
    ld = function(t, n) {
        return {
            name: t,
            rawVars: 1,
            init: function(i, o, s) {
                s._onInit = function(l) {
                    var a, u;
                    if (ct(o) && (a = {}, Ht(o, function(f) {
                            return a[f] = 1
                        }), o = a), n) {
                        a = {};
                        for (u in o) a[u] = n(o[u]);
                        o = a
                    }
                    T4(l, o)
                }
            }
        }
    },
    Gt = _u.registerPlugin({
        name: "attr",
        init: function(t, n, r, i, o) {
            var s, l, a;
            this.tween = r;
            for (s in n) a = t.getAttribute(s) || "", l = this.add(t, "setAttribute", (a || 0) + "", n[s], i, o, 0, 0, s), l.op = s, l.b = a, this._props.push(s)
        },
        render: function(t, n) {
            for (var r = n._pt; r;) Tt ? r.set(r.t, r.p, r.b, r) : r.r(t, r.d), r = r._next
        }
    }, {
        name: "endArray",
        init: function(t, n) {
            for (var r = n.length; r--;) this.add(t, r, t[r] || 0, n[r], 0, 0, 0, 0, 0, 1)
        }
    }, ld("roundProps", _p), ld("modifiers"), ld("snap", X_)) || _u;
nt.version = Ft.version = Gt.version = "3.11.5";
A_ = 1;
Fh() && Io();
ve.Power0;
ve.Power1;
ve.Power2;
ve.Power3;
ve.Power4;
ve.Linear;
ve.Quad;
ve.Cubic;
ve.Quart;
ve.Quint;
ve.Strong;
ve.Elastic;
ve.Back;
ve.SteppedEase;
ve.Bounce;
ve.Sine;
ve.Expo;
ve.Circ;
/*!
 * CSSPlugin 3.11.5
 * https://greensock.com
 *
 * Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var p1, Br, xo, qh, Ei, h1, Kh, P4 = function() {
        return typeof window < "u"
    },
    wr = {},
    _i = 180 / Math.PI,
    Eo = Math.PI / 180,
    Ji = Math.atan2,
    m1 = 1e8,
    Qh = /([A-Z])/g,
    k4 = /(left|right|width|margin|padding|x)/i,
    b4 = /[\s,\(]\S/,
    Gn = {
        autoAlpha: "opacity,visibility",
        scale: "scaleX,scaleY",
        alpha: "opacity"
    },
    xp = function(t, n) {
        return n.set(n.t, n.p, Math.round((n.s + n.c * t) * 1e4) / 1e4 + n.u, n)
    },
    M4 = function(t, n) {
        return n.set(n.t, n.p, t === 1 ? n.e : Math.round((n.s + n.c * t) * 1e4) / 1e4 + n.u, n)
    },
    O4 = function(t, n) {
        return n.set(n.t, n.p, t ? Math.round((n.s + n.c * t) * 1e4) / 1e4 + n.u : n.b, n)
    },
    L4 = function(t, n) {
        var r = n.s + n.c * t;
        n.set(n.t, n.p, ~~(r + (r < 0 ? -.5 : .5)) + n.u, n)
    },
    mS = function(t, n) {
        return n.set(n.t, n.p, t ? n.e : n.b, n)
    },
    vS = function(t, n) {
        return n.set(n.t, n.p, t !== 1 ? n.b : n.e, n)
    },
    N4 = function(t, n, r) {
        return t.style[n] = r
    },
    A4 = function(t, n, r) {
        return t.style.setProperty(n, r)
    },
    R4 = function(t, n, r) {
        return t._gsap[n] = r
    },
    D4 = function(t, n, r) {
        return t._gsap.scaleX = t._gsap.scaleY = r
    },
    z4 = function(t, n, r, i, o) {
        var s = t._gsap;
        s.scaleX = s.scaleY = r, s.renderTransform(o, s)
    },
    I4 = function(t, n, r, i, o) {
        var s = t._gsap;
        s[n] = r, s.renderTransform(o, s)
    },
    Fe = "transform",
    An = Fe + "Origin",
    F4 = function e(t, n) {
        var r = this,
            i = this.target,
            o = i.style;
        if (t in wr) {
            if (this.tfm = this.tfm || {}, t !== "transform") t = Gn[t] || t, ~t.indexOf(",") ? t.split(",").forEach(function(s) {
                return r.tfm[s] = fr(i, s)
            }) : this.tfm[t] = i._gsap.x ? i._gsap[t] : fr(i, t);
            else return Gn.transform.split(",").forEach(function(s) {
                return e.call(r, s, n)
            });
            if (this.props.indexOf(Fe) >= 0) return;
            i._gsap.svg && (this.svgo = i.getAttribute("data-svg-origin"), this.props.push(An, n, "")), t = Fe
        }(o || n) && this.props.push(t, n, o[t])
    },
    gS = function(t) {
        t.translate && (t.removeProperty("translate"), t.removeProperty("scale"), t.removeProperty("rotate"))
    },
    B4 = function() {
        var t = this.props,
            n = this.target,
            r = n.style,
            i = n._gsap,
            o, s;
        for (o = 0; o < t.length; o += 3) t[o + 1] ? n[t[o]] = t[o + 2] : t[o + 2] ? r[t[o]] = t[o + 2] : r.removeProperty(t[o].substr(0, 2) === "--" ? t[o] : t[o].replace(Qh, "-$1").toLowerCase());
        if (this.tfm) {
            for (s in this.tfm) i[s] = this.tfm[s];
            i.svg && (i.renderTransform(), n.setAttribute("data-svg-origin", this.svgo || "")), o = Kh(), (!o || !o.isStart) && !r[Fe] && (gS(r), i.uncache = 1)
        }
    },
    yS = function(t, n) {
        var r = {
            target: t,
            props: [],
            revert: B4,
            save: F4
        };
        return t._gsap || Gt.core.getCache(t), n && n.split(",").forEach(function(i) {
            return r.save(i)
        }), r
    },
    _S, Ep = function(t, n) {
        var r = Br.createElementNS ? Br.createElementNS((n || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), t) : Br.createElement(t);
        return r.style ? r : Br.createElement(t)
    },
    qn = function e(t, n, r) {
        var i = getComputedStyle(t);
        return i[n] || i.getPropertyValue(n.replace(Qh, "-$1").toLowerCase()) || i.getPropertyValue(n) || !r && e(t, jo(n) || n, 1) || ""
    },
    v1 = "O,Moz,ms,Ms,Webkit".split(","),
    jo = function(t, n, r) {
        var i = n || Ei,
            o = i.style,
            s = 5;
        if (t in o && !r) return t;
        for (t = t.charAt(0).toUpperCase() + t.substr(1); s-- && !(v1[s] + t in o););
        return s < 0 ? null : (s === 3 ? "ms" : s >= 0 ? v1[s] : "") + t
    },
    Cp = function() {
        P4() && window.document && (p1 = window, Br = p1.document, xo = Br.documentElement, Ei = Ep("div") || {
            style: {}
        }, Ep("div"), Fe = jo(Fe), An = Fe + "Origin", Ei.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0", _S = !!jo("perspective"), Kh = Gt.core.reverting, qh = 1)
    },
    ad = function e(t) {
        var n = Ep("svg", this.ownerSVGElement && this.ownerSVGElement.getAttribute("xmlns") || "http://www.w3.org/2000/svg"),
            r = this.parentNode,
            i = this.nextSibling,
            o = this.style.cssText,
            s;
        if (xo.appendChild(n), n.appendChild(this), this.style.display = "block", t) try {
            s = this.getBBox(), this._gsapBBox = this.getBBox, this.getBBox = e
        } catch {} else this._gsapBBox && (s = this._gsapBBox());
        return r && (i ? r.insertBefore(this, i) : r.appendChild(this)), xo.removeChild(n), this.style.cssText = o, s
    },
    g1 = function(t, n) {
        for (var r = n.length; r--;)
            if (t.hasAttribute(n[r])) return t.getAttribute(n[r])
    },
    SS = function(t) {
        var n;
        try {
            n = t.getBBox()
        } catch {
            n = ad.call(t, !0)
        }
        return n && (n.width || n.height) || t.getBBox === ad || (n = ad.call(t, !0)), n && !n.width && !n.x && !n.y ? {
            x: +g1(t, ["x", "cx", "x1"]) || 0,
            y: +g1(t, ["y", "cy", "y1"]) || 0,
            width: 0,
            height: 0
        } : n
    },
    wS = function(t) {
        return !!(t.getCTM && (!t.parentNode || t.ownerSVGElement) && SS(t))
    },
    cl = function(t, n) {
        if (n) {
            var r = t.style;
            n in wr && n !== An && (n = Fe), r.removeProperty ? ((n.substr(0, 2) === "ms" || n.substr(0, 6) === "webkit") && (n = "-" + n), r.removeProperty(n.replace(Qh, "-$1").toLowerCase())) : r.removeAttribute(n)
        }
    },
    jr = function(t, n, r, i, o, s) {
        var l = new Wt(t._pt, n, r, 0, 1, s ? vS : mS);
        return t._pt = l, l.b = i, l.e = o, t._props.push(r), l
    },
    y1 = {
        deg: 1,
        rad: 1,
        turn: 1
    },
    j4 = {
        grid: 1,
        flex: 1
    },
    ti = function e(t, n, r, i) {
        var o = parseFloat(r) || 0,
            s = (r + "").trim().substr((o + "").length) || "px",
            l = Ei.style,
            a = k4.test(n),
            u = t.tagName.toLowerCase() === "svg",
            f = (u ? "client" : "offset") + (a ? "Width" : "Height"),
            d = 100,
            h = i === "px",
            y = i === "%",
            _, v, E, m;
        return i === s || !o || y1[i] || y1[s] ? o : (s !== "px" && !h && (o = e(t, n, r, "px")), m = t.getCTM && wS(t), (y || s === "%") && (wr[n] || ~n.indexOf("adius")) ? (_ = m ? t.getBBox()[a ? "width" : "height"] : t[f], Ye(y ? o / _ * d : o / 100 * _)) : (l[a ? "width" : "height"] = d + (h ? s : i), v = ~n.indexOf("adius") || i === "em" && t.appendChild && !u ? t : t.parentNode, m && (v = (t.ownerSVGElement || {}).parentNode), (!v || v === Br || !v.appendChild) && (v = Br.body), E = v._gsap, E && y && E.width && a && E.time === Jt.time && !E.uncache ? Ye(o / E.width * d) : ((y || s === "%") && !j4[qn(v, "display")] && (l.position = qn(t, "position")), v === t && (l.position = "static"), v.appendChild(Ei), _ = Ei[f], v.removeChild(Ei), l.position = "absolute", a && y && (E = Pi(v), E.time = Jt.time, E.width = v[f]), Ye(h ? _ * o / d : _ && o ? d / _ * o : 0))))
    },
    fr = function(t, n, r, i) {
        var o;
        return qh || Cp(), n in Gn && n !== "transform" && (n = Gn[n], ~n.indexOf(",") && (n = n.split(",")[0])), wr[n] && n !== "transform" ? (o = dl(t, i), o = n !== "transformOrigin" ? o[n] : o.svg ? o.origin : wu(qn(t, An)) + " " + o.zOrigin + "px") : (o = t.style[n], (!o || o === "auto" || i || ~(o + "").indexOf("calc(")) && (o = Su[n] && Su[n](t, n, r) || qn(t, n) || I_(t, n) || (n === "opacity" ? 1 : 0))), r && !~(o + "").trim().indexOf(" ") ? ti(t, n, o, r) + r : o
    },
    V4 = function(t, n, r, i) {
        if (!r || r === "none") {
            var o = jo(n, t, 1),
                s = o && qn(t, o, 1);
            s && s !== r ? (n = o, r = s) : n === "borderColor" && (r = qn(t, "borderTopColor"))
        }
        var l = new Wt(this._pt, t.style, n, 0, 1, dS),
            a = 0,
            u = 0,
            f, d, h, y, _, v, E, m, g, S, x, P;
        if (l.b = r, l.e = i, r += "", i += "", i === "auto" && (t.style[n] = i, i = qn(t, n) || i, t.style[n] = r), f = [r, i], nS(f), r = f[0], i = f[1], h = r.match(po) || [], P = i.match(po) || [], P.length) {
            for (; d = po.exec(i);) E = d[0], g = i.substring(a, d.index), _ ? _ = (_ + 1) % 5 : (g.substr(-5) === "rgba(" || g.substr(-5) === "hsla(") && (_ = 1), E !== (v = h[u++] || "") && (y = parseFloat(v) || 0, x = v.substr((y + "").length), E.charAt(1) === "=" && (E = wo(y, E) + x), m = parseFloat(E), S = E.substr((m + "").length), a = po.lastIndex - S.length, S || (S = S || nn.units[n] || x, a === i.length && (i += S, l.e += S)), x !== S && (y = ti(t, n, v, S) || 0), l._pt = {
                _next: l._pt,
                p: g || u === 1 ? g : ",",
                s: y,
                c: m - y,
                m: _ && _ < 4 || n === "zIndex" ? Math.round : 0
            });
            l.c = a < i.length ? i.substring(a, i.length) : ""
        } else l.r = n === "display" && i === "none" ? vS : mS;
        return L_.test(i) && (l.e = 0), this._pt = l, l
    },
    _1 = {
        top: "0%",
        bottom: "100%",
        left: "0%",
        right: "100%",
        center: "50%"
    },
    U4 = function(t) {
        var n = t.split(" "),
            r = n[0],
            i = n[1] || "50%";
        return (r === "top" || r === "bottom" || i === "left" || i === "right") && (t = r, r = i, i = t), n[0] = _1[r] || r, n[1] = _1[i] || i, n.join(" ")
    },
    $4 = function(t, n) {
        if (n.tween && n.tween._time === n.tween._dur) {
            var r = n.t,
                i = r.style,
                o = n.u,
                s = r._gsap,
                l, a, u;
            if (o === "all" || o === !0) i.cssText = "", a = 1;
            else
                for (o = o.split(","), u = o.length; --u > -1;) l = o[u], wr[l] && (a = 1, l = l === "transformOrigin" ? An : Fe), cl(r, l);
            a && (cl(r, Fe), s && (s.svg && r.removeAttribute("transform"), dl(r, 1), s.uncache = 1, gS(i)))
        }
    },
    Su = {
        clearProps: function(t, n, r, i, o) {
            if (o.data !== "isFromStart") {
                var s = t._pt = new Wt(t._pt, n, r, 0, 0, $4);
                return s.u = i, s.pr = -10, s.tween = o, t._props.push(r), 1
            }
        }
    },
    fl = [1, 0, 0, 1, 0, 0],
    xS = {},
    ES = function(t) {
        return t === "matrix(1, 0, 0, 1, 0, 0)" || t === "none" || !t
    },
    S1 = function(t) {
        var n = qn(t, Fe);
        return ES(n) ? fl : n.substr(7).match(O_).map(Ye)
    },
    Zh = function(t, n) {
        var r = t._gsap || Pi(t),
            i = t.style,
            o = S1(t),
            s, l, a, u;
        return r.svg && t.getAttribute("transform") ? (a = t.transform.baseVal.consolidate().matrix, o = [a.a, a.b, a.c, a.d, a.e, a.f], o.join(",") === "1,0,0,1,0,0" ? fl : o) : (o === fl && !t.offsetParent && t !== xo && !r.svg && (a = i.display, i.display = "block", s = t.parentNode, (!s || !t.offsetParent) && (u = 1, l = t.nextElementSibling, xo.appendChild(t)), o = S1(t), a ? i.display = a : cl(t, "display"), u && (l ? s.insertBefore(t, l) : s ? s.appendChild(t) : xo.removeChild(t))), n && o.length > 6 ? [o[0], o[1], o[4], o[5], o[12], o[13]] : o)
    },
    Tp = function(t, n, r, i, o, s) {
        var l = t._gsap,
            a = o || Zh(t, !0),
            u = l.xOrigin || 0,
            f = l.yOrigin || 0,
            d = l.xOffset || 0,
            h = l.yOffset || 0,
            y = a[0],
            _ = a[1],
            v = a[2],
            E = a[3],
            m = a[4],
            g = a[5],
            S = n.split(" "),
            x = parseFloat(S[0]) || 0,
            P = parseFloat(S[1]) || 0,
            T, L, b, N;
        r ? a !== fl && (L = y * E - _ * v) && (b = x * (E / L) + P * (-v / L) + (v * g - E * m) / L, N = x * (-_ / L) + P * (y / L) - (y * g - _ * m) / L, x = b, P = N) : (T = SS(t), x = T.x + (~S[0].indexOf("%") ? x / 100 * T.width : x), P = T.y + (~(S[1] || S[0]).indexOf("%") ? P / 100 * T.height : P)), i || i !== !1 && l.smooth ? (m = x - u, g = P - f, l.xOffset = d + (m * y + g * v) - m, l.yOffset = h + (m * _ + g * E) - g) : l.xOffset = l.yOffset = 0, l.xOrigin = x, l.yOrigin = P, l.smooth = !!i, l.origin = n, l.originIsAbsolute = !!r, t.style[An] = "0px 0px", s && (jr(s, l, "xOrigin", u, x), jr(s, l, "yOrigin", f, P), jr(s, l, "xOffset", d, l.xOffset), jr(s, l, "yOffset", h, l.yOffset)), t.setAttribute("data-svg-origin", x + " " + P)
    },
    dl = function(t, n) {
        var r = t._gsap || new sS(t);
        if ("x" in r && !n && !r.uncache) return r;
        var i = t.style,
            o = r.scaleX < 0,
            s = "px",
            l = "deg",
            a = getComputedStyle(t),
            u = qn(t, An) || "0",
            f, d, h, y, _, v, E, m, g, S, x, P, T, L, b, N, H, A, I, B, G, Q, le, ie, D, V, U, q, ne, xe, fe, te;
        return f = d = h = v = E = m = g = S = x = 0, y = _ = 1, r.svg = !!(t.getCTM && wS(t)), a.translate && ((a.translate !== "none" || a.scale !== "none" || a.rotate !== "none") && (i[Fe] = (a.translate !== "none" ? "translate3d(" + (a.translate + " 0 0").split(" ").slice(0, 3).join(", ") + ") " : "") + (a.rotate !== "none" ? "rotate(" + a.rotate + ") " : "") + (a.scale !== "none" ? "scale(" + a.scale.split(" ").join(",") + ") " : "") + (a[Fe] !== "none" ? a[Fe] : "")), i.scale = i.rotate = i.translate = "none"), L = Zh(t, r.svg), r.svg && (r.uncache ? (D = t.getBBox(), u = r.xOrigin - D.x + "px " + (r.yOrigin - D.y) + "px", ie = "") : ie = !n && t.getAttribute("data-svg-origin"), Tp(t, ie || u, !!ie || r.originIsAbsolute, r.smooth !== !1, L)), P = r.xOrigin || 0, T = r.yOrigin || 0, L !== fl && (A = L[0], I = L[1], B = L[2], G = L[3], f = Q = L[4], d = le = L[5], L.length === 6 ? (y = Math.sqrt(A * A + I * I), _ = Math.sqrt(G * G + B * B), v = A || I ? Ji(I, A) * _i : 0, g = B || G ? Ji(B, G) * _i + v : 0, g && (_ *= Math.abs(Math.cos(g * Eo))), r.svg && (f -= P - (P * A + T * B), d -= T - (P * I + T * G))) : (te = L[6], xe = L[7], U = L[8], q = L[9], ne = L[10], fe = L[11], f = L[12], d = L[13], h = L[14], b = Ji(te, ne), E = b * _i, b && (N = Math.cos(-b), H = Math.sin(-b), ie = Q * N + U * H, D = le * N + q * H, V = te * N + ne * H, U = Q * -H + U * N, q = le * -H + q * N, ne = te * -H + ne * N, fe = xe * -H + fe * N, Q = ie, le = D, te = V), b = Ji(-B, ne), m = b * _i, b && (N = Math.cos(-b), H = Math.sin(-b), ie = A * N - U * H, D = I * N - q * H, V = B * N - ne * H, fe = G * H + fe * N, A = ie, I = D, B = V), b = Ji(I, A), v = b * _i, b && (N = Math.cos(b), H = Math.sin(b), ie = A * N + I * H, D = Q * N + le * H, I = I * N - A * H, le = le * N - Q * H, A = ie, Q = D), E && Math.abs(E) + Math.abs(v) > 359.9 && (E = v = 0, m = 180 - m), y = Ye(Math.sqrt(A * A + I * I + B * B)), _ = Ye(Math.sqrt(le * le + te * te)), b = Ji(Q, le), g = Math.abs(b) > 2e-4 ? b * _i : 0, x = fe ? 1 / (fe < 0 ? -fe : fe) : 0), r.svg && (ie = t.getAttribute("transform"), r.forceCSS = t.setAttribute("transform", "") || !ES(qn(t, Fe)), ie && t.setAttribute("transform", ie))), Math.abs(g) > 90 && Math.abs(g) < 270 && (o ? (y *= -1, g += v <= 0 ? 180 : -180, v += v <= 0 ? 180 : -180) : (_ *= -1, g += g <= 0 ? 180 : -180)), n = n || r.uncache, r.x = f - ((r.xPercent = f && (!n && r.xPercent || (Math.round(t.offsetWidth / 2) === Math.round(-f) ? -50 : 0))) ? t.offsetWidth * r.xPercent / 100 : 0) + s, r.y = d - ((r.yPercent = d && (!n && r.yPercent || (Math.round(t.offsetHeight / 2) === Math.round(-d) ? -50 : 0))) ? t.offsetHeight * r.yPercent / 100 : 0) + s, r.z = h + s, r.scaleX = Ye(y), r.scaleY = Ye(_), r.rotation = Ye(v) + l, r.rotationX = Ye(E) + l, r.rotationY = Ye(m) + l, r.skewX = g + l, r.skewY = S + l, r.transformPerspective = x + s, (r.zOrigin = parseFloat(u.split(" ")[2]) || 0) && (i[An] = wu(u)), r.xOffset = r.yOffset = 0, r.force3D = nn.force3D, r.renderTransform = r.svg ? W4 : _S ? CS : H4, r.uncache = 0, r
    },
    wu = function(t) {
        return (t = t.split(" "))[0] + " " + t[1]
    },
    ud = function(t, n, r) {
        var i = Ct(n);
        return Ye(parseFloat(n) + parseFloat(ti(t, "x", r + "px", i))) + i
    },
    H4 = function(t, n) {
        n.z = "0px", n.rotationY = n.rotationX = "0deg", n.force3D = 0, CS(t, n)
    },
    mi = "0deg",
    _s = "0px",
    vi = ") ",
    CS = function(t, n) {
        var r = n || this,
            i = r.xPercent,
            o = r.yPercent,
            s = r.x,
            l = r.y,
            a = r.z,
            u = r.rotation,
            f = r.rotationY,
            d = r.rotationX,
            h = r.skewX,
            y = r.skewY,
            _ = r.scaleX,
            v = r.scaleY,
            E = r.transformPerspective,
            m = r.force3D,
            g = r.target,
            S = r.zOrigin,
            x = "",
            P = m === "auto" && t && t !== 1 || m === !0;
        if (S && (d !== mi || f !== mi)) {
            var T = parseFloat(f) * Eo,
                L = Math.sin(T),
                b = Math.cos(T),
                N;
            T = parseFloat(d) * Eo, N = Math.cos(T), s = ud(g, s, L * N * -S), l = ud(g, l, -Math.sin(T) * -S), a = ud(g, a, b * N * -S + S)
        }
        E !== _s && (x += "perspective(" + E + vi), (i || o) && (x += "translate(" + i + "%, " + o + "%) "), (P || s !== _s || l !== _s || a !== _s) && (x += a !== _s || P ? "translate3d(" + s + ", " + l + ", " + a + ") " : "translate(" + s + ", " + l + vi), u !== mi && (x += "rotate(" + u + vi), f !== mi && (x += "rotateY(" + f + vi), d !== mi && (x += "rotateX(" + d + vi), (h !== mi || y !== mi) && (x += "skew(" + h + ", " + y + vi), (_ !== 1 || v !== 1) && (x += "scale(" + _ + ", " + v + vi), g.style[Fe] = x || "translate(0, 0)"
    },
    W4 = function(t, n) {
        var r = n || this,
            i = r.xPercent,
            o = r.yPercent,
            s = r.x,
            l = r.y,
            a = r.rotation,
            u = r.skewX,
            f = r.skewY,
            d = r.scaleX,
            h = r.scaleY,
            y = r.target,
            _ = r.xOrigin,
            v = r.yOrigin,
            E = r.xOffset,
            m = r.yOffset,
            g = r.forceCSS,
            S = parseFloat(s),
            x = parseFloat(l),
            P, T, L, b, N;
        a = parseFloat(a), u = parseFloat(u), f = parseFloat(f), f && (f = parseFloat(f), u += f, a += f), a || u ? (a *= Eo, u *= Eo, P = Math.cos(a) * d, T = Math.sin(a) * d, L = Math.sin(a - u) * -h, b = Math.cos(a - u) * h, u && (f *= Eo, N = Math.tan(u - f), N = Math.sqrt(1 + N * N), L *= N, b *= N, f && (N = Math.tan(f), N = Math.sqrt(1 + N * N), P *= N, T *= N)), P = Ye(P), T = Ye(T), L = Ye(L), b = Ye(b)) : (P = d, b = h, T = L = 0), (S && !~(s + "").indexOf("px") || x && !~(l + "").indexOf("px")) && (S = ti(y, "x", s, "px"), x = ti(y, "y", l, "px")), (_ || v || E || m) && (S = Ye(S + _ - (_ * P + v * L) + E), x = Ye(x + v - (_ * T + v * b) + m)), (i || o) && (N = y.getBBox(), S = Ye(S + i / 100 * N.width), x = Ye(x + o / 100 * N.height)), N = "matrix(" + P + "," + T + "," + L + "," + b + "," + S + "," + x + ")", y.setAttribute("transform", N), g && (y.style[Fe] = N)
    },
    G4 = function(t, n, r, i, o) {
        var s = 360,
            l = ct(o),
            a = parseFloat(o) * (l && ~o.indexOf("rad") ? _i : 1),
            u = a - i,
            f = i + u + "deg",
            d, h;
        return l && (d = o.split("_")[1], d === "short" && (u %= s, u !== u % (s / 2) && (u += u < 0 ? s : -s)), d === "cw" && u < 0 ? u = (u + s * m1) % s - ~~(u / s) * s : d === "ccw" && u > 0 && (u = (u - s * m1) % s - ~~(u / s) * s)), t._pt = h = new Wt(t._pt, n, r, i, u, M4), h.e = f, h.u = "deg", t._props.push(r), h
    },
    w1 = function(t, n) {
        for (var r in n) t[r] = n[r];
        return t
    },
    Y4 = function(t, n, r) {
        var i = w1({}, r._gsap),
            o = "perspective,force3D,transformOrigin,svgOrigin",
            s = r.style,
            l, a, u, f, d, h, y, _;
        i.svg ? (u = r.getAttribute("transform"), r.setAttribute("transform", ""), s[Fe] = n, l = dl(r, 1), cl(r, Fe), r.setAttribute("transform", u)) : (u = getComputedStyle(r)[Fe], s[Fe] = n, l = dl(r, 1), s[Fe] = u);
        for (a in wr) u = i[a], f = l[a], u !== f && o.indexOf(a) < 0 && (y = Ct(u), _ = Ct(f), d = y !== _ ? ti(r, a, u, _) : parseFloat(u), h = parseFloat(f), t._pt = new Wt(t._pt, l, a, d, h - d, xp), t._pt.u = _ || 0, t._props.push(a));
        w1(l, i)
    };
Ht("padding,margin,Width,Radius", function(e, t) {
    var n = "Top",
        r = "Right",
        i = "Bottom",
        o = "Left",
        s = (t < 3 ? [n, r, i, o] : [n + o, n + r, i + r, i + o]).map(function(l) {
            return t < 2 ? e + l : "border" + l + e
        });
    Su[t > 1 ? "border" + e : e] = function(l, a, u, f, d) {
        var h, y;
        if (arguments.length < 4) return h = s.map(function(_) {
            return fr(l, _, u)
        }), y = h.join(" "), y.split(h[0]).length === 5 ? h[0] : y;
        h = (f + "").split(" "), y = {}, s.forEach(function(_, v) {
            return y[_] = h[v] = h[v] || h[(v - 1) / 2 | 0]
        }), l.init(a, y, d)
    }
});
var TS = {
    name: "css",
    register: Cp,
    targetTest: function(t) {
        return t.style && t.nodeType
    },
    init: function(t, n, r, i, o) {
        var s = this._props,
            l = t.style,
            a = r.vars.startAt,
            u, f, d, h, y, _, v, E, m, g, S, x, P, T, L, b;
        qh || Cp(), this.styles = this.styles || yS(t), b = this.styles.props, this.tween = r;
        for (v in n)
            if (v !== "autoRound" && (f = n[v], !(Zt[v] && lS(v, n, r, i, t, o)))) {
                if (y = typeof f, _ = Su[v], y === "function" && (f = f.call(r, i, t, o), y = typeof f), y === "string" && ~f.indexOf("random(") && (f = al(f)), _) _(this, t, v, f, r) && (L = 1);
                else if (v.substr(0, 2) === "--") u = (getComputedStyle(t).getPropertyValue(v) + "").trim(), f += "", Qr.lastIndex = 0, Qr.test(u) || (E = Ct(u), m = Ct(f)), m ? E !== m && (u = ti(t, v, u, m) + m) : E && (f += E), this.add(l, "setProperty", u, f, i, o, 0, 0, v), s.push(v), b.push(v, 0, l[v]);
                else if (y !== "undefined") {
                    if (a && v in a ? (u = typeof a[v] == "function" ? a[v].call(r, i, t, o) : a[v], ct(u) && ~u.indexOf("random(") && (u = al(u)), Ct(u + "") || (u += nn.units[v] || Ct(fr(t, v)) || ""), (u + "").charAt(1) === "=" && (u = fr(t, v))) : u = fr(t, v), h = parseFloat(u), g = y === "string" && f.charAt(1) === "=" && f.substr(0, 2), g && (f = f.substr(2)), d = parseFloat(f), v in Gn && (v === "autoAlpha" && (h === 1 && fr(t, "visibility") === "hidden" && d && (h = 0), b.push("visibility", 0, l.visibility), jr(this, l, "visibility", h ? "inherit" : "hidden", d ? "inherit" : "hidden", !d)), v !== "scale" && v !== "transform" && (v = Gn[v], ~v.indexOf(",") && (v = v.split(",")[0]))), S = v in wr, S) {
                        if (this.styles.save(v), x || (P = t._gsap, P.renderTransform && !n.parseTransform || dl(t, n.parseTransform), T = n.smoothOrigin !== !1 && P.smooth, x = this._pt = new Wt(this._pt, l, Fe, 0, 1, P.renderTransform, P, 0, -1), x.dep = 1), v === "scale") this._pt = new Wt(this._pt, P, "scaleY", P.scaleY, (g ? wo(P.scaleY, g + d) : d) - P.scaleY || 0, xp), this._pt.u = 0, s.push("scaleY", v), v += "X";
                        else if (v === "transformOrigin") {
                            b.push(An, 0, l[An]), f = U4(f), P.svg ? Tp(t, f, 0, T, 0, this) : (m = parseFloat(f.split(" ")[2]) || 0, m !== P.zOrigin && jr(this, P, "zOrigin", P.zOrigin, m), jr(this, l, v, wu(u), wu(f)));
                            continue
                        } else if (v === "svgOrigin") {
                            Tp(t, f, 1, T, 0, this);
                            continue
                        } else if (v in xS) {
                            G4(this, P, v, h, g ? wo(h, g + f) : f);
                            continue
                        } else if (v === "smoothOrigin") {
                            jr(this, P, "smooth", P.smooth, f);
                            continue
                        } else if (v === "force3D") {
                            P[v] = f;
                            continue
                        } else if (v === "transform") {
                            Y4(this, f, t);
                            continue
                        }
                    } else v in l || (v = jo(v) || v);
                    if (S || (d || d === 0) && (h || h === 0) && !b4.test(f) && v in l) E = (u + "").substr((h + "").length), d || (d = 0), m = Ct(f) || (v in nn.units ? nn.units[v] : E), E !== m && (h = ti(t, v, u, m)), this._pt = new Wt(this._pt, S ? P : l, v, h, (g ? wo(h, g + d) : d) - h, !S && (m === "px" || v === "zIndex") && n.autoRound !== !1 ? L4 : xp), this._pt.u = m || 0, E !== m && m !== "%" && (this._pt.b = u, this._pt.r = O4);
                    else if (v in l) V4.call(this, t, v, u, g ? g + f : f);
                    else if (v in t) this.add(t, v, u || t[v], g ? g + f : f, i, o);
                    else if (v !== "parseTransform") {
                        jh(v, f);
                        continue
                    }
                    S || (v in l ? b.push(v, 0, l[v]) : b.push(v, 1, u || t[v])), s.push(v)
                }
            }
        L && pS(this)
    },
    render: function(t, n) {
        if (n.tween._time || !Kh())
            for (var r = n._pt; r;) r.r(t, r.d), r = r._next;
        else n.styles.revert()
    },
    get: fr,
    aliases: Gn,
    getSetter: function(t, n, r) {
        var i = Gn[n];
        return i && i.indexOf(",") < 0 && (n = i), n in wr && n !== An && (t._gsap.x || fr(t, "x")) ? r && h1 === r ? n === "scale" ? D4 : R4 : (h1 = r || {}) && (n === "scale" ? z4 : I4) : t.style && !Ih(t.style[n]) ? N4 : ~n.indexOf("-") ? A4 : Yh(t, n)
    },
    core: {
        _removeProperty: cl,
        _getMatrix: Zh
    }
};
Gt.utils.checkPrefix = jo;
Gt.core.getStyleSaver = yS;
(function(e, t, n, r) {
    var i = Ht(e + "," + t + "," + n, function(o) {
        wr[o] = 1
    });
    Ht(t, function(o) {
        nn.units[o] = "deg", xS[o] = 1
    }), Gn[i[13]] = e + "," + t, Ht(r, function(o) {
        var s = o.split(":");
        Gn[s[1]] = i[s[0]]
    })
})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent", "rotation,rotationX,rotationY,skewX,skewY", "transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", "0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");
Ht("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(e) {
    nn.units[e] = "px"
});
Gt.registerPlugin(TS);
var Lt = Gt.registerPlugin(TS) || Gt;
Lt.core.Tween;
const X4 = {
        async getAll() {
            return (await Mh.get(`${Oh}/albums`)).data
        }
    },
    cd = e => {
        const t = e.split("-"),
            n = t[0],
            r = o(t[1]),
            i = t[2];

        function o(s) {
            switch (s) {
                case "01":
                    return "January";
                case "02":
                    return "February";
                case "03":
                    return "March";
                case "04":
                    return "April";
                case "05":
                    return "May";
                case "06":
                    return "June";
                case "07":
                    return "July";
                case "08":
                    return "August";
                case "09":
                    return "September";
                case "10":
                    return "October";
                case "11":
                    return "November";
                case "12":
                    return "December"
            }
        }
        return {
            year: n,
            month: r,
            day: i
        }
    },
    q4 = () => {
        const [e, t] = R.useState(), [n, r] = R.useState(), [i, o] = R.useState(), [s, l] = R.useState(!1), [a, u] = R.useState(), [f, d] = R.useState(), h = R.useRef(null), y = R.useRef(null), _ = R.useRef(null), v = R.useRef(null), E = R.useRef(null), m = R.useRef(null), g = R.useRef(null), S = R.useRef(null);
        R.useEffect(() => {
            async function P() {
                const T = await X4.getAll();
                T.results && t(T.results)
            }
            P()
        }, []), R.useEffect(() => {
            var P, T;
            if (m.current && v.current && E.current && g.current && e) {
                const L = (P = v.current) == null ? void 0 : P.querySelectorAll(".s-char"),
                    b = E.current.querySelectorAll("div"),
                    N = g.current.querySelectorAll(".album");
                Array.from(b).forEach((H, A) => H.style.transitionDelay = `${(A+1)*.015}s`), Lt.set(m.current, {
                    opacity: 0,
                    y: "50%"
                }), ScrollTrigger.create({
                    start: "top top+=100%",
                    onUpdate: H => console.log(H.progress),
                    trigger: document.querySelector(".realeses"),
                    scroller: (T = document.querySelector(".home")) == null ? void 0 : T.querySelector(".fp-overflow"),
                    onEnter: () => {
                        m.current && v.current && E.current && (setTimeout(() => l(!0), 2e3), Array.from(L).map((H, A) => {
                            Lt.to(H, {
                                opacity: 1,
                                rotate: 0,
                                y: 0
                            })
                        }), Array.from(b).map((H, A) => {
                            Lt.to(H, {
                                opacity: 1,
                                rotate: 0,
                                y: 0
                            })
                        }), Array.from(N).map((H, A) => {
                            Lt.to(H, {
                                opacity: 1
                            })
                        }), Lt.to(m.current, {
                            opacity: 1,
                            y: 0,
                            duration: 1,
                            delay: .75
                        }))
                    }
                })
            }
        }, [e]), R.useEffect(() => {
            typeof n < "u" && !a && e && setTimeout(() => !a && o(e[n]), 250)
        }, [a, n, a]), R.useEffect(() => {
            typeof n < "u" && e && S.current && (a || (S.current.classList.contains(`${et.hovered}`) ? (S.current.classList.remove(`${et.hovered}`), u(!0), setTimeout(() => {
                var P;
                (P = S.current) == null || P.classList.add(`${et.hovered}`), u(!1)
            }, 1e3)) : S.current.classList.contains(`.${et.hovered}`) || (u(!0), S.current.classList.add(`${et.hovered}`), setTimeout(() => u(!1), 1e3))))
        }, [n, e]);
        const x = P => {
            r(P)
        };
        return O("section", {
            ref: S,
            className: de(et.realeses, "realeses"),
            children: oe("div", {
                className: et.container,
                children: [oe("div", {
                    className: et.desc,
                    children: [oe("div", {
                        ref: v,
                        children: [O("h1", {
                            children: ht("Powered by", !0, !1)
                        }), O("h1", {
                            children: ht("Stem", !0, !1)
                        })]
                    }), oe("p", {
                        ref: E,
                        children: [ht("Listen to our official playlist, featuring", !1), ht("new music from Brent Faiyaz, Sabrina", !1), ht("Claudio, Veeze, + more", !1)]
                    }), O("div", {
                        ref: m,
                        children: O("a", {
                            href: "https://open.spotify.com/playlist/3gEjr8K3sxvrEbK3sau0Ci?si=3aff8984e1ec45d0",
                            target: "_blank",
                            children: oe(Ah, {
                                children: ["Listen on spotify", O("svg", {
                                    width: "16",
                                    height: "16",
                                    viewBox: "0 0 16 16",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: O("path", {
                                        d: "M8 0C3.58387 0 0 3.58387 0 8C0 12.4161 3.58387 16 8 16C12.4161 16 16 12.4161 16 8C16 3.58387 12.4161 0 8 0ZM11.2484 11.771C11.1129 11.771 11.029 11.729 10.9032 11.6548C8.89032 10.4419 6.54839 10.3903 4.23548 10.8645C4.10968 10.8968 3.94516 10.9484 3.85161 10.9484C3.53871 10.9484 3.34194 10.7 3.34194 10.4387C3.34194 10.1065 3.53871 9.94839 3.78064 9.89677C6.42258 9.3129 9.12258 9.36452 11.4258 10.7419C11.6226 10.8677 11.7387 10.9806 11.7387 11.2742C11.7387 11.5677 11.5097 11.771 11.2484 11.771ZM12.1161 9.65484C11.9484 9.65484 11.8355 9.58065 11.7194 9.51935C9.70323 8.32581 6.69677 7.84516 4.02258 8.57097C3.86774 8.6129 3.78387 8.65484 3.63871 8.65484C3.29355 8.65484 3.0129 8.37419 3.0129 8.02903C3.0129 7.68387 3.18065 7.45484 3.5129 7.36129C4.40968 7.10968 5.32581 6.92258 6.66774 6.92258C8.76129 6.92258 10.7839 7.44194 12.3774 8.39032C12.6387 8.54516 12.7419 8.74516 12.7419 9.02581C12.7387 9.37419 12.4677 9.65484 12.1161 9.65484ZM13.1161 7.19677C12.9484 7.19677 12.8452 7.15484 12.7 7.07097C10.4032 5.7 6.29677 5.37097 3.63871 6.1129C3.52258 6.14516 3.37742 6.19677 3.22258 6.19677C2.79677 6.19677 2.47097 5.86452 2.47097 5.43548C2.47097 4.99677 2.74194 4.74839 3.03226 4.66452C4.16774 4.33226 5.43871 4.17419 6.82258 4.17419C9.17742 4.17419 11.6452 4.66452 13.4484 5.71613C13.7 5.86129 13.8645 6.06129 13.8645 6.44516C13.8645 6.88387 13.5097 7.19677 13.1161 7.19677Z",
                                        fill: "white"
                                    })
                                })]
                            })
                        })
                    })]
                }), O("div", {
                    ref: g,
                    className: et.albums,
                    children: window.innerWidth > 768 ? O(Rh, {
                        onSwiper: P => d(P),
                        slidesPerView: 10,
                        className: "albums-swiper",
                        children: e && e.map((P, T) => O(Dh, {
                            children: O("div", {
                                id: P.title,
                                style: {
                                    zIndex: -(T + 1),
                                    translate: `${-55*(T+1)}% 0`,
                                    opacity: 0,
                                    transitionDelay: `${(T+1)*.05+.25}s`
                                },
                                className: de(et.album, n === T && et.hovered, "album"),
                                onMouseEnter: () => {
                                    s && x(T)
                                },
                                children: O("img", {
                                    className: et.cover,
                                    draggable: !1,
                                    src: pu(P.image),
                                    alt: P.title
                                })
                            }, T)
                        }, T))
                    }) : O(Kn, {
                        children: e && e.map((P, T) => O("div", {
                            style: {
                                zIndex: -(T + 1),
                                translate: `${-55*(T+1)}% 0`,
                                opacity: 0,
                                transitionDelay: `${(T+1)*.05+.25}s`
                            },
                            className: de(et.album, n === T && et.hovered, "album"),
                            onTouchStart: () => {
                                s && x(T)
                            },
                            children: O("div", {
                                draggable: !1,
                                style: {
                                    backgroundImage: `url(${pu(P.image)})`
                                },
                                className: et.cover
                            })
                        }, T))
                    })
                }), O("div", {
                    className: et.albumInfo,
                    children: i && oe(Kn, {
                        children: [O("h1", {
                            ref: h,
                            className: et.title,
                            children: i.title
                        }), O("h2", {
                            ref: y,
                            className: et.artist,
                            children: i.artist
                        }), oe("div", {
                            ref: _,
                            className: et.date,
                            children: [cd(i.release_date).month, " •", " ", cd(i.release_date).day, " •", " ", cd(i.release_date).year]
                        })]
                    })
                })]
            })
        })
    },
    K4 = "_videoOutter_bpvae_1",
    Q4 = "_introText_bpvae_10",
    Z4 = "_scrolled_bpvae_19",
    J4 = "_soundToggle_bpvae_29",
    e5 = "_video_bpvae_1",
    Ss = {
        videoOutter: K4,
        introText: Q4,
        scrolled: Z4,
        soundToggle: J4,
        video: e5
    },
    t5 = "_prompt_1u1dm_1",
    n5 = "_active_1u1dm_12",
    r5 = "_content_1u1dm_17",
    i5 = "_icon_1u1dm_31",
    wa = {
        prompt: t5,
        active: n5,
        content: r5,
        icon: i5
    },
    PS = ({
        text: e,
        icon: t,
        onClick: n,
        active: r
    }) => O("div", {
        onClick: () => n && n(),
        className: de(wa.prompt, r && wa.active, "prompt"),
        children: oe("div", {
            className: wa.content,
            children: [t && O("div", {
                className: wa.icon,
                children: O("img", {
                    src: t,
                    alt: ""
                })
            }), O("span", {
                children: e
            })]
        })
    }),
    o5 = () => {
        const {
            videoActive: e,
            activeScreen: t,
            setVideoActive: n
        } = R.useContext(Dn), [r, i] = R.useState(!0), o = R.useRef(null), s = R.useRef(null);
        return R.useEffect(() => {
            var l;
            s.current && ScrollTrigger.create({
                start: "top 60%",
                onUpdate: a => console.log(a.progress),
                trigger: document.querySelector("section.video"),
                scroller: (l = document.querySelector(".home")) == null ? void 0 : l.querySelector(".fp-overflow"),
                onEnter: () => {
                    s.current && s.current.classList.add(Ss.scrolled)
                }
            })
        }, []), R.useEffect(() => {
            o.current && Lt.set(o.current, {
                scale: .35,
                y: "25%"
            })
        }, []), R.useEffect(() => {
            o.current && ScrollTrigger.create({
                trigger: document.querySelector(".video"),
                scroller: document.querySelector(".home .fp-overflow"),
                start: "top 20%",
                end: "bottom bottom",
                scrub: 4,
                onUpdate: l => {
                    console.log(l.progress)
                },
                animation: Lt.fromTo(o.current, {
                    scale: .35,
                    y: "25%",
                    borderRadius: 25
                }, {
                    y: 0,
                    scale: 1,
                    ease: "cubic-bezier(0.45, 0, 0.55, 1)",
                    duration: 1.5,
                    borderRadius: 0
                }),
                onEnter: () => n(!0)
            })
        }, [e]), R.useEffect(() => {
            e && t === 1 && o.current && o.current.play()
        }, [e, t]), oe("section", {
            className: de(Ss.videoOutter, "section video"),
            children: [O("div", {
                className: Ss.introText,
                children: O("p", {
                    ref: s,
                    children: ht("Are  you even a distro company if you don`t have a super sweet sizzle reel?", !1, !1)
                })
            }), O("div", {
                onClick: () => {
                    window.innerWidth > 768 && window.fullpage_api.moveSectionDown()
                },
                className: de(Ss.video),
                children: O("video", {
                    className: "stem-video",
                    ref: o,
                    loop: !0,
                    autoPlay: window.innerWidth <= 768,
                    playsInline: !0,
                    muted: r,
                    children: O("source", {
                        src: "/videos/singer.mp4",
                        type: "video/mp4"
                    })
                })
            }), O("div", {
                className: Ss.soundToggle,
                children: O(PS, {
                    active: e && !0,
                    onClick: () => i(!r),
                    icon: "/images/icons/sound.svg",
                    text: `${window.innerWidth<=768?"Tap":"Click"} here for sound`
                })
            })]
        })
    },
    s5 = () => {
        const {
            setAnchorScrolling: e
        } = R.useContext(Dn);
        return oe("section", {
            className: de(ir.hero, "section home"),
            children: [O("div", {
                className: ir.container,
                children: oe("div", {
                    onClick: () => {
                        var t;
                        e(!0), (t = document.querySelector(".home .fp-overflow")) == null || t.scrollTo({
                            left: 0,
                            top: window.innerHeight,
                            behavior: "smooth"
                        }), setTimeout(() => e(!1), 1e3)
                    },
                    className: de(ir.content, "home-wrapper"),
                    children: [O("div", {
                        className: ir.block,
                        children: oe("div", {
                            className: ir.text,
                            children: [O("h1", {
                                children: ht("Unleash your")
                            }), O("h1", {
                                children: ht("anthem.")
                            })]
                        })
                    }), oe("div", {
                        className: de(ir.block, ir.blockRight),
                        children: [oe("div", {
                            className: ir.text,
                            children: [O("h1", {
                                children: ht("Own your")
                            }), O("h1", {
                                children: ht("sound.")
                            })]
                        }), oe("div", {
                            className: ir.text,
                            children: [O("h1", {
                                children: ht("Own your")
                            }), O("h1", {
                                children: ht("sound.")
                            })]
                        })]
                    })]
                })
            }), O("div", {
                className: "banner-wrapper static",
                children: O(p_, {})
            }), O(q4, {}), O(o5, {})]
        })
    },
    l5 = "_outterRecord_1edwh_1",
    a5 = "_word_1edwh_18",
    u5 = "_bg_1edwh_58",
    c5 = "_scrollPrompt_1edwh_108",
    f5 = "_disc_1edwh_115",
    d5 = "_container_1edwh_141",
    or = {
        outterRecord: l5,
        word: a5,
        bg: u5,
        scrollPrompt: c5,
        disc: f5,
        container: d5
    },
    p5 = () => {
        const {
            activeScreen: e,
            pageLoaded: t
        } = R.useContext(Dn), [n, r] = R.useState(!1), i = R.useRef(null), o = R.useRef(null), s = R.useRef(null), [l, a] = R.useState(!1), [u, f] = R.useState(0);
        R.useEffect(() => {
            i.current && s.current && o.current && (ScrollTrigger.create({
                trigger: i.current.querySelector(".fp-overflow"),
                scroller: i.current.querySelector(".fp-overflow"),
                start: "top top",
                end: "bottom -100%",
                scrub: 1,
                onUpdate: h => {
                    f(h.progress)
                },
                animation: Lt.fromTo(s.current, {
                    rotate: -400,
                    duration: 1,
                    scale: 2.5,
                    ease: "linear"
                }, {
                    rotate: 0,
                    duration: 2,
                    scale: 1,
                    ease: "linear"
                })
            }), ScrollTrigger.create({
                trigger: i.current.querySelector(".fp-overflow"),
                scroller: i.current.querySelector(".fp-overflow"),
                start: "top top",
                end: "bottom -100%",
                scrub: 1,
                onUpdate: h => {
                    f(h.progress)
                },
                animation: Lt.fromTo(o.current, {
                    scale: 2.5
                }, {
                    duration: 1,
                    scale: 1,
                    ease: "linear"
                })
            }))
        }, []), R.useEffect(() => {
            t && setTimeout(() => {
                a(!0)
            }, 2e3)
        }, [t]), R.useEffect(() => {
            l && u > 0 && n && r(!1)
        }, [l, u, n]), R.useEffect(() => {
            l && u === 0 && e === 0 && r(!0)
        }, [l]);
        const d = () => {
            if (i.current) {
                const h = i.current.querySelector(".fp-overflow");
                h && h.scrollTo({
                    left: 0,
                    top: document.body.offsetHeight * 2 - 1,
                    behavior: "smooth"
                })
            }
        };
        return oe("section", {
            ref: i,
            onClick: () => {
                u < 1 ? d() : u >= 1 && window.fullpage_api.moveSectionDown()
            },
            className: de(or.outterRecord, "section record"),
            children: [O("div", {
                ref: o,
                className: or.bg
            }), window.innerWidth > 768 && O("div", {
                className: de(or.scrollPrompt, "prompt"),
                children: O(PS, {
                    onClick: () => {
                        d(), r(!1)
                    },
                    active: n && !0,
                    icon: "/images/icons/scroll-to-enter.svg",
                    text: "Scroll to enter"
                })
            }), O("div", {
                ref: s,
                className: de(or.disc)
            }), O("span", {
                className: or.word,
                id: "word-1",
                children: "indie"
            }), O("span", {
                className: or.word,
                id: "word-2",
                children: "music"
            }), O("span", {
                className: or.word,
                id: "word-3",
                children: "sounds"
            }), O("span", {
                className: or.word,
                id: "word-4",
                children: "better"
            }), O("div", {
                className: or.container
            })]
        })
    },
    h5 = "_services_f3xeg_1",
    m5 = "_shadowWave_f3xeg_9",
    v5 = "_soundWaves_f3xeg_24",
    g5 = "_container_f3xeg_80",
    y5 = "_shadow_f3xeg_9",
    _5 = "_top_f3xeg_117",
    S5 = "_bottom_f3xeg_125",
    w5 = "_col_f3xeg_128",
    x5 = "_serviceBlock_f3xeg_159",
    E5 = "_info_f3xeg_168",
    C5 = "_servicesTabs_f3xeg_182",
    T5 = "_tab_f3xeg_191",
    Mt = {
        services: h5,
        shadowWave: m5,
        soundWaves: v5,
        container: g5,
        shadow: y5,
        top: _5,
        bottom: S5,
        col: w5,
        serviceBlock: x5,
        info: E5,
        servicesTabs: C5,
        tab: T5
    },
    P5 = "_soundWaves_71kja_1",
    k5 = "_linear_71kja_11",
    b5 = "_soundWave_71kja_1",
    M5 = "_paused_71kja_31",
    ws = {
        soundWaves: P5,
        linear: k5,
        soundWave: b5,
        paused: M5
    },
    O5 = ({
        qty: e,
        color: t,
        animate: n = !0,
        linear: r = !1
    }) => {
        const i = R.useRef(null),
            [o, s] = R.useState([]);
        R.useEffect(() => {
            if (e) {
                const a = [];
                for (let u = 0; u < e; u++) a.push(u);
                s(a)
            }
        }, []);

        function l() {
            return String(Math.random() * (.8 - .2) + .2)
        }
        return R.useEffect(() => {
            if (i.current && o) {
                let a = function() {
                    u.forEach(f => {
                        const d = n ? l() : "0";
                        f.style.setProperty("--peak", d)
                    })
                };
                const u = i.current.querySelectorAll("div");
                u.forEach(f => {
                    f.addEventListener("animationiteration", a)
                })
            }
        }, [o, n]), O("div", {
            ref: i,
            className: de(ws.soundWaves, r && ws.linear),
            children: o && o.map((a, u) => oe("div", {
                className: ws.soundWave,
                children: [O("div", {
                    className: n ? "" : ws.paused,
                    style: {
                        background: `${t}`
                    }
                }), O("div", {
                    className: n ? "" : ws.paused,
                    style: {
                        background: `${t}`
                    }
                })]
            }, u))
        })
    },
    x1 = [{
        name: "digital strategy",
        title: "Upload & Distribute Your Music",
        dataEqualizerColor: "linear-gradient(180deg, #B4E4C3 0%, rgba(180, 228, 195, 0.00) 54.69%)",
        dataBgColor: "#EB8A66",
        dataTextColor: "#FEBDBF",
        description: ["Determine where and how your music is experienced. Fully customize your release, platforms, territories—and determine how fan-generated content is monetized.", "Access our team of experts and lean on them to assist with roll out strategy and artist development. They’ll help you tap into our vast network of digital advertising agencies, brand partnerships, and more."]
    }, {
        name: "playlisting",
        title: "Playlist Promotion",
        dataEqualizerColor: "linear-gradient(180deg, #B4E4C3 0%, rgba(180, 228, 195, 0.00) 54.69%)",
        dataBgColor: "#2D63AD",
        dataTextColor: "#629BAC",
        description: ["Receive personalized guidance on your music pitching strategy.", "We help craft your story and preach it with you– our focus is generating impactful opportunities for your project."]
    }, {
        name: "data-driven insights",
        title: "Track Marketing & Financial Data",
        dataEqualizerColor: "linear-gradient(180deg, #B4E4C3 0%, rgba(180, 228, 195, 0.00) 54.69%)",
        dataBgColor: "#629BAC",
        dataTextColor: "#2D63AD",
        description: ["See personalized performance and revenue data visualized from each platform.", "Our business intelligence team will flag key indicators and dig deep into platform-specific insights."]
    }, {
        name: "financial tools",
        title: "Everyone Gets Paid Monthly",
        dataEqualizerColor: "linear-gradient(180deg, #B4E4C3 0%, rgba(180, 228, 195, 0.00) 54.69%)",
        dataBgColor: "#1E1E1E",
        dataTextColor: "#B4E4C3",
        description: ["Split earnings with your collaborators, and track and recoup your expenses. Each shareholder receives an individualized dashboard so they know exactly how much they’re getting paid and when.", "Rest easy knowing your team will be paid on time, every month."]
    }, {
        name: "creative control",
        title: "You're In Control",
        dataEqualizerColor: "linear-gradient(180deg, #B4E4C3 0%, rgba(180, 228, 195, 0.00) 54.69%)",
        dataBgColor: "#B4E4C3",
        dataTextColor: "#68A077",
        description: ["We won’t ever claim ownership of your music or dictate how you roll out your project.", "If you take an advance, our system enables you to work with the team that best suits you and your vision. No need to work within the bureaucracy of the major system."]
    }, {
        name: "flexible advances",
        title: "Set Your Terms",
        dataEqualizerColor: "linear-gradient(180deg, #B4E4C3 0%, rgba(180, 228, 195, 0.00) 54.69%)",
        dataBgColor: "#68A077",
        dataTextColor: "#B4E4C3",
        description: ["Get cash up-front and use it on whatever you need while retaining full ownership.", "Our advances are purposefully flexible. Fine tune the advance size and the payback speed to land on the right fee for your business. You decide how much of your income pays down your advance."]
    }],
    L5 = () => {
        const {
            activeScreen: e,
            fullpageInit: t
        } = R.useContext(Dn), [n, r] = R.useState("linear-gradient(180deg, #B4E4C3 0%, rgba(180, 228, 195, 0.00) 100%)"), [i, o] = R.useState("#B4E4C3"), [s, l] = R.useState(i), [a, u] = R.useState(!0), [f, d] = R.useState(0), [h, y] = R.useState(!1);
        R.useEffect(() => {
            e === 4 ? h || setTimeout(() => y(!0), 1250) : y(!1)
        }, [e]), R.useEffect(() => {
            l(i)
        }, [i]);
        const _ = R.useRef(null),
            v = R.useRef(null),
            E = R.useRef(null),
            m = R.useRef(null);
        return R.useEffect(() => console.log(t), [t]), R.useEffect(() => console.log(f), [f]), R.useEffect(() => {
            if (_.current) {
                const g = _.current.querySelectorAll(".block");
                Array.from(g).map((S, x) => {
                    if (_.current) {
                        const P = x === 0 ? "" : Array.from(g)[x - 1].dataset.textColor,
                            T = x === 0 ? "" : Array.from(g)[x - 1].dataset.bgColor;
                        ScrollTrigger.create({
                            trigger: S,
                            scroller: _.current.querySelector(".fp-overflow"),
                            start: "top 70%",
                            onUpdate: L => {
                                d(L.progress)
                            },
                            onEnter: () => {
                                S.dataset.bgColor && r(S.dataset.bgColor), S.dataset.textColor && o(S.dataset.textColor)
                            },
                            onLeaveBack: () => {
                                P && o(P), T && r(T)
                            }
                        }), ScrollTrigger.addEventListener("scrollStart", () => {}), ScrollTrigger.addEventListener("scrollEnd", () => {})
                    }
                })
            }
        }, [h]), R.useEffect(() => {
            v.current && E.current && (Lt.to(E.current, {
                background: `linear-gradient(0,${n} 22.92%, rgba(42, 82, 76, 0) 73.44%)`,
                ease: "linear",
                duration: .2
            }), Lt.to(v.current, {
                background: `linear-gradient(0deg, rgba(42, 82, 76, 0) 22.92%, ${n} 73.44%)`,
                ease: "linear",
                duration: .2
            }), Lt.to(m.current, {
                background: `linear-gradient(90deg, ${n} 0%, rgba(255, 255, 255, 0) 100%)`,
                ease: "linear",
                duration: .2
            }))
        }, [n]), oe("section", {
            style: {
                backgroundColor: `${n}`
            },
            ref: _,
            className: de("section services", Mt.services),
            children: [O("div", {
                ref: m,
                className: Mt.shadowWave
            }), O("div", {
                className: Mt.soundWaves,
                children: O(O5, {
                    animate: a,
                    color: s,
                    qty: 7
                })
            }), oe("div", {
                className: Mt.container,
                children: [O("div", {
                    ref: v,
                    className: de(Mt.shadow, Mt.top)
                }), O("div", {
                    ref: E,
                    className: de(Mt.shadow, Mt.bottom)
                }), oe("div", {
                    style: {
                        color: `${i}`
                    },
                    className: Mt.col,
                    children: [oe("div", {
                        "data-bg-color": "#68A077",
                        "data-text-color": "#B4E4C3",
                        className: de(Mt.info, "block"),
                        children: [oe("div", {
                            children: [O("h3", {
                                children: ht("Personalized")
                            }), O("h3", {
                                children: ht("global distribution")
                            })]
                        }), O("div", {
                            className: "stem-text",
                            children: ht("Leveraging technology with a human touch", !1)
                        }), O("div", {
                            className: de(Mt.servicesTabs, "services-tabs"),
                            children: x1.map((g, S) => O("div", {
                                style: {
                                    transitionDelay: `${(S+1)*.075+1}s`
                                },
                                className: "fade tab",
                                children: O("div", {
                                    style: {
                                        color: i
                                    },
                                    onClick: () => {
                                        const x = document.querySelector(`.${Mt.services} > div`);
                                        console.log(x), x == null || x.scrollTo({
                                            left: 0,
                                            top: Array.from(x.querySelectorAll(`.${Mt.serviceBlock}`))[S].getBoundingClientRect().y - 250,
                                            behavior: "smooth"
                                        })
                                    },
                                    className: de(Mt.tab, "fade service-tab"),
                                    children: g.name
                                }, S)
                            }, S))
                        })]
                    }), x1.map((g, S) => oe("div", {
                        "data-text-color": g.dataTextColor ? g.dataTextColor : "",
                        "data-bg-color": g.dataBgColor,
                        className: de(Mt.serviceBlock, "block"),
                        children: [O("h3", {
                            children: ht(g.title)
                        }), g.description.map((x, P) => O("p", {
                            className: "stem-text",
                            children: ht(x, !1)
                        }, P))]
                    }, S))]
                })]
            })]
        })
    },
    N5 = [O(p5, {}), O(s5, {}), O(L5, {}), O(mT, {})],
    A5 = () => O(Kn, {
        children: N5.map((e, t) => O(Ge.Fragment, {
            children: e
        }, t))
    }),
    R5 = [{
        path: "/",
        element: O(A5, {})
    }];
/**
 * @remix-run/router v1.6.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function xu() {
    return xu = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, xu.apply(this, arguments)
}
var Vr;
(function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
})(Vr || (Vr = {}));
const E1 = "popstate";

function D5(e) {
    e === void 0 && (e = {});

    function t(r, i) {
        let {
            pathname: o,
            search: s,
            hash: l
        } = r.location;
        return Pp("", {
            pathname: o,
            search: s,
            hash: l
        }, i.state && i.state.usr || null, i.state && i.state.key || "default")
    }

    function n(r, i) {
        return typeof i == "string" ? i : kS(i)
    }
    return I5(t, n, null, e)
}

function Yt(e, t) {
    if (e === !1 || e === null || typeof e > "u") throw new Error(t)
}

function Jh(e, t) {
    if (!e) {
        typeof console < "u" && console.warn(t);
        try {
            throw new Error(t)
        } catch {}
    }
}

function z5() {
    return Math.random().toString(36).substr(2, 8)
}

function C1(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t
    }
}

function Pp(e, t, n, r) {
    return n === void 0 && (n = null), xu({
        pathname: typeof e == "string" ? e : e.pathname,
        search: "",
        hash: ""
    }, typeof t == "string" ? qu(t) : t, {
        state: n,
        key: t && t.key || r || z5()
    })
}

function kS(e) {
    let {
        pathname: t = "/",
        search: n = "",
        hash: r = ""
    } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t
}

function qu(e) {
    let t = {};
    if (e) {
        let n = e.indexOf("#");
        n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
        let r = e.indexOf("?");
        r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
    }
    return t
}

function I5(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        window: i = document.defaultView,
        v5Compat: o = !1
    } = r, s = i.history, l = Vr.Pop, a = null, u = f();
    u == null && (u = 0, s.replaceState(xu({}, s.state, {
        idx: u
    }), ""));

    function f() {
        return (s.state || {
            idx: null
        }).idx
    }

    function d() {
        l = Vr.Pop;
        let E = f(),
            m = E == null ? null : E - u;
        u = E, a && a({
            action: l,
            location: v.location,
            delta: m
        })
    }

    function h(E, m) {
        l = Vr.Push;
        let g = Pp(v.location, E, m);
        n && n(g, E), u = f() + 1;
        let S = C1(g, u),
            x = v.createHref(g);
        try {
            s.pushState(S, "", x)
        } catch {
            i.location.assign(x)
        }
        o && a && a({
            action: l,
            location: v.location,
            delta: 1
        })
    }

    function y(E, m) {
        l = Vr.Replace;
        let g = Pp(v.location, E, m);
        n && n(g, E), u = f();
        let S = C1(g, u),
            x = v.createHref(g);
        s.replaceState(S, "", x), o && a && a({
            action: l,
            location: v.location,
            delta: 0
        })
    }

    function _(E) {
        let m = i.location.origin !== "null" ? i.location.origin : i.location.href,
            g = typeof E == "string" ? E : kS(E);
        return Yt(m, "No window.location.(origin|href) available to create URL for href: " + g), new URL(g, m)
    }
    let v = {
        get action() {
            return l
        },
        get location() {
            return e(i, s)
        },
        listen(E) {
            if (a) throw new Error("A history only accepts one active listener");
            return i.addEventListener(E1, d), a = E, () => {
                i.removeEventListener(E1, d), a = null
            }
        },
        createHref(E) {
            return t(i, E)
        },
        createURL: _,
        encodeLocation(E) {
            let m = _(E);
            return {
                pathname: m.pathname,
                search: m.search,
                hash: m.hash
            }
        },
        push: h,
        replace: y,
        go(E) {
            return s.go(E)
        }
    };
    return v
}
var T1;
(function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
})(T1 || (T1 = {}));

function F5(e, t, n) {
    n === void 0 && (n = "/");
    let r = typeof t == "string" ? qu(t) : t,
        i = OS(r.pathname || "/", n);
    if (i == null) return null;
    let o = bS(e);
    B5(o);
    let s = null;
    for (let l = 0; s == null && l < o.length; ++l) s = X5(o[l], Q5(i));
    return s
}

function bS(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let i = (o, s, l) => {
        let a = {
            relativePath: l === void 0 ? o.path || "" : l,
            caseSensitive: o.caseSensitive === !0,
            childrenIndex: s,
            route: o
        };
        a.relativePath.startsWith("/") && (Yt(a.relativePath.startsWith(r), 'Absolute route path "' + a.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), a.relativePath = a.relativePath.slice(r.length));
        let u = Co([r, a.relativePath]),
            f = n.concat(a);
        o.children && o.children.length > 0 && (Yt(o.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + u + '".')), bS(o.children, t, f, u)), !(o.path == null && !o.index) && t.push({
            path: u,
            score: G5(u, o.index),
            routesMeta: f
        })
    };
    return e.forEach((o, s) => {
        var l;
        if (o.path === "" || !((l = o.path) != null && l.includes("?"))) i(o, s);
        else
            for (let a of MS(o.path)) i(o, s, a)
    }), t
}

function MS(e) {
    let t = e.split("/");
    if (t.length === 0) return [];
    let [n, ...r] = t, i = n.endsWith("?"), o = n.replace(/\?$/, "");
    if (r.length === 0) return i ? [o, ""] : [o];
    let s = MS(r.join("/")),
        l = [];
    return l.push(...s.map(a => a === "" ? o : [o, a].join("/"))), i && l.push(...s), l.map(a => e.startsWith("/") && a === "" ? "/" : a)
}

function B5(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : Y5(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex)))
}
const j5 = /^:\w+$/,
    V5 = 3,
    U5 = 2,
    $5 = 1,
    H5 = 10,
    W5 = -2,
    P1 = e => e === "*";

function G5(e, t) {
    let n = e.split("/"),
        r = n.length;
    return n.some(P1) && (r += W5), t && (r += U5), n.filter(i => !P1(i)).reduce((i, o) => i + (j5.test(o) ? V5 : o === "" ? $5 : H5), r)
}

function Y5(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, i) => r === t[i]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function X5(e, t) {
    let {
        routesMeta: n
    } = e, r = {}, i = "/", o = [];
    for (let s = 0; s < n.length; ++s) {
        let l = n[s],
            a = s === n.length - 1,
            u = i === "/" ? t : t.slice(i.length) || "/",
            f = q5({
                path: l.relativePath,
                caseSensitive: l.caseSensitive,
                end: a
            }, u);
        if (!f) return null;
        Object.assign(r, f.params);
        let d = l.route;
        o.push({
            params: r,
            pathname: Co([i, f.pathname]),
            pathnameBase: J5(Co([i, f.pathnameBase])),
            route: d
        }), f.pathnameBase !== "/" && (i = Co([i, f.pathnameBase]))
    }
    return o
}

function q5(e, t) {
    typeof e == "string" && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = K5(e.path, e.caseSensitive, e.end), i = t.match(n);
    if (!i) return null;
    let o = i[0],
        s = o.replace(/(.)\/+$/, "$1"),
        l = i.slice(1);
    return {
        params: r.reduce((u, f, d) => {
            if (f === "*") {
                let h = l[d] || "";
                s = o.slice(0, o.length - h.length).replace(/(.)\/+$/, "$1")
            }
            return u[f] = Z5(l[d] || "", f), u
        }, {}),
        pathname: o,
        pathnameBase: s,
        pattern: e
    }
}

function K5(e, t, n) {
    t === void 0 && (t = !1), n === void 0 && (n = !0), Jh(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [],
        i = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^$?{}|()[\]]/g, "\\$&").replace(/\/:(\w+)/g, (s, l) => (r.push(l), "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push("*"), i += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? i += "\\/*$" : e !== "" && e !== "/" && (i += "(?:(?=\\/|$))"), [new RegExp(i, t ? void 0 : "i"), r]
}

function Q5(e) {
    try {
        return decodeURI(e)
    } catch (t) {
        return Jh(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e
    }
}

function Z5(e, t) {
    try {
        return decodeURIComponent(e)
    } catch (n) {
        return Jh(!1, 'The value for the URL param "' + t + '" will not be decoded because' + (' the string "' + e + '" is a malformed URL segment. This is probably') + (" due to a bad percent encoding (" + n + ").")), e
    }
}

function OS(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/"
}
const Co = e => e.join("/").replace(/\/\/+/g, "/"),
    J5 = e => e.replace(/\/+$/, "").replace(/^\/*/, "/");

function e8(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e
}
const LS = ["post", "put", "patch", "delete"];
new Set(LS);
const t8 = ["get", ...LS];
new Set(t8);
/**
 * React Router v6.11.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function kp() {
    return kp = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, kp.apply(this, arguments)
}
const n8 = R.createContext(null),
    r8 = R.createContext(null),
    NS = R.createContext(null),
    Ku = R.createContext(null),
    Qu = R.createContext({
        outlet: null,
        matches: [],
        isDataRoute: !1
    }),
    AS = R.createContext(null);

function em() {
    return R.useContext(Ku) != null
}

function i8() {
    return em() || Yt(!1), R.useContext(Ku).location
}

function o8(e, t) {
    return s8(e, t)
}

function s8(e, t, n) {
    em() || Yt(!1);
    let {
        navigator: r
    } = R.useContext(NS), {
        matches: i
    } = R.useContext(Qu), o = i[i.length - 1], s = o ? o.params : {};
    o && o.pathname;
    let l = o ? o.pathnameBase : "/";
    o && o.route;
    let a = i8(),
        u;
    if (t) {
        var f;
        let v = typeof t == "string" ? qu(t) : t;
        l === "/" || (f = v.pathname) != null && f.startsWith(l) || Yt(!1), u = v
    } else u = a;
    let d = u.pathname || "/",
        h = l === "/" ? d : d.slice(l.length) || "/",
        y = F5(e, {
            pathname: h
        }),
        _ = f8(y && y.map(v => Object.assign({}, v, {
            params: Object.assign({}, s, v.params),
            pathname: Co([l, r.encodeLocation ? r.encodeLocation(v.pathname).pathname : v.pathname]),
            pathnameBase: v.pathnameBase === "/" ? l : Co([l, r.encodeLocation ? r.encodeLocation(v.pathnameBase).pathname : v.pathnameBase])
        })), i, n);
    return t && _ ? R.createElement(Ku.Provider, {
        value: {
            location: kp({
                pathname: "/",
                search: "",
                hash: "",
                state: null,
                key: "default"
            }, u),
            navigationType: Vr.Pop
        }
    }, _) : _
}

function l8() {
    let e = m8(),
        t = e8(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        i = {
            padding: "0.5rem",
            backgroundColor: "rgba(200,200,200, 0.5)"
        },
        o = null;
    return R.createElement(R.Fragment, null, R.createElement("h2", null, "Unexpected Application Error!"), R.createElement("h3", {
        style: {
            fontStyle: "italic"
        }
    }, t), n ? R.createElement("pre", {
        style: i
    }, n) : null, o)
}
const a8 = R.createElement(l8, null);
class u8 extends R.Component {
    constructor(t) {
        super(t), this.state = {
            location: t.location,
            revalidation: t.revalidation,
            error: t.error
        }
    }
    static getDerivedStateFromError(t) {
        return {
            error: t
        }
    }
    static getDerivedStateFromProps(t, n) {
        return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
            error: t.error,
            location: t.location,
            revalidation: t.revalidation
        } : {
            error: t.error || n.error,
            location: n.location,
            revalidation: t.revalidation || n.revalidation
        }
    }
    componentDidCatch(t, n) {
        console.error("React Router caught the following error during render", t, n)
    }
    render() {
        return this.state.error ? R.createElement(Qu.Provider, {
            value: this.props.routeContext
        }, R.createElement(AS.Provider, {
            value: this.state.error,
            children: this.props.component
        })) : this.props.children
    }
}

function c8(e) {
    let {
        routeContext: t,
        match: n,
        children: r
    } = e, i = R.useContext(n8);
    return i && i.static && i.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (i.staticContext._deepestRenderedBoundaryId = n.route.id), R.createElement(Qu.Provider, {
        value: t
    }, r)
}

function f8(e, t, n) {
    var r;
    if (t === void 0 && (t = []), n === void 0 && (n = null), e == null) {
        var i;
        if ((i = n) != null && i.errors) e = n.matches;
        else return null
    }
    let o = e,
        s = (r = n) == null ? void 0 : r.errors;
    if (s != null) {
        let l = o.findIndex(a => a.route.id && (s == null ? void 0 : s[a.route.id]));
        l >= 0 || Yt(!1), o = o.slice(0, Math.min(o.length, l + 1))
    }
    return o.reduceRight((l, a, u) => {
        let f = a.route.id ? s == null ? void 0 : s[a.route.id] : null,
            d = null;
        n && (d = a.route.errorElement || a8);
        let h = t.concat(o.slice(0, u + 1)),
            y = () => {
                let _;
                return f ? _ = d : a.route.Component ? _ = R.createElement(a.route.Component, null) : a.route.element ? _ = a.route.element : _ = l, R.createElement(c8, {
                    match: a,
                    routeContext: {
                        outlet: l,
                        matches: h,
                        isDataRoute: n != null
                    },
                    children: _
                })
            };
        return n && (a.route.ErrorBoundary || a.route.errorElement || u === 0) ? R.createElement(u8, {
            location: n.location,
            revalidation: n.revalidation,
            component: d,
            error: f,
            children: y(),
            routeContext: {
                outlet: null,
                matches: h,
                isDataRoute: !0
            }
        }) : y()
    }, null)
}
var k1;
(function(e) {
    e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate"
})(k1 || (k1 = {}));
var Eu;
(function(e) {
    e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId"
})(Eu || (Eu = {}));

function d8(e) {
    let t = R.useContext(r8);
    return t || Yt(!1), t
}

function p8(e) {
    let t = R.useContext(Qu);
    return t || Yt(!1), t
}

function h8(e) {
    let t = p8(),
        n = t.matches[t.matches.length - 1];
    return n.route.id || Yt(!1), n.route.id
}

function m8() {
    var e;
    let t = R.useContext(AS),
        n = d8(Eu.UseRouteError),
        r = h8(Eu.UseRouteError);
    return t || ((e = n.errors) == null ? void 0 : e[r])
}

function RS(e) {
    Yt(!1)
}

function v8(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: i = Vr.Pop,
        navigator: o,
        static: s = !1
    } = e;
    em() && Yt(!1);
    let l = t.replace(/^\/*/, "/"),
        a = R.useMemo(() => ({
            basename: l,
            navigator: o,
            static: s
        }), [l, o, s]);
    typeof r == "string" && (r = qu(r));
    let {
        pathname: u = "/",
        search: f = "",
        hash: d = "",
        state: h = null,
        key: y = "default"
    } = r, _ = R.useMemo(() => {
        let v = OS(u, l);
        return v == null ? null : {
            location: {
                pathname: v,
                search: f,
                hash: d,
                state: h,
                key: y
            },
            navigationType: i
        }
    }, [l, u, f, d, h, y, i]);
    return _ == null ? null : R.createElement(NS.Provider, {
        value: a
    }, R.createElement(Ku.Provider, {
        children: n,
        value: _
    }))
}

function g8(e) {
    let {
        children: t,
        location: n
    } = e;
    return o8(bp(t), n)
}
var b1;
(function(e) {
    e[e.pending = 0] = "pending", e[e.success = 1] = "success", e[e.error = 2] = "error"
})(b1 || (b1 = {}));
new Promise(() => {});

function bp(e, t) {
    t === void 0 && (t = []);
    let n = [];
    return R.Children.forEach(e, (r, i) => {
        if (!R.isValidElement(r)) return;
        let o = [...t, i];
        if (r.type === R.Fragment) {
            n.push.apply(n, bp(r.props.children, o));
            return
        }
        r.type !== RS && Yt(!1), !r.props.index || !r.props.children || Yt(!1);
        let s = {
            id: r.props.id || o.join("-"),
            caseSensitive: r.props.caseSensitive,
            element: r.props.element,
            Component: r.props.Component,
            index: r.props.index,
            path: r.props.path,
            loader: r.props.loader,
            action: r.props.action,
            errorElement: r.props.errorElement,
            ErrorBoundary: r.props.ErrorBoundary,
            hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null,
            shouldRevalidate: r.props.shouldRevalidate,
            handle: r.props.handle,
            lazy: r.props.lazy
        };
        r.props.children && (s.children = bp(r.props.children, o)), n.push(s)
    }), n
}
/**
 * React Router DOM v6.11.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function y8(e) {
    let {
        basename: t,
        children: n,
        window: r
    } = e, i = R.useRef();
    i.current == null && (i.current = D5({
        window: r,
        v5Compat: !0
    }));
    let o = i.current,
        [s, l] = R.useState({
            action: o.action,
            location: o.location
        });
    return R.useLayoutEffect(() => o.listen(l), [o]), R.createElement(v8, {
        basename: t,
        children: n,
        location: s.location,
        navigationType: s.action,
        navigator: o
    })
}
var M1;
(function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmitImpl = "useSubmitImpl", e.UseFetcher = "useFetcher"
})(M1 || (M1 = {}));
var O1;
(function(e) {
    e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
})(O1 || (O1 = {}));
const _8 = ({
        children: e
    }) => O(y8, {
        children: O(g8, {
            children: e
        })
    }),
    S8 = "_loadingScreen_i8n2u_1",
    w8 = "_loaded_i8n2u_16",
    x8 = "_curtain_i8n2u_19",
    E8 = "_blinkingLogo_i8n2u_22",
    C8 = "_soundWrap_i8n2u_22",
    T8 = "_curtains_i8n2u_29",
    P8 = "_wave_i8n2u_98",
    k8 = "_soundWaveDeep_i8n2u_1",
    b8 = "_soundWave_i8n2u_1",
    dt = {
        loadingScreen: S8,
        loaded: w8,
        curtain: x8,
        blinkingLogo: E8,
        soundWrap: C8,
        curtains: T8,
        wave: P8,
        soundWaveDeep: k8,
        soundWave: b8
    };

function M8(e) {
    const {
        onChange: t
    } = e;
    let n = [...Array.from(document.images), ...Array.from(document.getElementsByTagName("video"))],
        r = n.length,
        i = 0;
    for (let s of n) {
        let l = !1,
            a = "";
        if (s instanceof HTMLImageElement ? (l = s.complete, a = "load") : s instanceof HTMLVideoElement && (l = !!s.duration, a = "canplay"), l) {
            t(++i, !1);
            continue
        }
        s.addEventListener(a, o)
    }

    function o() {
        if (this.getAttribute("data-loaded")) return;
        this.setAttribute("data-loaded", ""), ++i;
        let s = i / r * 100;
        t(s, s === 100)
    }
}
const O8 = () => {
        const {
            pageLoaded: e,
            setPageLoaded: t
        } = R.useContext(Dn), [n, r] = R.useState(0), [i, o] = R.useState(!1);
        return R.useEffect(() => {
            M8({
                onChange(s, l) {
                    r(s)
                }
            })
        }, []), R.useEffect(() => {
            n >= 100 && !e && (setTimeout(() => t(!0), 2250), setTimeout(() => o(!0), 4e3))
        }, [n]), O("div", {
            className: de(dt.loadingScreen, e && dt.loaded, "preloader"),
            children: !i && oe(Kn, {
                children: [oe("div", {
                    className: dt.curtains,
                    children: [O("div", {
                        className: dt.curtain
                    }), O("div", {
                        className: dt.curtain
                    }), O("div", {
                        className: dt.curtain
                    }), O("div", {
                        className: dt.curtain
                    }), O("div", {
                        className: dt.curtain
                    })]
                }), oe("div", {
                    className: dt.blinkingLogo,
                    children: [O("div", {
                        className: dt.soundWrap,
                        children: O("div", {
                            className: dt.wave,
                            children: O("div", {})
                        })
                    }), O("div", {
                        className: dt.soundWrap,
                        children: O("div", {
                            className: dt.wave,
                            children: O("div", {})
                        })
                    }), O("div", {
                        className: dt.soundWrap,
                        children: O("div", {
                            className: dt.wave,
                            children: O("div", {})
                        })
                    }), O("div", {
                        className: dt.soundWrap,
                        children: O("div", {
                            className: dt.wave,
                            children: O("div", {})
                        })
                    })]
                })]
            })
        })
    },
    L8 = "_header_1l9au_1",
    N8 = "_noAfter_1l9au_16",
    A8 = "_bg_1l9au_19",
    R8 = "_active_1l9au_42",
    D8 = "_logo_1l9au_48",
    z8 = "_burger_1l9au_52",
    I8 = "_list_1l9au_76",
    F8 = "_hidden_1l9au_89",
    sr = {
        header: L8,
        noAfter: N8,
        bg: A8,
        active: R8,
        logo: D8,
        burger: z8,
        list: I8,
        hidden: F8
    },
    DS = [{
        scrollLink: !0,
        href: "#about-us",
        title: "About Us",
        toScreen: 2,
        additionalFunction: () => {
            var e;
            (e = document.querySelector(".home .fp-overflow")) == null || e.scrollTo({
                left: 0,
                top: window.innerHeight + 42,
                behavior: "smooth"
            })
        }
    }, {
        scrollLink: !0,
        href: "#services",
        title: "What we do",
        toScreen: 4,
        additionalFunction: () => {
            var e;
            (e = document.querySelector(".services .fp-overflow")) == null || e.scrollTo({
                left: 0,
                top: 0,
                behavior: "smooth"
            })
        }
    }, {
        scrollLink: !1,
        href: "https://app.stem.is/login",
        title: "Log in",
        type: "button"
    }, {
        scrollLink: !1,
        href: "https://apply.stem.is/apply-now",
        title: "Apply",
        type: "button"
    }],
    B8 = () => {
        const {
            activeScreen: e,
            menuActive: t,
            setMenuActive: n,
            setAnchorScrolling: r
        } = R.useContext(Dn), [i, o] = R.useState(!1);
        return R.useEffect(() => {
            var s;
            ScrollTrigger.create({
                start: "top 100%",
                end: "bottom 40%",
                trigger: document.querySelector(".realeses"),
                scroller: (s = document.querySelector(".home")) == null ? void 0 : s.querySelector(".fp-overflow"),
                onEnter: () => o(!0),
                onLeave: () => o(!1),
                onEnterBack: () => o(!0),
                onLeaveBack: () => o(!1)
            })
        }, []), oe("header", {
            className: de(sr.header, e >= 1 && e < 7 && sr.active),
            children: [O("div", {
                style: {
                    opacity: `${t?1:0}`,
                    transitionDelay: `${t?"0s":"1s"}`
                },
                className: sr.bg
            }), O("div", {
                onClick: () => window.fullpage_api.moveTo(2),
                className: sr.logo,
                children: O(__, {})
            }), O("ul", {
                className: sr.list,
                children: DS.map((s, l) => O("li", {
                    className: i ? sr.hidden : "",
                    children: s.type === "button" ? O("a", {
                        className: sr.noAfter,
                        href: s.href,
                        children: O(Ah, {
                            children: s.title
                        })
                    }) : O("a", {
                        onClick: a => {
                            a.preventDefault(), setTimeout(() => {
                                window.fullpage_api.moveTo(s.toScreen), s.additionalFunction && s.additionalFunction(), r(!0), setTimeout(() => r(!1), 1e3)
                            }, 0)
                        },
                        href: s.href,
                        children: s.title
                    })
                }, l))
            }), window.innerWidth <= 768 && oe("div", {
                onClick: () => n(!t),
                className: de(sr.burger, t && sr.active),
                children: [O("div", {}), O("div", {}), O("div", {})]
            })]
        })
    };
var zS = {
    exports: {}
};
/*!
 * @fullpage/react-fullpage 0.1.40
 * https://github.com/alvarotrigo/react-fullpage
 * @license https://github.com/alvarotrigo/react-fullpage#license
 *
 * Copyright (C) 2018 alvarotrigo.com - A project by Alvaro Trigo & Michael Walker
 */
(function(e) {
    (() => {
        var t = {
                271: (o, s, l) => {
                    l.d(s, {
                        Z: () => a
                    });
                    const a = (u, f) => u ? function() {
                        for (var d = arguments.length, h = new Array(d), y = 0; y < d; y++) h[y] = arguments[y];
                        return console.log(`<${f}/> Debug Log: `, ...h)
                    } : () => {}
                },
                88: (o, s, l) => {
                    l.d(s, {
                        Z: () => D
                    });
                    var a = l(497),
                        u = l.n(a),
                        f = l(379),
                        d = l.n(f),
                        h = l(795),
                        y = l.n(h),
                        _ = l(569),
                        v = l.n(_),
                        E = l(565),
                        m = l.n(E),
                        g = l(216),
                        S = l.n(g),
                        x = l(589),
                        P = l.n(x),
                        T = l(563),
                        L = {};
                    L.styleTagTransform = P(), L.setAttributes = m(), L.insert = v().bind(null, "head"), L.domAPI = y(), L.insertStyleElement = S(), d()(T.Z, L), T.Z && T.Z.locals && T.Z.locals;
                    var b = l(271),
                        N = l(542);

                    function H(V, U) {
                        var q = Object.keys(V);
                        if (Object.getOwnPropertySymbols) {
                            var ne = Object.getOwnPropertySymbols(V);
                            U && (ne = ne.filter(function(xe) {
                                return Object.getOwnPropertyDescriptor(V, xe).enumerable
                            })), q.push.apply(q, ne)
                        }
                        return q
                    }

                    function A(V) {
                        for (var U = 1; U < arguments.length; U++) {
                            var q = arguments[U] != null ? arguments[U] : {};
                            U % 2 ? H(Object(q), !0).forEach(function(ne) {
                                I(V, ne, q[ne])
                            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(V, Object.getOwnPropertyDescriptors(q)) : H(Object(q)).forEach(function(ne) {
                                Object.defineProperty(V, ne, Object.getOwnPropertyDescriptor(q, ne))
                            })
                        }
                        return V
                    }

                    function I(V, U, q) {
                        return U in V ? Object.defineProperty(V, U, {
                            value: q,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : V[U] = q, V
                    }
                    let B;
                    const G = V => typeof V == "function",
                        Q = (V, U) => V.length !== U.length ? !1 : V.find(q => !U.includes(q)) == null,
                        le = ["afterLoad", "afterRender", "afterResize", "afterResponsive", "afterSlideLoad", "onLeave", "onSlideLeave"];
                    class ie extends u().Component {
                        constructor(U) {
                            super(U);
                            const {
                                render: q,
                                pluginWrapper: ne
                            } = this.props;
                            if (!G(q)) throw new Error("must provide render prop to <ReactFullpage />");
                            this.log = (0, b.Z)(this.props.debug, "ReactFullpage"), this.log("Building component"), this.log("Importing vendor files"), this.importVendors(), ne && (this.log("Calling plugin wrapper"), ne()), this.log("Requiring fullpage.js"), B = l(933), this.state = {
                                initialized: !1,
                                sectionCount: 0,
                                slideCount: 0
                            }
                        }
                        componentDidMount() {
                            const U = this.buildOptions();
                            this.log("React Lifecycle: componentDidMount()"), B && (this.init(U), this.markInitialized())
                        }
                        isReRenderNecessary(U) {
                            const q = this.getSectionCount(),
                                ne = this.getSlideCount(),
                                {
                                    sectionCount: xe,
                                    slideCount: fe
                                } = this.state;
                            let te = xe !== q || fe !== ne;
                            return ["sectionsColor", "navigationTooltips", "navigationPosition", "navigation", "scrollBar"].forEach(Ve => {
                                typeof U[Ve] < "u" && (Array.isArray(U[Ve]) ? te = te || !Q(U[Ve], this.props[Ve]) : te = te || U[Ve] !== this.props[Ve])
                            }), te
                        }
                        componentDidUpdate(U) {
                            if (this.log("React Lifecycle: componentDidUpdate()"), this.isReRenderNecessary(U)) {
                                this.log("rebuilding due to a change in fullpage.js props or num sections/slides"), this.reRender();
                                return
                            }
                        }
                        componentWillUnmount() {
                            this.destroy()
                        }
                        getSectionCount() {
                            const {
                                sectionSelector: U = N.uS
                            } = this.props, {
                                length: q
                            } = document.querySelectorAll(U);
                            return q
                        }
                        getSlideCount() {
                            const {
                                slideSelector: U = N.xH
                            } = this.props, {
                                length: q
                            } = document.querySelectorAll(U);
                            return q
                        }
                        importVendors() {
                            const {
                                easing: U,
                                css3: q
                            } = this.props;
                            U && !q && l(239)
                        }
                        init(U) {
                            this.log("Reinitializing fullpage with options", U);
                            const q = U.animateAnchor;
                            U.animateAnchor = !1, new B(N.Km, U), this.fullpageApi = window.fullpage_api, this.fpUtils = window.fp_utils, this.fpEasings = window.fp_easings, window.fullpage_api.getFullpageData().options.animateAnchor = q
                        }
                        destroy() {
                            this.log("Destroying fullpage instance"), this.fullpageApi.destroy("all")
                        }
                        reRender() {
                            const U = this.props.slideSelector || ".slide",
                                q = this.props.sectionSelector || ".section",
                                ne = document.querySelector(q + ".active"),
                                xe = ne ? this.fpUtils.index(ne) : this.state.destination ? this.state.destination.index - 1 : 0,
                                fe = document.querySelector(q + ".active " + U + ".active"),
                                te = fe ? this.fpUtils.index(fe) : -1;
                            this.destroy(), xe > -1 && this.fpUtils.addClass(document.querySelectorAll(q)[xe], "active"), te > -1 && this.fpUtils.addClass(fe, "active"), this.init(this.buildOptions())
                        }
                        markInitialized() {
                            this.log("Marking initialized"), this.setState({
                                initialized: !0,
                                sectionCount: this.getSectionCount(),
                                slideCount: this.getSlideCount()
                            })
                        }
                        buildOptions() {
                            var U = this;
                            let q = null;
                            if (!this.state.initialized) {
                                const xe = te => !!Object.keys(this.props).find(Te => Te === te);
                                q = le.filter(xe).reduce((te, Te) => A(A({}, te), {}, {
                                    [Te]: function() {
                                        for (var Ve = arguments.length, Cn = new Array(Ve), yt = 0; yt < Ve; yt++) Cn[yt] = arguments[yt];
                                        return U.update(Te, ...Cn)
                                    }
                                }), {})
                            }
                            const ne = A(A({}, this.props), q);
                            return this.log("Building fullpage.js options: ", ne), ne
                        }
                        update(U) {
                            for (var q = arguments.length, ne = new Array(q > 1 ? q - 1 : 0), xe = 1; xe < q; xe++) ne[xe - 1] = arguments[xe];
                            this.log("Event trigger: ", U);
                            let fe = A(A({}, this.state), {}, {
                                sectionCount: this.getSectionCount(),
                                slideCount: this.getSlideCount()
                            });
                            const te = Cn => A(A(A({}, fe), Cn), {}, {
                                    lastEvent: U
                                }),
                                Te = Cn => Cn.reduce((yt, Cr, We) => {
                                    const Re = ne[We];
                                    return yt[Cr] = Re, yt
                                }, {});
                            switch (U) {
                                case "afterLoad":
                                    fe = te(Te(["origin", "destination", "direction"]));
                                    break;
                                case "afterResize":
                                    fe = te(Te([""]));
                                    break;
                                case "afterResponsive":
                                    fe = te(Te(["isResponsive"]));
                                    break;
                                case "afterSlideLoad":
                                    fe = te(Te(["section", "origin", "destination", "direction"]));
                                    break;
                                case "onLeave":
                                    fe = te(Te(["origin", "destination", "direction"]));
                                    break;
                                case "onSlideLeave":
                                    fe = te(Te(["section", "origin", "slideIndex", "destination", "direction"]));
                                    break
                            }
                            const Ve = this.props[U](...ne);
                            return this.log("Called callback: Returning => ", Ve), this.log("Updating State => ", fe), this.setState(fe), Ve
                        }
                        render() {
                            return this.log("<== Rendering ==>"), u().createElement("div", {
                                id: N.W1
                            }, this.props.render(this))
                        }
                    }
                    ie.defaultProps = {
                        sectionsColor: []
                    };
                    const D = ie
                },
                882: (o, s, l) => {
                    l.d(s, {
                        Z: () => y
                    });
                    var a = l(497),
                        u = l.n(a),
                        f = l(271),
                        d = l(542);
                    class h extends u().Component {
                        constructor(v) {
                            super(v), this.state = {}, this.log = (0, f.Z)(this.props.debug, "ReactFullpageShell"), this.log("Building component")
                        }
                        render() {
                            return u().createElement("div", {
                                id: d.W1
                            }, this.props.render(this))
                        }
                    }
                    const y = h
                },
                542: (o, s, l) => {
                    l.d(s, {
                        W1: () => a,
                        Km: () => u,
                        uS: () => f,
                        xH: () => d
                    });
                    const a = "fullpage",
                        u = `#${a}`,
                        f = ".section",
                        d = ".SLIDE"
                },
                563: (o, s, l) => {
                    l.d(s, {
                        Z: () => d
                    });
                    var a = l(645),
                        u = l.n(a),
                        f = u()(function(h) {
                            return h[1]
                        });
                    f.push([o.id, `/*!\r
 * fullPage 4.0.20\r
 * https://github.com/alvarotrigo/fullPage.js\r
 *\r
 * @license GPLv3 for open source use only\r
 * or Fullpage Commercial License for commercial use\r
 * http://alvarotrigo.com/fullPage/pricing/\r
 *\r
 * Copyright (C) 2021 http://alvarotrigo.com/fullPage - A project by Alvaro Trigo\r
 */.fp-enabled body,html.fp-enabled{margin:0;padding:0;overflow:hidden;-webkit-tap-highlight-color:rgba(0,0,0,0)}.fp-section{position:relative;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;height:100%;display:block}.fp-slide{float:left}.fp-slide,.fp-slidesContainer{height:100%;display:block}.fp-slides{z-index:1;height:100%;overflow:hidden;position:relative;-webkit-transition:all .3s ease-out;transition:all .3s ease-out}.fp-table{display:flex;flex-direction:column;justify-content:center;width:100%}.fp-slidesContainer{float:left;position:relative}.fp-controlArrow{-webkit-user-select:none;-moz-user-select:none;-khtml-user-select:none;-ms-user-select:none;position:absolute;z-index:4;top:50%;cursor:pointer;margin-top:-38px;-webkit-transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}.fp-prev{left:15px}.fp-next{right:15px}.fp-arrow{width:0;height:0;border-style:solid}.fp-arrow.fp-prev{border-width:38.5px 34px 38.5px 0;border-color:transparent #fff transparent transparent}.fp-arrow.fp-next{border-width:38.5px 0 38.5px 34px;border-color:transparent transparent transparent #fff}.fp-notransition{-webkit-transition:none!important;transition:none!important}#fp-nav{position:fixed;z-index:100;top:50%;opacity:1;transform:translateY(-50%);-ms-transform:translateY(-50%);-webkit-transform:translate3d(0,-50%,0)}#fp-nav.fp-right{right:17px}#fp-nav.fp-left{left:17px}.fp-slidesNav{position:absolute;z-index:4;opacity:1;-webkit-transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);transform:translate3d(0,0,0);left:0!important;right:0;margin:0 auto!important}.fp-slidesNav.fp-bottom{bottom:17px}.fp-slidesNav.fp-top{top:17px}#fp-nav ul,.fp-slidesNav ul{margin:0;padding:0}#fp-nav ul li,.fp-slidesNav ul li{display:block;width:14px;height:13px;margin:7px;position:relative}.fp-slidesNav ul li{display:inline-block}#fp-nav ul li a,.fp-slidesNav ul li a{display:block;position:relative;z-index:1;width:100%;height:100%;cursor:pointer;text-decoration:none}#fp-nav ul li a.active span,#fp-nav ul li:hover a.active span,.fp-slidesNav ul li a.active span,.fp-slidesNav ul li:hover a.active span{height:12px;width:12px;margin:-6px 0 0 -6px;border-radius:100%}#fp-nav ul li a span,.fp-slidesNav ul li a span{border-radius:50%;position:absolute;z-index:1;height:4px;width:4px;border:0;background:#333;left:50%;top:50%;margin:-2px 0 0 -2px;-webkit-transition:all .1s ease-in-out;-moz-transition:all .1s ease-in-out;-o-transition:all .1s ease-in-out;transition:all .1s ease-in-out}#fp-nav ul li:hover a span,.fp-slidesNav ul li:hover a span{width:10px;height:10px;margin:-5px 0 0 -5px}#fp-nav ul li .fp-tooltip{position:absolute;top:-2px;color:#fff;font-size:14px;font-family:arial,helvetica,sans-serif;white-space:nowrap;max-width:220px;overflow:hidden;display:block;opacity:0;width:0;cursor:pointer}#fp-nav ul li:hover .fp-tooltip,#fp-nav.fp-show-active a.active+.fp-tooltip{-webkit-transition:opacity .2s ease-in;transition:opacity .2s ease-in;width:auto;opacity:1}#fp-nav ul li .fp-tooltip.fp-right{right:20px}#fp-nav ul li .fp-tooltip.fp-left{left:20px}.fp-auto-height .fp-slide,.fp-auto-height.fp-section{height:auto!important}.fp-responsive .fp-is-overflow.fp-section{height:auto!important}.fp-scrollable .fp-section,.fp-scrollable .fp-slide,.fp-scrollable.fp-responsive .fp-is-overflow.fp-section{height:100vh;height:calc(var(--vh,1vh) * 100)}.fp-scrollable .fp-section:not(.fp-auto-height):not([data-percentage]),.fp-scrollable .fp-slide:not(.fp-auto-height):not([data-percentage]),.fp-scrollable.fp-responsive .fp-is-overflow.fp-section:not(.fp-auto-height):not([data-percentage]){min-height:100vh;min-height:calc(var(--vh,1vh) * 100)}.fp-overflow{justify-content:flex-start;max-height:100vh}.fp-scrollable .fp-auto-height .fp-overflow{max-height:none}.fp-is-overflow .fp-overflow.fp-auto-height,.fp-is-overflow .fp-overflow.fp-auto-height-responsive,.fp-is-overflow>.fp-overflow{overflow-y:auto}.fp-overflow{outline:0}.fp-overflow.fp-table{display:block}.fp-responsive .fp-auto-height-responsive .fp-slide,.fp-responsive .fp-auto-height-responsive.fp-section{height:auto!important;min-height:auto!important}.fp-sr-only{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.fp-scroll-mac .fp-overflow::-webkit-scrollbar{background-color:transparent;width:9px}.fp-scroll-mac .fp-overflow::-webkit-scrollbar-track{background-color:transparent}.fp-scroll-mac .fp-overflow::-webkit-scrollbar-thumb{background-color:rgba(0,0,0,.4);border-radius:16px;border:4px solid transparent}.fp-warning,.fp-watermark{z-index:9999999;position:absolute;bottom:0}.fp-warning,.fp-watermark a{text-decoration:none;color:#000;background:rgba(255,255,255,.6);padding:5px 8px;font-size:14px;font-family:arial;color:#000;display:inline-block;border-radius:3px;margin:12px}.fp-noscroll .fp-overflow{overflow:hidden}\r
`, ""]);
                    const d = f
                },
                645: o => {
                    o.exports = function(s) {
                        var l = [];
                        return l.toString = function() {
                            return this.map(function(u) {
                                var f = s(u);
                                return u[2] ? "@media ".concat(u[2], " {").concat(f, "}") : f
                            }).join("")
                        }, l.i = function(a, u, f) {
                            typeof a == "string" && (a = [
                                [null, a, ""]
                            ]);
                            var d = {};
                            if (f)
                                for (var h = 0; h < this.length; h++) {
                                    var y = this[h][0];
                                    y != null && (d[y] = !0)
                                }
                            for (var _ = 0; _ < a.length; _++) {
                                var v = [].concat(a[_]);
                                f && d[v[0]] || (u && (v[2] ? v[2] = "".concat(u, " and ").concat(v[2]) : v[2] = u), l.push(v))
                            }
                        }, l
                    }
                },
                933: function(o) {
                    /*!
                     * fullPage 4.0.20
                     * https://github.com/alvarotrigo/fullPage.js
                     *
                     * @license GPLv3 for open source use only
                     * or Fullpage Commercial License for commercial use
                     * http://alvarotrigo.com/fullPage/pricing/
                     *
                     * Copyright (C) 2018 http://alvarotrigo.com/fullPage/ - A project by Alvaro Trigo
                     */
                    (function(s, l) {
                        o.exports = l()
                    })(this, function() {
                        var s, l, a, u;
                        Array.prototype.find || Object.defineProperty(Array.prototype, "find", {
                            value: function(c) {
                                if (this == null) throw new TypeError('"this" is null or not defined');
                                var p = Object(this),
                                    w = p.length >>> 0;
                                if (typeof c != "function") throw new TypeError("predicate must be a function");
                                for (var C = arguments[1], M = 0; M < w;) {
                                    var F = p[M];
                                    if (c.call(C, F, M, p)) return F;
                                    M++
                                }
                            }
                        }), Array.from || (Array.from = (s = Object.prototype.toString, l = function(c) {
                            return typeof c == "function" || s.call(c) === "[object Function]"
                        }, a = Math.pow(2, 53) - 1, u = function(c) {
                            var p = function(w) {
                                var C = Number(w);
                                return isNaN(C) ? 0 : C !== 0 && isFinite(C) ? (C > 0 ? 1 : -1) * Math.floor(Math.abs(C)) : C
                            }(c);
                            return Math.min(Math.max(p, 0), a)
                        }, function(c) {
                            var p = this,
                                w = Object(c);
                            if (c == null) throw new TypeError("Array.from requires an array-like object - not null or undefined");
                            var C, M = arguments.length > 1 ? arguments[1] : void 0;
                            if (M !== void 0) {
                                if (!l(M)) throw new TypeError("Array.from: when provided, the second argument must be a function");
                                arguments.length > 2 && (C = arguments[2])
                            }
                            for (var F, z = u(w.length), J = l(p) ? Object(new p(z)) : new Array(z), X = 0; X < z;) F = w[X], J[X] = M ? C === void 0 ? M(F, X) : M.call(C, F, X) : F, X += 1;
                            return J.length = z, J
                        }));
                        var f = window,
                            d = document,
                            h = navigator.userAgent.match(/(iPhone|iPod|iPad|Android|playbook|silk|BlackBerry|BB10|Windows Phone|Tizen|Bada|webOS|IEMobile|Opera Mini)/),
                            y = /(Mac|iPhone|iPod|iPad)/i.test(f.navigator.userAgent),
                            _ = "ontouchstart" in f || navigator.msMaxTouchPoints > 0 || navigator.maxTouchPoints,
                            v = !!window.MSInputMethodContext && !!document.documentMode,
                            E = {
                                test: {},
                                shared: {}
                            };

                        function m(c, p) {
                            f.console && f.console[c] && f.console[c]("fullPage: " + p)
                        }

                        function g(c) {
                            return f.getComputedStyle(c).display !== "none"
                        }

                        function S(c) {
                            return Array.from(c).filter(function(p) {
                                return g(p)
                            })
                        }

                        function x(c, p) {
                            return (p = arguments.length > 1 ? p : document) ? p.querySelectorAll(c) : null
                        }

                        function P(c) {
                            c = c || {};
                            for (var p = 1, w = arguments.length; p < w; ++p) {
                                var C = arguments[p];
                                if (C)
                                    for (var M in C) C.hasOwnProperty(M) && M != "__proto__" && M != "constructor" && (Object.prototype.toString.call(C[M]) !== "[object Object]" ? c[M] = C[M] : c[M] = P(c[M], C[M]))
                            }
                            return c
                        }

                        function T(c, p) {
                            return c != null && c.classList.contains(p)
                        }

                        function L() {
                            return "innerHeight" in f ? f.innerHeight : d.documentElement.offsetHeight
                        }

                        function b() {
                            return f.innerWidth
                        }

                        function N(c, p) {
                            var w;
                            for (w in c = G(c), p)
                                if (p.hasOwnProperty(w) && w !== null)
                                    for (var C = 0; C < c.length; C++) c[C].style[w] = p[w];
                            return c
                        }

                        function H(c, p) {
                            if (!c) return null;
                            if (p == null) return c.previousElementSibling;
                            var w = H(c);
                            return w && Ke(w, p) ? w : null
                        }

                        function A(c, p) {
                            if (!c) return null;
                            if (p == null) return c.nextElementSibling;
                            var w = A(c);
                            return w && Ke(w, p) ? w : null
                        }

                        function I(c) {
                            return c[c.length - 1]
                        }

                        function B(c, p) {
                            c = ie(c) ? c[0] : c;
                            for (var w = p != null ? x(p, c.parentNode) : c.parentNode.childNodes, C = 0, M = 0; M < w.length; M++) {
                                if (w[M] == c) return C;
                                w[M].nodeType == 1 && C++
                            }
                            return -1
                        }

                        function G(c) {
                            return ie(c) ? c : [c]
                        }

                        function Q(c) {
                            c = G(c);
                            for (var p = 0; p < c.length; p++) c[p].style.display = "none";
                            return c
                        }

                        function le(c) {
                            c = G(c);
                            for (var p = 0; p < c.length; p++) c[p].style.display = "block";
                            return c
                        }

                        function ie(c) {
                            return Object.prototype.toString.call(c) === "[object Array]" || Object.prototype.toString.call(c) === "[object NodeList]"
                        }

                        function D(c, p) {
                            c = G(c);
                            for (var w = 0; w < c.length; w++) c[w].classList.add(p);
                            return c
                        }

                        function V(c, p) {
                            c = G(c);
                            for (var w = p.split(" "), C = 0; C < w.length; C++) {
                                p = w[C];
                                for (var M = 0; M < c.length; M++) c[M].classList.remove(p)
                            }
                            return c
                        }

                        function U(c, p) {
                            p.appendChild(c)
                        }

                        function q(c, p, w) {
                            var C;
                            p = p || d.createElement("div");
                            for (var M = 0; M < c.length; M++) {
                                var F = c[M];
                                (w && !M || !w) && (C = p.cloneNode(!0), F.parentNode.insertBefore(C, F)), C.appendChild(F)
                            }
                            return c
                        }

                        function ne(c, p) {
                            q(c, p, !0)
                        }

                        function xe(c, p) {
                            for (typeof p == "string" && (p = Tr(p)), c.appendChild(p); c.firstChild !== p;) p.appendChild(c.firstChild)
                        }

                        function fe(c) {
                            for (var p = d.createDocumentFragment(); c.firstChild;) p.appendChild(c.firstChild);
                            c.parentNode.replaceChild(p, c)
                        }

                        function te(c, p) {
                            return c && c.nodeType === 1 ? Ke(c, p) ? c : te(c.parentNode, p) : null
                        }

                        function Te(c, p) {
                            Cn(c, c.nextSibling, p)
                        }

                        function Ve(c, p) {
                            Cn(c, c, p)
                        }

                        function Cn(c, p, w) {
                            ie(w) || (typeof w == "string" && (w = Tr(w)), w = [w]);
                            for (var C = 0; C < w.length; C++) c.parentNode.insertBefore(w[C], p)
                        }

                        function yt() {
                            var c = d.documentElement;
                            return (f.pageYOffset || c.scrollTop) - (c.clientTop || 0)
                        }

                        function Cr(c) {
                            return Array.prototype.filter.call(c.parentNode.children, function(p) {
                                return p !== c
                            })
                        }

                        function We(c) {
                            c.preventDefault()
                        }

                        function Re(c, p) {
                            return c.getAttribute(p)
                        }

                        function si(c, p, w) {
                            d.addEventListener(c, p, w === "undefined" ? null : w)
                        }

                        function Jn(c, p, w) {
                            f.addEventListener(c, p, w === "undefined" ? null : w)
                        }

                        function er(c, p, w) {
                            d.removeEventListener(c, p, w === "undefined" ? null : w)
                        }

                        function Bi(c, p, w) {
                            f.removeEventListener(c, p, w === "undefined" ? null : w)
                        }

                        function qe(c) {
                            if (typeof c == "function") return !0;
                            var p = Object.prototype.toString.call(c);
                            return p === "[object Function]" || p === "[object GeneratorFunction]"
                        }

                        function _t(c, p, w) {
                            var C;
                            w = w === void 0 ? {} : w, typeof f.CustomEvent == "function" ? C = new CustomEvent(p, {
                                detail: w
                            }) : (C = d.createEvent("CustomEvent")).initCustomEvent(p, !0, !0, w), c.dispatchEvent(C)
                        }

                        function Ke(c, p) {
                            return (c.matches || c.t || c.msMatchesSelector || c.mozMatchesSelector || c.webkitMatchesSelector || c.oMatchesSelector).call(c, p)
                        }

                        function wl(c, p) {
                            if (typeof p == "boolean")
                                for (var w = 0; w < c.length; w++) c[w].style.display = p ? "block" : "none";
                            return c
                        }

                        function Tr(c) {
                            var p = d.createElement("div");
                            return p.innerHTML = c.trim(), p.firstChild
                        }

                        function li(c) {
                            c = G(c);
                            for (var p = 0; p < c.length; p++) {
                                var w = c[p];
                                w && w.parentElement && w.parentNode.removeChild(w)
                            }
                        }

                        function tm(c, p) {
                            Array.prototype.filter.call(c, p)
                        }

                        function xl(c, p, w) {
                            for (var C = c[w], M = []; C;)(Ke(C, p) || p == null) && M.push(C), C = C[w];
                            return M
                        }

                        function Zu(c, p) {
                            return xl(c, p, "nextElementSibling")
                        }

                        function Ju(c, p) {
                            return xl(c, p, "previousElementSibling")
                        }

                        function nm(c) {
                            return Object.keys(c).map(function(p) {
                                return c[p]
                            })
                        }

                        function zn(c) {
                            return c[c.length - 1]
                        }

                        function Wo(c, p) {
                            for (var w = 0, C = c.slice(Math.max(c.length - p, 1)), M = 0; M < C.length; M++) w += C[M];
                            return Math.ceil(w / p)
                        }

                        function El(c, p) {
                            c.setAttribute(p, Re(c, "data-" + p)), c.removeAttribute("data-" + p)
                        }

                        function rm(c, p) {
                            var w = [c];
                            do c = c.parentNode, w.push(c); while (!Ke(c, p));
                            return w
                        }

                        function ec() {
                            var c = d.activeElement;
                            return Ke(c, "textarea") || Ke(c, "input") || Ke(c, "select") || Re(c, "contentEditable") == "true" || Re(c, "contentEditable") == ""
                        }
                        f.NodeList && !NodeList.prototype.forEach && (NodeList.prototype.forEach = function(c, p) {
                            p = p || window;
                            for (var w = 0; w < this.length; w++) c.call(p, this[w], w, this)
                        }), typeof Object.assign != "function" && Object.defineProperty(Object, "assign", {
                            value: function(c, p) {
                                if (c == null) throw new TypeError("Cannot convert undefined or null to object");
                                for (var w = Object(c), C = 1; C < arguments.length; C++) {
                                    var M = arguments[C];
                                    if (M != null)
                                        for (var F in M) Object.prototype.hasOwnProperty.call(M, F) && (w[F] = M[F])
                                }
                                return w
                            },
                            writable: !0,
                            i: !0
                        }), window.fp_utils = {
                            $: x,
                            deepExtend: P,
                            hasClass: T,
                            getWindowHeight: L,
                            css: N,
                            prev: H,
                            next: A,
                            last: I,
                            index: B,
                            getList: G,
                            hide: Q,
                            show: le,
                            isArrayOrList: ie,
                            addClass: D,
                            removeClass: V,
                            appendTo: U,
                            wrap: q,
                            wrapAll: ne,
                            wrapInner: xe,
                            unwrap: fe,
                            closest: te,
                            after: Te,
                            before: Ve,
                            insertBefore: Cn,
                            getScrollTop: yt,
                            siblings: Cr,
                            preventDefault: We,
                            isFunction: qe,
                            trigger: _t,
                            matches: Ke,
                            toggle: wl,
                            createElementFromHTML: Tr,
                            remove: li,
                            filter: tm,
                            untilAll: xl,
                            nextAll: Zu,
                            prevAll: Ju,
                            showError: m
                        };
                        var im = Object.freeze({
                            __proto__: null,
                            showError: m,
                            isVisible: g,
                            getVisible: S,
                            $: x,
                            deepExtend: P,
                            hasClass: T,
                            getWindowHeight: L,
                            o: b,
                            css: N,
                            prev: H,
                            next: A,
                            last: I,
                            index: B,
                            getList: G,
                            hide: Q,
                            show: le,
                            isArrayOrList: ie,
                            addClass: D,
                            removeClass: V,
                            appendTo: U,
                            wrap: q,
                            wrapAll: ne,
                            wrapInner: xe,
                            unwrap: fe,
                            closest: te,
                            after: Te,
                            before: Ve,
                            insertBefore: Cn,
                            getScrollTop: yt,
                            siblings: Cr,
                            preventDefault: We,
                            l: Re,
                            u: si,
                            v: Jn,
                            p: er,
                            h: Bi,
                            isFunction: qe,
                            trigger: _t,
                            matches: Ke,
                            toggle: wl,
                            createElementFromHTML: Tr,
                            remove: li,
                            filter: tm,
                            untilAll: xl,
                            nextAll: Zu,
                            prevAll: Ju,
                            toArray: nm,
                            g: zn,
                            S: Wo,
                            M: El,
                            T: rm,
                            A: ec
                        });

                        function Go(c) {
                            return Go = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(p) {
                                return typeof p
                            } : function(p) {
                                return p && typeof Symbol == "function" && p.constructor === Symbol && p !== Symbol.prototype ? "symbol" : typeof p
                            }, Go(c)
                        }
                        var K = {
                                O: {},
                                R: function(c, p) {
                                    var w = this;
                                    return Go(this.O[c]) !== "object" && (this.O[c] = []), this.O[c].push(p),
                                        function() {
                                            return w.removeListener(c, p)
                                        }
                                },
                                removeListener: function(c, p) {
                                    if (Go(this.O[c]) === "object") {
                                        var w = this.O[c].indexOf(p);
                                        w > -1 && this.O[c].splice(w, 1)
                                    }
                                },
                                L: function(c) {
                                    for (var p = this, w = arguments.length, C = new Array(w > 1 ? w - 1 : 0), M = 1; M < w; M++) C[M - 1] = arguments[M];
                                    Go(this.O[c]) === "object" && this.O[c].forEach(function(F) {
                                        return F.apply(p, C)
                                    })
                                },
                                once: function(c, p) {
                                    var w = this,
                                        C = this.R(c, function() {
                                            C();
                                            for (var M = arguments.length, F = new Array(M), z = 0; z < M; z++) F[z] = arguments[z];
                                            p.apply(w, F)
                                        })
                                }
                            },
                            $ = {
                                j: 0,
                                D: 0,
                                slides: [],
                                N: [],
                                P: null,
                                H: null,
                                C: !1,
                                I: !1,
                                W: !1,
                                F: !1,
                                V: !1,
                                Z: void 0,
                                B: void 0,
                                G: !1,
                                canScroll: !0,
                                Y: "none",
                                U: "none",
                                X: !1,
                                _: !1,
                                J: !0,
                                K: 0,
                                q: L(),
                                nn: !1,
                                tn: {}
                            };

                        function Z(c) {
                            Object.assign($, c)
                        }

                        function Y() {
                            return $
                        }
                        f.state = $;
                        var tc = "onAfterRenderNoAnchor",
                            Cl = "onClickOrTouch",
                            nc = "moveSlideLeft",
                            rc = "moveSlideRight",
                            om = "onInitialise",
                            bt = "bindEvents",
                            Tn = "onDestroy",
                            sm = "contentChanged",
                            lm = "onScrollOverflowScrolled",
                            ic = "onScrollPageAndSlide",
                            am = "onKeyDown",
                            um = "onMenuClick",
                            cm = "scrollPage",
                            fm = "landscapeScroll",
                            dm = "scrollBeyondFullpage",
                            pm = "onPerformMovement",
                            hm = "onSlideLeave",
                            mm = "onLeave",
                            oc = "afterSectionLoads",
                            sc = "afterSlideLoads";

                        function vm(c) {
                            K.L(Cl, {
                                e: c,
                                target: c.target
                            })
                        }

                        function FS() {
                            ["click", "touchstart"].forEach(function(c) {
                                er(c, vm, {
                                    passive: !1
                                })
                            })
                        }

                        function BS() {
                            Z({
                                J: !0
                            })
                        }
                        K.R(bt, function() {
                            ["click", "touchstart"].forEach(function(c) {
                                si(c, vm, {
                                    passive: !1
                                })
                            }), Jn("focus", BS), K.R(Tn, FS)
                        });
                        var lc = "fullpage-wrapper",
                            ai = "." + lc,
                            Tl = "fp-responsive",
                            ac = "fp-notransition",
                            uc = "fp-destroyed",
                            Pl = "fp-enabled",
                            Oe = "active",
                            cc = ".active",
                            ji = "fp-completely",
                            kl = "fp-section",
                            Xt = "." + kl,
                            jS = ".fp-tableCell",
                            ui = "#fp-nav",
                            fc = "fp-slide",
                            dc = "." + fc,
                            bl = ".fp-slide.active",
                            Ml = "fp-slides",
                            tr = ".fp-slides",
                            pc = "fp-slidesContainer",
                            Yo = "." + pc,
                            gm = "fp-table",
                            Vi = "fp-overflow",
                            Xo = "." + Vi,
                            qo = "fp-is-overflow",
                            hc = ".fp-slidesNav",
                            ym = ".fp-slidesNav a",
                            _m = "fp-controlArrow",
                            mc = "." + _m,
                            Sm = "fp-prev",
                            vc = ".fp-controlArrow.fp-prev",
                            wm = ".fp-controlArrow.fp-next",
                            Ol = {
                                menu: !1,
                                anchors: [],
                                lockAnchors: !1,
                                navigation: !1,
                                navigationPosition: "right",
                                navigationTooltips: [],
                                showActiveTooltip: !1,
                                slidesNavigation: !1,
                                slidesNavPosition: "bottom",
                                scrollBar: !1,
                                hybrid: !1,
                                licenseKey: "",
                                credits: {
                                    enabled: !0,
                                    label: "Made with fullPage.js",
                                    position: "right"
                                },
                                css3: !0,
                                scrollingSpeed: 700,
                                autoScrolling: !0,
                                fitToSection: !0,
                                en: 600,
                                easing: "easeInOutCubic",
                                easingcss3: "ease",
                                loopBottom: !1,
                                loopTop: !1,
                                loopHorizontal: !0,
                                continuousVertical: !1,
                                continuousHorizontal: !1,
                                scrollHorizontally: !1,
                                interlockedSlides: !1,
                                dragAndMove: !1,
                                offsetSections: !1,
                                resetSliders: !1,
                                fadingEffect: !1,
                                normalScrollElements: null,
                                scrollOverflow: !0,
                                scrollOverflowReset: !1,
                                touchSensitivity: 5,
                                touchWrapper: null,
                                bigSectionsDestination: null,
                                keyboardScrolling: !0,
                                animateAnchor: !0,
                                recordHistory: !0,
                                allowCorrectDirection: !1,
                                scrollOverflowMacStyle: !0,
                                controlArrows: !0,
                                controlArrowsHTML: ['<div class="fp-arrow"></div>', '<div class="fp-arrow"></div>'],
                                controlArrowColor: "#fff",
                                verticalCentered: !0,
                                sectionsColor: [],
                                paddingTop: 0,
                                paddingBottom: 0,
                                fixedElements: null,
                                responsive: 0,
                                responsiveWidth: 0,
                                responsiveHeight: 0,
                                responsiveSlides: !1,
                                parallax: !1,
                                parallaxOptions: {
                                    type: "reveal",
                                    percentage: 62,
                                    property: "translate"
                                },
                                cards: !1,
                                cardsOptions: {
                                    perspective: 100,
                                    fadeContent: !0,
                                    fadeBackground: !0
                                },
                                sectionSelector: ".section",
                                slideSelector: ".slide",
                                afterLoad: null,
                                beforeLeave: null,
                                onLeave: null,
                                afterRender: null,
                                afterResize: null,
                                afterReBuild: null,
                                afterSlideLoad: null,
                                onSlideLeave: null,
                                afterResponsive: null,
                                onScrollOverflow: null,
                                lazyLoading: !0,
                                observer: !0
                            },
                            Ko = null,
                            xm = !1,
                            gc = P({}, Ol),
                            Ll = null;

                        function re(c) {
                            return Ko
                        }

                        function k() {
                            return Ll || Ol
                        }

                        function Ui() {
                            return gc
                        }

                        function Nl(c, p, w) {
                            Ll[c] = p, w !== "internal" && (gc[c] = p)
                        }

                        function Em() {
                            if (!k().anchors.length) {
                                var c = x(k().sectionSelector.split(",").join("[data-anchor],") + "[data-anchor]", Ko);
                                c.length && c.length === x(k().sectionSelector, Ko).length && (xm = !0, c.forEach(function(w) {
                                    k().anchors.push(Re(w, "data-anchor").toString())
                                }))
                            }
                            if (!k().navigationTooltips.length) {
                                var p = x(k().sectionSelector.split(",").join("[data-tooltip],") + "[data-tooltip]", Ko);
                                p.length && p.forEach(function(w) {
                                    k().navigationTooltips.push(Re(w, "data-tooltip").toString())
                                })
                            }
                        }

                        function Cm(c) {
                            return window["fp_" + c + "Extension"] !== void 0
                        }

                        function De(c) {
                            var p = k();
                            return p[c] !== null && Object.prototype.toString.call(p[c]) === "[object Array]" ? p[c].length && E[c] : p[c] && E[c]
                        }

                        function se(c, p, w) {
                            if (De(c)) return qe(E[c][p]) ? E[c][p](w) : E[c][p]
                        }

                        function Al() {
                            return se("dragAndMove", "isAnimating")
                        }

                        function Tm() {
                            return se("dragAndMove", "isGrabbing")
                        }

                        function yc(c) {
                            if (k().offsetSections && E.offsetSections) {
                                var p = se("offsetSections", "getWindowHeight", c);
                                return p !== "" ? Math.round(p) + "px" : p
                            }
                            return L() + "px"
                        }

                        function Pm(c, p) {
                            c.insertBefore(p, c.firstChild)
                        }

                        function St(c) {
                            var p = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

                            function w(M) {
                                var F, z, J, X, ce, pe, ue = "",
                                    _e = 0;
                                for (M = M.replace(/[^A-Za-z0-9+/=]/g, ""); _e < M.length;) F = p.indexOf(M.charAt(_e++)) << 2 | (X = p.indexOf(M.charAt(_e++))) >> 4, z = (15 & X) << 4 | (ce = p.indexOf(M.charAt(_e++))) >> 2, J = (3 & ce) << 6 | (pe = p.indexOf(M.charAt(_e++))), ue += String.fromCharCode(F), ce != 64 && (ue += String.fromCharCode(z)), pe != 64 && (ue += String.fromCharCode(J));
                                return ue = function(we) {
                                    for (var st, Je = "", Le = 0, Ne = 0, me = 0; Le < we.length;)(Ne = we.charCodeAt(Le)) < 128 ? (Je += String.fromCharCode(Ne), Le++) : Ne > 191 && Ne < 224 ? (me = we.charCodeAt(Le + 1), Je += String.fromCharCode((31 & Ne) << 6 | 63 & me), Le += 2) : (me = we.charCodeAt(Le + 1), st = we.charCodeAt(Le + 2), Je += String.fromCharCode((15 & Ne) << 12 | (63 & me) << 6 | 63 & st), Le += 3);
                                    return Je
                                }(ue), ue
                            }

                            function C(M) {
                                return M.slice(3).slice(0, -3)
                            }
                            return function(M) {
                                var F = M.split("_");
                                if (F.length > 1) {
                                    var z = F[1];
                                    return w(M.replace(C(F[1]), "").split("_")[0].slice(2).slice(0, -2)) + "_" + w(z.slice(3).slice(0, -3))
                                }
                                return C(M)
                            }(w(c))
                        }
                        f.fp_utils = f.fp_utils || {}, Object.assign(f.fp_utils, {
                            prependTo: Pm,
                            toggleClass: function(c, p, w) {
                                if (c.classList && w == null) c.classList.toggle(p);
                                else {
                                    var C = T(c, p);
                                    C && w == null || !w ? V(c, p) : (!C && w == null || w) && D(c, p)
                                }
                            }
                        });
                        var km = function(c) {
                                this.anchor = c.anchor, this.item = c.item, this.index = c.index(), this.isLast = this.index === c.item.parentElement.querySelectorAll(c.selector).length - 1, this.isFirst = !this.index, this.isActive = c.isActive
                            },
                            Pn = function(c, p) {
                                this.parent = this.parent || null, this.selector = p, this.anchor = Re(c, "data-anchor") || k().anchors[B(c, k().sectionSelector)], this.item = c, this.isVisible = g(c), this.isActive = T(c, Oe), this.on = T(c, Vi) || x(Xo, c)[0] != null, this.rn = p === k().sectionSelector, this.container = te(c, Yo) || te(c, ai), this.index = function() {
                                    return this.siblings().indexOf(this)
                                }
                            };

                        function _c(c) {
                            return c.map(function(p) {
                                return p.item
                            })
                        }

                        function Sc(c, p) {
                            return c.find(function(w) {
                                return w.item === p
                            })
                        }
                        Pn.prototype.siblings = function() {
                            return this.rn ? this.isVisible ? $.N : $.an : this.parent ? this.parent.slides : 0
                        }, Pn.prototype.prev = function() {
                            var c = this.siblings(),
                                p = (this.rn ? c.indexOf(this) : this.parent.slides.indexOf(this)) - 1;
                            return p >= 0 ? c[p] : null
                        }, Pn.prototype.next = function() {
                            var c = this.siblings(),
                                p = (this.rn ? c.indexOf(this) : this.parent.slides.indexOf(this)) + 1;
                            return p < c.length ? c[p] : null
                        }, Pn.prototype.prevPanel = function() {
                            return this === this.prev() ? this.parent ? this.parent.prev() : null : this.prev() || (this.parent ? this.parent.prev() : null)
                        }, Pn.prototype.nextPanel = function() {
                            return this === this.next() ? this.parent ? this.parent.next() : null : this.next() || (this.parent ? this.parent.next() : null)
                        }, Pn.prototype.ln = function() {
                            return this.rn ? $.N : $.un
                        };
                        var bm, Mm = function(c) {
                                km.call(this, c)
                            },
                            VS = function(c) {
                                km.call(this, c)
                            };

                        function ci(c) {
                            var p = x(bl, c);
                            return p.length && (c = p[0]), c
                        }

                        function Om(c) {
                            return c ? c.activeSlide ? c.activeSlide : c : null
                        }

                        function $i(c) {
                            var p, w, C = k();
                            return C.autoScrolling && !C.scrollBar ? (p = -c, w = x(ai)[0]) : (p = c, w = window), {
                                options: p,
                                element: w
                            }
                        }

                        function Lm(c, p) {
                            !k().autoScrolling || k().scrollBar || c.self != window && T(c, Ml) ? c.self != window && T(c, Ml) ? c.scrollLeft = p : c.scrollTo(0, p) : c.style.top = p + "px"
                        }

                        function wc(c) {
                            var p = "transform " + k().scrollingSpeed + "ms " + k().easingcss3;
                            return V(c, ac), N(c, {
                                "-webkit-transition": p,
                                transition: p
                            })
                        }

                        function xc(c, p) {
                            var w = c.index(),
                                C = B(p, Xt);
                            return w == C ? "none" : w > C ? "up" : "down"
                        }

                        function Rl(c) {
                            return D(c, ac)
                        }

                        function Ec(c) {
                            return {
                                "-webkit-transform": c,
                                "-moz-transform": c,
                                "-ms-transform": c,
                                transform: c
                            }
                        }

                        function Nm(c, p) {
                            p ? wc(re()) : Rl(re()), clearTimeout(bm), N(re(), Ec(c)), E.test.cn = c, bm = setTimeout(function() {
                                V(re(), ac)
                            }, 10)
                        }

                        function fi(c) {
                            var p = Math.round(c);
                            if (k().css3 && k().autoScrolling && !k().scrollBar) Nm("translate3d(0px, -" + p + "px, 0px)", !1);
                            else if (k().autoScrolling && !k().scrollBar) N(re(), {
                                top: -p + "px"
                            }), E.test.top = -p + "px";
                            else {
                                var w = $i(p);
                                Lm(w.element, w.options)
                            }
                        }

                        function Qo(c, p) {
                            p !== "internal" && se("fadingEffect", "update", c), se("cards", "update_", c), Nl("scrollingSpeed", c, p)
                        }
                        E.setScrollingSpeed = Qo;
                        var Zo, ke = null,
                            Jo = null,
                            Dl = null;

                        function zl(c, p, w, C) {
                            var M, F = function(ce) {
                                    return ce.self != f && T(ce, Ml) ? ce.scrollLeft : !k().autoScrolling || k().scrollBar ? yt() : ce.offsetTop
                                }(c),
                                z = p - F,
                                J = !1,
                                X = $.G;
                            Z({
                                G: !0
                            }), Zo && window.cancelAnimationFrame(Zo), Zo = function(ce) {
                                M || (M = ce);
                                var pe = Math.floor(ce - M);
                                if ($.G) {
                                    var ue = p;
                                    w && (ue = f.fp_easings[k().easing](pe, F, z, w)), pe <= w && Lm(c, ue), pe < w ? window.requestAnimationFrame(Zo) : C === void 0 || J || (C(), Z({
                                        G: !1
                                    }), J = !0)
                                } else J || X || (C(), Z({
                                    G: !1
                                }), J = !0)
                            }, window.requestAnimationFrame(Zo)
                        }

                        function Pr(c) {
                            return c && !c.item ? new Mm(new hi(c)) : c ? new Mm(c) : null
                        }

                        function Cc(c) {
                            return c ? new VS(c) : null
                        }

                        function In(c, p) {
                            var w = function(C, M) {
                                var F = {
                                    afterRender: function() {
                                        return {
                                            section: Pr(Y().P),
                                            sn: Cc(Y().P.activeSlide)
                                        }
                                    },
                                    onLeave: function() {
                                        return {
                                            origin: Pr(M.items.origin),
                                            destination: Pr(M.items.destination),
                                            direction: M.direction,
                                            trigger: Y().H
                                        }
                                    },
                                    afterLoad: function() {
                                        return F.onLeave()
                                    },
                                    afterSlideLoad: function() {
                                        return {
                                            section: Pr(M.items.section),
                                            origin: Pr(M.items.origin),
                                            destination: Pr(M.items.destination),
                                            direction: M.direction,
                                            trigger: Y().H
                                        }
                                    },
                                    onSlideLeave: function() {
                                        return F.afterSlideLoad()
                                    },
                                    beforeLeave: function() {
                                        return F.onLeave()
                                    },
                                    onScrollOverflow: function() {
                                        return {
                                            section: Pr(Y().P),
                                            sn: Cc(Y().P.activeSlide),
                                            position: M.position,
                                            direction: M.direction
                                        }
                                    }
                                };
                                return F[C]()
                            }(c, p);
                            return _t(re(), c, w), k()[c].apply(w[Object.keys(w)[0]], nm(w)) !== !1
                        }

                        function Il(c) {
                            var p = ci(c);
                            x("video, audio", p).forEach(function(w) {
                                w.hasAttribute("data-autoplay") && typeof w.play == "function" && w.play()
                            }), x('iframe[src*="youtube.com/embed/"]', p).forEach(function(w) {
                                w.hasAttribute("data-autoplay") && Am(w), w.onload = function() {
                                    w.hasAttribute("data-autoplay") && Am(w)
                                }
                            })
                        }

                        function Am(c) {
                            c.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', "*")
                        }

                        function Tc(c) {
                            var p = ci(c);
                            x("video, audio", p).forEach(function(w) {
                                w.hasAttribute("data-keepplaying") || typeof w.pause != "function" || w.pause()
                            }), x('iframe[src*="youtube.com/embed/"]', p).forEach(function(w) {
                                /youtube\.com\/embed\//.test(Re(w, "src")) && !w.hasAttribute("data-keepplaying") && w.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', "*")
                            })
                        }

                        function Hi(c) {
                            k().lazyLoading && x("img[data-src], img[data-srcset], source[data-src], source[data-srcset], video[data-src], audio[data-src], iframe[data-src]", ci(c)).forEach(function(p) {
                                if (["src", "srcset"].forEach(function(C) {
                                        var M = Re(p, "data-" + C);
                                        M != null && M && (El(p, C), p.addEventListener("load", function() {}))
                                    }), Ke(p, "source")) {
                                    var w = te(p, "video, audio");
                                    w && (w.load(), w.onloadeddata = function() {})
                                }
                            })
                        }

                        function Rm() {
                            var c = Y().P.item,
                                p = Y().P.activeSlide,
                                w = Dm(c),
                                C = String(w);
                            p && (C = C + "-" + Dm(p.item)), C = C.replace("/", "-").replace("#", "");
                            var M = new RegExp("\\b\\s?fp-viewing-[^\\s]+\\b", "g");
                            ke.className = ke.className.replace(M, ""), D(ke, "fp-viewing-" + C)
                        }

                        function Dm(c) {
                            if (!c) return null;
                            var p = Re(c, "data-anchor"),
                                w = B(c);
                            return p == null && (p = w), p
                        }

                        function Pc(c, p, w) {
                            var C = "";
                            k().anchors.length && !k().lockAnchors && (c ? (w != null && (C = w), p == null && (p = c), Z({
                                B: p
                            }), kc(C + "/" + p)) : (c != null && Z({
                                B: p
                            }), kc(w))), Rm()
                        }

                        function kc(c) {
                            if (k().recordHistory) location.hash = c;
                            else if (h || _) f.history.replaceState(void 0, void 0, "#" + c);
                            else {
                                var p = f.location.href.split("#")[0];
                                f.location.replace(p + "#" + c)
                            }
                        }

                        function zm(c, p, w) {
                            var C = p === "Section" ? k().anchors[c] : Re(w, "data-anchor");
                            return encodeURI(k().navigationTooltips[c] || C || p + " " + (c + 1))
                        }

                        function US(c) {
                            c.cancelable && We(c), Z({
                                H: "horizontalNav"
                            });
                            var p = te(this, Xt),
                                w = x(tr, te(this, Xt))[0],
                                C = Sc(Y().N, p).slides[B(te(this, "li"))];
                            K.L(fm, {
                                slides: w,
                                destination: C.item
                            })
                        }

                        function Im(c, p) {
                            k().slidesNavigation && c != null && (V(x(cc, c), Oe), D(x("a", x("li", c)[p]), Oe))
                        }
                        var Fl, di = {};

                        function Bl(c, p, w) {
                            p !== "all" ? di[w][p] = c : Object.keys(di[w]).forEach(function(C) {
                                di[w][C] = c
                            })
                        }

                        function ot() {
                            return di
                        }

                        function $S() {
                            var c = te(this, Xt);
                            T(this, Sm) ? ot().m.left && (Z({
                                H: "slideArrow"
                            }), K.L(nc, {
                                section: c
                            })) : ot().m.right && (Z({
                                H: "slideArrow"
                            }), K.L(rc, {
                                section: c
                            }))
                        }

                        function Fm(c) {
                            !k().loopHorizontal && k().controlArrows && (wl(x(vc, c.section), c.slideIndex !== 0), wl(x(wm, c.section), A(c.destiny) != null))
                        }

                        function HS() {
                            clearTimeout(Fl), Z({
                                W: !1
                            })
                        }

                        function pi(c, p, w) {
                            var C = te(c, Xt),
                                M = Y().N.filter(function(J) {
                                    return J.item == C
                                })[0],
                                F = M.slides.filter(function(J) {
                                    return J.item == p
                                })[0],
                                z = {
                                    slides: c,
                                    destiny: p,
                                    direction: w,
                                    destinyPos: {
                                        left: p.offsetLeft
                                    },
                                    slideIndex: F.index(),
                                    section: C,
                                    sectionIndex: M.index(),
                                    anchorLink: M.anchor,
                                    slidesNav: x(hc, C)[0],
                                    slideAnchor: F.anchor,
                                    prevSlide: M.activeSlide.item,
                                    prevSlideIndex: M.activeSlide.index(),
                                    items: {
                                        section: M,
                                        origin: M.activeSlide,
                                        destination: F
                                    },
                                    localIsResizing: $.F
                                };
                            z.xMovement = jm(z.prevSlideIndex, z.slideIndex), z.direction = z.direction ? z.direction : z.xMovement, z.localIsResizing || Z({
                                canScroll: !1
                            }), se("parallax", "applyHorizontal", z), se("cards", "apply", z), se("dropEffect", "apply", z), se("waterEffect", "apply", z), k().onSlideLeave && !z.localIsResizing && z.xMovement !== "none" && qe(k().onSlideLeave) && In("onSlideLeave", z) === !1 ? Z({
                                W: !1
                            }) : (De("dropEffect") && k().dropEffect || (D(p, Oe), V(Cr(p), Oe)), Fn(), z.localIsResizing || (Tc(z.prevSlide), Hi(p)), Fm(z), M.isActive && !z.localIsResizing && Pc(z.slideIndex, z.slideAnchor, z.anchorLink), se("continuousHorizontal", "apply", z), K.L(hm, z), Tm() ? bc(z) : Bm(c, z, !0), k().interlockedSlides && E.interlockedSlides && (De("continuousHorizontal") && w !== void 0 && w !== z.xMovement || se("interlockedSlides", "apply", z)))
                        }

                        function Bm(c, p, w) {
                            var C = p.destinyPos;
                            if (Im(p.slidesNav, p.slideIndex), Z({
                                    scrollX: Math.round(C.left)
                                }), k().css3) {
                                var M = "translate3d(-" + Math.round(C.left) + "px, 0px, 0px)";
                                E.test.dn[p.sectionIndex] = M, De("dragAndMove") && p.vn !== void 0 || wc(x(Yo, c)), N(x(Yo, c), Ec(M)), De("interlockedSlides") || clearTimeout(Fl), Fl = setTimeout(function() {
                                    w && bc(p)
                                }, k().scrollingSpeed)
                            } else E.test.left[p.sectionIndex] = Math.round(C.left), zl(c, Math.round(C.left), k().scrollingSpeed, function() {
                                w && bc(p)
                            })
                        }

                        function jm(c, p) {
                            return c == p ? "none" : c > p ? "left" : "right"
                        }

                        function WS() {
                            clearTimeout(Fl)
                        }

                        function bc(c) {
                            se("continuousHorizontal", "afterSlideLoads", c), se("dragAndMove", "afterSlideLoads", c), c.localIsResizing || (se("parallax", "afterSlideLoads"), se("scrollOverflowReset", "setPrevious", c.prevSlide), se("scrollOverflowReset", "reset"), qe(k().afterSlideLoad) && In("afterSlideLoad", c), Z({
                                canScroll: !0
                            }), Il(c.destiny), K.L(sc, c)), Z({
                                W: !1
                            }), se("interlockedSlides", "interlockedSlides", c)
                        }

                        function es(c, p) {
                            Qo(0, "internal"), p !== void 0 && Z({
                                F: !0
                            }), pi(te(c, tr), c), p !== void 0 && Z({
                                F: !1
                            }), Qo(Ui().scrollingSpeed, "internal")
                        }

                        function Mc(c, p) {
                            Nl("recordHistory", c, p)
                        }

                        function Wi(c, p) {
                            c || fi(0), Nl("autoScrolling", c, p);
                            var w = Y().P.item;
                            if (k().autoScrolling && !k().scrollBar) N(Dl, {
                                overflow: "hidden",
                                height: "100%"
                            }), V(ke, "fp-scrollable"), Mc(Ui().recordHistory, "internal"), N(re(), {
                                "-ms-touch-action": "none",
                                "touch-action": "none"
                            }), w != null && fi(w.offsetTop);
                            else if (N(Dl, {
                                    overflow: "visible",
                                    height: "initial"
                                }), D(ke, "fp-scrollable"), Mc(!!k().autoScrolling && Ui().recordHistory, "internal"), N(re(), {
                                    "-ms-touch-action": "",
                                    "touch-action": ""
                                }), Rl(re()), w != null) {
                                var C = $i(w.offsetTop);
                                C.element.scrollTo(0, C.options)
                            }
                            _t(re(), "setAutoScrolling", c)
                        }

                        function Oc() {
                            for (var c = x(bl), p = 0; p < c.length; p++) es(c[p], "internal")
                        }

                        function Vm() {
                            var c = x(".fp-auto-height")[0] || Fc() && x(".fp-auto-height-responsive")[0];
                            k().lazyLoading && c && x(".fp-section:not(.active)").forEach(function(p) {
                                var w, C, M, F, z;
                                C = (w = p.getBoundingClientRect()).top, M = w.bottom, F = C + 2 < $.q && C > 0, z = M > 2 && M < $.q, (F || z) && Hi(p)
                            })
                        }

                        function GS() {
                            _t(H(this), "click")
                        }

                        function Um() {
                            li(x(ui));
                            var c = d.createElement("div");
                            c.setAttribute("id", "fp-nav");
                            var p = d.createElement("ul");
                            c.appendChild(p), U(c, ke);
                            var w = x(ui)[0];
                            D(w, "fp-" + k().navigationPosition), k().showActiveTooltip && D(w, "fp-show-active");
                            for (var C = "", M = 0; M < Y().N.length; M++) {
                                var F = Y().N[M],
                                    z = "";
                                k().anchors.length && (z = F.anchor), C += '<li><a href="#' + encodeURI(z) + '"><span class="fp-sr-only">' + zm(F.index(), "Section") + "</span><span></span></a>";
                                var J = k().navigationTooltips[F.index()];
                                J !== void 0 && J !== "" && (C += '<div class="fp-tooltip fp-' + k().navigationPosition + '">' + J + "</div>"), C += "</li>"
                            }
                            x("ul", w)[0].innerHTML = C;
                            var X = x("li", x(ui)[0])[Y().P.index()];
                            D(x("a", X), Oe)
                        }

                        function YS(c) {
                            c.preventDefault && We(c), Z({
                                H: "verticalNav"
                            });
                            var p = B(te(this, "#fp-nav li"));
                            K.L(cm, {
                                destination: Y().N[p]
                            })
                        }

                        function Lc(c, p) {
                            var w;
                            w = c, k().menu && k().menu.length && x(k().menu).forEach(function(C) {
                                    C != null && (V(x(cc, C), Oe), D(x('[data-menuanchor="' + w + '"]', C), Oe))
                                }),
                                function(C, M) {
                                    var F = x(ui)[0];
                                    k().navigation && F != null && F.style.display !== "none" && (V(x(cc, F), Oe), D(C ? x('a[href="#' + C + '"]', F) : x("a", x("li", F)[M]), Oe))
                                }(c, p)
                        }
                        di.m = {
                            up: !0,
                            down: !0,
                            left: !0,
                            right: !0
                        }, di.k = P({}, di.m), K.R(Cl, function(c) {
                            var p = c.target;
                            (Ke(p, mc) || te(p, mc)) && $S.call(p, c)
                        }), E.landscapeScroll = pi, K.R(bt, function() {
                            K.R(pm, HS)
                        }), E.setRecordHistory = Mc, E.setAutoScrolling = Wi, E.test.setAutoScrolling = Wi, new Date().getTime();
                        var Nc, Ac, Rc, Dc, ts, zc, XS = (Ac = !0, Rc = new Date().getTime(), Dc = !f.fullpage_api, function(c, p) {
                            var w = new Date().getTime(),
                                C = c === "wheel" ? k().scrollingSpeed : 100;
                            return Ac = Dc || w - Rc >= C, Dc = !f.fullpage_api, Ac && (Nc = p(), Rc = w), Nc === void 0 || Nc
                        });

                        function $m(c, p) {
                            if (qe(k().beforeLeave)) return XS(Y().H, function() {
                                return In(c, p)
                            })
                        }

                        function Gi(c, p, w) {
                            var C = c.item;
                            if (C != null) {
                                var M, F, z = {
                                    element: C,
                                    callback: p,
                                    isMovementUp: w,
                                    dtop: Hm(C),
                                    yMovement: xc(Y().P, C),
                                    anchorLink: c.anchor,
                                    sectionIndex: c.index(),
                                    activeSlide: c.activeSlide ? c.activeSlide.item : null,
                                    leavingSection: Y().P.index() + 1,
                                    localIsResizing: $.F,
                                    items: {
                                        origin: Y().P,
                                        destination: c
                                    },
                                    direction: null
                                };
                                if (!(Y().P.item == C && !$.F || k().scrollBar && yt() === z.dtop && !T(C, "fp-auto-height"))) {
                                    if (z.activeSlide != null && (M = Re(z.activeSlide, "data-anchor"), F = B(z.activeSlide, null)), !z.localIsResizing) {
                                        var J = z.yMovement;
                                        if (w !== void 0 && (J = w ? "up" : "down"), z.direction = J, Cm("dropEffect") && E.dropEffect.onLeave_(z), Cm("waterEffect") && E.waterEffect.onLeave_(z), qe(k().beforeLeave) && $m("beforeLeave", z) === !1 || qe(k().onLeave) && !In("onLeave", z)) return
                                    }
                                    se("parallax", "apply", z), se("cards", "apply", z), se("dropEffect", "apply", z), se("waterEffect", "apply", z), k().autoScrolling && k().continuousVertical && z.isMovementUp !== void 0 && (!z.isMovementUp && z.yMovement == "up" || z.isMovementUp && z.yMovement == "down") && (z = function(X) {
                                            Z({
                                                nn: !0
                                            });
                                            var ce = Y().P.item;
                                            return X.isMovementUp ? Ve(ce, Zu(ce, Xt)) : Te(ce, Ju(ce, Xt).reverse()), fi(Y().P.item.offsetTop), Oc(), X.pn = ce, X.dtop = X.element.offsetTop, X.yMovement = xc(Y().P, X.element), X.leavingSection = X.items.origin.index() + 1, X.sectionIndex = X.items.destination.index(), _t(re(), "onContinuousVertical", X), X
                                        }(z)), se("scrollOverflowReset", "setPrevious", Y().P.item), z.localIsResizing || Tc(Y().P.item), De("dropEffect") && k().dropEffect || (D(C, Oe), V(Cr(C), Oe)), Fn(), Hi(C), Z({
                                            canScroll: E.test.hn
                                        }), Pc(F, M, z.anchorLink), K.L(mm, z),
                                        function(X) {
                                            var ce = k().scrollingSpeed < 700,
                                                pe = ce ? 700 : k().scrollingSpeed;
                                            if (Z({
                                                    Y: "none",
                                                    scrollY: Math.round(X.dtop)
                                                }), K.L(pm), k().css3 && k().autoScrolling && !k().scrollBar) Nm("translate3d(0px, -" + Math.round(X.dtop) + "px, 0px)", !0), De("waterEffect") && Oc(), k().scrollingSpeed ? (clearTimeout(ts), ts = setTimeout(function() {
                                                jl(X), Z({
                                                    canScroll: !ce || E.test.hn
                                                })
                                            }, k().scrollingSpeed)) : jl(X);
                                            else {
                                                var ue = $i(X.dtop);
                                                E.test.top = -X.dtop + "px", clearTimeout(ts), zl(ue.element, ue.options, k().scrollingSpeed, function() {
                                                    k().scrollBar ? ts = setTimeout(function() {
                                                        jl(X)
                                                    }, 30) : (jl(X), Z({
                                                        canScroll: !ce || E.test.hn
                                                    }))
                                                })
                                            }
                                            ce && (clearTimeout(zc), zc = setTimeout(function() {
                                                Z({
                                                    canScroll: !0
                                                })
                                            }, pe))
                                        }(z), Z({
                                            Z: z.anchorLink
                                        }), Lc(z.anchorLink, function(X) {
                                            return X.pn != null ? X.isMovementUp ? $.j - 1 : 0 : X.sectionIndex
                                        }(z))
                                }
                            }
                        }

                        function Hm(c) {
                            var p = c.offsetHeight,
                                w = c.offsetTop,
                                C = w,
                                M = De("dragAndMove") && se("dragAndMove", "isGrabbing") ? se("dragAndMove", "isScrollingDown") : w > $.K,
                                F = C - L() + p,
                                z = k().bigSectionsDestination;
                            return p > L() ? (M || z) && z !== "bottom" || (C = F) : (M || $.F && A(c) == null) && (C = F), De("offsetSections") && (C = E.offsetSections.getSectionPosition_(M, C, c)), Z({
                                K: C
                            }), C
                        }

                        function jl(c) {
                            Z({
                                    C: !1
                                }),
                                function(p) {
                                    p.pn != null && (p.isMovementUp ? Ve(x(Xt)[0], p.pn) : Te(x(Xt)[Y().N.length - 1], p.pn), fi(Y().P.item.offsetTop), function() {
                                        for (var w = x(bl), C = 0; C < w.length; C++) es(w[C], "internal")
                                    }(), p.sectionIndex = p.items.destination.index(), p.leavingSection = p.items.origin.index() + 1, Z({
                                        nn: !1
                                    }))
                                }(c), qe(k().afterLoad) && !c.localIsResizing && In("afterLoad", c), se("parallax", "afterLoad"), se("waterEffect", "afterLoad"), se("dropEffect", "afterLoad"), se("scrollOverflowReset", "reset"), se("resetSliders", "apply", c), Fn(), c.localIsResizing || Il(c.element), D(c.element, ji), V(Cr(c.element), ji), Vm(), Z({
                                    canScroll: !0
                                }), K.L(oc, c), qe(c.callback) && c.callback()
                        }

                        function Ic(c, p) {
                            Nl("fitToSection", c, p)
                        }

                        function Wm() {
                            $.canScroll && (Z({
                                F: !0
                            }), Gi($.P), Z({
                                F: !1
                            }))
                        }

                        function Gm() {
                            var c = k().responsive || k().responsiveWidth,
                                p = k().responsiveHeight,
                                w = c && f.innerWidth < c,
                                C = p && f.innerHeight < p;
                            c && p ? Vl(w || C) : c ? Vl(w) : p && Vl(C)
                        }

                        function Vl(c) {
                            var p = Fc();
                            c ? p || (Wi(!1, "internal"), Ic(!1, "internal"), Q(x(ui)), D(ke, Tl), qe(k().afterResponsive) && k().afterResponsive.call(re(), c), se("responsiveSlides", "toSections"), _t(re(), "afterResponsive", c)) : p && (Wi(Ui().autoScrolling, "internal"), Ic(Ui().autoScrolling, "internal"), le(x(ui)), V(ke, Tl), qe(k().afterResponsive) && k().afterResponsive.call(re(), c), se("responsiveSlides", "toSlides"), _t(re(), "afterResponsive", c))
                        }

                        function Fc() {
                            return T(ke, Tl)
                        }

                        function Ym(c) {
                            k().verticalCentered && (!k().scrollOverflow && ae.gn(c.item) || ae.mn(c) || T(c.item, gm) || D(c.item, gm))
                        }
                        E.moveTo = moveTo, E.getScrollY = function() {
                            return $.scrollY
                        }, K.R(Tn, function() {
                            clearTimeout(ts), clearTimeout(zc)
                        }), E.setFitToSection = Ic, E.fitToSection = Wm, E.setResponsive = Vl;
                        var Bc, Xm = null;

                        function jc(c) {
                            var p = c.item,
                                w = c.wn.length,
                                C = c.index();
                            !Y().P && c.isVisible && (D(p, Oe), Fn(), Xm = Y().P.item), De("offsetSections") && N(p, {
                                height: yc(p)
                            }), k().paddingTop && N(p, {
                                "padding-top": k().paddingTop
                            }), k().paddingBottom && N(p, {
                                "padding-bottom": k().paddingBottom
                            }), k().sectionsColor[C] !== void 0 && N(p, {
                                "background-color": k().sectionsColor[C]
                            }), k().anchors[C] !== void 0 && p.setAttribute("data-anchor", c.anchor), w || Ym(c)
                        }

                        function qm() {
                            k().scrollOverflow && !k().scrollBar && (ae.bn(), ae.Sn())
                        }

                        function qS() {
                            K.removeListener(tc, qm), er("keyup", ae.yn)
                        }
                        E.getActiveSection = function() {
                            return Y().P
                        }, K.R(bt, function() {
                            K.R(tc, qm), K.R(mm, ae.onLeave), K.R(hm, ae.onLeave), K.R(sc, ae.afterLoad), K.R(oc, ae.afterLoad), K.R(Tn, qS), si("keyup", ae.yn)
                        });
                        var Vc, ae = {
                                Mn: null,
                                Tn: !0,
                                An: !0,
                                xn: null,
                                On: null,
                                kn: function(c) {
                                    if (!$.canScroll) return We(c), !1
                                },
                                En: function(c) {
                                    if (!ec() && k().keyboardScrolling && [38, 33, 32, 40, 34, 36, 35].indexOf(c.keyCode) > -1 && !ae.An) return We(c), !1
                                },
                                yn: function() {
                                    ae.Tn = $.canScroll
                                },
                                onLeave: function() {
                                    clearTimeout(Bc), ae.An = !1
                                },
                                afterLoad: function() {
                                    ae.An = !1, clearTimeout(Bc), Bc = setTimeout(function() {
                                        ae.Tn = $.canScroll
                                    }, 200)
                                },
                                Rn: function() {
                                    d.activeElement === this.Mn && (this.Mn.blur(), ae.An = !1)
                                },
                                Sn: function() {
                                    if (k().scrollOverflow && ae.Tn) {
                                        ae.Rn();
                                        var c = ae.Ln(Y().P.item);
                                        !c || h || _ || (this.Mn = c, requestAnimationFrame(function() {
                                            c.focus(), ae.An = !0
                                        })), ae.Tn = !1
                                    }
                                },
                                bn: function() {
                                    k().scrollOverflowMacStyle && !y && D(ke, "fp-scroll-mac"), Y().un.forEach(function(c) {
                                        if (!(c.slides && c.slides.length || T(c.item, "fp-auto-height-responsive") && Fc())) {
                                            var p, w = ci(c.item),
                                                C = ae.gn(c.item),
                                                M = (p = c).rn ? p : p.parent;
                                            if (v) {
                                                var F = C ? "addClass" : "removeClass";
                                                im[F](M.item, qo), im[F](c.item, qo)
                                            } else D(M.item, qo), D(c.item, qo);
                                            c.on || (ae.jn(w), ae.zn(w)), c.on = !0
                                        }
                                    })
                                },
                                zn: function(c) {
                                    ae.Ln(c).addEventListener("scroll", ae.Dn), c.addEventListener("wheel", ae.kn, {
                                        passive: !1
                                    }), c.addEventListener("keydown", ae.En, {
                                        passive: !1
                                    })
                                },
                                jn: function(c) {
                                    var p = document.createElement("div");
                                    p.className = Vi, xe(c, p), p.setAttribute("tabindex", "-1")
                                },
                                Nn: function(c) {
                                    var p = x(Xo, c)[0];
                                    p && (fe(p), c.removeAttribute("tabindex"))
                                },
                                Ln: function(c) {
                                    var p = ci(c);
                                    return x(Xo, p)[0] || p
                                },
                                on: function(c) {
                                    return T(c, Vi) || x(Xo, c)[0] != null
                                },
                                mn: function(c) {
                                    return c.rn && c.activeSlide ? c.activeSlide.on : c.on
                                },
                                gn: function(c) {
                                    return ae.Ln(c).scrollHeight > f.innerHeight
                                },
                                Pn: function(c, p) {
                                    if (!$.canScroll) return !1;
                                    if (k().scrollBar) return !0;
                                    var w = ae.Ln(p);
                                    if (!k().scrollOverflow || !T(w, Vi) || T(p, "fp-noscroll") || T(ci(p), "fp-noscroll")) return !0;
                                    var C = v ? 1 : 0,
                                        M = w.scrollTop,
                                        F = c === "up" && M <= 0,
                                        z = c === "down" && w.scrollHeight <= Math.ceil(w.offsetHeight + M) + C,
                                        J = F || z;
                                    return J || (this.xn = new Date().getTime()), J
                                },
                                Hn: function() {
                                    this.On = new Date().getTime();
                                    var c = this.On - ae.xn,
                                        p = (h || _) && $.X,
                                        w = $._ && c > 600;
                                    return p && c > 400 || w
                                },
                                Dn: (Vc = 0, function(c) {
                                    var p = c.target.scrollTop,
                                        w = $.Y !== "none" ? $.Y : Vc < p ? "down" : "up";
                                    Vc = p, qe(k().onScrollOverflow) && In("onScrollOverflow", {
                                        position: p,
                                        direction: w
                                    }), T(c.target, Vi) && $.canScroll && ae.Pn(w, c.target) && ae.Hn() && ae.gn(Y().P.item) && K.L(lm, {
                                        direction: w
                                    })
                                })
                            },
                            Uc = null,
                            $c = null;

                        function Fn() {
                            $.P = null, $.N.map(function(c) {
                                    var p = T(c.item, Oe);
                                    c.isActive = p, c.on = ae.on(c.item), p && ($.P = c), c.slides.length && (c.activeSlide = null, c.slides.map(function(w) {
                                        var C = T(w.item, Oe);
                                        w.on = ae.on(c.item), w.isActive = C, C && (c.activeSlide = w)
                                    }))
                                }),
                                function() {
                                    var c = $.P,
                                        p = !!$.P && $.P.slides.length,
                                        w = $.P ? $.P.activeSlide : null;
                                    if (!c && $.N.length && !Y().C) {
                                        if (Uc) {
                                            var C = Qm(Uc, $.N);
                                            C && ($.P = C, $.P.isActive = !0, D($.P.item, Oe)), $.P && fi($.P.item.offsetTop)
                                        }
                                        if (p && !w && $c) {
                                            var M = Qm($c, $.P.slides);
                                            M && ($.P.activeSlide = M, $.P.activeSlide.isActive = !0, D($.P.activeSlide.item, Oe)), $.P.activeSlide && es($.P.activeSlide.item, "internal")
                                        }
                                    }
                                }(), _t(re(), "onUpdateStateDone")
                        }

                        function Ul() {
                            var c = x(k().sectionSelector + ", " + Xt, re()),
                                p = S(c),
                                w = Array.from(c).map(function(F) {
                                    return new hi(F)
                                }),
                                C = w.filter(function(F) {
                                    return F.isVisible
                                }),
                                M = C.reduce(function(F, z) {
                                    return F.concat(z.slides)
                                }, []);
                            Uc = Km($.P), $c = Km($.P ? $.P.activeSlide : null), $.j = p.length, $.D = C.reduce(function(F, z) {
                                return F + z.slides.length
                            }, 0), $.N = C, $.an = w, $.slides = M, $.un = $.N.concat($.slides)
                        }

                        function Km(c) {
                            if (!c) return null;
                            var p = c ? c.item : null,
                                w = c.rn ? $.an : $.P.Cn;
                            if (p) {
                                var C = Sc(w, p);
                                return C ? C.index() : null
                            }
                            return null
                        }

                        function Qm(c, p) {
                            var w, C = c - 1,
                                M = c;
                            do {
                                if (w = p[C] || p[M]) break;
                                C -= 1, M += 1
                            } while (C >= 0 || M < p.length);
                            return w
                        }
                        var hi = function(c) {
                            var p = this;
                            [].push.call(arguments, k().sectionSelector), Pn.apply(this, arguments), this.wn = x(k().slideSelector, c), this.Cn = Array.from(this.wn).map(function(w) {
                                return new $l(w, p)
                            }), this.slides = this.Cn.filter(function(w) {
                                return w.isVisible
                            }), this.activeSlide = this.slides.length ? this.slides.filter(function(w) {
                                return w.isActive
                            })[0] || this.slides[0] : null
                        };
                        hi.prototype = Pn.prototype, hi.prototype.constructor = hi;
                        var ns, $l = function(c, p) {
                            this.parent = p, Pn.call(this, c, k().slideSelector)
                        };

                        function Zm() {
                            D(x(k().sectionSelector, re()), kl), D(x(k().slideSelector, re()), fc)
                        }

                        function Hc(c) {
                            var p = c.slides.length,
                                w = c.wn,
                                C = c.slides,
                                M = 100 * p,
                                F = 100 / p;
                            if (!x(tr, c.item)[0]) {
                                var z = d.createElement("div");
                                z.className = Ml, ne(w, z);
                                var J = d.createElement("div");
                                J.className = pc, ne(w, J)
                            }
                            N(x(Yo, c.item), {
                                width: M + "%"
                            }), p > 1 && (k().controlArrows && function(ce) {
                                var pe = ce.item,
                                    ue = [Tr(k().controlArrowsHTML[0]), Tr(k().controlArrowsHTML[1])];
                                Te(x(tr, pe)[0], ue), D(ue, _m), D(ue[0], Sm), D(ue[1], "fp-next"), k().controlArrowColor !== "#fff" && (N(x(wm, pe), {
                                    "border-color": "transparent transparent transparent " + k().controlArrowColor
                                }), N(x(vc, pe), {
                                    "border-color": "transparent " + k().controlArrowColor + " transparent transparent"
                                })), k().loopHorizontal || Q(x(vc, pe))
                            }(c), k().slidesNavigation && function(ce) {
                                var pe = ce.item,
                                    ue = ce.slides.length;
                                U(Tr('<div class="fp-slidesNav"><ul></ul></div>'), pe);
                                var _e = x(hc, pe)[0];
                                D(_e, "fp-" + k().slidesNavPosition);
                                for (var we = 0; we < ue; we++) U(Tr('<li><a href="#"><span class="fp-sr-only">' + zm(we, "Slide", x(dc, pe)[we]) + "</span><span></span></a></li>"), x("ul", _e)[0]);
                                N(_e, {
                                    "margin-left": "-" + _e.innerWidth / 2 + "px"
                                });
                                var st = ce.activeSlide ? ce.activeSlide.index() : 0;
                                D(x("a", x("li", _e)[st]), Oe)
                            }(c)), C.forEach(function(ce) {
                                N(ce.item, {
                                    width: F + "%"
                                }), k().verticalCentered && Ym(ce)
                            });
                            var X = De("responsiveSlides") ? null : c.activeSlide || null;
                            X != null && $.P && ($.P.index() !== 0 || $.P.index() === 0 && X.index() !== 0) ? (es(X.item, "internal"), D(X.item, "fp-initial")) : D(w[0], Oe)
                        }
                        $l.prototype = Pn.prototype, $l.prototype.constructor = hi;
                        var Jm = {
                            attributes: !1,
                            subtree: !0,
                            childList: !0,
                            characterData: !0
                        };

                        function e0() {
                            return se("responsiveSlides", "isResponsiveSlidesChanging") || S(x(k().slideSelector, re())).length !== Y().D
                        }

                        function Wc(c) {
                            var p = e0();
                            (e0() || se("responsiveSlides", "isResponsiveSlidesChanging") || S(x(k().sectionSelector, re())).length !== Y().j) && !$.nn && (k().observer && ns && ns.disconnect(), Ul(), Fn(), k().anchors = [], li(x(ui)), se("responsiveSlides", "isResponsiveSlidesChanging") || Zm(), Em(), k().navigation && Um(), p && (li(x(hc)), li(x(mc))), Y().N.forEach(function(w) {
                                w.slides.length ? p && Hc(w) : jc(w)
                            })), k().observer && ns && x(ai)[0] && ns.observe(x(ai)[0], Jm)
                        }
                        K.R(bt, function() {
                            var c, p, w;
                            k().observer && "MutationObserver" in window && x(ai)[0] && (c = x(ai)[0], p = Jm, (w = new MutationObserver(Wc)).observe(c, p), ns = w), K.R(sm, Wc)
                        }), E.render = Wc;
                        var KS = function() {
                            var c = !1;
                            try {
                                var p = Object.defineProperty({}, "passive", {
                                    get: function() {
                                        c = !0
                                    }
                                });
                                Jn("testPassive", null, p), Bi("testPassive", null, p)
                            } catch {}
                            return function() {
                                return c
                            }
                        }();

                        function t0() {
                            return !!KS() && {
                                passive: !1
                            }
                        }
                        var n0, r0, Gc, kr, Hl = (Gc = new Date().getTime(), kr = [], {
                            In: function(c) {
                                var p = (c = c || f.event).wheelDelta || -c.deltaY || -c.detail,
                                    w = Math.max(-1, Math.min(1, p)),
                                    C = c.wheelDeltaX !== void 0 || c.deltaX !== void 0;
                                n0 = Math.abs(c.wheelDeltaX) < Math.abs(c.wheelDelta) || Math.abs(c.deltaX) < Math.abs(c.deltaY) || !C;
                                var M = new Date().getTime();
                                r0 = w < 0 ? "down" : "up", kr.length > 149 && kr.shift(), kr.push(Math.abs(p));
                                var F = M - Gc;
                                Gc = M, F > 200 && (kr = [])
                            },
                            Wn: function() {
                                var c = Wo(kr, 10) >= Wo(kr, 70);
                                return !!kr.length && c && n0
                            },
                            Fn: function() {
                                return r0
                            }
                        });

                        function QS() {
                            var c = k().css3 ? yt() + L() : zn(Y().N).item.offsetTop + zn(Y().N).item.offsetHeight,
                                p = $i(c);
                            E.test.top = -c + "px", Z({
                                canScroll: !1
                            }), zl(p.element, p.options, k().scrollingSpeed, function() {
                                setTimeout(function() {
                                    Z({
                                        C: !0
                                    }), Z({
                                        canScroll: !0
                                    })
                                }, 30)
                            })
                        }

                        function ZS() {
                            re().getBoundingClientRect().bottom >= 0 && i0()
                        }

                        function i0() {
                            var c = $i(zn(Y().N).item.offsetTop);
                            Z({
                                canScroll: !1
                            }), zl(c.element, c.options, k().scrollingSpeed, function() {
                                Z({
                                    canScroll: !0
                                }), Z({
                                    C: !1
                                }), Z({
                                    Vn: !1
                                })
                            })
                        }
                        var Yc, Xc, qc, o0 = (Yc = !1, Xc = {}, qc = {}, function(c, p, w) {
                            switch (c) {
                                case "set":
                                    Xc[p] = new Date().getTime(), qc[p] = w;
                                    break;
                                case "isNewKeyframe":
                                    var C = new Date().getTime();
                                    Yc = C - Xc[p] > qc[p]
                            }
                            return Yc
                        });

                        function rs() {
                            var c = Y().P.next();
                            c || !k().loopBottom && !k().continuousVertical || (c = Y().N[0]), c != null ? Gi(c, null, !1) : re().scrollHeight < ke.scrollHeight && k().scrollBar && k().Zn && K.L(dm)
                        }

                        function Yi() {
                            var c = Y().P.prev();
                            c || !k().loopTop && !k().continuousVertical || (c = zn(Y().N)), c != null && Gi(c, null, !0)
                        }
                        E.moveSectionDown = rs, E.moveSectionUp = Yi;
                        var Wl = 0;

                        function s0(c) {
                            k().autoScrolling && ($.canScroll && (c.pageY < Wl && ot().m.up ? Yi() : c.pageY > Wl && ot().m.down && rs()), Wl = c.pageY)
                        }

                        function l0(c) {
                            if (ot().m[c]) {
                                var p = c === "down" ? rs : Yi;
                                De("scrollHorizontally") && (p = se("scrollHorizontally", "getScrollSection", {
                                    type: c,
                                    scrollSection: p
                                })), k().scrollOverflow && ae.mn(Y().P) ? ae.Pn(c, Y().P.item) && ae.Hn() && p() : p()
                            }
                        }
                        var Gl, Kc, Xi, Yl = 0,
                            is = 0,
                            Xl = 0,
                            os = 0,
                            ql = u0(),
                            an = {
                                Bn: "ontouchmove" in window ? "touchmove" : ql ? ql.move : null,
                                Gn: "ontouchstart" in window ? "touchstart" : ql ? ql.down : null
                            };

                        function ss(c) {
                            var p = te(c.target, Xt) || Y().P.item,
                                w = ae.mn(Y().P);
                            if (ls(c)) {
                                Z({
                                    X: !0,
                                    _: !1
                                }), k().autoScrolling && (w && !$.canScroll || k().scrollBar) && We(c);
                                var C = Qc(c);
                                Xl = C.y, os = C.x;
                                var M = Math.abs(Yl - Xl) > f.innerHeight / 100 * k().touchSensitivity,
                                    F = Math.abs(is - os) > b() / 100 * k().touchSensitivity,
                                    z = x(tr, p).length && Math.abs(is - os) > Math.abs(Yl - Xl),
                                    J = Yl > Xl ? "down" : "up";
                                Z({
                                    Y: z ? is > os ? "right" : "left" : J
                                }), z ? !$.W && F && (is > os ? ot().m.right && K.L(rc, {
                                    section: p
                                }) : ot().m.left && K.L(nc, {
                                    section: p
                                })) : k().autoScrolling && $.canScroll && M && l0(J)
                            }
                        }

                        function ls(c) {
                            return c.pointerType === void 0 || c.pointerType != "mouse"
                        }

                        function Kl(c) {
                            if (k().fitToSection && Z({
                                    G: !1
                                }), ls(c)) {
                                var p = Qc(c);
                                Yl = p.y, is = p.x
                            }
                            Jn("touchend", a0)
                        }

                        function a0() {
                            Bi("touchend", a0), Z({
                                X: !1
                            })
                        }

                        function Qc(c) {
                            var p = {};
                            return p.y = c.pageY !== void 0 && (c.pageY || c.pageX) ? c.pageY : c.touches[0].pageY, p.x = c.pageX !== void 0 && (c.pageY || c.pageX) ? c.pageX : c.touches[0].pageX, _ && ls(c) && k().scrollBar && c.touches !== void 0 && (p.y = c.touches[0].pageY, p.x = c.touches[0].pageX), p
                        }

                        function u0() {
                            var c;
                            return f.PointerEvent && (c = {
                                down: "pointerdown",
                                move: "pointermove"
                            }), c
                        }

                        function Zc(c) {
                            k().autoScrolling && ls(c) && ot().m.up && ($.canScroll || We(c))
                        }

                        function c0(c, p) {
                            var w = p ? ? Y().P.item,
                                C = Sc($.N, w),
                                M = x(tr, w)[0];
                            if (!(M == null || Al() || $.W || C.slides.length < 2)) {
                                var F = C.activeSlide,
                                    z = c === "left" ? F.prev() : F.next();
                                if (!z) {
                                    if (!k().loopHorizontal) return;
                                    z = c === "left" ? zn(C.slides) : C.slides[0]
                                }
                                Z({
                                    W: !E.test.hn
                                }), pi(M, z.item, c)
                            }
                        }

                        function Jc(c) {
                            c0("left", c)
                        }

                        function ef(c) {
                            c0("right", c)
                        }

                        function tf(c) {
                            var p = Y().N.filter(function(C) {
                                return C.anchor === c
                            })[0];
                            if (!p) {
                                var w = c !== void 0 ? c - 1 : 0;
                                p = Y().N[w]
                            }
                            return p
                        }

                        function f0(c) {
                            c != null && pi(te(c, tr), c)
                        }

                        function nf(c, p) {
                            var w = tf(c);
                            if (w != null) {
                                var C = function(M, F) {
                                    var z = F.slides.filter(function(J) {
                                        return J.anchor === M
                                    })[0];
                                    return z == null && (M = M !== void 0 ? M : 0, z = F.slides[M]), z ? z.item : null
                                }(p, w);
                                w.anchor && w.anchor === $.Z || T(w.item, Oe) ? f0(C) : Gi(w, function() {
                                    f0(C)
                                })
                            }
                        }

                        function as(c, p) {
                            var w = tf(c);
                            p !== void 0 ? nf(c, p) : w != null && Gi(w)
                        }

                        function JS() {
                            clearTimeout(Kc), er("keydown", d0), er("keyup", p0)
                        }

                        function d0(c) {
                            clearTimeout(Kc);
                            var p = c.keyCode,
                                w = [37, 39].indexOf(p) > -1,
                                C = k().autoScrolling || k().fitToSection || w;
                            p === 9 ? function(M) {
                                var F = M.shiftKey,
                                    z = d.activeElement,
                                    J = rf(ci(Y().P.item));

                                function X(Je) {
                                    return We(Je), J[0] ? J[0].focus() : null
                                }
                                if ($.canScroll) {
                                    if (! function(Je) {
                                            var Le = rf(d),
                                                Ne = Le.indexOf(d.activeElement),
                                                me = Le[Je.shiftKey ? Ne - 1 : Ne + 1],
                                                lt = te(me, dc),
                                                ft = te(me, Xt);
                                            return !lt && !ft
                                        }(M)) {
                                        z ? te(z, ".fp-section.active,.fp-section.active .fp-slide.active") == null && (z = X(M)) : X(M);
                                        var ce = z == J[0],
                                            pe = z == J[J.length - 1],
                                            ue = F && ce;
                                        if (ue || !F && pe) {
                                            We(M);
                                            var _e = function(Je) {
                                                    var Le, Ne = Je ? "prevPanel" : "nextPanel",
                                                        me = [],
                                                        lt = Om(($.P && $.P.activeSlide ? $.P.activeSlide : $.P)[Ne]());
                                                    do(me = rf(lt.item)).length && (Le = {
                                                        Yn: lt,
                                                        Un: me[Je ? me.length - 1 : 0]
                                                    }), lt = Om(lt[Ne]()); while (lt && me.length === 0);
                                                    return Le
                                                }(ue),
                                                we = _e ? _e.Yn : null;
                                            if (we) {
                                                var st = we.rn ? we : we.parent;
                                                K.L(ic, {
                                                    Xn: st.index() + 1,
                                                    slideAnchor: we.rn ? 0 : we.index()
                                                }), Xi = _e.Un, We(M)
                                            }
                                        }
                                    }
                                } else We(M)
                            }(c) : !ec() && k().keyboardScrolling && C && (Gl = c.ctrlKey, Kc = setTimeout(function() {
                                (function(M) {
                                    var F = M.shiftKey,
                                        z = d.activeElement,
                                        J = Ke(z, "video") || Ke(z, "audio"),
                                        X = ae.Pn("up", Y().P.item),
                                        ce = ae.Pn("down", Y().P.item),
                                        pe = [37, 39].indexOf(M.keyCode) > -1;
                                    if (function(ue) {
                                            (function(_e) {
                                                return [40, 38, 32, 33, 34].indexOf(_e.keyCode) > -1 && !$.C
                                            })(ue) && !te(ue.target, Xo) && ue.preventDefault()
                                        }(M), $.canScroll || pe) switch (Z({
                                        H: "keydown"
                                    }), M.keyCode) {
                                        case 38:
                                        case 33:
                                            ot().k.up && X ? $.C ? K.L(am, {
                                                e: M
                                            }) : Yi() : ae.Sn();
                                            break;
                                        case 32:
                                            if (F && ot().k.up && !J && X) {
                                                Yi();
                                                break
                                            }
                                        case 40:
                                        case 34:
                                            if (ot().k.down && ce) {
                                                if ($.C) return;
                                                M.keyCode === 32 && J || rs()
                                            } else ae.Sn();
                                            break;
                                        case 36:
                                            ot().k.up && as(1);
                                            break;
                                        case 35:
                                            ot().k.down && as(Y().N.length);
                                            break;
                                        case 37:
                                            ot().k.left && Jc();
                                            break;
                                        case 39:
                                            ot().k.right && ef()
                                    }
                                })(c)
                            }, 0))
                        }

                        function p0(c) {
                            $.J && (Gl = c.ctrlKey)
                        }

                        function ew() {
                            Z({
                                J: !1
                            }), Gl = !1
                        }

                        function tw(c) {
                            h0()
                        }

                        function nw(c) {
                            te(Xi, dc) && !te(Xi, bl) || h0()
                        }

                        function h0() {
                            Xi && (Xi.focus(), Xi = null)
                        }

                        function rf(c) {
                            return [].slice.call(x('a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex="0"], [contenteditable]', c)).filter(function(p) {
                                return Re(p, "tabindex") !== "-1" && p.offsetParent !== null
                            })
                        }
                        E.moveSlideLeft = Jc, E.moveSlideRight = ef, E.moveTo = as, K.R(bt, function() {
                            Jn("blur", ew), si("keydown", d0), si("keyup", p0), K.R(Tn, JS), K.R(sc, tw), K.R(oc, nw)
                        });
                        var m0 = new Date().getTime(),
                            qi = [];

                        function of (c) {
                            c ? (function() {
                                var p, w = "";
                                f.addEventListener ? p = "addEventListener" : (p = "attachEvent", w = "on");
                                var C = "onwheel" in d.createElement("div") ? "wheel" : d.onmousewheel !== void 0 ? "mousewheel" : "DOMMouseScroll",
                                    M = t0();
                                C == "DOMMouseScroll" ? d[p](w + "MozMousePixelScroll", Ki, M) : d[p](w + C, Ki, M)
                            }(), re().addEventListener("mousedown", v0), re().addEventListener("mouseup", g0)) : (d.addEventListener ? (er("mousewheel", Ki, !1), er("wheel", Ki, !1), er("MozMousePixelScroll", Ki, !1)) : d.detachEvent("onmousewheel", Ki), re().removeEventListener("mousedown", v0), re().removeEventListener("mouseup", g0))
                        }

                        function Ki(c) {
                            var p = new Date().getTime(),
                                w = T(x(".fp-completely")[0], "fp-normal-scroll"),
                                C = function(pe, ue) {
                                    new Date().getTime();
                                    var _e = Y().C && pe.getBoundingClientRect().bottom >= 0 && Hl.Fn() === "up",
                                        we = Y().Vn;
                                    if (we) return We(ue), !1;
                                    if (Y().C) {
                                        if (_e) {
                                            var st;
                                            if (!(we || o0("isNewKeyframe", "beyondFullpage") && Hl.Wn())) return (st = $i(zn(Y().N).item.offsetTop + zn(Y().N).item.offsetHeight)).element.scrollTo(0, st.options), Z({
                                                Vn: !1
                                            }), We(ue), !1;
                                            if (Hl.Wn()) return _e = !1, Z({
                                                Vn: !0
                                            }), Z({
                                                H: "wheel"
                                            }), i0(), We(ue), !1
                                        } else o0("set", "beyondFullpage", 1e3);
                                        if (!we && !_e) return !0
                                    }
                                }(re(), c);
                            if ($._ || Z({
                                    X: !1,
                                    _: !0,
                                    Y: "none"
                                }), !ot().m.down && !ot().m.up) return We(c), !1;
                            if (C) return !0;
                            if (C === !1) return We(c), !1;
                            if (k().autoScrolling && !Gl && !w) {
                                var M = (c = c || f.event).wheelDelta || -c.deltaY || -c.detail,
                                    F = Math.max(-1, Math.min(1, M)),
                                    z = c.wheelDeltaX !== void 0 || c.deltaX !== void 0,
                                    J = Math.abs(c.wheelDeltaX) < Math.abs(c.wheelDelta) || Math.abs(c.deltaX) < Math.abs(c.deltaY) || !z,
                                    X = F < 0 ? "down" : F > 0 ? "up" : "none";
                                qi.length > 149 && qi.shift(), qi.push(Math.abs(M)), k().scrollBar && We(c);
                                var ce = p - m0;
                                return m0 = p, ce > 200 && (qi = []), Z({
                                    U: X
                                }), $.canScroll && !Al() && Wo(qi, 10) >= Wo(qi, 70) && J && (Z({
                                    H: "wheel"
                                }), l0(F < 0 ? "down" : "up")), !1
                            }
                            k().fitToSection && Z({
                                G: !1
                            })
                        }

                        function v0(c) {
                            var p;
                            c.which == 2 && (p = c.pageY, Wl = p, re().addEventListener("mousemove", s0))
                        }

                        function g0(c) {
                            c.which == 2 && re().removeEventListener("mousemove", s0)
                        }

                        function us(c) {
                            c ? ( of (!0), function() {
                                if (an.Bn && (h || _) && (!De("dragAndMove") || k().dragAndMove === "mouseonly")) {
                                    k().autoScrolling && (ke.removeEventListener(an.Bn, Zc, {
                                        passive: !1
                                    }), ke.addEventListener(an.Bn, Zc, {
                                        passive: !1
                                    }));
                                    var p = k().touchWrapper;
                                    p.removeEventListener(an.Gn, Kl), p.removeEventListener(an.Bn, ss, {
                                        passive: !1
                                    }), p.addEventListener(an.Gn, Kl), p.addEventListener(an.Bn, ss, {
                                        passive: !1
                                    })
                                }
                            }()) : ( of (!1), function() {
                                if (an.Bn && (h || _)) {
                                    k().autoScrolling && (ke.removeEventListener(an.Bn, ss, {
                                        passive: !1
                                    }), ke.removeEventListener(an.Bn, Zc, {
                                        passive: !1
                                    }));
                                    var p = k().touchWrapper;
                                    p.removeEventListener(an.Gn, Kl), p.removeEventListener(an.Bn, ss, {
                                        passive: !1
                                    })
                                }
                            }())
                        }
                        E.setMouseWheelScrolling = of ;
                        var sf = !0;

                        function rw() {
                            ["mouseenter", "touchstart", "mouseleave", "touchend"].forEach(function(c) {
                                er(c, _0, !0)
                            })
                        }

                        function y0(c, p) {
                            document["fp_" + c] = p, si(c, _0, !0)
                        }

                        function _0(c) {
                            var p = c.type,
                                w = !1,
                                C = p === "mouseleave" ? c.toElement || c.relatedTarget : c.target;
                            C != document && C ? (p === "touchend" && (sf = !1, setTimeout(function() {
                                sf = !0
                            }, 800)), (p !== "mouseenter" || sf) && (k().normalScrollElements.split(",").forEach(function(M) {
                                if (!w) {
                                    var F = Ke(C, M),
                                        z = te(C, M);
                                    (F || z) && (E.shared._n || us(!1), E.shared._n = !0, w = !0)
                                }
                            }), !w && E.shared._n && (us(!0), E.shared._n = !1))) : us(!0)
                        }

                        function Ql(c, p) {
                            Qo(0, "internal"), as(c, p), Qo(Ui().scrollingSpeed, "internal")
                        }
                        K.R(bt, function() {
                            k().normalScrollElements && (["mouseenter", "touchstart"].forEach(function(c) {
                                y0(c, !1)
                            }), ["mouseleave", "touchend"].forEach(function(c) {
                                y0(c, !0)
                            })), K.R(Tn, rw)
                        }), E.silentMoveTo = Ql;
                        var lf, S0, af = L(),
                            w0 = b(),
                            uf = !1;

                        function iw() {
                            clearTimeout(lf), clearTimeout(S0), Bi("resize", cf)
                        }

                        function cf() {
                            uf || (k().autoScrolling && !k().scrollBar || !k().fitToSection) && x0(L()),
                                function() {
                                    if (h)
                                        for (var c = 0; c < 4; c++) S0 = setTimeout(function() {
                                            window.requestAnimationFrame(function() {
                                                k().autoScrolling && !k().scrollBar && (Z({
                                                    F: !0
                                                }), Ql($.P.index() + 1), Z({
                                                    F: !1
                                                }))
                                            })
                                        }, 200 * c)
                                }(), uf = !0, clearTimeout(lf), lf = setTimeout(function() {
                                    (function() {
                                        if (Z({
                                                F: !0
                                            }), x0(""), _t(re(), "onResize"), k().autoScrolling || $.C || function() {
                                                if (!k().autoScrolling || k().scrollBar) {
                                                    var M = .01 * f.innerHeight;
                                                    d.documentElement.style.setProperty("--vh", "".concat(M, "px"))
                                                }
                                            }(), K.L(sm), Fn(), Gm(), h) {
                                            var c = d.activeElement;
                                            if (!Ke(c, "textarea") && !Ke(c, "input") && !Ke(c, "select")) {
                                                var p = L();
                                                Math.abs(p - af) > 20 * Math.max(af, p) / 100 && (ff(!0), af = p)
                                            }
                                        } else w = L(), C = b(), $.q === w && w0 === C || (Z({
                                            q: w
                                        }), w0 = C, ff(!0));
                                        var w, C;
                                        _t(re(), "onResizeEnds"), Z({
                                            F: !1
                                        })
                                    })(), uf = !1
                                }, 400)
                        }

                        function ff(c) {
                            if (!T(re(), uc)) {
                                Z({
                                    F: !0,
                                    q: L(),
                                    Qn: b()
                                });
                                for (var p = Y().N, w = 0; w < p.length; ++w) {
                                    var C = p[w],
                                        M = x(tr, C.item)[0],
                                        F = C.slides;
                                    De("offsetSections") && N(C.item, {
                                        height: yc(C.item)
                                    }), F.length > 1 && pi(M, C.activeSlide.item)
                                }
                                k().scrollOverflow && ae.bn();
                                var z = Y().P.index();
                                $.C || !z || De("fadingEffect") || De("dropEffect") || De("waterEffect") || Ql(z + 1), Z({
                                    F: !1
                                }), qe(k().afterResize) && c && k().afterResize.call(re(), f.innerWidth, f.innerHeight), qe(k().afterReBuild) && !c && k().afterReBuild.call(re()), _t(re(), "afterRebuild")
                            }
                        }

                        function x0(c) {
                            Y().N.forEach(function(p) {
                                var w = c !== "" || De("offsetSections") ? yc(p.item) : "";
                                N(p.item, {
                                    height: w
                                })
                            })
                        }

                        function df() {
                            var c, p, w = f.location.hash;
                            if (w.length) {
                                var C = w.replace("#", "").split("/"),
                                    M = w.indexOf("#/") > -1;
                                c = M ? "/" + C[1] : decodeURIComponent(C[0]);
                                var F = M ? C[2] : C[1];
                                F && F.length && (p = decodeURIComponent(F))
                            }
                            return {
                                section: c,
                                sn: p
                            }
                        }

                        function ow() {
                            Bi("hashchange", E0)
                        }

                        function E0() {
                            if (!$.V && !k().lockAnchors) {
                                var c = df(),
                                    p = c.section,
                                    w = c.sn,
                                    C = $.Z === void 0,
                                    M = $.Z === void 0 && w === void 0 && !$.W;
                                p && p.length && (p && p !== $.Z && !C || M && !Al() || !$.W && $.B != w && !Al()) && K.L(ic, {
                                    Xn: p,
                                    slideAnchor: w
                                })
                            }
                        }

                        function sw(c) {
                            var p = c.target;
                            te(p, k().menu + " [data-menuanchor]") && lw.call(p, c)
                        }

                        function lw(c) {
                            Z({
                                H: "menu"
                            }), !x(k().menu)[0] || !k().lockAnchors && k().anchors.length || (We(c), K.L(um, {
                                anchor: Re(this, "data-menuanchor")
                            }))
                        }

                        function aw(c) {
                            var p = c.target;
                            p && te(p, "#fp-nav a") ? YS.call(p, c.e) : Ke(p, ".fp-tooltip") ? GS.call(p) : (Ke(p, ym) || te(p, ym) != null) && US.call(p, c.e)
                        }
                        E.reBuild = ff, K.R(bt, function() {
                            cf(), Jn("resize", cf), K.R(Tn, iw)
                        }), E.setLockAnchors = function(c) {
                            k().lockAnchors = c
                        }, K.R(bt, function() {
                            Jn("hashchange", E0), K.R(Tn, ow)
                        }), K.R(bt, function() {
                            si("wheel", Hl.In, t0()), K.R(dm, QS), K.R(am, ZS)
                        }), K.R(bt, function() {
                            K.R(Cl, sw)
                        }), K.R(bt, function() {
                            K.R(Cl, aw)
                        });
                        var pf, hf, C0 = 0;

                        function Zl(c) {
                            var p, w, C, M, F;
                            if (_t(re(), "onScroll"), !$.F && Y().P && (zn(Y().N), !Y().C && !Y().Vn && (!k().autoScrolling || k().scrollBar || De("dragAndMove")) && !Tm())) {
                                var z = De("dragAndMove") ? Math.abs(se("dragAndMove", "getCurrentScroll")) : yt(),
                                    J = function(zt) {
                                        var un = zt > C0 ? "down" : "up";
                                        return C0 = zt, Z({
                                            K: zt
                                        }), un
                                    }(z),
                                    X = 0,
                                    ce = z + L() / 2,
                                    pe = (De("dragAndMove") ? se("dragAndMove", "getDocumentHeight") : ke.scrollHeight - L()) === z,
                                    ue = Y().N;
                                if (Z({
                                        scrollY: z
                                    }), pe) X = ue.length - 1;
                                else if (z)
                                    for (var _e = 0; _e < ue.length; ++_e)(te(ue[_e].item, Xt) || ue[_e].item).offsetTop <= ce && (X = _e);
                                else X = 0;
                                if (C = J, M = Y().P.item.offsetTop, F = M + L(), (C == "up" ? F >= yt() + L() : M <= yt()) && (T(Y().P.item, ji) || (D(Y().P.item, ji), V(Cr(Y().P.item), ji))), w = (p = ue[X]).item, !p.isActive) {
                                    Z({
                                        V: !0
                                    });
                                    var we, st, Je = Y().P.item,
                                        Le = Y().P.index() + 1,
                                        Ne = xc(Y().P, w),
                                        me = p.anchor,
                                        lt = p.index() + 1,
                                        ft = p.activeSlide,
                                        rr = {
                                            P: Je,
                                            sectionIndex: lt - 1,
                                            anchorLink: me,
                                            element: w,
                                            leavingSection: Le,
                                            direction: Ne,
                                            items: {
                                                origin: Y().P,
                                                destination: p
                                            }
                                        };
                                    ft && (st = ft.anchor, we = ft.index()), $.canScroll && (V(ue.filter(function(zt) {
                                        return zt.index() !== p.index()
                                    }).map(function(zt) {
                                        return zt.item
                                    }), Oe), D(w, Oe), se("parallax", "afterLoad"), qe(k().beforeLeave) && $m("beforeLeave", rr), qe(k().onLeave) && In("onLeave", rr), qe(k().afterLoad) && In("afterLoad", rr), se("resetSliders", "apply", {
                                        localIsResizing: $.F,
                                        leavingSection: Le
                                    }), Tc(Je), Hi(w), Il(w), Lc(me, lt - 1), k().anchors.length && Z({
                                        Z: me
                                    }), Fn(), Pc(we, st, me)), clearTimeout(pf), pf = setTimeout(function() {
                                        Z({
                                            V: !1
                                        })
                                    }, 100)
                                }
                                k().fitToSection && $.canScroll && (clearTimeout(hf), hf = setTimeout(function() {
                                    $.N.filter(function(zt) {
                                        var un = zt.item.getBoundingClientRect();
                                        return Math.round(un.bottom) === Math.round(L()) || Math.round(un.top) === 0
                                    }).length || Wm()
                                }, k().en))
                            }
                        }

                        function T0(c, p) {
                            p !== void 0 ? (p = p.replace(/ /g, "").split(",")).forEach(function(w) {
                                Bl(c, w, "k")
                            }) : (Bl(c, "all", "k"), k().keyboardScrolling = c)
                        }

                        function uw(c) {
                            var p = c.index();
                            k().anchors[p] !== void 0 && c.isActive && Lc(k().anchors[p], p), k().menu && k().css3 && te(x(k().menu)[0], ai) != null && x(k().menu).forEach(function(w) {
                                ke.appendChild(w)
                            })
                        }

                        function P0() {
                            var c, p, w = Y().P,
                                C = Y().P.item;
                            D(C, ji), Hi(C), Vm(), Il(C), p = tf((c = df()).section), c.section && p && (p === void 0 || p.index() !== B(Xm)) || !qe(k().afterLoad) || In("afterLoad", {
                                P: C,
                                element: C,
                                direction: null,
                                anchorLink: w.anchor,
                                sectionIndex: w.index(),
                                items: {
                                    origin: Y().P,
                                    destination: Y().P
                                }
                            }), qe(k().afterRender) && In("afterRender"), _t(re(), "afterRender")
                        }

                        function mf(c, p) {
                            p !== void 0 ? (p = p.replace(/ /g, "").split(",")).forEach(function(w) {
                                Bl(c, w, "m")
                            }) : Bl(c, "all", "m"), _t(re(), "setAllowScrolling", {
                                value: c,
                                Jn: p
                            })
                        }

                        function k0() {
                            var c = df(),
                                p = c.section,
                                w = c.sn;
                            p ? k().animateAnchor ? nf(p, w) : Ql(p, w) : K.L(tc, null)
                        }
                        K.R(Tn, function() {
                                clearTimeout(pf), clearTimeout(hf)
                            }), K.R(bt, function() {
                                Jn("scroll", Zl), d.body.addEventListener("scroll", Zl), K.R(ic, function(c) {
                                    nf(c.Xn, c.slideAnchor)
                                }), K.R(um, function(c) {
                                    as(c.anchor, void 0)
                                }), K.R(lm, function(c) {
                                    (c.direction === "down" ? rs : Yi)()
                                }), K.R(cm, function(c) {
                                    Gi(c.destination)
                                })
                            }), K.R(Tn, function() {
                                Bi("scroll", Zl)
                            }), E.getActiveSlide = function() {
                                return Cc(Y().P.activeSlide)
                            }, E.getScrollX = function() {
                                return $.scrollX
                            }, K.R(bt, function() {
                                K.R(Tn, WS), K.R(fm, function(c) {
                                    pi(c.slides, c.destination)
                                }), K.R(rc, function(c) {
                                    ef(c.section)
                                }), K.R(nc, function(c) {
                                    Jc(c.section)
                                })
                            }), K.R(bt, function() {
                                var c = k().credits.position,
                                    p = ["left", "right"].indexOf(c) > -1 ? "".concat(c, ": 0;") : "",
                                    w = `
        <div class="fp-watermark" style="`.concat(p, `">
            <a href="https://alvarotrigo.com/fullPage/" 
                rel="nofollow noopener" 
                target="_blank" 
                style="text-decoration:none; color: #000;">
                    `).concat(k().credits.label, `
            </a>
        </div>
    `),
                                    C = zn($.N),
                                    M = !$.Kn || k().credits.enabled;
                                C && C.item && M && C.item.insertAdjacentHTML("beforeend", w)
                            }),
                            function() {
                                K.R(om, function() {
                                    var J, X, ce;
                                    Z({
                                        Kn: (k().licenseKey, J = k().licenseKey, X = function(pe) {
                                            var ue = parseInt("514").toString(16);
                                            if (!pe || pe.length < 29 || pe.split(c[0]).length === 4) return null;
                                            var _e = ["Each", "for"][M()]().join(""),
                                                we = pe[["split"]]("-"),
                                                st = [];
                                            we[_e](function(Ne, me) {
                                                if (me < 4) {
                                                    var lt = function(zt) {
                                                        var un = zt[zt.length - 1],
                                                            mw = ["NaN", "is"][M()]().join("");
                                                        return window[mw](un) ? F(un) : function(vw) {
                                                            return vw - Oe.length
                                                        }(un)
                                                    }(Ne);
                                                    st.push(lt);
                                                    var ft = F(Ne[lt]);
                                                    if (me === 1) {
                                                        var rr = ["pa", "dS", "t", "art"].join("");
                                                        ft = ft.toString()[rr](2, "0")
                                                    }
                                                    ue += ft, me !== 0 && me !== 1 || (ue += "-")
                                                }
                                            });
                                            var Je = 0,
                                                Le = "";
                                            return pe.split("-").forEach(function(Ne, me) {
                                                if (me < 4) {
                                                    for (var lt = 0, ft = 0; ft < 4; ft++) ft !== st[me] && (lt += Math.abs(F(Ne[ft])), isNaN(Ne[ft]) || Je++);
                                                    var rr = z(lt);
                                                    Le += rr
                                                }
                                            }), Le += z(Je), {
                                                qn: new Date(ue + "T00:00"),
                                                $n: ue.split("-")[2] === 8 * (Oe.length - 2) + "",
                                                nt: Le
                                            }
                                        }(J), ce = function(pe) {
                                            var ue = C[M()]().join("");
                                            return pe && ue.indexOf(pe) === 0 && pe.length === ue.length
                                        }(J), (X || ce) && (X && w <= X.qn && X.nt === J.split(c[0])[4] || ce || X.$n) || !1)
                                    })
                                });
                                var c = ["-"],
                                    p = "2023-4-29".split("-"),
                                    w = new Date(p[0], p[1], p[2]),
                                    C = ["se", "licen", "-", "v3", "l", "gp"];

                                function M() {
                                    return [
                                        ["re", "verse"].join("")
                                    ][0]
                                }

                                function F(J) {
                                    return J ? isNaN(J) ? J.charCodeAt(0) - 72 : J : ""
                                }

                                function z(J) {
                                    var X = 72 + J;
                                    return X > 90 && X < 97 && (X += 15), String.fromCharCode(X).toUpperCase()
                                }
                            }(), E.setKeyboardScrolling = T0, E.shared.tt = P0, E.setAllowScrolling = mf;
                        var cw = {};

                        function Qi() {
                            return cw
                        }
                        var Jl, nr, b0, vf, ea = !T(ke, St("OHNsd3AtZnVsbHBhZ2UtanM5T20="));

                        function M0(c) {
                            if (nr = d.createElement("div"), Jl = St("MTIzPGRpdj48YSBocmVmPSJodHRwOi8vYWx2YXJvdHJpZ28uY29tL2Z1bGxQYWdlL2V4dGVuc2lvbnMvIiBzdHlsZT0iY29sb3I6ICNmZmYgIWltcG9ydGFudDsgdGV4dC1kZWNvcmF0aW9uOm5vbmUgIWltcG9ydGFudDsiPlVubGljZW5zZWQgZnVsbFBhZ2UuanMgRXh0ZW5zaW9uPC9hPjwvZGl2PjEyMw=="), ea || (Jl = Jl.replace("extensions/", "").replace("Extension", "")), nr.innerHTML = Jl, nr = nr.firstChild, "MutationObserver" in window && new MutationObserver(fw).observe(d.body, {
                                    childList: !0,
                                    subtree: !1
                                }), (!ea || De(c) && E[c]) && (! function(w) {
                                    var C = Qi()[w] !== void 0 && Qi()[w].length,
                                        M = [],
                                        F = !1;
                                    return ie(Qi()[w]) ? M = Qi()[w] : M.push(Qi()[w]), M.forEach(function(z) {
                                        var J = function() {
                                                if (d.domain.length) {
                                                    for (var un = d.domain.replace(/^(www\.)/, "").split("."); un.length > 2;) un.shift();
                                                    return un.join(".").replace(/(^\.*)|(\.*$)/g, "")
                                                }
                                                return ""
                                            }(),
                                            X = ["MTM0bG9jYWxob3N0MjM0", "MTM0MC4xMjM0", "MTM0anNoZWxsLm5ldDIzNA==", "UDdDQU5ZNlNN", "NTY3YnVuZGxlNzg5", "NTU1S2V5Nzc3", "NDU2dGVzdDQ1Ng=="],
                                            ce = St(X[0]),
                                            pe = St(X[1]),
                                            ue = St(X[2]),
                                            _e = St(X[6]),
                                            we = St(X[3]),
                                            st = St(X[4]),
                                            Je = St(X[5]),
                                            Le = k()[st + Je] !== void 0;
                                        C = C || Le;
                                        var Ne = [ce, pe, ue, _e].indexOf(J) < 0 && J.length !== 0;
                                        if (!C && !Le && Ne) return !1;
                                        var me = C ? St(z) : "",
                                            lt = (me = me.split("_")).length > 1 && me[1].indexOf(w, me[1].length - w.length) > -1,
                                            ft = me.length > 1 && me[1].toLowerCase().indexOf(st) > -1,
                                            rr = me[0].indexOf(J, me[0].length - J.length) < 0,
                                            zt = lt || ft;
                                        F = F || !(rr && Ne && we != me[0]) && zt || !Ne
                                    }), F
                                }(c) || !ea)) {
                                O0();
                                var p = St("MzQ1c2V0SW50ZXJ2YWwxMjM=");
                                window[p](O0, 2e3)
                            }
                        }

                        function O0() {
                            nr && (vf || (Math.random() < .5 ? Pm(ke, nr) : U(nr, ke), vf = !0), nr.setAttribute("style", St("MTIzei1pbmRleDo5OTk5OTk5O3Bvc2l0aW9uOmZpeGVkO3RvcDoyMHB4O2JvdHRvbTphdXRvO2xlZnQ6MjBweDtyaWdodDphdXRvO2JhY2tncm91bmQ6cmVkO3BhZGRpbmc6N3B4IDE1cHg7Zm9udC1zaXplOjE0cHg7Zm9udC1mYW1pbHk6YXJpYWw7Y29sb3I6I2ZmZjtkaXNwbGF5OmlubGluZS1ibG9jazt0cmFuc2Zvcm06dHJhbnNsYXRlM2QoMCwwLDApO29wYWNpdHk6MTtoZWlnaHQ6YXV0bzt3aWR0aDphdXRvO3pvb206MTttYXJnaW46YXV0bztib3JkZXI6bm9uZTt2aXNpYmlsaXR5OnZpc2libGU7Y2xpcC1wYXRoOm5vbmU7MTIz").replace(/;/g, St("MTIzICFpbXBvcnRhbnQ7MzQ1"))))
                        }

                        function fw(c) {
                            c.forEach(function(p) {
                                if (p.removedNodes[0] && p.removedNodes[0].isEqualNode(nr)) {
                                    clearTimeout(b0);
                                    var w = St("bDIwc2V0VGltZW91dDAzbA==");
                                    b0 = window[w](dw, 900)
                                }
                            })
                        }

                        function dw() {
                            vf = !1
                        }

                        function pw() {
                            Ul(), Fn(), k().scrollBar = k().scrollBar || k().hybrid, Em(),
                                function() {
                                    N(rm(re(), "body"), {
                                        height: "100%",
                                        position: "relative"
                                    }), D(re(), lc), D(Jo, Pl), Z({
                                        q: L()
                                    }), V(re(), uc), Zm(), se("parallax", "init");
                                    for (var c = Y().an, p = 0; p < c.length; p++) {
                                        var w = c[p],
                                            C = w.wn,
                                            M = Re(w.item, "style");
                                        M && w.item.setAttribute("data-fp-styles", M), jc(w), uw(w), C.length > 0 && Hc(w)
                                    }
                                    k().fixedElements && k().css3 && x(k().fixedElements).forEach(function(F) {
                                        ke.appendChild(F)
                                    }), k().navigation && Um(), x('iframe[src*="youtube.com/embed/"]', re()).forEach(function(F) {
                                        var z, J;
                                        J = Re(z = F, "src"), z.setAttribute("src", J + (/\?/.test(J) ? "&" : "?") + "enablejsapi=1")
                                    }), se("fadingEffect", "apply"), se("waterEffect", "init"), se("dropEffect", "init"), se("cards", "init"), k().scrollOverflow && ae.bn()
                                }(), mf(!0), us(!0), Wi(k().autoScrolling, "internal"), Gm(), Rm(), d.readyState === "complete" && k0(), Jn("load", k0), P0(), ea || M0("l"), Ul(), Fn()
                        }

                        function L0() {
                            var c = k().licenseKey;
                            k().licenseKey.trim() === "" ? (m("error", "Fullpage.js requires a `licenseKey` option. Read about it on the following URL:"), m("error", "https://github.com/alvarotrigo/fullPage.js#options")) : k() && $.Kn || d.domain.indexOf("alvarotrigo.com") > -1 ? c && c.length : (m("error", "Incorrect `licenseKey`. Get one for fullPage.js version 4 here:"), m("error", "https://alvarotrigo.com/fullPage/pricing")), T(Jo, Pl) ? m("error", "Fullpage.js can only be initialized once and you are doing it multiple times!") : (k().continuousVertical && (k().loopTop || k().loopBottom) && (k().continuousVertical = !1, m("warn", "Option `loopTop/loopBottom` is mutually exclusive with `continuousVertical`; `continuousVertical` disabled")), !k().scrollOverflow || !k().scrollBar && k().autoScrolling || m("warn", "Options scrollBar:true and autoScrolling:false are mutually exclusive with scrollOverflow:true. Sections with scrollOverflow might not work well in Firefox"), !k().continuousVertical || !k().scrollBar && k().autoScrolling || (k().continuousVertical = !1, m("warn", "Scroll bars (`scrollBar:true` or `autoScrolling:false`) are mutually exclusive with `continuousVertical`; `continuousVertical` disabled")), k().anchors.forEach(function(p) {
                                var w = [].slice.call(x("[name]")).filter(function(F) {
                                        return Re(F, "name") && Re(F, "name").toLowerCase() == p.toLowerCase()
                                    }),
                                    C = [].slice.call(x("[id]")).filter(function(F) {
                                        return Re(F, "id") && Re(F, "id").toLowerCase() == p.toLowerCase()
                                    });
                                if (C.length || w.length) {
                                    m("error", "data-anchor tags can not have the same value as any `id` element on the site (or `name` element for IE).");
                                    var M = C.length ? "id" : "name";
                                    (C.length || w.length) && m("error", '"' + p + '" is is being used by another element `' + M + "` property")
                                }
                            }))
                        }

                        function hw() {
                            return {
                                options: k(),
                                internals: {
                                    container: re(),
                                    canScroll: $.canScroll,
                                    isScrollAllowed: ot(),
                                    getDestinationPosition: Hm,
                                    isTouch: _,
                                    c: M0,
                                    getXmovement: jm,
                                    removeAnimation: Rl,
                                    getTransforms: Ec,
                                    lazyLoad: Hi,
                                    addAnimation: wc,
                                    performHorizontalMove: Bm,
                                    landscapeScroll: pi,
                                    silentLandscapeScroll: es,
                                    keepSlidesPosition: Oc,
                                    silentScroll: fi,
                                    styleSlides: Hc,
                                    styleSection: jc,
                                    scrollHandler: Zl,
                                    getEventsPage: Qc,
                                    getMSPointer: u0,
                                    isReallyTouch: ls,
                                    usingExtension: De,
                                    toggleControlArrows: Fm,
                                    touchStartHandler: Kl,
                                    touchMoveHandler: ss,
                                    nullOrSection: Pr,
                                    items: {
                                        SectionPanel: hi,
                                        SlidePanel: $l,
                                        Item: Pn
                                    },
                                    getVisible: S,
                                    getState: Y,
                                    updateState: Fn,
                                    updateStructuralState: Ul,
                                    activeSlidesNavigation: Im,
                                    getPanels: function() {
                                        return $.un
                                    },
                                    getSections: function() {
                                        return $.N
                                    },
                                    setActiveSection: function(c) {
                                        $.P = c
                                    }
                                }
                            }
                        }

                        function qt(c) {
                            var p = ["NTY3YnVuZGxlNzg5", "NTU1S2V5Nzc3"],
                                w = St(p[0]),
                                C = St(p[1]),
                                M = k()[w + C] !== void 0,
                                F = "fp_" + c + "Extension";
                            Qi()[c] = M ? k()[w + C] : k()[c + C], E[c] = window[F] !== void 0 ? new window[F] : null, E[c] && E[c].c(c)
                        }

                        function N0(c, p) {
                            var w;
                            if (ke = x("body")[0], Jo = x("html")[0], Dl = x("html, body"), !T(Jo, Pl)) return w = typeof c == "string" ? x(c)[0] : c, Ol.touchWrapper = w,
                                function(C) {
                                    Ll = P({}, Ol, C), gc = Object.assign({}, Ll)
                                }(p),
                                function(C) {
                                    Ko = C
                                }(typeof c == "string" ? x(c)[0] : c), K.L(om), L0(), E.getFullpageData = hw, E.version = "4.0.20", E.test = Object.assign(E.test, {
                                    top: "0px",
                                    cn: "translate3d(0px, 0px, 0px)",
                                    dn: function() {
                                        for (var C = [], M = 0; M < x(k().sectionSelector, re()).length; M++) C.push("translate3d(0px, 0px, 0px)");
                                        return C
                                    }(),
                                    left: function() {
                                        for (var C = [], M = 0; M < x(k().sectionSelector, re()).length; M++) C.push(0);
                                        return C
                                    }(),
                                    options: k(),
                                    setAutoScrolling: null
                                }), E.shared = Object.assign(E.shared, {
                                    tt: null,
                                    _n: !1
                                }), f.fullpage_api = E, f.fullpage_extensions = !0, re() && (K.L("beforeInit"), qt("continuousHorizontal"), qt("scrollHorizontally"), qt("resetSliders"), qt("interlockedSlides"), qt("responsiveSlides"), qt("fadingEffect"), qt("dragAndMove"), qt("offsetSections"), qt("scrollOverflowReset"), qt("parallax"), qt("cards"), qt("dropEffect"), qt("waterEffect"), se("dragAndMove", "init"), se("responsiveSlides", "init"), pw(), K.L(bt), se("dragAndMove", "turnOffTouch")), f.fullpage_api;
                            L0()
                        }
                        return E.destroy = function(c) {
                            _t(re(), "destroy", c), Wi(!1, "internal"), mf(!0), us(!1), T0(!1), D(re(), uc), K.L(Tn), se("dragAndMove", "destroy"), c && (fi(0), x("img[data-src], source[data-src], audio[data-src], iframe[data-src]", re()).forEach(function(p) {
                                El(p, "src")
                            }), x("img[data-srcset]").forEach(function(p) {
                                El(p, "srcset")
                            }), li(x("#fp-nav, .fp-slidesNav, .fp-controlArrow")), N(_c(Y().N), {
                                height: "",
                                "background-color": "",
                                padding: ""
                            }), N(_c(Y().slides), {
                                width: ""
                            }), N(re(), {
                                height: "",
                                position: "",
                                "-ms-touch-action": "",
                                "touch-action": ""
                            }), N(Dl, {
                                overflow: "",
                                height: ""
                            }), V(Jo, Pl), V(ke, Tl + " fp-scrollable"), ke.className.split(/\s+/).forEach(function(p) {
                                p.indexOf("fp-viewing") === 0 && V(ke, p)
                            }), _c(Y().un).forEach(function(p) {
                                k().scrollOverflow && ae.Nn(p), V(p, "fp-table active fp-completely " + qo);
                                var w = Re(p, "data-fp-styles");
                                w && p.setAttribute("style", w), T(p, kl) && !xm && p.removeAttribute("data-anchor")
                            }), Rl(re()), [jS, Yo, tr].forEach(function(p) {
                                x(p, re()).forEach(function(w) {
                                    fe(w)
                                })
                            }), N(re(), {
                                "-webkit-transition": "none",
                                transition: "none"
                            }), V(re(), lc), f.scrollTo(0, 0), [kl, fc, pc].forEach(function(p) {
                                V(x("." + p), p)
                            }))
                        }, f.fp_easings = P(f.fp_easings, {
                            easeInOutCubic: function(c, p, w, C) {
                                return (c /= C / 2) < 1 ? w / 2 * c * c * c + p : w / 2 * ((c -= 2) * c * c + 2) + p
                            }
                        }), f.jQuery && function(c, p) {
                            c && p ? c.fn.fullpage = function(w) {
                                w = c.extend({}, w, {
                                    $: c
                                }), new p(this[0], w), Object.keys(E).forEach(function(C) {
                                    k().$.fn.fullpage[C] = E[C]
                                })
                            } : m("error", "jQuery is required to use the jQuery fullpage adapter!")
                        }(f.jQuery, N0), N0
                    })
                },
                239: () => {
                    window.fp_easings = {
                        def: "easeOutQuad",
                        linear: function(o, s, l, a) {
                            return l * o / a + s
                        },
                        swing: function(o, s, l, a) {
                            return window.fp_easings[window.fp_easings.def](o, s, l, a)
                        },
                        easeInQuad: function(o, s, l, a) {
                            return l * (o /= a) * o + s
                        },
                        easeOutQuad: function(o, s, l, a) {
                            return -l * (o /= a) * (o - 2) + s
                        },
                        easeInOutQuad: function(o, s, l, a) {
                            return (o /= a / 2) < 1 ? l / 2 * o * o + s : -l / 2 * (--o * (o - 2) - 1) + s
                        },
                        easeInCubic: function(o, s, l, a) {
                            return l * (o /= a) * o * o + s
                        },
                        easeOutCubic: function(o, s, l, a) {
                            return l * ((o = o / a - 1) * o * o + 1) + s
                        },
                        easeInOutCubic: function(o, s, l, a) {
                            return (o /= a / 2) < 1 ? l / 2 * o * o * o + s : l / 2 * ((o -= 2) * o * o + 2) + s
                        },
                        easeInQuart: function(o, s, l, a) {
                            return l * (o /= a) * o * o * o + s
                        },
                        easeOutQuart: function(o, s, l, a) {
                            return -l * ((o = o / a - 1) * o * o * o - 1) + s
                        },
                        easeInOutQuart: function(o, s, l, a) {
                            return (o /= a / 2) < 1 ? l / 2 * o * o * o * o + s : -l / 2 * ((o -= 2) * o * o * o - 2) + s
                        },
                        easeInQuint: function(o, s, l, a) {
                            return l * (o /= a) * o * o * o * o + s
                        },
                        easeOutQuint: function(o, s, l, a) {
                            return l * ((o = o / a - 1) * o * o * o * o + 1) + s
                        },
                        easeInOutQuint: function(o, s, l, a) {
                            return (o /= a / 2) < 1 ? l / 2 * o * o * o * o * o + s : l / 2 * ((o -= 2) * o * o * o * o + 2) + s
                        },
                        easeInSine: function(o, s, l, a) {
                            return -l * Math.cos(o / a * (Math.PI / 2)) + l + s
                        },
                        easeOutSine: function(o, s, l, a) {
                            return l * Math.sin(o / a * (Math.PI / 2)) + s
                        },
                        easeInOutSine: function(o, s, l, a) {
                            return -l / 2 * (Math.cos(Math.PI * o / a) - 1) + s
                        },
                        easeInExpo: function(o, s, l, a) {
                            return o == 0 ? s : l * Math.pow(2, 10 * (o / a - 1)) + s
                        },
                        easeOutExpo: function(o, s, l, a) {
                            return o == a ? s + l : l * (1 - Math.pow(2, -10 * o / a)) + s
                        },
                        easeInOutExpo: function(o, s, l, a) {
                            return o == 0 ? s : o == a ? s + l : (o /= a / 2) < 1 ? l / 2 * Math.pow(2, 10 * (o - 1)) + s : l / 2 * (2 - Math.pow(2, -10 * --o)) + s
                        },
                        easeInCirc: function(o, s, l, a) {
                            return -l * (Math.sqrt(1 - (o /= a) * o) - 1) + s
                        },
                        easeOutCirc: function(o, s, l, a) {
                            return l * Math.sqrt(1 - (o = o / a - 1) * o) + s
                        },
                        easeInOutCirc: function(o, s, l, a) {
                            return (o /= a / 2) < 1 ? -l / 2 * (Math.sqrt(1 - o * o) - 1) + s : l / 2 * (Math.sqrt(1 - (o -= 2) * o) + 1) + s
                        },
                        easeInElastic: function(o, s, l, a) {
                            var u = 1.70158,
                                f = 0,
                                d = l;
                            return o == 0 ? s : (o /= a) == 1 ? s + l : (f || (f = .3 * a), d < Math.abs(l) ? (d = l, u = f / 4) : u = f / (2 * Math.PI) * Math.asin(l / d), -d * Math.pow(2, 10 * (o -= 1)) * Math.sin((o * a - u) * (2 * Math.PI) / f) + s)
                        },
                        easeOutElastic: function(o, s, l, a) {
                            var u = 1.70158,
                                f = 0,
                                d = l;
                            return o == 0 ? s : (o /= a) == 1 ? s + l : (f || (f = .3 * a), d < Math.abs(l) ? (d = l, u = f / 4) : u = f / (2 * Math.PI) * Math.asin(l / d), d * Math.pow(2, -10 * o) * Math.sin((o * a - u) * (2 * Math.PI) / f) + l + s)
                        },
                        easeInOutElastic: function(o, s, l, a) {
                            var u = 1.70158,
                                f = 0,
                                d = l;
                            return o == 0 ? s : (o /= a / 2) == 2 ? s + l : (f || (f = a * .44999999999999996), d < Math.abs(l) ? (d = l, u = f / 4) : u = f / (2 * Math.PI) * Math.asin(l / d), o < 1 ? d * Math.pow(2, 10 * (o -= 1)) * Math.sin((o * a - u) * (2 * Math.PI) / f) * -.5 + s : d * Math.pow(2, -10 * (o -= 1)) * Math.sin((o * a - u) * (2 * Math.PI) / f) * .5 + l + s)
                        },
                        easeInBack: function(o, s, l, a, u) {
                            return u == null && (u = 1.70158), l * (o /= a) * o * ((u + 1) * o - u) + s
                        },
                        easeOutBack: function(o, s, l, a, u) {
                            return u == null && (u = 1.70158), l * ((o = o / a - 1) * o * ((u + 1) * o + u) + 1) + s
                        },
                        easeInOutBack: function(o, s, l, a, u) {
                            return u == null && (u = 1.70158), (o /= a / 2) < 1 ? l / 2 * (o * o * ((1 + (u *= 1.525)) * o - u)) + s : l / 2 * ((o -= 2) * o * ((1 + (u *= 1.525)) * o + u) + 2) + s
                        },
                        easeInBounce: function(o, s, l, a) {
                            return l - window.fp_easings.easeOutBounce(a - o, 0, l, a) + s
                        },
                        easeOutBounce: function(o, s, l, a) {
                            return (o /= a) < .36363636363636365 ? l * (7.5625 * o * o) + s : o < .7272727272727273 ? l * (7.5625 * (o -= .5454545454545454) * o + .75) + s : o < .9090909090909091 ? l * (7.5625 * (o -= .8181818181818182) * o + .9375) + s : l * (7.5625 * (o -= .9545454545454546) * o + .984375) + s
                        },
                        easeInOutBounce: function(o, s, l, a) {
                            return o < a / 2 ? .5 * window.fp_easings.easeInBounce(2 * o, 0, l, a) + s : .5 * window.fp_easings.easeOutBounce(2 * o - a, 0, l, a) + .5 * l + s
                        }
                    }
                },
                379: o => {
                    var s = [];

                    function l(f) {
                        for (var d = -1, h = 0; h < s.length; h++)
                            if (s[h].identifier === f) {
                                d = h;
                                break
                            }
                        return d
                    }

                    function a(f, d) {
                        for (var h = {}, y = [], _ = 0; _ < f.length; _++) {
                            var v = f[_],
                                E = d.base ? v[0] + d.base : v[0],
                                m = h[E] || 0,
                                g = "".concat(E, " ").concat(m);
                            h[E] = m + 1;
                            var S = l(g),
                                x = {
                                    css: v[1],
                                    media: v[2],
                                    sourceMap: v[3]
                                };
                            S !== -1 ? (s[S].references++, s[S].updater(x)) : s.push({
                                identifier: g,
                                updater: u(x, d),
                                references: 1
                            }), y.push(g)
                        }
                        return y
                    }

                    function u(f, d) {
                        var h = d.domAPI(d);
                        return h.update(f),
                            function(_) {
                                if (_) {
                                    if (_.css === f.css && _.media === f.media && _.sourceMap === f.sourceMap) return;
                                    h.update(f = _)
                                } else h.remove()
                            }
                    }
                    o.exports = function(f, d) {
                        d = d || {}, f = f || [];
                        var h = a(f, d);
                        return function(_) {
                            _ = _ || [];
                            for (var v = 0; v < h.length; v++) {
                                var E = h[v],
                                    m = l(E);
                                s[m].references--
                            }
                            for (var g = a(_, d), S = 0; S < h.length; S++) {
                                var x = h[S],
                                    P = l(x);
                                s[P].references === 0 && (s[P].updater(), s.splice(P, 1))
                            }
                            h = g
                        }
                    }
                },
                569: o => {
                    var s = {};

                    function l(u) {
                        if (typeof s[u] > "u") {
                            var f = document.querySelector(u);
                            if (window.HTMLIFrameElement && f instanceof window.HTMLIFrameElement) try {
                                f = f.contentDocument.head
                            } catch {
                                f = null
                            }
                            s[u] = f
                        }
                        return s[u]
                    }

                    function a(u, f) {
                        var d = l(u);
                        if (!d) throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
                        d.appendChild(f)
                    }
                    o.exports = a
                },
                216: o => {
                    function s(l) {
                        var a = document.createElement("style");
                        return l.setAttributes(a, l.attributes), l.insert(a), a
                    }
                    o.exports = s
                },
                565: (o, s, l) => {
                    function a(u) {
                        var f = l.nc;
                        f && u.setAttribute("nonce", f)
                    }
                    o.exports = a
                },
                795: o => {
                    function s(u, f, d) {
                        var h = d.css,
                            y = d.media,
                            _ = d.sourceMap;
                        y ? u.setAttribute("media", y) : u.removeAttribute("media"), _ && typeof btoa < "u" && (h += `
/*# sourceMappingURL=data:application/json;base64,`.concat(btoa(unescape(encodeURIComponent(JSON.stringify(_)))), " */")), f.styleTagTransform(h, u)
                    }

                    function l(u) {
                        if (u.parentNode === null) return !1;
                        u.parentNode.removeChild(u)
                    }

                    function a(u) {
                        var f = u.insertStyleElement(u);
                        return {
                            update: function(h) {
                                s(f, u, h)
                            },
                            remove: function() {
                                l(f)
                            }
                        }
                    }
                    o.exports = a
                },
                589: o => {
                    function s(l, a) {
                        if (a.styleSheet) a.styleSheet.cssText = l;
                        else {
                            for (; a.firstChild;) a.removeChild(a.firstChild);
                            a.appendChild(document.createTextNode(l))
                        }
                    }
                    o.exports = s
                },
                497: o => {
                    o.exports = R
                }
            },
            n = {};

        function r(o) {
            var s = n[o];
            if (s !== void 0) return s.exports;
            var l = n[o] = {
                id: o,
                exports: {}
            };
            return t[o].call(l.exports, l, l.exports, r), l.exports
        }
        r.n = o => {
            var s = o && o.__esModule ? () => o.default : () => o;
            return r.d(s, {
                a: s
            }), s
        }, r.d = (o, s) => {
            for (var l in s) r.o(s, l) && !r.o(o, l) && Object.defineProperty(o, l, {
                enumerable: !0,
                get: s[l]
            })
        }, r.o = (o, s) => Object.prototype.hasOwnProperty.call(o, s), r.r = o => {
            typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(o, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(o, "__esModule", {
                value: !0
            })
        };
        var i = {};
        (() => {
            r.r(i), r.d(i, {
                default: () => f
            });
            var o = r(497),
                s = r.n(o);
            const a = d => {
                    let {
                        children: h
                    } = d;
                    return s().createElement(o.Fragment, null, h)
                },
                u = () => {
                    if (typeof window > "u") return !1;
                    try {
                        return !"production".toLowerCase().match(/test/)
                    } catch {
                        return !0
                    }
                },
                f = (() => {
                    let d;
                    return u() ? d = r(88).Z : d = r(882).Z, d.Wrapper = a, d
                })()
        })(), e.exports = i
    })()
})(zS);
var j8 = zS.exports;
const L1 = N1(j8);
/*!
 * Cuberto Mouse Follower
 * https://cuberto.com/
 *
 * @version 1.1.2
 * @author Cuberto, Artem Dordzhiev (Draft)
 */
var IS = function() {
    e.registerGSAP = function(r) {
        e.gsap = r
    };

    function e(n) {
        n === void 0 && (n = {}), this.options = Object.assign({}, {
            el: null,
            container: document.body,
            className: "mf-cursor",
            innerClassName: "mf-cursor-inner",
            textClassName: "mf-cursor-text",
            mediaClassName: "mf-cursor-media",
            mediaBoxClassName: "mf-cursor-media-box",
            iconSvgClassName: "mf-svgsprite",
            iconSvgNamePrefix: "-",
            iconSvgSrc: "",
            dataAttr: "cursor",
            hiddenState: "-hidden",
            textState: "-text",
            iconState: "-icon",
            activeState: "-active",
            mediaState: "-media",
            stateDetection: {
                "-pointer": "a,button"
            },
            visible: !0,
            visibleOnState: !1,
            speed: .55,
            ease: "expo.out",
            overwrite: !0,
            skewing: 0,
            skewingText: 2,
            skewingIcon: 2,
            skewingMedia: 2,
            skewingDelta: .001,
            skewingDeltaMax: .15,
            stickDelta: .15,
            showTimeout: 0,
            hideOnLeave: !0,
            hideTimeout: 300,
            hideMediaTimeout: 300,
            initialPos: [-window.innerWidth, -window.innerHeight]
        }, n), this.options.visible && n.stateDetection == null && (this.options.stateDetection["-hidden"] = "iframe"), this.gsap = e.gsap || window.gsap, this.el = typeof this.options.el == "string" ? document.querySelector(this.options.el) : this.options.el, this.container = typeof this.options.container == "string" ? document.querySelector(this.options.container) : this.options.container, this.skewing = this.options.skewing, this.pos = {
            x: this.options.initialPos[0],
            y: this.options.initialPos[1]
        }, this.vel = {
            x: 0,
            y: 0
        }, this.event = {}, this.events = [], this.init()
    }
    var t = e.prototype;
    return t.init = function() {
        this.el || this.create(), this.createSetter(), this.bind(), this.render(!0), this.ticker = this.render.bind(this, !1), this.gsap.ticker.add(this.ticker)
    }, t.create = function() {
        this.el = document.createElement("div"), this.el.className = this.options.className, this.el.classList.add(this.options.hiddenState), this.inner = document.createElement("div"), this.inner.className = this.options.innerClassName, this.text = document.createElement("div"), this.text.className = this.options.textClassName, this.media = document.createElement("div"), this.media.className = this.options.mediaClassName, this.mediaBox = document.createElement("div"), this.mediaBox.className = this.options.mediaBoxClassName, this.media.appendChild(this.mediaBox), this.inner.appendChild(this.media), this.inner.appendChild(this.text), this.el.appendChild(this.inner), this.container.appendChild(this.el)
    }, t.createSetter = function() {
        this.setter = {
            x: this.gsap.quickSetter(this.el, "x", "px"),
            y: this.gsap.quickSetter(this.el, "y", "px"),
            rotation: this.gsap.quickSetter(this.el, "rotation", "deg"),
            scaleX: this.gsap.quickSetter(this.el, "scaleX"),
            scaleY: this.gsap.quickSetter(this.el, "scaleY"),
            wc: this.gsap.quickSetter(this.el, "willChange"),
            inner: {
                rotation: this.gsap.quickSetter(this.inner, "rotation", "deg")
            }
        }
    }, t.bind = function() {
        var r = this;
        this.event.mouseleave = function() {
            return r.hide()
        }, this.event.mouseenter = function() {
            return r.show()
        }, this.event.mousedown = function() {
            return r.addState(r.options.activeState)
        }, this.event.mouseup = function() {
            return r.removeState(r.options.activeState)
        }, this.event.mousemoveOnce = function() {
            return r.show()
        }, this.event.mousemove = function(i) {
            r.gsap.to(r.pos, {
                x: r.stick ? r.stick.x - (r.stick.x - i.clientX) * r.options.stickDelta : i.clientX,
                y: r.stick ? r.stick.y - (r.stick.y - i.clientY) * r.options.stickDelta : i.clientY,
                overwrite: r.options.overwrite,
                ease: r.options.ease,
                duration: r.visible ? r.options.speed : 0,
                onUpdate: function() {
                    return r.vel = {
                        x: i.clientX - r.pos.x,
                        y: i.clientY - r.pos.y
                    }
                }
            })
        }, this.event.mouseover = function(i) {
            for (var o = i.target; o && o !== r.container && !(i.relatedTarget && o.contains(i.relatedTarget)); o = o.parentNode) {
                for (var s in r.options.stateDetection) o.matches(r.options.stateDetection[s]) && r.addState(s);
                if (r.options.dataAttr) {
                    var l = r.getFromDataset(o);
                    l.state && r.addState(l.state), l.text && r.setText(l.text), l.icon && r.setIcon(l.icon), l.img && r.setImg(l.img), l.video && r.setVideo(l.video), typeof l.show < "u" && r.show(), typeof l.stick < "u" && r.setStick(l.stick || o)
                }
            }
        }, this.event.mouseout = function(i) {
            for (var o = i.target; o && o !== r.container && !(i.relatedTarget && o.contains(i.relatedTarget)); o = o.parentNode) {
                for (var s in r.options.stateDetection) o.matches(r.options.stateDetection[s]) && r.removeState(s);
                if (r.options.dataAttr) {
                    var l = r.getFromDataset(o);
                    l.state && r.removeState(l.state), l.text && r.removeText(), l.icon && r.removeIcon(), l.img && r.removeImg(), l.video && r.removeVideo(), typeof l.show < "u" && r.hide(), typeof l.stick < "u" && r.removeStick()
                }
            }
        }, this.options.hideOnLeave && this.container.addEventListener("mouseleave", this.event.mouseleave, {
            passive: !0
        }), this.options.visible && this.container.addEventListener("mouseenter", this.event.mouseenter, {
            passive: !0
        }), this.options.activeState && (this.container.addEventListener("mousedown", this.event.mousedown, {
            passive: !0
        }), this.container.addEventListener("mouseup", this.event.mouseup, {
            passive: !0
        })), this.container.addEventListener("mousemove", this.event.mousemove, {
            passive: !0
        }), this.options.visible && this.container.addEventListener("mousemove", this.event.mousemoveOnce, {
            passive: !0,
            once: !0
        }), (this.options.stateDetection || this.options.dataAttr) && (this.container.addEventListener("mouseover", this.event.mouseover, {
            passive: !0
        }), this.container.addEventListener("mouseout", this.event.mouseout, {
            passive: !0
        }))
    }, t.render = function(r) {
        if (r !== !0 && (this.vel.y === 0 || this.vel.x === 0)) {
            this.setter.wc("auto");
            return
        }
        if (this.trigger("render"), this.setter.wc("transform"), this.setter.x(this.pos.x), this.setter.y(this.pos.y), this.skewing) {
            var i = Math.sqrt(Math.pow(this.vel.x, 2) + Math.pow(this.vel.y, 2)),
                o = Math.min(i * this.options.skewingDelta, this.options.skewingDeltaMax) * this.skewing,
                s = Math.atan2(this.vel.y, this.vel.x) * 180 / Math.PI;
            this.setter.rotation(s), this.setter.scaleX(1 + o), this.setter.scaleY(1 - o), this.setter.inner.rotation(-s)
        }
    }, t.show = function() {
        var r = this;
        this.trigger("show"), clearInterval(this.visibleInt), this.visibleInt = setTimeout(function() {
            r.el.classList.remove(r.options.hiddenState), r.visible = !0, r.render(!0)
        }, this.options.showTimeout)
    }, t.hide = function() {
        var r = this;
        this.trigger("hide"), clearInterval(this.visibleInt), this.el.classList.add(this.options.hiddenState), this.visibleInt = setTimeout(function() {
            return r.visible = !1
        }, this.options.hideTimeout)
    }, t.toggle = function(r) {
        r === !0 || r !== !1 && !this.visible ? this.show() : this.hide()
    }, t.addState = function(r) {
        var i;
        if (this.trigger("addState", r), r === this.options.hiddenState) return this.hide();
        (i = this.el.classList).add.apply(i, r.split(" ")), this.options.visibleOnState && this.show()
    }, t.removeState = function(r) {
        var i;
        if (this.trigger("removeState", r), r === this.options.hiddenState) return this.show();
        (i = this.el.classList).remove.apply(i, r.split(" ")), this.options.visibleOnState && this.el.className === this.options.className && this.hide()
    }, t.toggleState = function(r, i) {
        i === !0 || i !== !1 && !this.el.classList.contains(r) ? this.addState(r) : this.removeState(r)
    }, t.setSkewing = function(r) {
        this.gsap.to(this, {
            skewing: r
        })
    }, t.removeSkewing = function() {
        this.gsap.to(this, {
            skewing: this.options.skewing
        })
    }, t.setStick = function(r) {
        var i = typeof r == "string" ? document.querySelector(r) : r,
            o = i.getBoundingClientRect();
        this.stick = {
            y: o.top + o.height / 2,
            x: o.left + o.width / 2
        }
    }, t.removeStick = function() {
        this.stick = !1
    }, t.setText = function(r) {
        this.text.innerHTML = r, this.addState(this.options.textState), this.setSkewing(this.options.skewingText)
    }, t.removeText = function() {
        this.removeState(this.options.textState), this.removeSkewing()
    }, t.setIcon = function(r, i) {
        i === void 0 && (i = ""), this.text.innerHTML = "<svg class='" + this.options.iconSvgClassName + " " + this.options.iconSvgNamePrefix + r + "'" + (" style='" + i + "'><use xlink:href='" + this.options.iconSvgSrc + "#" + r + "'></use></svg>"), this.addState(this.options.iconState), this.setSkewing(this.options.skewingIcon)
    }, t.removeIcon = function() {
        this.removeState(this.options.iconState), this.removeSkewing()
    }, t.setMedia = function(r) {
        var i = this;
        clearTimeout(this.mediaInt), r && (this.mediaBox.innerHTML = "", this.mediaBox.appendChild(r)), this.mediaInt = setTimeout(function() {
            return i.addState(i.options.mediaState)
        }, 20), this.setSkewing(this.options.skewingMedia)
    }, t.removeMedia = function() {
        var r = this;
        clearTimeout(this.mediaInt), this.removeState(this.options.mediaState), this.mediaInt = setTimeout(function() {
            return r.mediaBox.innerHTML = ""
        }, this.options.hideMediaTimeout), this.removeSkewing()
    }, t.setImg = function(r) {
        this.mediaImg || (this.mediaImg = new Image), this.mediaImg.src !== r && (this.mediaImg.src = r), this.setMedia(this.mediaImg)
    }, t.removeImg = function() {
        this.removeMedia()
    }, t.setVideo = function(r) {
        this.mediaVideo || (this.mediaVideo = document.createElement("video"), this.mediaVideo.muted = !0, this.mediaVideo.loop = !0, this.mediaVideo.autoplay = !0), this.mediaVideo.src !== r && (this.mediaVideo.src = r, this.mediaVideo.load()), this.mediaVideo.play(), this.setMedia(this.mediaVideo)
    }, t.removeVideo = function() {
        this.mediaVideo && this.mediaVideo.readyState > 2 && this.mediaVideo.pause(), this.removeMedia()
    }, t.on = function(r, i) {
        this.events[r] instanceof Array || this.off(r), this.events[r].push(i)
    }, t.off = function(r, i) {
        i ? this.events[r] = this.events[r].filter(function(o) {
            return o !== i
        }) : this.events[r] = []
    }, t.trigger = function(r) {
        var i = arguments,
            o = this;
        this.events[r] && this.events[r].forEach(function(s) {
            return s.call.apply(s, [o, o].concat([].slice.call(i, 1)))
        })
    }, t.getFromDataset = function(r) {
        var i = r.dataset;
        return {
            state: i[this.options.dataAttr],
            show: i[this.options.dataAttr + "Show"],
            text: i[this.options.dataAttr + "Text"],
            icon: i[this.options.dataAttr + "Icon"],
            img: i[this.options.dataAttr + "Img"],
            video: i[this.options.dataAttr + "Video"],
            stick: i[this.options.dataAttr + "Stick"]
        }
    }, t.destroy = function() {
        this.trigger("destroy"), this.gsap.ticker.remove(this.ticker), this.container.removeEventListener("mouseleave", this.event.mouseleave), this.container.removeEventListener("mouseenter", this.event.mouseenter), this.container.removeEventListener("mousedown", this.event.mousedown), this.container.removeEventListener("mouseup", this.event.mouseup), this.container.removeEventListener("mousemove", this.event.mousemove), this.container.removeEventListener("mousemove", this.event.mousemoveOnce), this.container.removeEventListener("mouseover", this.event.mouseover), this.container.removeEventListener("mouseout", this.event.mouseout), this.el && (this.container.removeChild(this.el), this.el = null, this.mediaImg = null, this.mediaVideo = null)
    }, e
}();
IS.registerGSAP(Lt);
const V8 = () => {
        const e = R.useRef(null);
        return R.useEffect(() => {
            e.current && new IS({
                el: e.current,
                container: document.body,
                speed: .5,
                ease: "expo.out",
                stateDetection: {
                    "-blur-light": ".home-wrapper",
                    "-album": ".album",
                    "-blur": ".stem-video, .record, .home-wrapper"
                }
            })
        }, []), O("div", {
            ref: e,
            className: "cursor",
            children: O("div", {
                className: "element",
                children: O("svg", {
                    width: "16",
                    height: "17",
                    viewBox: "0 0 16 17",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: O("path", {
                        d: "M14.9283 6.97962L15.7417 7.79299C16.0861 8.13739 16.0861 8.6943 15.7417 9.03504L8.62285 16.1575C8.27845 16.5019 7.72155 16.5019 7.38081 16.1575L0.258301 9.03504C-0.0861003 8.69063 -0.0861003 8.13373 0.258301 7.79299L1.07167 6.97962C1.41974 6.63155 1.98763 6.63888 2.32837 6.99428L6.53446 11.4092V0.879322C6.53446 0.392031 6.9265 0 7.41379 0H8.58622C9.07351 0 9.46554 0.392031 9.46554 0.879322V11.4092L13.6716 6.99428C14.0124 6.63522 14.5803 6.62789 14.9283 6.97962Z",
                        fill: "#1E1E1E"
                    })
                })
            })
        })
    },
    U8 = "_menu_zfn5e_1",
    $8 = "_active_zfn5e_19",
    H8 = "_nav_zfn5e_24",
    W8 = "_group_zfn5e_30",
    G8 = "_socials_zfn5e_61",
    xs = {
        menu: U8,
        active: $8,
        nav: H8,
        group: W8,
        socials: G8
    },
    Y8 = () => {
        const {
            menuActive: e,
            setMenuActive: t,
            setAnchorScrolling: n
        } = R.useContext(Dn);
        return oe("menu", {
            className: de(xs.menu, e && xs.active),
            children: [O("nav", {
                className: xs.nav,
                children: O("ul", {
                    children: DS.map((r, i) => O("li", {
                        children: O("a", {
                            onClick: o => {
                                r.scrollLink && (o.preventDefault(), t(!1), setTimeout(() => {
                                    n(!0), window.fullpage_api.moveTo(r.toScreen), r.additionalFunction && r.additionalFunction(), setTimeout(() => n(!1), 1e3)
                                }, 1e3))
                            },
                            href: r.href,
                            children: r.title
                        })
                    }, i))
                })
            }), oe("div", {
                className: de(xs.group),
                children: [O("p", {
                    children: "Where music makes money."
                }), oe("ul", {
                    className: xs.socials,
                    children: [O("li", {
                        children: O("a", {
                            href: "https://www.instagram.com/stem/",
                            children: O("img", {
                                src: "/images/icons/insta.svg",
                                alt: "Instagram"
                            })
                        })
                    }), O("li", {
                        children: O("a", {
                            href: "https://twitter.com/stem?lang=en",
                            children: O("img", {
                                src: "/images/icons/twitter.svg",
                                alt: "Twitter"
                            })
                        })
                    })]
                })]
            })]
        })
    };
Lt.registerPlugin(ScrollTrigger);
const X8 = ({
        children: e
    }) => {
        const {
            setActiveScreen: t,
            setDirection: n,
            menuActive: r,
            activeScreen: i,
            setFullpageInit: o,
            pageLoaded: s,
            anchorScrolling: l,
            articlesProgress: a
        } = R.useContext(Dn);
        return R.useEffect(() => {
            const u = document.querySelectorAll(".section");
            u && Array.from(u).map((f, d) => {
                f.dataset.animated = "false", f.id = `${d}`
            })
        }, []), R.useEffect(() => {
            const u = document.querySelectorAll("section");
            u && Array.from(u).map(f => {
                const d = f.id;
                Number(d) === i && f.dataset.animated === "false" && (f.dataset.animated = "true", f.classList.add("animated"))
            })
        }, [i]), oe(Kn, {
            children: [O(O8, {}), O(B8, {}), window.innerWidth <= 768 && O(Y8, {}), window.innerWidth > 768 && O(V8, {}), O(L1, {
                credits: {
                    enabled: !1
                },
                onLeave: (u, f, d, h) => {
                    if (console.log("updated...."), r || !s || l || f.index === 6 && d === "down" || f.index === 5 && d === "up" && a > 0) return !1;
                    if (f.index === 2 && d === "down") return setTimeout(() => window.fullpage_api.moveTo(4), 0), !1;
                    if (f.index === 2 && d === "up") return setTimeout(() => window.fullpage_api.moveTo(2), 0), !1;
                    t(f.index), n(d)
                },
                easingcss3: "cubic-bezier(0.76, 0, 0.24, 1)",
                licenseKey: "YOUR_KEY_HERE",
                scrollingSpeed: 1250,
                touchSensitivity: .01,
                render: ({
                    state: u,
                    fullpageApi: f
                }) => (o(!0), O(L1.Wrapper, {
                    children: O(Kn, {
                        children: e
                    })
                }))
            })]
        })
    },
    q8 = () => {
        const [e, t] = R.useState(0), [n, r] = R.useState("down"), [i, o] = R.useState(!1), [s, l] = R.useState(!1), [a, u] = R.useState(!1), [f, d] = R.useState(!1), [h, y] = R.useState(!1), [_, v] = R.useState(!1), [E, m] = R.useState(!1), [g, S] = R.useState(0);
        return O(Dn.Provider, {
            value: {
                activeScreen: e,
                setActiveScreen: t,
                direction: n,
                setDirection: r,
                menuActive: i,
                setMenuActive: o,
                videoActive: s,
                setVideoActive: l,
                canScrollAfterDisc: f,
                setCanScrollAfterDisc: d,
                discActive: a,
                setDiscActive: u,
                pageLoaded: h,
                setPageLoaded: y,
                fullpageInit: _,
                setFullpageInit: v,
                anchorScrolling: E,
                setAnchorScrolling: m,
                articlesProgress: g,
                setArticlesProgress: S
            },
            children: O(_8, {
                children: R5.map(x => O(RS, {
                    path: x.path,
                    element: O(X8, {
                        children: x.element
                    })
                }, x.path))
            })
        })
    };
fd.createRoot(document.getElementById("root")).render(O(Ge.StrictMode, {
    children: O(q8, {})
}));